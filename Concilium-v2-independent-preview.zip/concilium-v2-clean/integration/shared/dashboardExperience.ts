export const DASHBOARD_EXPERIENCES = ["operacional", "editorial"] as const;

export type DashboardExperience = (typeof DASHBOARD_EXPERIENCES)[number];

export const DASHBOARD_EXPERIENCE_LABELS: Record<DashboardExperience, string> = {
  operacional: "Operacional",
  editorial: "Editorial",
};

export const DASHBOARD_EXPERIENCE_DESCRIPTIONS: Record<DashboardExperience, string> = {
  operacional: "Mais direto e completo para conduzir casos, documentos e rodadas de negociação.",
  editorial: "Mais visual e contextual para acompanhar o caso com a experiência refinada da V2.",
};

export const DASHBOARD_EXPERIENCE_STORAGE_KEY = "concilium-dashboard-experience";

export function isDashboardExperience(value: unknown): value is DashboardExperience {
  return typeof value === "string" && (DASHBOARD_EXPERIENCES as readonly string[]).includes(value);
}

export function readDashboardExperience(storage: Storage | undefined): DashboardExperience {
  try {
    const value = storage?.getItem(DASHBOARD_EXPERIENCE_STORAGE_KEY);
    return isDashboardExperience(value) ? value : "operacional";
  } catch {
    return "operacional";
  }
}
