import { createHash } from "node:crypto";

/** Stable, non-guessable namespace used to link the V2 owner to one V1 operational user. */
export const OWNER_OPERATIONAL_OPEN_ID_PREFIX = "concilium-owner:";

export function operationalOpenIdForOwner(ownerId: string): string {
  const normalized = ownerId.trim();
  if (!normalized) throw new Error("ownerId is required");
  return `${OWNER_OPERATIONAL_OPEN_ID_PREFIX}${normalized}`;
}

export function isOperationalOwnerOpenId(openId: string): boolean {
  return openId.startsWith(OWNER_OPERATIONAL_OPEN_ID_PREFIX) && openId.length > OWNER_OPERATIONAL_OPEN_ID_PREFIX.length;
}

export function operationalScopeKey(ownerId: string, caseId: string): string {
  const value = `${ownerId.trim()}:${caseId.trim()}`;
  return createHash("sha256").update(value, "utf8").digest("hex");
}

export type OperationalOwnerIdentity = {
  ownerId: string;
  operationalUserId: number;
  openId: string;
};

/**
 * The adapter must resolve exactly one operational user for an owner. It must
 * never fall back to an admin-wide query, because that would expose unrelated
 * cases to the titular session.
 */
export function assertOperationalOwnerIdentity(identity: OperationalOwnerIdentity): OperationalOwnerIdentity {
  if (!identity.ownerId || !identity.operationalUserId || !isOperationalOwnerOpenId(identity.openId)) {
    throw new Error("Invalid owner-to-operational identity link");
  }
  return identity;
}
