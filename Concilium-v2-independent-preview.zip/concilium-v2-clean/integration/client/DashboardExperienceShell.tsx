import type { ReactNode } from "react";
import { DashboardExperienceSelector } from "./DashboardExperienceSelector";
import { useDashboardExperience, type DashboardExperience } from "./useDashboardExperience";

type DashboardExperienceShellProps = {
  operational: ReactNode;
  editorial: ReactNode;
  onExperienceChange?: (experience: DashboardExperience) => void;
};

/**
 * Shared presentation switch. Both children must receive the same case data
 * and actions from their parent; this component intentionally owns no domain
 * state or permissions.
 */
export function DashboardExperienceShell({
  operational,
  editorial,
  onExperienceChange,
}: DashboardExperienceShellProps) {
  const { experience, setExperience } = useDashboardExperience();
  const changeExperience = (next: DashboardExperience) => {
    setExperience(next);
    onExperienceChange?.(next);
  };

  return (
    <div data-dashboard-experience={experience}>
      <div className="dashboard-experience-toolbar">
        <DashboardExperienceSelector value={experience} onChange={changeExperience} compact />
      </div>
      {experience === "operacional" ? operational : editorial}
    </div>
  );
}
