import { useCallback, useState } from "react";
import {
  DASHBOARD_EXPERIENCE_STORAGE_KEY,
  isDashboardExperience,
  readDashboardExperience,
  type DashboardExperience,
} from "../shared/dashboardExperience";

export function useDashboardExperience() {
  const [experience, setExperienceState] = useState<DashboardExperience>(() =>
    readDashboardExperience(typeof window === "undefined" ? undefined : window.localStorage),
  );

  const setExperience = useCallback((next: DashboardExperience) => {
    setExperienceState(next);
    try {
      window.localStorage.setItem(DASHBOARD_EXPERIENCE_STORAGE_KEY, next);
    } catch {
      // A preferência transitória não deve impedir o uso do dashboard.
    }
  }, []);

  return { experience, setExperience };
}

export { isDashboardExperience };
export type { DashboardExperience };
