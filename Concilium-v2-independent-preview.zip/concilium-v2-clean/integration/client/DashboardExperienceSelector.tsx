import {
  DASHBOARD_EXPERIENCE_DESCRIPTIONS,
  DASHBOARD_EXPERIENCE_LABELS,
  DASHBOARD_EXPERIENCES,
  type DashboardExperience,
} from "../shared/dashboardExperience";

type DashboardExperienceSelectorProps = {
  value: DashboardExperience;
  onChange: (value: DashboardExperience) => void;
  compact?: boolean;
};

export function DashboardExperienceSelector({
  value,
  onChange,
  compact = false,
}: DashboardExperienceSelectorProps) {
  return (
    <fieldset className={compact ? "dashboard-experience-selector compact" : "dashboard-experience-selector"}>
      <legend>Experiência do dashboard</legend>
      <div role="radiogroup" aria-label="Experiência do dashboard">
        {DASHBOARD_EXPERIENCES.map(experience => (
          <label key={experience} data-selected={value === experience}>
            <input
              type="radio"
              name="dashboard-experience"
              value={experience}
              checked={value === experience}
              onChange={() => onChange(experience)}
            />
            <span>
              <strong>{DASHBOARD_EXPERIENCE_LABELS[experience]}</strong>
              {!compact && <small>{DASHBOARD_EXPERIENCE_DESCRIPTIONS[experience]}</small>}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
