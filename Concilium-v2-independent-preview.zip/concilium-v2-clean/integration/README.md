# Camada de integração — primeira implementação

Esta pasta contém o contrato inicial do seletor de experiência do dashboard.

- `shared/dashboardExperience.ts`: valores permitidos e funções de validação.
- `client/useDashboardExperience.ts`: preferência local com fallback seguro.
- `client/DashboardExperienceSelector.tsx`: controle visual acessível para escolher Operacional ou Editorial.

O seletor ainda não foi conectado às duas telas finais. Isso ocorrerá depois da ponte de identidade e dados, para que a troca de experiência não fique apenas cosmética nem crie duas fontes de verdade.
