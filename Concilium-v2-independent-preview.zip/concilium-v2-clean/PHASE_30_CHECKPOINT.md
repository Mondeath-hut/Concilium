# Concilium — checkpoint da fase 30

## Encaminhamento após decisão humana
As comparações agora registram, além da decisão sobre a versão, o próximo destino escolhido pelo titular:

- Estrategista;
- Bibliotecário;
- Arena;
- Compêndio;
- Arquivo.

O encaminhamento é explícito e auditável. Escolher um destino não sobrescreve versões nem converte o material em documento vinculante.

## Persistência
- `nextDestination`;
- `routedAt`;
- `drizzle/0024_comparison_routing.sql`.

## Interface
Cada comparação apresenta um seletor de próximo destino e o botão `Registrar encaminhamento`. O estado registrado aparece junto da comparação.

## Estado de validação
Código e migração preparados. Ainda não houve build, type-check, aplicação em banco ou execução com provedor real.
