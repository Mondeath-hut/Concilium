# Concilium — checkpoint da fase 19

## Encaminhamento efetivo das sínteses
O destino escolhido para uma síntese homologada agora gera uma ação persistida:

- **Bibliotecário:** cria uma solicitação de pesquisa para verificar fundamentos, fontes, jurisdição e vigência;
- **Compêndio:** cria um rascunho de cláusula derivado da síntese, explicitamente não aprovado;
- **Arena:** cria uma sessão de refinamento vinculada à rodada de origem;
- **Arquivo:** registra a conservação sem uso ativo.

O histórico da Arena continua preservado. O encaminhamento não apaga a rodada original.

## Regra de autorização
Síntese não homologada não pode seguir para Bibliotecário, Compêndio ou Arena. O arquivo é permitido mesmo sem homologação.

## Próximo marco
Ligar as solicitações do Bibliotecário ao serviço de conhecimento e abrir os rascunhos do compêndio na área de Documentos/Negociação, sem transformar automaticamente nenhum deles em proposta ou acordo.
