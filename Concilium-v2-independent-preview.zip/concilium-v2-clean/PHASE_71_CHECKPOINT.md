# Concilium — checkpoint da fase 71

## Confirmação humana da catalogação

Foi implementada a transição explícita da sugestão para a catalogação confirmada.

### Nova rota

```text
confirmDocumentCatalog
```

### Regras

- exige titular autenticado e caso autorizado;
- aceita somente cofres conhecidos;
- só atua quando o documento está em `needs_owner_review`;
- grava `confirmedVault`;
- muda o estado para `confirmed`;
- registra auditoria sem conteúdo documental;
- não confirma autenticidade ou relevância jurídica;
- não permite confirmação automática pelo ensemble.

## Estado

O ciclo documental agora está completo no backend: quarentena → sugestão por ensemble → revisão humana → confirmação de cofre. A interface ainda pode receber um seletor explícito de cofre e a comparação das sugestões dos papéis.
