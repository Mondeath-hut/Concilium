# Protocolo de ramificações dinâmicas

## Ideia central

Uma IA pode identificar uma questão que não pertence à linha estrutural em que está trabalhando. Essa questão não deve ser incorporada à linha original. Ela vira uma proposta de ramificação, com proveniência preservada, e fica estacionada para avaliação posterior.

## Ciclo

```text
linha original
   ↓
pergunta original
   ↓
respostas independentes
   ↓
questão lateral identificada
   ↓
ramificação estacionada, vinculada à origem
   ↓
agrupamento de ramificações relacionadas
   ↓
pergunta composta para o Estrategista
   ↓
revisão/submissão humana
   ↓
novo ciclo de pulverização
   ↓
nova rodada ou exploração derivada
```

## Proveniência obrigatória

Cada ramificação mantém:

- exploração de origem;
- linha de origem;
- pergunta original;
- mensagem que a originou;
- texto da nova questão;
- motivo de relevância;
- estado da ramificação.

## Estados

- `parked`: identificada e reservada;
- `grouped`: relacionada a outras propostas;
- `ready_for_strategist`: pacote composto, ainda não enviado;
- `submitted`: submetida ao Estrategista;
- `resolved`: tratada em novo ciclo;
- `dismissed`: descartada com justificativa.

## Regras

- a linha original não é reescrita;
- a resposta original continua preservada;
- a nova questão não é tratada como fato provado;
- agrupamento não significa fusão de históricos;
- nenhuma pergunta composta é enviada automaticamente;
- o titular/supervisor decide quando submeter o pacote;
- o Estrategista pode reformular, separar ou descartar as propostas;
- a nova pulverização começa como nova unidade comparável;
- sínteses e decisões homologadas anteriores não são alteradas.

## Sugestão de interface

Exibir cada pacote com: linha de origem, pergunta original, ramificações relacionadas, pergunta composta, motivo de relevância e botões `Editar`, `Submeter ao Estrategista`, `Manter reservado` e `Descartar`.
