# Concilium — checkpoint da fase 65

## Síntese da exploração derivada

A nova exploração derivada agora percorre o mesmo ciclo de consolidação da exploração original.

### Após a pulverização

- linhas encerradas geram sínteses individuais;
- sínteses preservam divergências e lacunas;
- quando todas as linhas terminam, uma síntese final é produzida;
- a síntese pertence somente ao novo `runId`;
- a exploração original não recebe atualização retroativa;
- novas ramificações continuam disponíveis para outro ciclo.

### Garantias

A síntese não escolhe uma vencedora automaticamente, não transforma convergência em decisão e não trata resposta de IA como fato jurídico comprovado.

## Estado

O ciclo derivado agora cobre criação, coordenação, pulverização, sínteses progressivas e síntese final. Falta, em etapa futura, oferecer na interface a comparação lado a lado entre exploração original e derivada.
