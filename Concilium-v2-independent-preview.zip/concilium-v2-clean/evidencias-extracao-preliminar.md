# Evidências da extração preliminar

## Fontes recebidas e leitura efetuada

| Fonte | Leitura efetuada | Classificação inicial | Limite de uso |
|---|---|---|---|
| `ACA-AnálisedePropostadeDivórcio.zip` | Inventário somente leitura de nomes e extensões; leitura textual seletiva do memorial em Markdown. | Um memorial conversacional, 48 anexos em imagem e referências técnicas repetidas de arquitetura. | Não foram executados scripts, alterados arquivos ou importados dados. |
| Anexos do arquivo ACA | Somente nomes e tipos de arquivo. Entre os nomes visíveis há certificados, referência a mensalidade de terreno e capturas de tela. | Candidatos a documento patrimonial, comprovante ou contexto conversacional; conteúdo ainda não classificado por leitura. | O nome do arquivo não é prova de conteúdo, autenticidade ou relevância. |
| `PUACC_Webbook_v1_4_Unificado.html` | Inventário estático. | Referência técnica para arquitetura de memorial e log. | Não é fonte de fatos, propostas ou decisões do caso. |

## Resultado textual preliminar

O memorial em Markdown reúne conversas sobre proposta de divórcio e diversas discussões técnicas sobre módulos, cláusulas, motor documental e simulação. Para o Concilium, menções a pagamento programado, correção monetária, prazo, liquidez de bem e alternativas de negociação permanecem classificadas como **notas candidatas de estratégia**, pendentes de confirmação do titular. Nenhuma delas foi convertida em registro, termo, cláusula ou decisão do caso.

## Próxima etapa autorizada

Com a autorização do titular, a próxima extração deverá classificar anexos individualmente por tipo, data, origem, vínculo e estado de revisão. Um documento só poderá alimentar patrimônio, cronologia, negociação, estratégia ou biblioteca após essa classificação; estimativas e hipóteses continuarão identificadas como tal.

## Evidências visuais verificadas

| Identificador de origem | Classe preliminar | Campos legíveis preservados | Estado de revisão |
|---|---|---|---|
| `anexos/0001_Cert.jpg.jpg` | Certidão de casamento | Certidão civil brasileira, data do casamento em 25/02/2005 e referência a regime de comunhão parcial de bens. | Documento primário a conferir; elegível para a cronologia e para o rascunho de separação de fato. |
| `anexos/0002_Mensalidade Terreno.jpg.jpg` | Comprovante de parcela de terreno | Parcela mensal nº 84, vencimento em 15/06/2026, valor de R$ 431,12, indicada como paga em 02/06/2026, vinculada a contrato e unidade identificados no próprio comprovante. | Documento patrimonial a conferir; elegível para o inventário patrimonial, sem inferir titularidade ou valor total do bem. |
| `anexos/0003_file_00000000b810720ebd69649473df0161.jpg` | Fotografia de imóvel ou edificação | Fachada de construção residencial/comercial sem texto documental legível. | Evidência visual patrimonial a conferir; não comprova endereço, titularidade, valor, origem dos recursos ou situação jurídica do bem. |

Os dados acima são apenas transcrições de campos visíveis em imagens fornecidas pelo titular. Não comprovam, isoladamente, validade jurídica, titularidade, quitação integral, avaliação de bem ou aceitação de qualquer proposta.
