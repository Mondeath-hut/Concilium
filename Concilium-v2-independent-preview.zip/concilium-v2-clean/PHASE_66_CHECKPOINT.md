# Concilium — checkpoint da fase 66

## Comparação de linhagem

Foi criada uma visão lado a lado entre a exploração original e uma exploração derivada.

### Exibe

- objetivo de cada exploração;
- quantidade de linhas;
- quantidade de sínteses;
- sínteses individuais e finais disponíveis;
- seleção da exploração derivada;
- vínculo com a exploração de origem.

### Regras

- comparação é organizacional, não decisão automática;
- semelhança visual não é consenso;
- divergência não é erro;
- sínteses permanecem pertencentes aos seus respectivos `runId`;
- a origem não é alterada pela derivação.

## Arquivos

- `client/src/components/ExplorationLineageComparison.tsx`;
- integração em `client/src/pages/OwnerWorkspace.tsx`;
- `PHASE_66_CHECKPOINT.md`.
