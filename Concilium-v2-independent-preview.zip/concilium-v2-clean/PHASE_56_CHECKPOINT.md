# Concilium — checkpoint da fase 56

## Abertura automática controlada de linhas

O Estrategista agora pode propor linhas exploratórias adicionais quando identificar um eixo ausente na distribuição padrão.

### Como funciona

- a pauta pode declarar `LINHA_EXPLORATORIA: descrição curta`;
- o sistema extrai somente descrições curtas e não duplicadas;
- as cinco perspectivas padrão continuam preservadas;
- propostas novas são acrescentadas ao conjunto;
- o limite é de 12 perspectivas;
- cada modelo continua recebendo uma única linha independente;
- o agrupamento visual não mistura históricos ou respostas.

### Proteções

- não há criação baseada em qualquer texto casual da resposta;
- o marcador precisa estar explicitamente na pauta do Estrategista;
- nenhuma linha é criada a partir de resposta de outra IA;
- a nova linha recebe projeção protegida e segue as mesmas regras de encerramento;
- o Estrategista propõe, mas não decide pelo titular.

## Arquivos

- `shared/strategyExploration.ts`;
- `shared/strategyExploration.test.ts`;
- `server/routers/ownerWorkspace.ts`.

## Estado
A abertura automática controlada está implementada no início de uma exploração. A criação dinâmica de novas linhas durante uma exploração já aberta ainda depende de uma futura continuação do endpoint do Estrategista.
