# Concilium — migração de documentos sensíveis

## Objetivo

Permitir que documentos reais sejam incorporados sem recusa automática, exposição indevida ou transformação de narrativa em fato provado.

## Regra essencial

Sensibilidade não é motivo para descartar o documento. É motivo para aumentar proteção, limitar acesso e exigir confirmação humana.

## Fluxo correto

```text
recebimento autorizado
   ↓
quarentena
   ↓
hash e metadados técnicos
   ↓
extração/OCR controlado
   ↓
sugestão de cofre e sensibilidade
   ↓
revisão humana
   ↓
confirmação de catalogação
   ↓
acesso projetado por função
```

## O que o agente documental pode fazer

- registrar recebimento;
- calcular hash;
- extrair texto/OCR quando autorizado;
- sugerir cofre;
- sugerir sensibilidade;
- apontar possível duplicidade;
- apontar lacunas, cronologia e relação temática;
- preservar fonte, versão e observações.

## O que não pode fazer

- confirmar autenticidade;
- afirmar que uma narrativa é fato provado;
- decidir relevância definitiva;
- mover o arquivo sem confirmação;
- excluir ou compartilhar automaticamente;
- enviar documento integral a qualquer IA por padrão;
- recusar apenas por conter dados pessoais, jurídicos, financeiros ou familiares.

## Cofres previstos

Identidade; Família; Patrimônio; Renda e despesas; Jurídico/processual; Acordos e estratégias; Evidências; Comunicações; Pesquisa; Quarentena; Arquivo.

## Projeção para IAs

- supervisor autorizado: pode receber contexto integral conforme a rodada;
- Estrategista: recebe contexto integral autorizado para coordenação;
- Laboratório: recebe projeção protegida, com identificadores e valores mascarados quando necessário;
- Arena: cada função recebe somente a projeção compatível;
- Bibliotecário: recebe pergunta e mapa contextual neutro, não o caso integral por padrão.

## Como lidar com recusas do ambiente

Se o Manus ou outro servidor recusar um documento sensível, não remover o documento nem colar seu conteúdo em canal alternativo. Registrar a recusa, classificar o tipo de bloqueio, usar armazenamento privado autorizado e adaptar o conector para transportar metadados ou conteúdo cifrado. A política de quarentena e acesso deve permanecer intacta.

## Importação do acervo existente

1. Preservar o arquivo original e seu SHA-256.
2. Importar para Quarentena.
3. Confirmar quantidade e tamanho.
4. Extrair/OCR somente em ambiente autorizado.
5. Catalogar sem mover automaticamente.
6. Revisar sugestões por lote.
7. Confirmar cofres individualmente ou por lote explícito.
8. Registrar responsáveis, data, versão e pendências.
9. Manter cópia de origem até a conferência final.

## Resultado

O documento sensível não é rejeitado nem tratado automaticamente como prova. Ele permanece rastreável, protegido e disponível para decisão humana.
