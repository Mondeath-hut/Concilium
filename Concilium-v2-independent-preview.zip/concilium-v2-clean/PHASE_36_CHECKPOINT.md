# Concilium — checkpoint da fase 36

## Permissões do Estrategista e projeção do Laboratório
A política de acesso foi ajustada para distinguir o módulo que recebe a solicitação do titular das IAs derivadas que exploram alternativas.

### Estrategista

- recebe a pergunta e a contextualização integralmente quando o titular autoriza;
- pode fazer a triagem direta do argumento sobre o conteúdo integral;
- pode preservar detalhes pessoais, relacionais, patrimoniais e domésticos necessários ao raciocínio;
- a consulta ao Bibliotecário continua minimizada e sem identificadores por padrão.

### Laboratório

- cada IA divergente recebe `contexto_protegido`;
- conteúdo, objetivo, histórico de linha, pergunta e resposta do titular são projetados antes do envio;
- a semântica jurídica e relacional é preservada tanto quanto possível;
- identificadores, endereços, valores e números sensíveis são mascarados;
- as respostas continuam isoladas entre as linhas.

## Auditoria
A triagem registra separadamente:

- transmissão integral ao Estrategista;
- consulta redigida ao Knowledge Service.

## Implementação
- `STRATEGIST_ACCESS_LEVEL`;
- `LAB_DEFAULT_ACCESS_LEVEL`;
- projeção protegida no `exploreStrategies`;
- projeção protegida nas perguntas de continuação do Laboratório;
- triagem direta do Estrategista com formulação integral autorizada;
- testes atualizados em `shared/aiForumPolicy.test.ts`.

## Estado
Política e aplicação preparadas. A validação com modelos reais ainda depende de build, banco, credenciais seguras e execução controlada.
