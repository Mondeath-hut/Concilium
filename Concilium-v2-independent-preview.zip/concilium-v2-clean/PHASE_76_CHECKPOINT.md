# Concilium — checkpoint da fase 76

## Análise técnica do histórico

Foi adicionada uma análise não conclusiva das versões documentais.

### Detecta

- quantidade de versões;
- ordem cronológica;
- grupos com hash repetido;
- necessidade de revisão quando houver repetição.

### Regras

- hash repetido indica possível cópia ou registro duplicado;
- não confirma que dois documentos são juridicamente equivalentes;
- não escolhe qual versão é autêntica;
- apenas sinaliza revisão humana;
- o histórico original permanece preservado.

## Arquivos

- `shared/documentVersionAnalysis.ts`;
- `shared/documentVersionAnalysis.test.ts`;
- atualização em `client/src/components/DocumentVersionHistory.tsx`;
- `PHASE_76_CHECKPOINT.md`.
