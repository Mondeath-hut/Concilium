# Concilium — checkpoint da fase 59

## Caixa visual de ramificações

Foi criada e integrada a primeira interface para revisar ramificações de uma exploração ativa.

### A interface permite

- listar questões paralelas reservadas;
- mostrar motivo e linha de origem;
- selecionar propostas relacionadas;
- compor uma pergunta preliminar ao Estrategista;
- revisar a pergunta antes do envio;
- manter o pacote reservado;
- submeter explicitamente o pacote.

### Segurança conceitual

A caixa aparece separada da linha estrutural. A submissão não edita a linha original nem altera sínteses anteriores. O envio ao Estrategista continua sendo uma ação explícita.

## Integração

- `client/src/components/StrategyBranchInbox.tsx`;
- integração em `client/src/pages/OwnerWorkspace.tsx`;
- rotas protegidas da fase anterior;
- auditoria de composição e mudança de estado.

## Limite conhecido

A etapa de `submitted` registra o pacote, mas a criação automática da nova exploração derivada ainda será implementada em seguida. A nova pulverização não deve ocorrer no mesmo run nem reutilizar silenciosamente a síntese anterior.
