# Concilium — checkpoint da fase 20

## Trabalho derivado visível no caso
Os encaminhamentos da Arena agora aparecem novamente na Biblioteca:

- solicitações de pesquisa derivadas de sínteses homologadas;
- botão para levar uma solicitação à busca do Bibliotecário;
- rascunhos criados no Compêndio de Cláusulas;
- origem e estado de cada rascunho;
- distinção visual entre rascunho e material final.

## Fluxo integrado

```text
Arena homologa síntese
      ↓
Biblioteca recebe tarefa de pesquisa
ou
Compêndio recebe rascunho
      ↓
Titular revisa
      ↓
Bibliotecário verifica fontes
ou
Arena estressa o rascunho
      ↓
Somente depois pode virar material operacional
```

Nenhum encaminhamento altera automaticamente uma proposta, envia documento ou transforma o rascunho em cláusula aprovada.

## Próximo marco
Adicionar aprovação/revisão própria dos itens do Compêndio e registrar o vínculo entre uma cláusula refinada, suas fontes e a síntese da Arena que a originou.
