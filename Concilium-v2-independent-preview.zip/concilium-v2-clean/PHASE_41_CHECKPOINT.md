# Concilium — checkpoint da fase 41

## Simulação integrada do fluxo jurídico
Foi estruturada uma simulação completa com a pergunta sobre despesas de supermercado durante coabitação e eventual substituição/compensação de alimentos em dinheiro.

### Etapas simuladas

1. pergunta original do titular;
2. classificação do Bibliotecário como `strategy_handoff`;
3. ampliação contextual em oito consultas derivadas;
4. resposta neutra com materiais simulados, limites e fontes contrárias;
5. envio da pergunta, pacote e resultados ao Estrategista;
6. pauta central com distribuição por linhas;
7. projeção protegida para cinco IAs do Laboratório;
8. perguntas bloqueantes por linha;
9. possíveis respostas de estresse do titular;
10. critérios para síntese sem conclusão automática.

## Regra de simulação
Todos os materiais foram marcados como `SIMULADO / NÃO VERIFICADO`. Nenhuma fonte jurídica real foi citada como fundamento e nenhuma conclusão foi dada sobre dispensa, substituição ou compensação de alimentos.

## Arquivo

- `tests/LIBRARIAN_SIMULATION_ALIMENTOS_EX_CONJUGE.md`.

## Estado
Fluxo simulado e documentado. A consulta real ainda depende de fonte/Knowledge Service conectado e de triagem jurídica verificável.
