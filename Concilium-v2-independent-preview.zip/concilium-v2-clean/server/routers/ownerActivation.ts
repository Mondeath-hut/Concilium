import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { generateAuthenticationOptions, generateRegistrationOptions, verifyAuthenticationResponse, verifyRegistrationResponse } from "@simplewebauthn/server";
import { TOTP } from "otpauth";
import { z } from "zod";
import { clearOwnerAuthThrottle, consumeOwnerEmailVerification, createOwnerAccount, createOwnerEmailVerification, createOwnerSession, getOwnerAccount, getOwnerAccountById, getOwnerAuthThrottle, getOwnerMfa, getOwnerPasskey, getOwnerPasskeys, recordOwnerAudit, recordOwnerAuthFailure, revokeOutstandingOwnerEmailVerifications, saveOwnerPasskey, updateOwnerPasskeyUsage, upsertOwnerMfa, updateOwnerAccount } from "../db";
import { hashOwnerEmailVerificationToken, makeOwnerEmailVerificationLink, makeOwnerEmailVerificationToken, OWNER_EMAIL_VERIFICATION_TTL_MS, sendOwnerEmailVerification } from "../emailVerification";
import { clearOwnerSession, clearSetupCookie, decryptTotpSecret, encryptTotpSecret, makeSessionId, requestOrigin, requestRpId, setOwnerSession, setSetupCookie, readSetupCookie } from "../ownerAuth";
import { ownerProcedure, publicProcedure, router } from "../_core/trpc";

function hashed(value: string) {
  return createHash("sha256").update(value, "utf8").digest();
}

function asBase64Url(value: Uint8Array) {
  return Buffer.from(value).toString("base64url");
}

function fromBase64Url(value: string) {
  return new Uint8Array(Buffer.from(value, "base64url"));
}

function newRecoveryCodes() {
  return Array.from({ length: 10 }, () => randomBytes(7).toString("base64url").toUpperCase());
}

function hashRecoveryCodes(codes: string[]) {
  return JSON.stringify(codes.map(code => createHash("sha256").update(code, "utf8").digest("hex")));
}

function recoveryCodeHash(code: string) {
  return createHash("sha256").update(code.trim().toUpperCase(), "utf8").digest("hex");
}

export function remainingRecoveryCodeCount(serialized: string) {
  try {
    const hashes = JSON.parse(serialized);
    return Array.isArray(hashes) ? hashes.length : 0;
  } catch {
    return 0;
  }
}

export function createRecoveryCodeRotation(previousSerialized: string) {
  const recoveryCodes = newRecoveryCodes();
  return {
    recoveryCodes,
    recoveryCodesHash: hashRecoveryCodes(recoveryCodes),
    replacedRemaining: remainingRecoveryCodeCount(previousSerialized),
  };
}

export function assertRecoveryCodeRegenerationAuthorized(input: { setupOwnerId: string | undefined; sessionOwnerId: string; passkeyVerified: boolean }) {
  if (!input.setupOwnerId || input.setupOwnerId !== input.sessionOwnerId || !input.passkeyVerified) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "A confirmação por passkey para renovar os códigos não foi concluída." });
  }
}

function sameDigest(left: string, right: string) {
  return left.length === right.length && timingSafeEqual(Buffer.from(left, "hex"), Buffer.from(right, "hex"));
}

export function consumeRecoveryCodeHash(storedHashes: string[], candidateHash: string) {
  const matchIndex = storedHashes.findIndex(hash => sameDigest(hash, candidateHash));
  if (matchIndex < 0) return null;
  return storedHashes.filter((_, index) => index !== matchIndex);
}

export const OWNER_AUTH_FAILURE_LIMIT = 5;
export const OWNER_AUTH_LOCK_WINDOW_MS = 15 * 60 * 1000;

export function isOwnerAuthLocked(lockedUntil: Date | null | undefined, now = Date.now()) {
  return Boolean(lockedUntil && lockedUntil.getTime() > now);
}

export function nextOwnerAuthThrottle(previousFailureCount: number, previousLockedUntil: Date | null | undefined, now = Date.now()) {
  const baseFailures = previousLockedUntil && !isOwnerAuthLocked(previousLockedUntil, now) ? 0 : previousFailureCount;
  const failureCount = baseFailures + 1;
  return {
    failureCount,
    lockedUntil: failureCount >= OWNER_AUTH_FAILURE_LIMIT ? new Date(now + OWNER_AUTH_LOCK_WINDOW_MS) : null,
  };
}

function ownerAuthThrottleScope(req: any, purpose: string, ownerId?: string) {
  const forwarded = req?.headers?.["x-forwarded-for"];
  const clientAddress = (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(",")[0]?.trim() || req?.socket?.remoteAddress || "unknown";
  return createHash("sha256").update(`concilium-owner-auth:v1:${purpose}:${ownerId ?? "pre-activation"}:${clientAddress}`, "utf8").digest("hex");
}

async function assertOwnerAuthNotLocked(ctx: { req: any }, scopeKey: string, ownerId: string | null, eventType: string) {
  const throttle = await getOwnerAuthThrottle(scopeKey);
  if (!isOwnerAuthLocked(throttle?.lockedUntil)) return;
  await recordOwnerAudit(ownerId, `${eventType}_blocked`, { reason: "temporary_lock" });
  throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Muitas tentativas. Aguarde 15 minutos antes de tentar novamente." });
}

async function rejectOwnerAuthAttempt(scopeKey: string, ownerId: string | null, eventType: string, currentFailureCount = 0, currentLockedUntil?: Date | null) {
  const next = nextOwnerAuthThrottle(currentFailureCount, currentLockedUntil);
  await recordOwnerAuthFailure({ scopeKey, ownerId, ...next });
  await recordOwnerAudit(ownerId, eventType, { failureCount: next.failureCount, locked: Boolean(next.lockedUntil) });
  if (next.lockedUntil) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Muitas tentativas. Aguarde 15 minutos antes de tentar novamente." });
  throw new TRPCError({ code: "UNAUTHORIZED", message: "Não foi possível validar esta credencial." });
}

export function matchesBootstrapCode(candidate: string) {
  const configured = process.env.CONCILIUM_BOOTSTRAP_CODE?.trim();
  if (!configured || !candidate) return false;
  return timingSafeEqual(hashed(candidate), hashed(configured));
}

async function issueOwnerSession(ctx: { req: any; res: any }, ownerId: string) {
  const sessionId = makeSessionId();
  const { tokenHash } = await setOwnerSession(ctx.res, ctx.req, { ownerId, sessionId });
  await createOwnerSession({
    id: sessionId,
    ownerId,
    tokenHash,
    expiresAt: new Date(Date.now() + 12 * 60 * 60 * 1000),
  });
}

async function issueOwnerEmailConfirmation(ctx: { req: any }, owner: { id: string; email: string }) {
  const token = makeOwnerEmailVerificationToken();
  const expiresAt = new Date(Date.now() + OWNER_EMAIL_VERIFICATION_TTL_MS);
  await revokeOutstandingOwnerEmailVerifications(owner.id);
  await createOwnerEmailVerification({ ownerId: owner.id, tokenHash: hashOwnerEmailVerificationToken(token), expiresAt });
  try {
    await sendOwnerEmailVerification({ to: owner.email, verificationLink: makeOwnerEmailVerificationLink(requestOrigin(ctx.req), token) });
  } catch (error) {
    await revokeOutstandingOwnerEmailVerifications(owner.id);
    await recordOwnerAudit(owner.id, "owner.email_confirmation_delivery_failed", { reason: error instanceof Error ? error.message : "unknown" });
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível enviar a confirmação de e-mail. Tente novamente em alguns instantes." });
  }
  await recordOwnerAudit(owner.id, "owner.email_confirmation_sent", { expiresAt: expiresAt.toISOString() });
  return { email: owner.email, expiresAt };
}

const setupInput = z.object({
  code: z.string().min(20).max(512),
  email: z.string().email().max(320),
  displayName: z.string().trim().min(2).max(160),
});

export const ownerActivationRouter = router({
  status: publicProcedure.query(async () => {
    const owner = await getOwnerAccount().catch(() => undefined);
    return {
      activationConfigured: Boolean(process.env.CONCILIUM_BOOTSTRAP_CODE?.trim()),
      mfaEncryptionConfigured: Boolean(process.env.CONCILIUM_MFA_ENCRYPTION_KEY?.trim()),
      ownerState: owner?.state ?? "not_initialized",
      ownerExists: Boolean(owner),
    };
  }),

  validateBootstrapCode: publicProcedure.input(z.object({ code: z.string().min(1).max(512) })).mutation(async ({ input }) => {
    const owner = await getOwnerAccount();
    return { valid: !owner?.bootstrapCodeRetiredAt && owner?.state !== "active" && matchesBootstrapCode(input.code) };
  }),

  beginSetup: publicProcedure.input(setupInput).mutation(async ({ ctx, input }) => {
    const existing = await getOwnerAccount();
    const throttleScope = ownerAuthThrottleScope(ctx.req, "bootstrap", existing?.id);
    const throttle = await getOwnerAuthThrottle(throttleScope);
    await assertOwnerAuthNotLocked(ctx, throttleScope, existing?.id ?? null, "owner.bootstrap_code");
    if (!matchesBootstrapCode(input.code)) {
      await rejectOwnerAuthAttempt(throttleScope, existing?.id ?? null, "owner.bootstrap_code_failed", throttle?.failureCount, throttle?.lockedUntil);
    }
    if (existing?.state === "active") throw new TRPCError({ code: "CONFLICT", message: "A conta titular já foi ativada." });
    if (existing?.bootstrapCodeRetiredAt) throw new TRPCError({ code: "CONFLICT", message: "O código de ativação foi aposentado após o primeiro uso." });
    if (existing && existing.email !== input.email.toLowerCase()) throw new TRPCError({ code: "FORBIDDEN", message: "A ativação pendente pertence a outro endereço institucional." });

    const owner = existing ?? await createOwnerAccount({ id: crypto.randomUUID(), email: input.email.toLowerCase(), displayName: input.displayName });
    if (!owner) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível preparar a conta titular." });

    await clearOwnerAuthThrottle(throttleScope);

    const options = await generateRegistrationOptions({
      rpName: "Concilium",
      rpID: requestRpId(ctx.req),
      userID: new TextEncoder().encode(owner.id),
      userName: owner.email,
      userDisplayName: owner.displayName,
      attestationType: "none",
      authenticatorSelection: { residentKey: "required", userVerification: "required" },
      excludeCredentials: (await getOwnerPasskeys(owner.id)).map(credential => ({ id: credential.credentialId, transports: credential.transports?.split(",") as any })),
      supportedAlgorithmIDs: [-7, -257],
    });
    await setSetupCookie(ctx.res, ctx.req, { ownerId: owner.id, challenge: options.challenge, purpose: "passkey_registration", origin: requestOrigin(ctx.req), rpId: requestRpId(ctx.req) });
    await recordOwnerAudit(owner.id, "owner.setup_started", { email: owner.email });
    return options;
  }),

  resendEmailConfirmation: publicProcedure.mutation(async ({ ctx }) => {
    const setup = (await readSetupCookie(ctx.req, "totp_setup")) ?? (await readSetupCookie(ctx.req, "passkey_registration"));
    if (!setup) throw new TRPCError({ code: "UNAUTHORIZED", message: "A ativação expirou. Recomece pelo código inicial." });
    const owner = await getOwnerAccountById(setup.ownerId);
    if (!owner || owner.state !== "setup_pending") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Não há uma ativação pendente para confirmar." });
    if (owner.emailVerifiedAt) return { email: owner.email, alreadyVerified: true };
    const delivery = await issueOwnerEmailConfirmation(ctx, owner);
    return { ...delivery, alreadyVerified: false };
  }),

  confirmEmailVerification: publicProcedure.input(z.object({ token: z.string().min(32).max(256) })).mutation(async ({ input }) => {
    const verification = await consumeOwnerEmailVerification(hashOwnerEmailVerificationToken(input.token));
    if (!verification) throw new TRPCError({ code: "UNAUTHORIZED", message: "Este link de confirmação é inválido, expirou ou já foi utilizado." });
    const owner = await getOwnerAccountById(verification.ownerId);
    if (!owner || owner.state !== "setup_pending") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Esta ativação não está mais disponível." });
    await updateOwnerAccount(owner.id, { emailVerifiedAt: new Date() });
    await recordOwnerAudit(owner.id, "owner.email_confirmed", {});
    return { verified: true, email: owner.email };
  }),

  finishPasskeyRegistration: publicProcedure.input(z.object({ response: z.any() })).mutation(async ({ ctx, input }) => {
    const setup = await readSetupCookie(ctx.req, "passkey_registration");
    if (!setup) throw new TRPCError({ code: "UNAUTHORIZED", message: "A etapa de passkey expirou. Recomece a ativação." });
    const verification = await verifyRegistrationResponse({
      response: input.response,
      expectedChallenge: setup.challenge,
      expectedOrigin: setup.origin,
      expectedRPID: setup.rpId,
      requireUserVerification: true,
    });
    if (!verification.verified || !verification.registrationInfo) throw new TRPCError({ code: "UNAUTHORIZED", message: "Não foi possível verificar a passkey." });

    const registration = verification.registrationInfo as any;
    const credential = registration.credential ?? registration;
    await saveOwnerPasskey({
      credentialId: credential.id ?? registration.credentialID,
      ownerId: setup.ownerId,
      publicKey: asBase64Url(credential.publicKey ?? registration.credentialPublicKey),
      counter: credential.counter ?? registration.counter ?? 0,
      transports: Array.isArray(credential.transports) ? credential.transports.join(",") : null,
      deviceType: registration.credentialDeviceType ?? "singleDevice",
      backedUp: registration.credentialBackedUp ? 1 : 0,
    });
    await setSetupCookie(ctx.res, ctx.req, { ...setup, challenge: "totp", purpose: "totp_setup" });
    await recordOwnerAudit(setup.ownerId, "owner.passkey_registered", {});
    return { verified: true };
  }),

  activateWithPasskey: publicProcedure.mutation(async ({ ctx }) => {
    const setup = await readSetupCookie(ctx.req, "totp_setup");
    if (!setup) throw new TRPCError({ code: "UNAUTHORIZED", message: "A ativação expirou. Recomece a partir da passkey." });
    const owner = await getOwnerAccountById(setup.ownerId);
    if (!owner || owner.state !== "setup_pending") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Não há uma ativação titular pendente." });
    if ((await getOwnerPasskeys(setup.ownerId)).length < 1) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Registre uma passkey antes de concluir a ativação." });
    const recoveryCodes = newRecoveryCodes();
    await upsertOwnerMfa({ ownerId: setup.ownerId, recoveryCodesHash: hashRecoveryCodes(recoveryCodes) });
    await updateOwnerAccount(setup.ownerId, { state: "active", activatedAt: new Date(), bootstrapCodeRetiredAt: new Date(), failedActivationAttempts: 0 });
    await issueOwnerSession(ctx, setup.ownerId);
    clearSetupCookie(ctx.res, ctx.req);
    await recordOwnerAudit(setup.ownerId, "owner.activation_completed", { primaryFactor: "passkey", optionalFactorsDeferred: ["email", "totp"] });
    return { recoveryCodes };
  }),

  beginTotpSetup: publicProcedure.mutation(async ({ ctx }) => {
    const setup = await readSetupCookie(ctx.req, "totp_setup");
    if (!setup) throw new TRPCError({ code: "UNAUTHORIZED", message: "A ativação expirou. Recomece a partir da passkey." });
    const owner = await getOwnerAccount();
    if (!owner || owner.id !== setup.ownerId) throw new TRPCError({ code: "UNAUTHORIZED" });
    if (!owner.emailVerifiedAt) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Confirme o e-mail institucional antes de configurar a contingência." });

    const totp = new TOTP({ issuer: "Concilium", label: owner.email, algorithm: "SHA1", digits: 6, period: 30 });
    await upsertOwnerMfa({ ownerId: owner.id, totpSecretEncrypted: encryptTotpSecret(totp.secret.base32), recoveryCodesHash: "pending" });
    return { provisioningUri: totp.toString(), manualKey: totp.secret.base32 };
  }),

  confirmTotpAndActivate: publicProcedure.input(z.object({ code: z.string().regex(/^\d{6}$/) })).mutation(async ({ ctx, input }) => {
    const setup = await readSetupCookie(ctx.req, "totp_setup");
    if (!setup) throw new TRPCError({ code: "UNAUTHORIZED", message: "A ativação expirou. Recomece a partir da passkey." });
    const mfa = await getOwnerMfa(setup.ownerId);
    if (!mfa || !mfa.totpSecretEncrypted) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Configure o autenticador antes de confirmar." });
    if ((await getOwnerPasskeys(setup.ownerId)).length < 1) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Registre ao menos uma passkey antes de concluir a ativação." });
    const throttleScope = ownerAuthThrottleScope(ctx.req, "totp_setup", setup.ownerId);
    const throttle = await getOwnerAuthThrottle(throttleScope);
    await assertOwnerAuthNotLocked(ctx, throttleScope, setup.ownerId, "owner.totp_setup");
    const secret = decryptTotpSecret(mfa.totpSecretEncrypted);
    const totp = new TOTP({ issuer: "Concilium", secret, algorithm: "SHA1", digits: 6, period: 30 });
    if (totp.validate({ token: input.code, window: 1 }) === null) {
      await rejectOwnerAuthAttempt(throttleScope, setup.ownerId, "owner.totp_setup_failed", throttle?.failureCount, throttle?.lockedUntil);
    }

    const recoveryCodes = newRecoveryCodes();
    await upsertOwnerMfa({ ownerId: setup.ownerId, totpSecretEncrypted: mfa.totpSecretEncrypted, recoveryCodesHash: hashRecoveryCodes(recoveryCodes) });
    await updateOwnerAccount(setup.ownerId, { state: "active", activatedAt: new Date(), bootstrapCodeRetiredAt: new Date(), failedActivationAttempts: 0 });
    await clearOwnerAuthThrottle(throttleScope);
    await issueOwnerSession(ctx, setup.ownerId);
    clearSetupCookie(ctx.res, ctx.req);
    await recordOwnerAudit(setup.ownerId, "owner.activation_completed", {});
    return { recoveryCodes };
  }),

  beginPasskeyLogin: publicProcedure.mutation(async ({ ctx }) => {
    const owner = await getOwnerAccount();
    if (!owner || owner.state !== "active") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A conta titular ainda não foi ativada." });
    const options = await generateAuthenticationOptions({ rpID: requestRpId(ctx.req), userVerification: "required" });
    await setSetupCookie(ctx.res, ctx.req, { ownerId: owner.id, challenge: options.challenge, purpose: "passkey_authentication", origin: requestOrigin(ctx.req), rpId: requestRpId(ctx.req) });
    return options;
  }),

  finishPasskeyLogin: publicProcedure.input(z.object({ response: z.any() })).mutation(async ({ ctx, input }) => {
    const setup = await readSetupCookie(ctx.req, "passkey_authentication");
    if (!setup) throw new TRPCError({ code: "UNAUTHORIZED", message: "A etapa de acesso expirou. Tente novamente." });
    const credential = await getOwnerPasskey(input.response.id);
    if (!credential || credential.ownerId !== setup.ownerId) throw new TRPCError({ code: "UNAUTHORIZED", message: "Passkey não reconhecida." });
    const verification = await verifyAuthenticationResponse({
      response: input.response,
      expectedChallenge: setup.challenge,
      expectedOrigin: setup.origin,
      expectedRPID: setup.rpId,
      credential: { id: credential.credentialId, publicKey: fromBase64Url(credential.publicKey), counter: credential.counter, transports: credential.transports?.split(",") as any },
      requireUserVerification: true,
    });
    if (!verification.verified) throw new TRPCError({ code: "UNAUTHORIZED", message: "Não foi possível verificar a passkey." });
    const nextCounter = verification.authenticationInfo.newCounter;
    if (credential.counter > 0 && nextCounter <= credential.counter) {
      await recordOwnerAudit(setup.ownerId, "owner.passkey_counter_regression", { credentialId: credential.credentialId });
      throw new TRPCError({ code: "UNAUTHORIZED", message: "A passkey apresentou um contador inesperado. Use a contingência ou registre uma nova credencial." });
    }
    await updateOwnerPasskeyUsage(credential.credentialId, nextCounter);
    await updateOwnerAccount(setup.ownerId, { failedActivationAttempts: 0 });
    await issueOwnerSession(ctx, setup.ownerId);
    clearSetupCookie(ctx.res, ctx.req);
    await recordOwnerAudit(setup.ownerId, "owner.passkey_authenticated", {});
    return { verified: true };
  }),

  useTotpContingency: publicProcedure.input(z.object({ code: z.string().regex(/^\d{6}$/) })).mutation(async ({ ctx, input }) => {
    const owner = await getOwnerAccount();
    if (!owner || owner.state !== "active") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A conta titular ainda não foi ativada." });
    const mfa = await getOwnerMfa(owner.id);
    if (!mfa || !mfa.totpSecretEncrypted) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A contingência ainda não foi configurada." });
    const throttleScope = ownerAuthThrottleScope(ctx.req, "totp_contingency", owner.id);
    const throttle = await getOwnerAuthThrottle(throttleScope);
    await assertOwnerAuthNotLocked(ctx, throttleScope, owner.id, "owner.totp_contingency");
    const totp = new TOTP({ issuer: "Concilium", secret: decryptTotpSecret(mfa.totpSecretEncrypted), algorithm: "SHA1", digits: 6, period: 30 });
    if (totp.validate({ token: input.code, window: 1 }) === null) {
      await rejectOwnerAuthAttempt(throttleScope, owner.id, "owner.totp_contingency_failed", throttle?.failureCount, throttle?.lockedUntil);
    }
    await clearOwnerAuthThrottle(throttleScope);
    await issueOwnerSession(ctx, owner.id);
    await recordOwnerAudit(owner.id, "owner.totp_contingency_authenticated", {});
    return { verified: true };
  }),

  useRecoveryCode: publicProcedure.input(z.object({ code: z.string().trim().min(8).max(128) })).mutation(async ({ ctx, input }) => {
    const owner = await getOwnerAccount();
    if (!owner || owner.state !== "active") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A conta titular ainda não foi ativada." });
    const mfa = await getOwnerMfa(owner.id);
    if (!mfa) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A recuperação ainda não foi configurada." });
    const throttleScope = ownerAuthThrottleScope(ctx.req, "recovery_code", owner.id);
    const throttle = await getOwnerAuthThrottle(throttleScope);
    await assertOwnerAuthNotLocked(ctx, throttleScope, owner.id, "owner.recovery_code");
    let storedHashes: string[];
    try { storedHashes = JSON.parse(mfa.recoveryCodesHash) as string[]; } catch { throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Códigos de recuperação indisponíveis." }); }
    const remainingHashes = consumeRecoveryCodeHash(storedHashes, recoveryCodeHash(input.code));
    if (!remainingHashes) {
      await rejectOwnerAuthAttempt(throttleScope, owner.id, "owner.recovery_code_failed", throttle?.failureCount, throttle?.lockedUntil);
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Código de recuperação inválido ou já utilizado." });
    }
    await upsertOwnerMfa({ ownerId: owner.id, totpSecretEncrypted: mfa.totpSecretEncrypted, recoveryCodesHash: JSON.stringify(remainingHashes), totpConfiguredAt: mfa.totpConfiguredAt });
    await clearOwnerAuthThrottle(throttleScope);
    await issueOwnerSession(ctx, owner.id);
    await recordOwnerAudit(owner.id, "owner.recovery_code_authenticated", { remaining: remainingHashes.length });
    return { verified: true, remainingRecoveryCodes: remainingHashes.length };
  }),

  beginRecoveryCodeRegeneration: ownerProcedure.mutation(async ({ ctx }) => {
    const credentials = await getOwnerPasskeys(ctx.owner.id);
    if (credentials.length < 1) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Registre uma passkey antes de renovar códigos de recuperação." });
    const options = await generateAuthenticationOptions({
      rpID: requestRpId(ctx.req),
      userVerification: "required",
      allowCredentials: credentials.map(credential => ({ id: credential.credentialId, transports: credential.transports?.split(",") as any })),
    });
    await setSetupCookie(ctx.res, ctx.req, { ownerId: ctx.owner.id, challenge: options.challenge, purpose: "recovery_code_regeneration", origin: requestOrigin(ctx.req), rpId: requestRpId(ctx.req) });
    return options;
  }),

  finishRecoveryCodeRegeneration: ownerProcedure.input(z.object({ response: z.any() })).mutation(async ({ ctx, input }) => {
    const setup = await readSetupCookie(ctx.req, "recovery_code_regeneration");
    if (!setup || setup.ownerId !== ctx.owner.id) throw new TRPCError({ code: "UNAUTHORIZED", message: "A confirmação para renovar os códigos expirou. Tente novamente." });
    const credential = await getOwnerPasskey(input.response.id);
    if (!credential || credential.ownerId !== ctx.owner.id) throw new TRPCError({ code: "UNAUTHORIZED", message: "Passkey não reconhecida." });
    const verification = await verifyAuthenticationResponse({
      response: input.response,
      expectedChallenge: setup.challenge,
      expectedOrigin: setup.origin,
      expectedRPID: setup.rpId,
      credential: { id: credential.credentialId, publicKey: fromBase64Url(credential.publicKey), counter: credential.counter, transports: credential.transports?.split(",") as any },
      requireUserVerification: true,
    });
    assertRecoveryCodeRegenerationAuthorized({ setupOwnerId: setup.ownerId, sessionOwnerId: ctx.owner.id, passkeyVerified: verification.verified });
    const nextCounter = verification.authenticationInfo.newCounter;
    if (credential.counter > 0 && nextCounter <= credential.counter) {
      await recordOwnerAudit(ctx.owner.id, "owner.passkey_counter_regression", { credentialId: credential.credentialId, purpose: "recovery_code_regeneration" });
      throw new TRPCError({ code: "UNAUTHORIZED", message: "A passkey apresentou um contador inesperado." });
    }
    const mfa = await getOwnerMfa(ctx.owner.id);
    if (!mfa) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A contingência ainda não foi configurada." });
    const rotation = createRecoveryCodeRotation(mfa.recoveryCodesHash);
    await updateOwnerPasskeyUsage(credential.credentialId, nextCounter);
    await upsertOwnerMfa({ ownerId: ctx.owner.id, totpSecretEncrypted: mfa.totpSecretEncrypted, recoveryCodesHash: rotation.recoveryCodesHash, totpConfiguredAt: mfa.totpConfiguredAt });
    clearSetupCookie(ctx.res, ctx.req);
    await recordOwnerAudit(ctx.owner.id, "owner.recovery_codes_regenerated", { replacedRemaining: rotation.replacedRemaining, issued: rotation.recoveryCodes.length });
    return { recoveryCodes: rotation.recoveryCodes, remainingRecoveryCodes: rotation.recoveryCodes.length };
  }),

  beginApiCredentialReauthentication: ownerProcedure.mutation(async ({ ctx }) => {
    const credentials = await getOwnerPasskeys(ctx.owner.id);
    if (credentials.length < 1) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Registre uma passkey antes de alterar uma credencial de API." });
    const options = await generateAuthenticationOptions({
      rpID: requestRpId(ctx.req),
      userVerification: "required",
      allowCredentials: credentials.map(credential => ({ id: credential.credentialId, transports: credential.transports?.split(",") as any })),
    });
    await setSetupCookie(ctx.res, ctx.req, { ownerId: ctx.owner.id, challenge: options.challenge, purpose: "api_credential_reauthentication", origin: requestOrigin(ctx.req), rpId: requestRpId(ctx.req) });
    return options;
  }),

  finishApiCredentialReauthentication: ownerProcedure.input(z.object({ response: z.any() })).mutation(async ({ ctx, input }) => {
    const setup = await readSetupCookie(ctx.req, "api_credential_reauthentication");
    if (!setup || setup.ownerId !== ctx.owner.id) throw new TRPCError({ code: "UNAUTHORIZED", message: "A confirmação para alterar a credencial expirou. Tente novamente." });
    const credential = await getOwnerPasskey(input.response.id);
    if (!credential || credential.ownerId !== ctx.owner.id) throw new TRPCError({ code: "UNAUTHORIZED", message: "Passkey não reconhecida." });
    const verification = await verifyAuthenticationResponse({
      response: input.response,
      expectedChallenge: setup.challenge,
      expectedOrigin: setup.origin,
      expectedRPID: setup.rpId,
      credential: { id: credential.credentialId, publicKey: fromBase64Url(credential.publicKey), counter: credential.counter, transports: credential.transports?.split(",") as any },
      requireUserVerification: true,
    });
    if (!verification.verified) throw new TRPCError({ code: "UNAUTHORIZED", message: "A confirmação por passkey não foi concluída." });
    const nextCounter = verification.authenticationInfo.newCounter;
    if (credential.counter > 0 && nextCounter <= credential.counter) {
      await recordOwnerAudit(ctx.owner.id, "owner.passkey_counter_regression", { credentialId: credential.credentialId, purpose: "api_credential_reauthentication" });
      throw new TRPCError({ code: "UNAUTHORIZED", message: "A passkey apresentou um contador inesperado." });
    }
    await updateOwnerPasskeyUsage(credential.credentialId, nextCounter);
    await setSetupCookie(ctx.res, ctx.req, { ownerId: ctx.owner.id, challenge: randomBytes(24).toString("base64url"), purpose: "api_credential_update_authorized", origin: setup.origin, rpId: setup.rpId });
    await recordOwnerAudit(ctx.owner.id, "owner.ai_provider_reauth_authorized", {});
    return { authorized: true };
  }),

  logout: ownerProcedure.mutation(async ({ ctx }) => {
    await clearOwnerSession(ctx.res, ctx.req);
    await recordOwnerAudit(ctx.owner.id, "owner.session_revoked", {});
    return { success: true };
  }),

  dashboard: ownerProcedure.query(async ({ ctx }) => {
    const [mfa, passkeys] = await Promise.all([getOwnerMfa(ctx.owner.id), getOwnerPasskeys(ctx.owner.id)]);
    return {
      owner: { displayName: ctx.owner.displayName, email: ctx.owner.email, state: ctx.owner.state, emailVerified: Boolean(ctx.owner.emailVerifiedAt) },
      remainingRecoveryCodes: mfa ? remainingRecoveryCodeCount(mfa.recoveryCodesHash) : 0,
      passkeyCount: passkeys.length,
      totpContingencyConfigured: Boolean(mfa?.totpConfiguredAt),
    };
  }),
});
