import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { knowledgeSearchInput, knowledgeResultSchema } from "@shared/knowledgeService";
import { classifyLibrarianRequest } from "@shared/librarianWorkflow";
import { runLibrarianEnsemble } from "@shared/librarianEnsemble";
import { ownerProcedure, router } from "../_core/trpc";
import { getOwnerCase, getOwnerKnowledgeReference, listOwnerKnowledgeReferences, markOwnerKnowledgeReferenceInArena, recordOwnerAudit, saveOwnerKnowledgeReference } from "../db";
import { searchKnowledgeService } from "../knowledgeClient";
import { redactIdentifiersKeepContext } from "@shared/workspacePolicy";

const referenceInput = z.object({
  caseId: z.string().uuid(),
  result: knowledgeResultSchema,
});
const clauseInput = referenceInput.extend({ clauseDraft: z.string().trim().min(20).max(12_000) });
const referenceIdInput = z.object({ caseId: z.string().uuid(), referenceId: z.string().uuid() });

async function requireKnowledgeCase(ownerId: string, caseId: string) {
  const ownerCase = await getOwnerCase(ownerId, caseId);
  if (!ownerCase) throw new TRPCError({ code: "NOT_FOUND", message: "Caso não encontrado ou não autorizado." });
  return ownerCase;
}

export const knowledgeRouter = router({
  search: ownerProcedure.input(knowledgeSearchInput).mutation(async ({ ctx, input }) => {
    try {
      const routing = classifyLibrarianRequest(input.query, input.researchMode);
      const safeInput = {
        ...input,
        researchMode: routing.mode,
        agentRoles: routing.activeRoles,
        query: redactIdentifiersKeepContext(input.query),
        ...(input.contextSummary ? { contextSummary: redactIdentifiersKeepContext(input.contextSummary) } : {}),
      };
      const ensemble = await runLibrarianEnsemble({
        query: safeInput.query,
        mode: routing.mode,
        agents: routing.activeRoles.map(role => ({
          role,
          search: async () => (await searchKnowledgeService({ ...safeInput, agentRoles: [role] })).results,
        })),
      });
      const failedRoles = ensemble.roleResults.filter(item => item.status === "failed").map(item => item.role);
      await recordOwnerAudit(ctx.owner.id, "owner.knowledge_search", {
        areas: input.areas,
        includeRelated: input.includeRelated,
        researchMode: routing.mode,
        handoffRecommended: routing.handoffRecommended,
        usedCaseContext: Boolean(input.contextSummary),
        resultCount: ensemble.results.length,
        failedRoles,
      });
      return { results: ensemble.results, routing, packet: ensemble.packet, roleResults: ensemble.roleResults, notice: failedRoles.length ? "Alguns papéis do Bibliotecário não responderam; os resultados disponíveis permanecem marcados para conferência." : undefined };
    } catch {
      throw new TRPCError({ code: "BAD_GATEWAY", message: "Não foi possível consultar a biblioteca jurídica agora." });
    }
  }),

  listReferences: ownerProcedure.input(z.object({ caseId: z.string().uuid() })).query(async ({ ctx, input }) => {
    await requireKnowledgeCase(ctx.owner.id, input.caseId);
    return listOwnerKnowledgeReferences(ctx.owner.id, input.caseId);
  }),

  saveReference: ownerProcedure.input(referenceInput).mutation(async ({ ctx, input }) => {
    await requireKnowledgeCase(ctx.owner.id, input.caseId);
    const result = await saveOwnerKnowledgeReference({
      ownerId: ctx.owner.id,
      caseId: input.caseId,
      externalEntryId: input.result.id,
      title: input.result.title,
      summary: input.result.summary,
      sourceTitle: input.result.sourceTitle,
      sourceUrl: input.result.sourceUrl,
      sourceVersion: input.result.sourceVersion,
      country: input.result.country,
      jurisdiction: input.result.jurisdiction,
      authorityLevel: input.result.authorityLevel,
      validityState: input.result.validityState,
      validityCheckedAt: input.result.validityCheckedAt ? new Date(input.result.validityCheckedAt) : null,
      supersededBy: input.result.supersededBy,
      citationsJson: JSON.stringify(input.result.citations),
      actionType: "reference",
    });
    await recordOwnerAudit(ctx.owner.id, "owner.knowledge_reference_saved", { caseId: input.caseId, referenceId: result.id, externalEntryId: input.result.id });
    return result;
  }),

  saveClause: ownerProcedure.input(clauseInput).mutation(async ({ ctx, input }) => {
    await requireKnowledgeCase(ctx.owner.id, input.caseId);
    const result = await saveOwnerKnowledgeReference({
      ownerId: ctx.owner.id,
      caseId: input.caseId,
      externalEntryId: input.result.id,
      title: input.result.title,
      summary: input.result.summary,
      sourceTitle: input.result.sourceTitle,
      sourceUrl: input.result.sourceUrl,
      sourceVersion: input.result.sourceVersion,
      country: input.result.country,
      jurisdiction: input.result.jurisdiction,
      authorityLevel: input.result.authorityLevel,
      validityState: input.result.validityState,
      validityCheckedAt: input.result.validityCheckedAt ? new Date(input.result.validityCheckedAt) : null,
      supersededBy: input.result.supersededBy,
      citationsJson: JSON.stringify(input.result.citations),
      actionType: "clause_compendium",
      clauseDraft: input.clauseDraft,
    });
    await recordOwnerAudit(ctx.owner.id, "owner.knowledge_clause_added", { caseId: input.caseId, referenceId: result.id, status: "requires_refinement" });
    return result;
  }),

  getReference: ownerProcedure.input(referenceIdInput).query(async ({ ctx, input }) => {
    await requireKnowledgeCase(ctx.owner.id, input.caseId);
    return getOwnerKnowledgeReference(ctx.owner.id, input.caseId, input.referenceId);
  }),

  prepareArena: ownerProcedure.input(referenceIdInput).mutation(async ({ ctx, input }) => {
    await requireKnowledgeCase(ctx.owner.id, input.caseId);
    const result = await markOwnerKnowledgeReferenceInArena(ctx.owner.id, input.caseId, input.referenceId);
    if (!result) throw new TRPCError({ code: "NOT_FOUND", message: "Referência não encontrada ou não autorizada." });
    await recordOwnerAudit(ctx.owner.id, "owner.knowledge_reference_prepared_for_arena", { caseId: input.caseId, referenceId: input.referenceId });
    return result;
  }),
});
