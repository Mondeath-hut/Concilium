import { describe, expect, it } from "vitest";
import {
  assertOperationalOwnerIdentity,
  isOperationalOwnerOpenId,
  operationalOpenIdForOwner,
} from "../integration/server/ownerOperationalIdentity";

describe("vínculo titular-operacional", () => {
  it("cria um identificador estável e separado do OAuth", () => {
    const openId = operationalOpenIdForOwner("owner-123");
    expect(openId).toBe("concilium-owner:owner-123");
    expect(isOperationalOwnerOpenId(openId)).toBe(true);
  });

  it("rejeita uma identidade que não pertença ao namespace do Concilium", () => {
    expect(() => assertOperationalOwnerIdentity({
      ownerId: "owner-123",
      operationalUserId: 9,
      openId: "oauth-user-9",
    })).toThrow();
  });
});
