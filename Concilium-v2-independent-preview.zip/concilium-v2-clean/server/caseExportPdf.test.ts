import { PDFDocument } from "pdf-lib";
import { describe, expect, it } from "vitest";
import { buildCaseExportBundle, type ChecklistExportItem } from "../shared/caseExport";
import { buildCaseExportPdf } from "./caseExportPdf";

const checklistItems: ChecklistExportItem[] = [
  { id: "1", groupLabel: "Casa", description: "Uso exclusivo provisório do imóvel em Ananindeua", itemType: "negociavel", priority: "alta", state: "pendente" },
  { id: "2", groupLabel: "Pensão", description: "Valor mínimo intocável — reserva protegida do titular", itemType: "inegociavel_exige_pausa", priority: "critica", state: "pendente" },
];

function sampleBundle() {
  return buildCaseExportBundle({
    caseTitle: "Caso de teste — acentuação e ç, ã, õ",
    currentStage: "equilibrado",
    keyFacts: ["fato número um", "fato número dois com uma frase bem mais longa para forçar quebra de linha automática no PDF"],
    topRisks: ["risco principal"],
    nextSteps: ["marcar próxima reunião"],
    checklistItems,
    formalHistory: [{ id: "doc-1", documentType: "proposta", title: "Proposta inicial", currentStatus: "apresentada", createdAtIso: new Date().toISOString() }],
  });
}

describe("buildCaseExportPdf", () => {
  it("gera bytes que começam com a assinatura %PDF-", async () => {
    const bytes = await buildCaseExportPdf(sampleBundle());
    const header = Buffer.from(bytes.slice(0, 5)).toString("utf8");
    expect(header).toBe("%PDF-");
  });

  it("o PDF gerado é válido e recarregável pela própria pdf-lib", async () => {
    const bytes = await buildCaseExportPdf(sampleBundle());
    const reloaded = await PDFDocument.load(bytes);
    expect(reloaded.getPageCount()).toBeGreaterThan(0);
  });

  it("continua gerando um PDF válido mesmo com checklist e histórico vazios", async () => {
    const emptyBundle = buildCaseExportBundle({
      caseTitle: "Caso vazio",
      currentStage: "cooperativo",
      keyFacts: [], topRisks: [], nextSteps: [],
      checklistItems: [],
      formalHistory: [],
    });
    const bytes = await buildCaseExportPdf(emptyBundle);
    const reloaded = await PDFDocument.load(bytes);
    expect(reloaded.getPageCount()).toBeGreaterThan(0);
  });

  it("quebra em mais de uma página quando o checklist é longo o suficiente", async () => {
    const longChecklist: ChecklistExportItem[] = Array.from({ length: 80 }, (_, index) => ({
      id: `item-${index}`,
      groupLabel: `Grupo ${index}`,
      description: `Descrição bem detalhada do item ${index}, com bastante texto para ocupar espaço vertical na página do PDF gerado.`,
      itemType: "negociavel",
      priority: "normal",
      state: "pendente",
    }));
    const bundle = buildCaseExportBundle({
      caseTitle: "Caso longo",
      currentStage: "equilibrado",
      keyFacts: [], topRisks: [], nextSteps: [],
      checklistItems: longChecklist,
      formalHistory: [],
    });
    const bytes = await buildCaseExportPdf(bundle);
    const reloaded = await PDFDocument.load(bytes);
    expect(reloaded.getPageCount()).toBeGreaterThan(1);
  });
});
