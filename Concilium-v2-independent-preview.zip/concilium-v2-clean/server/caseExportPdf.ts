/**
 * Exportação em PDF de verdade (Manual funcional v2, seção 17), usando pdf-lib.
 *
 * Por que pdf-lib: é puro JavaScript, sem binário nativo (nada de Chromium/Puppeteer
 * embutido), ~1MB de dependência, roda igual em qualquer host — condiz com a filosofia
 * "sem firula" do resto do projeto (nenhuma outra parte do Concilium depende de um
 * navegador headless). Em troca, o layout é desenhado manualmente aqui (pdf-lib não
 * interpreta HTML/CSS), então o texto é sempre selecionável e pesquisável, mas o visual
 * é mais simples que o HTML de `shared/caseExport.ts` (que continua existindo — os dois
 * formatos de exportação coexistem, o titular escolhe qual usar).
 */
import { PDFDocument, PDFFont, PDFPage, StandardFonts, rgb } from "pdf-lib";
import type { CaseExportBundle } from "../shared/caseExport";

const PAGE_WIDTH = 595.28; // A4 em pontos
const PAGE_HEIGHT = 841.89;
const MARGIN = 48;
const CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2;

const ALERT_RGB: Record<"green" | "amber" | "red", ReturnType<typeof rgb>> = {
  green: rgb(0.06, 0.72, 0.51),
  amber: rgb(0.96, 0.62, 0.04),
  red: rgb(0.94, 0.27, 0.27),
};

type Cursor = { page: PDFPage; y: number };

/** Quebra de linha simples por largura real do texto na fonte/tamanho dados. */
function wrapText(text: string, font: PDFFont, size: number, maxWidth: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = candidate;
    }
  }
  if (current) lines.push(current);
  return lines.length > 0 ? lines : [""];
}

export type PdfBuilder = {
  doc: PDFDocument;
  regular: PDFFont;
  bold: PDFFont;
  cursor: Cursor;
};

function newPage(builder: Pick<PdfBuilder, "doc">): Cursor {
  const page = builder.doc.addPage([PAGE_WIDTH, PAGE_HEIGHT]);
  return { page, y: PAGE_HEIGHT - MARGIN };
}

function ensureSpace(builder: PdfBuilder, neededHeight: number) {
  if (builder.cursor.y - neededHeight < MARGIN) {
    builder.cursor = newPage(builder);
  }
}

function writeParagraph(builder: PdfBuilder, text: string, options?: { size?: number; bold?: boolean; gapAfter?: number; color?: ReturnType<typeof rgb> }) {
  const size = options?.size ?? 10.5;
  const font = options?.bold ? builder.bold : builder.regular;
  const lineHeight = size * 1.35;
  const lines = wrapText(text, font, size, CONTENT_WIDTH);

  for (const line of lines) {
    ensureSpace(builder, lineHeight);
    builder.cursor.page.drawText(line, {
      x: MARGIN,
      y: builder.cursor.y - lineHeight,
      size,
      font,
      color: options?.color ?? rgb(0.12, 0.16, 0.22),
    });
    builder.cursor.y -= lineHeight;
  }
  builder.cursor.y -= options?.gapAfter ?? 4;
}

function writeSectionTitle(builder: PdfBuilder, text: string) {
  ensureSpace(builder, 34);
  builder.cursor.y -= 10;
  writeParagraph(builder, text, { size: 13, bold: true, gapAfter: 6 });
  ensureSpace(builder, 4);
  builder.cursor.page.drawLine({
    start: { x: MARGIN, y: builder.cursor.y },
    end: { x: PAGE_WIDTH - MARGIN, y: builder.cursor.y },
    thickness: 0.75,
    color: rgb(0.8, 0.84, 0.89),
  });
  builder.cursor.y -= 10;
}

function writeBulletList(builder: PdfBuilder, items: string[], emptyLabel: string) {
  if (items.length === 0) {
    writeParagraph(builder, `• ${emptyLabel}`, { color: rgb(0.4, 0.45, 0.5) });
    return;
  }
  for (const item of items) writeParagraph(builder, `•  ${item}`);
}

function writeChecklistRow(builder: PdfBuilder, item: CaseExportBundle["checklist"][number]) {
  const size = 9.5;
  const lineHeight = size * 1.4;
  ensureSpace(builder, lineHeight);
  const dotX = MARGIN;
  builder.cursor.page.drawCircle({ x: dotX + 3, y: builder.cursor.y - lineHeight / 2, size: 3, color: ALERT_RGB[item.alertLevel] });
  const text = `${item.groupLabel} — ${item.description} [${item.itemType} · ${item.state}]`;
  const lines = wrapText(text, builder.regular, size, CONTENT_WIDTH - 16);
  for (const [index, line] of lines.entries()) {
    if (index > 0) ensureSpace(builder, lineHeight);
    builder.cursor.page.drawText(line, { x: MARGIN + 14, y: builder.cursor.y - lineHeight, size, font: builder.regular, color: rgb(0.12, 0.16, 0.22) });
    builder.cursor.y -= lineHeight;
  }
}

/**
 * Gera os bytes de um PDF a partir do mesmo `CaseExportBundle` usado na exportação em
 * HTML/JSON — as três exportações sempre descrevem o mesmo conteúdo, só o formato muda.
 */
export async function buildCaseExportPdf(bundle: CaseExportBundle): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.setTitle(bundle.caseTitle);
  doc.setSubject("Exportação Concilium — documento informativo, não substitui o histórico formal do sistema.");
  doc.setProducer("Concilium");

  const regular = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const builder: PdfBuilder = { doc, regular, bold, cursor: newPage({ doc }) };

  writeParagraph(builder, bundle.caseTitle, { size: 18, bold: true, gapAfter: 2 });
  writeParagraph(
    builder,
    `Gerado em ${new Date(bundle.generatedAtIso).toLocaleString("pt-BR")} — documento informativo, não substitui o histórico formal do sistema nem constitui decisão jurídica.`,
    { size: 8.5, color: rgb(0.45, 0.5, 0.56), gapAfter: 10 },
  );

  writeSectionTitle(builder, "Síntese de uma página");
  writeParagraph(builder, `Estágio atual: ${bundle.onePageSynthesis.currentStage}`, { bold: true });
  writeParagraph(builder, "Fatos-chave:");
  writeBulletList(builder, bundle.onePageSynthesis.keyFacts, "Nenhum registrado.");
  writeParagraph(builder, "Principais riscos:");
  writeBulletList(builder, bundle.onePageSynthesis.topRisks, "Nenhum registrado.");
  writeParagraph(builder, "Próximos passos:");
  writeBulletList(builder, bundle.onePageSynthesis.nextSteps, "Nenhum registrado.");

  writeSectionTitle(builder, "Pontos inegociáveis");
  writeBulletList(builder, bundle.inegotiableItems.map(item => item.description), "Nenhum registrado.");

  writeSectionTitle(builder, "Perguntas de audiência");
  writeBulletList(builder, bundle.hearingQuestions.map(item => item.description), "Nenhuma pendente.");

  writeSectionTitle(builder, "Checklist atual");
  if (bundle.checklist.length === 0) {
    writeParagraph(builder, "Nenhum item registrado.", { color: rgb(0.4, 0.45, 0.5) });
  } else {
    for (const item of bundle.checklist) writeChecklistRow(builder, item);
  }

  writeSectionTitle(builder, "Histórico formal da negociação (Mesa Formal)");
  if (bundle.formalHistory.length === 0) {
    writeParagraph(builder, "Nenhum documento registrado.", { color: rgb(0.4, 0.45, 0.5) });
  } else {
    for (const row of bundle.formalHistory) {
      writeParagraph(builder, `${row.title} — ${row.documentType} — ${row.currentStatus} — ${new Date(row.createdAtIso).toLocaleString("pt-BR")}`, { size: 9.5 });
    }
  }

  return doc.save();
}
