import { z } from "zod";
import { ownerProcedure, router } from "./_core/trpc";
import {
  createChecklistItem,
  ingestTranscriptChunk,
  listChecklistItems,
  listScenarioParameters,
  listTranscriptReviews,
  migrateScenarioStage,
  resolveTranscriptReview,
  setScenarioParameter,
  updateChecklistItemState,
} from "./checklistDb";

const scenarioId = z.object({ scenarioId: z.string().min(8).max(64) });

const checklistItemInput = scenarioId.extend({
  caseId: z.string().min(8).max(64),
  groupLabel: z.string().trim().min(2).max(160),
  description: z.string().trim().min(3).max(2_000),
  itemType: z.enum(["negociavel", "inegociavel_exige_pausa", "pendente_de_prova"]),
  priority: z.enum(["critica", "alta", "normal", "baixa"]),
  justification: z.string().trim().max(2_000).optional(),
  riskLevel: z.enum(["baixo", "medio", "alto"]).optional(),
  relatedDocumentId: z.string().max(36).optional(),
  // "dicionário de contexto amplo" deste item (Manual v2, seção 9-A) — usado pela Camada C do matcher.
  canonicalKeywords: z.array(z.string().trim().min(1).max(80)).max(40),
});

const scenarioParameterInput = scenarioId.extend({
  caseId: z.string().min(8).max(64),
  parameterKey: z.string().trim().min(2).max(120),
  label: z.string().trim().min(2).max(200),
  valueType: z.enum(["numeric", "date", "text", "boolean"]),
  minValue: z.string().max(64).optional(),
  idealValue: z.string().max(64).optional(),
  maxValue: z.string().max(64).optional(),
  hardFloor: z.string().max(64).optional(),
  unit: z.string().max(32).optional(),
});

// [NOVO v2 / Fase 0-1] Ainda sem conexão real de IA online/local nesta primeira versão —
// a cascata cai direto para a Camada C (léxica), que já funciona sozinha. Wire dos providers
// online/local fica para quando as Fases seguintes conectarem um modelo de verdade.
export const checklistRouter = router({
  list: ownerProcedure.input(scenarioId).query(({ ctx, input }) =>
    listChecklistItems(ctx.owner.id, input.scenarioId),
  ),

  create: ownerProcedure.input(checklistItemInput).mutation(({ ctx, input }) =>
    createChecklistItem({ ownerId: ctx.owner.id, ...input }),
  ),

  updateState: ownerProcedure.input(z.object({
    checklistItemId: z.string().min(8).max(64),
    nextState: z.enum(["pendente", "aceito", "recusado", "parcialmente_aceito", "substituido", "dependente_confirmacao"]),
  })).mutation(({ ctx, input }) =>
    updateChecklistItemState({ ownerId: ctx.owner.id, checklistItemId: input.checklistItemId, nextState: input.nextState }),
  ),

  setParameter: ownerProcedure.input(scenarioParameterInput).mutation(({ ctx, input }) =>
    setScenarioParameter({ ownerId: ctx.owner.id, ...input }),
  ),

  listParameters: ownerProcedure.input(scenarioId).query(({ ctx, input }) =>
    listScenarioParameters(ctx.owner.id, input.scenarioId),
  ),

  migrateStage: ownerProcedure.input(z.object({
    scenarioId: z.string().min(8).max(64),
    to: z.enum(["cooperativo", "cooperativo_protegido", "equilibrado", "defensivo", "impasse"]),
    reason: z.string().trim().min(8).max(2_000),
  })).mutation(({ ctx, input }) =>
    migrateScenarioStage({ ownerId: ctx.owner.id, scenarioId: input.scenarioId, to: input.to, reason: input.reason, migratedBy: ctx.owner.id }),
  ),

  // Modo ao vivo e modo manual (ditado) chamam a mesma mutation — só muda "source".
  ingestTranscriptChunk: ownerProcedure.input(z.object({
    caseId: z.string().min(8).max(64),
    scenarioId: z.string().min(8).max(64),
    source: z.enum(["audio_ao_vivo", "ditado_manual"]),
    speaker: z.string().max(120).optional(),
    startMs: z.number().int().nonnegative().optional(),
    endMs: z.number().int().nonnegative().optional(),
    textOriginal: z.string().trim().min(1).max(4_000),
    confidence: z.number().min(0).max(1).optional(),
  })).mutation(({ ctx, input }) => ingestTranscriptChunk({ ownerId: ctx.owner.id, ...input })),

  listTranscriptReviews: ownerProcedure.input(z.object({ caseId: z.string().min(8).max(64) })).query(({ ctx, input }) =>
    listTranscriptReviews(ctx.owner.id, input.caseId),
  ),

  resolveTranscriptReview: ownerProcedure.input(z.object({
    reviewId: z.string().min(8).max(64),
    resolution: z.enum(["confirmado", "descartado"]),
  })).mutation(({ ctx, input }) =>
    resolveTranscriptReview({ ownerId: ctx.owner.id, reviewId: input.reviewId, resolution: input.resolution }),
  ),
});
