import { describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.CONCILIUM_BOOTSTRAP_CODE ??= "round2-fictitious-bootstrap-code";
  process.env.CONCILIUM_MFA_ENCRYPTION_KEY ??= "round2-fictitious-mfa-encryption-key-000000000000";
});
import { OWNER_AUTH_FAILURE_LIMIT, OWNER_AUTH_LOCK_WINDOW_MS, assertRecoveryCodeRegenerationAuthorized, consumeRecoveryCodeHash, createRecoveryCodeRotation, isOwnerAuthLocked, nextOwnerAuthThrottle, ownerActivationRouter, remainingRecoveryCodeCount } from "./routers/ownerActivation";

vi.mock("./db", () => ({ getOwnerAccount: vi.fn().mockResolvedValue(undefined) }));

describe("owner activation bootstrap configuration", () => {
  it("exposes configured secrets without revalidating bootstrap after a completed activation", async () => {
    const configuredCode = process.env.CONCILIUM_BOOTSTRAP_CODE;
    const encryptionKey = process.env.CONCILIUM_MFA_ENCRYPTION_KEY;
    expect(configuredCode).toBeTruthy();
    expect(encryptionKey).toBeTruthy();

    const caller = ownerActivationRouter.createCaller({} as never);
    const status = await caller.status();
    const validation = await caller.validateBootstrapCode({ code: configuredCode! });

    expect(status.activationConfigured).toBe(true);
    expect(status.mfaEncryptionConfigured).toBe(true);
    expect(validation.valid).toBe(status.ownerState !== "active");
  });
});

describe("recovery code inventory", () => {
  it("derives remaining quantity from hashes only and fails closed for malformed values", () => {
    expect(remainingRecoveryCodeCount(JSON.stringify(["hash-a", "hash-b", "hash-c"]))).toBe(3);
    expect(remainingRecoveryCodeCount("malformed")).toBe(0);
  });

  it("replaces all prior hashes with ten new recovery codes only after a matching verified passkey", () => {
    const rotation = createRecoveryCodeRotation(JSON.stringify(["old-hash-one", "old-hash-two"]));
    const replacementHashes = JSON.parse(rotation.recoveryCodesHash) as string[];

    expect(rotation.replacedRemaining).toBe(2);
    expect(rotation.recoveryCodes).toHaveLength(10);
    expect(new Set(rotation.recoveryCodes).size).toBe(10);
    expect(replacementHashes).toHaveLength(10);
    expect(replacementHashes).not.toContain("old-hash-one");
    expect(() => assertRecoveryCodeRegenerationAuthorized({ setupOwnerId: "owner-a", sessionOwnerId: "owner-a", passkeyVerified: true })).not.toThrow();
    expect(() => assertRecoveryCodeRegenerationAuthorized({ setupOwnerId: "owner-a", sessionOwnerId: "owner-b", passkeyVerified: true })).toThrow(/passkey/i);
    expect(() => assertRecoveryCodeRegenerationAuthorized({ setupOwnerId: "owner-a", sessionOwnerId: "owner-a", passkeyVerified: false })).toThrow(/passkey/i);
  });

  it("consumes a recovery hash once, decrements inventory and rejects reuse", () => {
    const current = ["a".repeat(64), "b".repeat(64)];
    const afterUse = consumeRecoveryCodeHash(current, "a".repeat(64));

    expect(afterUse).toEqual(["b".repeat(64)]);
    expect(remainingRecoveryCodeCount(JSON.stringify(afterUse))).toBe(1);
    expect(consumeRecoveryCodeHash(afterUse!, "a".repeat(64))).toBeNull();
  });
});

describe("owner activation protections", () => {
  it("locks a credential scope on the fifth failed attempt and resets a previous expired lock window", () => {
    const now = Date.UTC(2026, 7, 20, 21, 0, 0);
    const locked = nextOwnerAuthThrottle(OWNER_AUTH_FAILURE_LIMIT - 1, null, now);
    expect(locked.failureCount).toBe(OWNER_AUTH_FAILURE_LIMIT);
    expect(locked.lockedUntil?.getTime()).toBe(now + OWNER_AUTH_LOCK_WINDOW_MS);
    expect(isOwnerAuthLocked(locked.lockedUntil, now)).toBe(true);

    const retryAfterExpiry = nextOwnerAuthThrottle(OWNER_AUTH_FAILURE_LIMIT, new Date(now - 1), now);
    expect(retryAfterExpiry.failureCount).toBe(1);
    expect(retryAfterExpiry.lockedUntil).toBeNull();
  });
});
