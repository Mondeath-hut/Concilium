import { z } from "zod";
import { ownerProcedure, router } from "./_core/trpc";
import { listChecklistItems } from "./checklistDb";
import { buildCaseExportBundle, exportBundleToJson, exportBundleToPrintableHtml, type ChecklistExportItem } from "../shared/caseExport";
import { buildCaseExportPdf } from "./caseExportPdf";

const proposalRow = z.object({
  id: z.string(),
  documentType: z.enum(["proposta", "contraproposta"]),
  title: z.string(),
  currentStatus: z.enum([
    "rascunho_interno", "apresentada", "recebida", "aceita", "recusada",
    "aceita_parcialmente", "contraproposta_recebida", "substituida", "encerrada",
  ]),
  parentDocumentId: z.string().nullable().optional(),
  createdAtIso: z.string(),
});

/**
 * [NOVO v2 / Fase 4] O checklist vem do sistema "owner" (shared/checklistDb.ts). O
 * histórico formal da Mesa Formal ainda mora no sistema "operational" mais antigo
 * (server/operationalDb.ts) — em vez de forçar um join frágil entre os dois, o
 * cliente passa o histórico já obtido de operationalDocuments.list. Quando os dois
 * sistemas forem unificados, isso pode virar uma busca única no servidor.
 */
export const caseExportRouter = router({
  buildBundle: ownerProcedure.input(z.object({
    scenarioId: z.string().min(8).max(64),
    caseTitle: z.string().trim().min(1).max(220),
    currentStage: z.string().trim().min(1).max(60),
    keyFacts: z.array(z.string().trim().min(1)).max(50),
    topRisks: z.array(z.string().trim().min(1)).max(50),
    nextSteps: z.array(z.string().trim().min(1)).max(50),
    formalHistory: z.array(proposalRow).max(500),
  })).mutation(async ({ ctx, input }) => {
    const items = await listChecklistItems(ctx.owner.id, input.scenarioId);
    const checklistItems: ChecklistExportItem[] = items.map(item => ({
      id: item.id,
      groupLabel: item.groupLabel,
      description: item.description,
      itemType: item.itemType,
      priority: item.priority,
      state: item.state,
      justification: item.justification,
    }));

    const bundle = buildCaseExportBundle({
      caseTitle: input.caseTitle,
      currentStage: input.currentStage,
      keyFacts: input.keyFacts,
      topRisks: input.topRisks,
      nextSteps: input.nextSteps,
      checklistItems,
      formalHistory: input.formalHistory,
    });

    const pdfBytes = await buildCaseExportPdf(bundle);

    return {
      bundle,
      json: exportBundleToJson(bundle),
      printableHtml: exportBundleToPrintableHtml(bundle),
      // [NOVO v2 / Fase 4] base64 — o cliente decodifica e baixa como .pdf (application/pdf)
      pdfBase64: Buffer.from(pdfBytes).toString("base64"),
    };
  }),
});
