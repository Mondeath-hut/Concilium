import { z } from "zod";
import { ownerProcedure, router } from "./_core/trpc";
import { ACTOR_DEFAULT_ACCESS, ACTOR_ROLES, buildActorSystemPrompt, type ActorRole } from "../shared/actorRoles";
import { projectContentForAi } from "../shared/aiForumPolicy";
import { invokeLLM } from "./_core/llm";

const chatMessage = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().trim().min(1).max(8_000),
});

function textFromResult(result: Awaited<ReturnType<typeof invokeLLM>>) {
  const content = result.choices[0]?.message.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) return content.filter(part => part.type === "text").map(part => part.text).join("\n").trim();
  return "A resposta do modelo não trouxe conteúdo textual.";
}

/**
 * [NOVO v2 / Fase 3] Chat por retrato clicável, sem nome próprio — só o papel.
 * Sem estado no servidor por enquanto: o histórico vive no cliente (React) e é reenviado
 * a cada mensagem, igual ao padrão de client/src/components/AIChatBox.tsx. Persistir o
 * histórico é um bom próximo passo, mas não é necessário para o ator responder.
 */
export const actorChatRouter = router({
  roles: ownerProcedure.query(() => ACTOR_ROLES.map(role => ({ role, defaultAccess: ACTOR_DEFAULT_ACCESS[role] }))),

  sendMessage: ownerProcedure.input(z.object({
    role: z.enum(ACTOR_ROLES as unknown as [ActorRole, ...ActorRole[]]),
    title: z.string().trim().min(1).max(220),
    objective: z.string().trim().min(1).max(2_000),
    // Conteúdo bruto do caso — a redação por nível de acesso acontece aqui, nunca no cliente.
    rawCaseContent: z.string().trim().max(60_000),
    history: z.array(chatMessage).max(40),
    message: z.string().trim().min(1).max(4_000),
    modelId: z.string().trim().min(1).max(80).default("claude-sonnet-4-6"),
  })).mutation(async ({ input }) => {
    const visibilityLevel = ACTOR_DEFAULT_ACCESS[input.role];
    const projectedContent = projectContentForAi(input.rawCaseContent, visibilityLevel);
    const systemPrompt = buildActorSystemPrompt({
      role: input.role,
      title: input.title,
      objective: input.objective,
      projectedContent,
      visibilityLevel,
    });

    const result = await invokeLLM({
      model: input.modelId,
      messages: [
        { role: "system", content: systemPrompt },
        ...input.history,
        { role: "user", content: input.message },
      ],
    });

    return { reply: textFromResult(result), visibilityLevel };
  }),
});
