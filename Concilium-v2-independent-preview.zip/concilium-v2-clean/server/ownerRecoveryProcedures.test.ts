import { createHash } from "crypto";
import { beforeEach, describe, expect, it, vi } from "vitest";

const fixtures = vi.hoisted(() => ({
  owner: { id: "owner-test", email: "titular@exemplo.test", displayName: "Titular", state: "active" },
  mfa: { ownerId: "owner-test", totpSecretEncrypted: "ciphertext", recoveryCodesHash: "[]", totpConfiguredAt: new Date() },
  setup: { ownerId: "owner-test", challenge: "challenge", purpose: "recovery_code_regeneration", origin: "https://concilium.test", rpId: "concilium.test" },
}));

const db = vi.hoisted(() => ({
  clearOwnerAuthThrottle: vi.fn(),
  consumeOwnerEmailVerification: vi.fn(),
  createOwnerAccount: vi.fn(),
  createOwnerEmailVerification: vi.fn(),
  createOwnerSession: vi.fn(),
  getOwnerAccount: vi.fn(),
  getOwnerAccountById: vi.fn(),
  getOwnerAuthThrottle: vi.fn(),
  getOwnerMfa: vi.fn(),
  getOwnerPasskey: vi.fn(),
  getOwnerPasskeys: vi.fn(),
  recordOwnerAudit: vi.fn(),
  recordOwnerAuthFailure: vi.fn(),
  revokeOutstandingOwnerEmailVerifications: vi.fn(),
  saveOwnerPasskey: vi.fn(),
  listOwnerCases: vi.fn(),
  updateOwnerPasskeyUsage: vi.fn(),
  upsertOwnerMfa: vi.fn(),
  updateOwnerAccount: vi.fn(),
}));

const ownerAuth = vi.hoisted(() => ({
  getOwnerSession: vi.fn(),
  clearOwnerSession: vi.fn(),
  clearSetupCookie: vi.fn(),
  decryptTotpSecret: vi.fn(() => "totp-secret"),
  encryptTotpSecret: vi.fn((value: string) => value),
  makeSessionId: vi.fn(() => "session-test"),
  requestOrigin: vi.fn(() => "https://concilium.test"),
  requestRpId: vi.fn(() => "concilium.test"),
  setOwnerSession: vi.fn(async () => ({ tokenHash: "token-hash" })),
  setSetupCookie: vi.fn(),
  readSetupCookie: vi.fn(),
}));

const webauthn = vi.hoisted(() => ({
  generateAuthenticationOptions: vi.fn(),
  generateRegistrationOptions: vi.fn(),
  verifyAuthenticationResponse: vi.fn(),
  verifyRegistrationResponse: vi.fn(),
}));

const emailVerification = vi.hoisted(() => ({
  sendOwnerEmailVerification: vi.fn(),
}));

vi.mock("./db", () => db);
vi.mock("./ownerAuth", () => ownerAuth);
vi.mock("@simplewebauthn/server", () => webauthn);
vi.mock("./emailVerification", async importOriginal => ({
  ...(await importOriginal<typeof import("./emailVerification")>()),
  sendOwnerEmailVerification: emailVerification.sendOwnerEmailVerification,
}));

import { ownerActivationRouter } from "./routers/ownerActivation";
import { ownerWorkspaceRouter } from "./routers/ownerWorkspace";

const sha256 = (value: string) => createHash("sha256").update(value, "utf8").digest("hex");
const caller = () => ownerActivationRouter.createCaller({ req: {}, res: {} } as never);
const workspaceCaller = () => ownerWorkspaceRouter.createCaller({ req: {}, res: {} } as never);

describe("owner recovery tRPC procedures", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fixtures.mfa = { ownerId: "owner-test", totpSecretEncrypted: "ciphertext", recoveryCodesHash: "[]", totpConfiguredAt: new Date() };
    fixtures.setup = { ownerId: "owner-test", challenge: "challenge", purpose: "recovery_code_regeneration", origin: "https://concilium.test", rpId: "concilium.test" };
    ownerAuth.getOwnerSession.mockResolvedValue({ owner: fixtures.owner });
    ownerAuth.readSetupCookie.mockResolvedValue(fixtures.setup);
    ownerAuth.setSetupCookie.mockImplementation(async (_res: unknown, _req: unknown, setup: typeof fixtures.setup) => { fixtures.setup = setup; });
    db.getOwnerAccount.mockResolvedValue(fixtures.owner);
    db.getOwnerAccountById.mockResolvedValue(fixtures.owner);
    db.getOwnerAuthThrottle.mockResolvedValue(undefined);
    db.getOwnerMfa.mockImplementation(async () => fixtures.mfa);
    db.upsertOwnerMfa.mockImplementation(async (values: typeof fixtures.mfa) => {
      fixtures.mfa = { ...fixtures.mfa, ...values };
    });
    db.getOwnerPasskeys.mockResolvedValue([{ credentialId: "credential-test", ownerId: "owner-test", publicKey: "", counter: 0, transports: "internal" }]);
    db.getOwnerPasskey.mockResolvedValue({ credentialId: "credential-test", ownerId: "owner-test", publicKey: "", counter: 0, transports: "internal" });
    db.listOwnerCases.mockResolvedValue([]);
    webauthn.generateAuthenticationOptions.mockResolvedValue({ challenge: "challenge", rpId: "concilium.test" });
    webauthn.verifyAuthenticationResponse.mockResolvedValue({ verified: true, authenticationInfo: { newCounter: 1 } });
    emailVerification.sendOwnerEmailVerification.mockResolvedValue({ id: "email-test" });
  });

  it("consumes a valid code once, persists the decrement, issues a session and rejects reuse", async () => {
    const recoveryCode = "RECOVERY-CODE-ONE";
    fixtures.mfa.recoveryCodesHash = JSON.stringify([sha256(recoveryCode), sha256("RECOVERY-CODE-TWO")]);

    await expect(caller().useRecoveryCode({ code: recoveryCode })).resolves.toMatchObject({ verified: true, remainingRecoveryCodes: 1 });
    expect(JSON.parse(fixtures.mfa.recoveryCodesHash)).toHaveLength(1);
    expect(db.createOwnerSession).toHaveBeenCalledWith(expect.objectContaining({ ownerId: "owner-test" }));
    await expect(caller().useRecoveryCode({ code: recoveryCode })).rejects.toThrow(/não foi possível validar/i);
  });

  it("requires WebAuthn reauthentication and persistently replaces prior recovery hashes with ten new ones", async () => {
    fixtures.mfa.recoveryCodesHash = JSON.stringify([sha256("OLD-ONE"), sha256("OLD-TWO")]);

    await expect(caller().beginRecoveryCodeRegeneration()).resolves.toMatchObject({ challenge: "challenge" });
    expect(ownerAuth.setSetupCookie).toHaveBeenCalledWith(expect.anything(), expect.anything(), expect.objectContaining({ purpose: "recovery_code_regeneration", ownerId: "owner-test" }));

    const result = await caller().finishRecoveryCodeRegeneration({ response: { id: "credential-test" } });
    const persistedHashes = JSON.parse(fixtures.mfa.recoveryCodesHash) as string[];
    expect(webauthn.verifyAuthenticationResponse).toHaveBeenCalled();
    expect(result.recoveryCodes).toHaveLength(10);
    expect(result.remainingRecoveryCodes).toBe(10);
    expect(persistedHashes).toHaveLength(10);
    expect(persistedHashes).not.toContain(sha256("OLD-ONE"));
    expect(db.recordOwnerAudit).toHaveBeenCalledWith("owner-test", "owner.recovery_codes_regenerated", expect.objectContaining({ replacedRemaining: 2, issued: 10 }));
  });

  it("authenticates an active owner by passkey and creates a private owner session", async () => {
    await expect(caller().beginPasskeyLogin()).resolves.toMatchObject({ challenge: "challenge" });
    expect(ownerAuth.setSetupCookie).toHaveBeenCalledWith(expect.anything(), expect.anything(), expect.objectContaining({ purpose: "passkey_authentication", ownerId: "owner-test" }));

    await expect(caller().finishPasskeyLogin({ response: { id: "credential-test" } })).resolves.toEqual({ verified: true });
    expect(webauthn.verifyAuthenticationResponse).toHaveBeenCalledWith(expect.objectContaining({ expectedChallenge: "challenge", requireUserVerification: true }));
    expect(db.updateOwnerPasskeyUsage).toHaveBeenCalledWith("credential-test", 1);
    expect(db.createOwnerSession).toHaveBeenCalledWith(expect.objectContaining({ ownerId: "owner-test" }));
    expect(db.recordOwnerAudit).toHaveBeenCalledWith("owner-test", "owner.passkey_authenticated", {});
  });

  it("uses the session emitted after passkey confirmation to authorize the private workspace", async () => {
    let sessionCreated = false;
    db.createOwnerSession.mockImplementation(async () => {
      sessionCreated = true;
    });
    ownerAuth.getOwnerSession.mockImplementation(async () => sessionCreated ? { owner: fixtures.owner } : undefined);

    await caller().beginPasskeyLogin();
    await expect(caller().finishPasskeyLogin({ response: { id: "credential-test" } })).resolves.toEqual({ verified: true });
    await expect(workspaceCaller().listCases()).resolves.toEqual([]);
    expect(db.createOwnerSession).toHaveBeenCalledWith(expect.objectContaining({ ownerId: "owner-test" }));
    expect(db.listOwnerCases).toHaveBeenCalledWith("owner-test");
  });

  it("revokes the prior email link before securely resending a replacement during setup", async () => {
    fixtures.owner = { ...fixtures.owner, state: "setup_pending", emailVerifiedAt: null } as typeof fixtures.owner;
    fixtures.setup = { ...fixtures.setup, purpose: "totp_setup" };
    db.getOwnerAccountById.mockResolvedValue(fixtures.owner);
    const result = await caller().resendEmailConfirmation();

    expect(result).toMatchObject({ email: "titular@exemplo.test", alreadyVerified: false });
    expect(db.revokeOutstandingOwnerEmailVerifications).toHaveBeenCalledWith("owner-test");
    expect(db.createOwnerEmailVerification).toHaveBeenCalledWith(expect.objectContaining({ ownerId: "owner-test", tokenHash: expect.stringMatching(/^[a-f0-9]{64}$/), expiresAt: expect.any(Date) }));
    expect(emailVerification.sendOwnerEmailVerification).toHaveBeenCalledWith(expect.objectContaining({ to: "titular@exemplo.test", verificationLink: expect.stringContaining("/confirmar-email?token=") }));
  });

  it("rejects an expired confirmation token without changing the owner record", async () => {
    db.consumeOwnerEmailVerification.mockResolvedValue(undefined);
    await expect(caller().confirmEmailVerification({ token: "x".repeat(43) })).rejects.toThrow(/inválido, expirou ou já foi utilizado/i);
    expect(db.updateOwnerAccount).not.toHaveBeenCalled();
  });

  it("confirms an email once and rejects reuse of its already-consumed token", async () => {
    fixtures.owner = { ...fixtures.owner, state: "setup_pending", emailVerifiedAt: null } as typeof fixtures.owner;
    let consumed = false;
    db.consumeOwnerEmailVerification.mockImplementation(async () => {
      if (consumed) return undefined;
      consumed = true;
      return { ownerId: "owner-test" };
    });

    await expect(caller().confirmEmailVerification({ token: "x".repeat(43) })).resolves.toEqual({ verified: true, email: "titular@exemplo.test" });
    expect(db.updateOwnerAccount).toHaveBeenCalledWith("owner-test", expect.objectContaining({ emailVerifiedAt: expect.any(Date) }));
    await expect(caller().confirmEmailVerification({ token: "x".repeat(43) })).rejects.toThrow(/inválido, expirou ou já foi utilizado/i);
  });
});
