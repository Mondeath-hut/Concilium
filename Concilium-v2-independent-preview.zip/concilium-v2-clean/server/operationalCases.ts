import { z } from "zod";
import { ownerOperationalProcedure, router } from "./_core/trpc";
import { createOperationalCase, createOperationalStrategy, getOperationalCaseOverview, listOperationalCases } from "./operationalDb";

const caseInput = z.object({
  title: z.string().trim().min(3).max(180),
  description: z.string().trim().max(2_000).optional(),
});

/**
 * First operational slice of the V1 domain under the V2 owner session.
 * Further document/negotiation procedures will be added only after this
 * identity boundary is covered by tests.
 */
export const operationalCasesRouter = router({
  list: ownerOperationalProcedure.query(({ ctx }) =>
    listOperationalCases(ctx.operationalIdentity.operationalUserId),
  ),

  create: ownerOperationalProcedure.input(caseInput).mutation(async ({ ctx, input }) => {
    const caseId = await createOperationalCase({
      title: input.title,
      description: input.description,
      ownerId: ctx.operationalIdentity.operationalUserId,
    });
    return { caseId };
  }),

  overview: ownerOperationalProcedure.input(z.object({ caseId: z.string().min(8).max(36) })).query(({ ctx, input }) =>
    getOperationalCaseOverview(ctx.operationalIdentity.operationalUserId, input.caseId),
  ),

  createStrategy: ownerOperationalProcedure.input(z.object({
    caseId: z.string().min(8).max(36),
    title: z.string().trim().min(3).max(200),
    notes: z.string().trim().max(10_000).optional(),
  })).mutation(({ ctx, input }) => createOperationalStrategy({
    userId: ctx.operationalIdentity.operationalUserId,
    caseId: input.caseId,
    title: input.title,
    notes: input.notes,
  })),
});
