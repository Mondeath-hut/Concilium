import { beforeEach, describe, expect, it, vi } from "vitest";

const fixtures = vi.hoisted(() => ({
  owner: { id: "owner-workspace", email: "titular@exemplo.test", displayName: "Titular", state: "active" },
  ownerCase: { id: "a7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20", ownerId: "owner-workspace", title: "Acordo patrimonial", summary: "Caso reservado" },
  auditEvents: [
    { id: "a7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a21", ownerId: "owner-workspace", eventType: "owner.passkey_authenticated", metadata: "{\"secret\":\"never-returned\"}", createdAt: new Date("2026-08-21T08:00:00.000Z") },
    { id: "a7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a22", ownerId: "owner-workspace", eventType: "owner.case_created", metadata: "{\"caseId\":\"private\"}", createdAt: new Date("2026-08-20T08:00:00.000Z") },
  ],
}));

const db = vi.hoisted(() => ({
  createOwnerCase: vi.fn(),
  createOwnerCaseAsset: vi.fn(),
  createOwnerCaseDocument: vi.fn(),
  createOwnerCaseMemorialEntry: vi.fn(),
  createOwnerCaseNegotiationScenario: vi.fn(),
  createOwnerCaseStrategy: vi.fn(),
  createOwnerAiAnalysisRun: vi.fn(),
  createOwnerAiAnalysisExecution: vi.fn(),
  completeOwnerAiAnalysisExecution: vi.fn(),
  createOwnerAiArenaSession: vi.fn(),
  createOwnerAiRoundMessage: vi.fn(),
  listOwnerAiArenaSessions: vi.fn(),
  decideOwnerAiAnalysisRun: vi.fn(),
  getOwnerCase: vi.fn(),
  getOwnerCaseDocument: vi.fn(),
  getOwnerAiAnalysisRun: vi.fn(),
  listOwnerAuditEvents: vi.fn(),
  listOwnerAiAnalysisRuns: vi.fn(),
  listOwnerCaseAssets: vi.fn(),
  listOwnerCaseDocuments: vi.fn(),
  listOwnerCaseMemorialEntries: vi.fn(),
  listOwnerCaseNegotiationScenarios: vi.fn(),
  listOwnerCases: vi.fn(),
  listOwnerCaseStrategies: vi.fn(),
  recordOwnerAudit: vi.fn(),
}));

const ownerAuth = vi.hoisted(() => ({ getOwnerSession: vi.fn() }));
const storage = vi.hoisted(() => ({ storageGetSignedUrl: vi.fn() }));
const llm = vi.hoisted(() => ({ invokeLLM: vi.fn(), listLLMModels: vi.fn() }));

vi.mock("./db", () => db);
vi.mock("./ownerAuth", () => ownerAuth);
vi.mock("./storage", () => storage);
vi.mock("./_core/llm", () => llm);

import { isCaseHistoryAuditEvent, ownerWorkspaceRouter } from "./routers/ownerWorkspace";

const caller = () => ownerWorkspaceRouter.createCaller({ req: {}, res: {} } as never);

describe("owner workspace tRPC procedures", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    ownerAuth.getOwnerSession.mockResolvedValue({ owner: fixtures.owner });
    db.listOwnerCases.mockResolvedValue([fixtures.ownerCase]);
    db.createOwnerCase.mockResolvedValue(fixtures.ownerCase);
    db.getOwnerCase.mockResolvedValue(fixtures.ownerCase);
    db.getOwnerCaseDocument.mockResolvedValue(undefined);
    storage.storageGetSignedUrl.mockResolvedValue("https://storage.example.test/temporary-download");
    db.listOwnerCaseStrategies.mockResolvedValue([]);
    db.listOwnerCaseMemorialEntries.mockResolvedValue([]);
    db.listOwnerCaseAssets.mockResolvedValue([]);
    db.listOwnerCaseDocuments.mockResolvedValue([]);
    db.listOwnerCaseNegotiationScenarios.mockResolvedValue([]);
    db.listOwnerAuditEvents.mockResolvedValue(fixtures.auditEvents);
    db.listOwnerAiAnalysisRuns.mockResolvedValue([]);
    db.createOwnerAiArenaSession.mockResolvedValue({ id: "session-ai-test" });
    db.createOwnerAiRoundMessage.mockResolvedValue({ id: "round-message-test" });
    db.listOwnerAiArenaSessions.mockResolvedValue([]);
    llm.listLLMModels.mockResolvedValue({ data: [{ id: "modelo-integrado" }] });
    llm.invokeLLM.mockResolvedValue({ choices: [{ message: { content: "Resposta técnica sob revisão humana." } }] });
  });

  it("lists and creates cases scoped to the authenticated owner", async () => {
    await expect(caller().listCases()).resolves.toEqual([fixtures.ownerCase]);
    expect(db.listOwnerCases).toHaveBeenCalledWith("owner-workspace");

    await expect(caller().createCase({ title: "Acordo patrimonial", summary: "Caso reservado" })).resolves.toEqual(fixtures.ownerCase);
    expect(db.createOwnerCase).toHaveBeenCalledWith(expect.objectContaining({ ownerId: "owner-workspace" }));
    expect(db.recordOwnerAudit).toHaveBeenCalledWith("owner-workspace", "owner.case_created", expect.objectContaining({ caseId: fixtures.ownerCase.id }));
  });

  it("never exposes a case that is not owned by the active titular", async () => {
    db.getOwnerCase.mockResolvedValue(undefined);
    await expect(caller().caseOverview({ caseId: fixtures.ownerCase.id })).rejects.toThrow(/não encontrado ou não autorizado/i);
    expect(db.listOwnerCaseStrategies).not.toHaveBeenCalled();
    expect(db.listOwnerCaseMemorialEntries).not.toHaveBeenCalled();
    expect(db.listOwnerCaseAssets).not.toHaveBeenCalled();
    expect(db.listOwnerCaseDocuments).not.toHaveBeenCalled();
    expect(db.listOwnerCaseNegotiationScenarios).not.toHaveBeenCalled();
  });

  it("returns traced case records only after validating titular ownership", async () => {
    const memorialEntry = { id: "memorial-1", title: "Marco temporal", sourceReference: "Fonte autorizada", reviewStatus: "pending_review" };
    const asset = { id: "asset-1", title: "Referência patrimonial", sourceReference: "Anexo autorizado", reviewStatus: "pending_review" };
    const document = {
      id: "document-1",
      title: "Comprovante",
      sourceReference: "Anexo autorizado",
      reviewStatus: "pending_review",
      storageKey: "concilium-private/owner-workspace/file.pdf",
      contentHash: "internal-content-hash",
    };
    const scenario = { id: "scenario-1", title: "Cenário técnico", sourceReference: "Minuta autorizada", reviewStatus: "draft" };
    db.listOwnerCaseMemorialEntries.mockResolvedValue([memorialEntry]);
    db.listOwnerCaseAssets.mockResolvedValue([asset]);
    db.listOwnerCaseDocuments.mockResolvedValue([document]);
    db.listOwnerCaseNegotiationScenarios.mockResolvedValue([scenario]);

    const result = await caller().caseOverview({ caseId: fixtures.ownerCase.id });

    expect(result).toMatchObject({
      ownerCase: fixtures.ownerCase,
      memorialEntries: [memorialEntry],
      assets: [asset],
      documents: [{ id: document.id, title: document.title, hasStoredFile: true }],
      scenarios: [scenario],
    });
    expect(JSON.stringify(result.documents)).not.toContain("concilium-private");
    expect(JSON.stringify(result.documents)).not.toContain("internal-content-hash");
    expect(db.getOwnerCase).toHaveBeenCalledWith("owner-workspace", fixtures.ownerCase.id);
    expect(db.listOwnerCaseMemorialEntries).toHaveBeenCalledWith("owner-workspace", fixtures.ownerCase.id);
    expect(db.listOwnerCaseAssets).toHaveBeenCalledWith("owner-workspace", fixtures.ownerCase.id);
    expect(db.listOwnerCaseDocuments).toHaveBeenCalledWith("owner-workspace", fixtures.ownerCase.id);
    expect(db.listOwnerCaseNegotiationScenarios).toHaveBeenCalledWith("owner-workspace", fixtures.ownerCase.id);
  });

  it("scopes the case-history audit to the authenticated titular and omits sensitive metadata", async () => {
    const result = await caller().audit({ limit: 5, cursor: { id: fixtures.auditEvents[0].id, createdAt: fixtures.auditEvents[0].createdAt } });

    expect(db.listOwnerAuditEvents).toHaveBeenCalledWith("owner-workspace", expect.objectContaining({ limit: 5, cursor: expect.objectContaining({ id: fixtures.auditEvents[0].id }) }));
    expect(result.events).toEqual([fixtures.auditEvents[1]].map(({ id, eventType, createdAt }) => ({ id, eventType, createdAt })));
    expect(JSON.stringify(result)).not.toContain("never-returned");
    expect(result.nextCursor).toBeNull();
  });

  it("classifies only events explicitly associated with a case as case history", () => {
    expect(isCaseHistoryAuditEvent("owner.case_created")).toBe(true);
    expect(isCaseHistoryAuditEvent("owner.case_strategy_created")).toBe(true);
    expect(isCaseHistoryAuditEvent("owner.passkey_authenticated")).toBe(false);
    expect(isCaseHistoryAuditEvent("owner.activation_completed")).toBe(false);
  });

  it("emits a temporary download URL only for a stored document owned by the active titular", async () => {
    db.getOwnerCaseDocument.mockResolvedValue({
      id: "b7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20",
      storageKey: "private/internal-key.pdf",
      contentHash: "never-returned",
    });

    await expect(caller().requestDocumentAccess({
      caseId: fixtures.ownerCase.id,
      documentId: "b7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20",
    })).resolves.toEqual({ url: "https://storage.example.test/temporary-download" });

    expect(db.getOwnerCaseDocument).toHaveBeenCalledWith("owner-workspace", fixtures.ownerCase.id, "b7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20");
    expect(storage.storageGetSignedUrl).toHaveBeenCalledWith("private/internal-key.pdf");
    expect(db.recordOwnerAudit).toHaveBeenCalledWith("owner-workspace", "owner.case_document_accessed", expect.objectContaining({ caseId: fixtures.ownerCase.id }));
    expect(JSON.stringify(await caller().requestDocumentAccess({ caseId: fixtures.ownerCase.id, documentId: "b7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20" }))).not.toContain("internal-key");
  });

  it("rejects an unavailable or unowned document before requesting a storage URL", async () => {
    await expect(caller().requestDocumentAccess({
      caseId: fixtures.ownerCase.id,
      documentId: "c7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20",
    })).rejects.toThrow(/não encontrado|não autorizado|não armazenado/i);
    expect(storage.storageGetSignedUrl).not.toHaveBeenCalled();
  });

  it("exige consentimento, valida o modelo e persiste somente hashes em uma rodada de IA do caso titular", async () => {
    const runId = "d7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20";
    const executionId = "e7b2f5d3-2a0c-4c0f-9a2a-0c2d5d2f6a20";
    const run = { id: runId, title: "Revisão técnica", executions: [] };
    db.createOwnerAiAnalysisRun.mockResolvedValue({ id: runId });
    db.createOwnerAiAnalysisExecution.mockResolvedValue({ id: executionId });
    db.getOwnerAiAnalysisRun.mockResolvedValue(run);
    const sourceContent = "Conteúdo privado autorizado para revisão técnica e confirmação de lacunas documentais.";

    await expect(caller().runAiCommittee({
      caseId: fixtures.ownerCase.id,
      title: "Revisão técnica",
      objective: "Identificar lacunas documentais e perguntas para validação humana.",
      sourceContent,
      visibilityLevel: "contexto_protegido",
      modelIds: ["modelo-integrado"],
      consentConfirmed: true,
    })).resolves.toEqual(run);

    expect(db.createOwnerAiAnalysisRun).toHaveBeenCalledWith(expect.objectContaining({ ownerId: "owner-workspace", caseId: fixtures.ownerCase.id, originalContentHash: expect.any(String) }));
    expect(JSON.stringify(db.createOwnerAiAnalysisRun.mock.calls)).not.toContain(sourceContent);
    expect(db.createOwnerAiAnalysisExecution).toHaveBeenCalledWith(expect.objectContaining({ promptHash: expect.any(String), transmittedContentHash: expect.any(String) }));
    expect(llm.invokeLLM).toHaveBeenCalledWith(expect.objectContaining({ model: "modelo-integrado" }));
    expect(db.completeOwnerAiAnalysisExecution).toHaveBeenCalledWith({ executionId, responseBody: "Resposta técnica sob revisão humana." });
    expect(db.recordOwnerAudit).toHaveBeenCalledWith("owner-workspace", "owner.case_ai_run_created", expect.objectContaining({ caseId: fixtures.ownerCase.id, executionCount: 1 }));
  });
});
