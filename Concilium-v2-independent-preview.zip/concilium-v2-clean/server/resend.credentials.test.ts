import { describe, expect, it } from "vitest";

describe("Resend credentials", () => {
  it.skipIf(!process.env.RESEND_API_KEY || !process.env.RESEND_FROM_EMAIL)("autentica a chave configurada ao consultar os domínios permitidos", async () => {
    const apiKey = process.env.RESEND_API_KEY;
    const from = process.env.RESEND_FROM_EMAIL;
    expect(apiKey, "RESEND_API_KEY deve estar configurada quando o teste de integração estiver habilitado").toBeTruthy();
    expect(from, "RESEND_FROM_EMAIL deve estar configurado quando o teste de integração estiver habilitado").toBeTruthy();

    const response = await fetch("https://api.resend.com/domains", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    expect(response.ok, `Resend recusou a credencial (HTTP ${response.status})`).toBe(true);
    const payload = await response.json() as { data?: Array<{ name?: string; status?: string }> };
    const senderAddress = from!.match(/<([^>]+)>/)?.[1] ?? from!;
    const senderDomain = senderAddress.split("@")[1]?.toLowerCase();
    expect(senderDomain, "RESEND_FROM_EMAIL deve conter um endereço de e-mail válido").toBeTruthy();
    const isAuthorizedTestSender = senderAddress.toLowerCase() === "onboarding@resend.dev";
    const hasVerifiedSenderDomain = payload.data?.some(domain => domain.name?.toLowerCase() === senderDomain && domain.status === "verified");
    expect(isAuthorizedTestSender || hasVerifiedSenderDomain, `O domínio do remetente ${senderDomain} precisa estar verificado no Resend, exceto pelo remetente temporário autorizado`).toBe(true);
  }, 15_000);
});
