import { describe, expect, it } from "vitest";
import { createSecretVaultRecord, decryptSecretForVault, encryptSecretForVault } from "./secretVault";

describe("cofre de segredos", () => {
  const vaultKey = "chave-de-teste-nao-real-com-mais-de-32-caracteres";

  it("cifra e recupera somente com a chave correta", () => {
    const encrypted = encryptSecretForVault("segredo-de-teste", vaultKey);
    expect(encrypted).not.toContain("segredo-de-teste");
    expect(decryptSecretForVault(encrypted, vaultKey)).toBe("segredo-de-teste");
    expect(() => decryptSecretForVault(encrypted, "outra-chave-tambem-nao-real".padEnd(32, "x"))).toThrow();
  });

  it("retorna registro sem valor em claro", () => {
    const record = createSecretVaultRecord({ name: "TEST_SECRET", consumer: "ai_context", secret: "valor-ficticio", vaultKey });
    expect(record.encryptedValue).not.toContain("valor-ficticio");
    expect(record).not.toHaveProperty("secret");
    expect(record.consumer).toBe("ai_context");
  });

  // [NOVO v2 / Fase 2] a derivação passou de SHA-256 simples para PBKDF2 com sal.
  it("cada registro novo usa um sal diferente, mesmo para o mesmo segredo e a mesma chave", () => {
    const a = encryptSecretForVault("mesmo-segredo", vaultKey);
    const b = encryptSecretForVault("mesmo-segredo", vaultKey);
    expect(a).not.toBe(b); // sal e IV aleatórios -> ciphertext diferente
    expect(decryptSecretForVault(a, vaultKey)).toBe("mesmo-segredo");
    expect(decryptSecretForVault(b, vaultKey)).toBe("mesmo-segredo");
  });

  it("registro novo usa o prefixo sv2 (versão com sal)", () => {
    const encrypted = encryptSecretForVault("segredo-de-teste", vaultKey);
    expect(encrypted.startsWith("sv2.")).toBe(true);
  });

  it("ainda decifra um registro antigo (sv1, sem sal) gravado antes da Fase 2", async () => {
    const { createCipheriv, createHash, randomBytes } = await import("node:crypto");
    const legacyKey = createHash("sha256").update(vaultKey, "utf8").digest();
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", legacyKey, iv);
    const ciphertext = Buffer.concat([cipher.update("segredo-legado", "utf8"), cipher.final()]);
    const legacyRecord = ["sv1", iv, cipher.getAuthTag(), ciphertext].map(part => part.toString("base64url")).join(".");

    expect(decryptSecretForVault(legacyRecord, vaultKey)).toBe("segredo-legado");
  });
});
