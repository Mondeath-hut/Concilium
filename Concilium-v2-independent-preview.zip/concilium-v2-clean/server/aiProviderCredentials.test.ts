import { describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY ??= "round2-fictitious-ai-credential-key-000000000000";
});
import { decryptAiProviderCredential, encryptAiProviderCredential } from "./ownerAuth";

type ProviderProbe = {
  name: string;
  secret: string | undefined;
  url: string;
  headers?: Record<string, string>;
};

const probes: ProviderProbe[] = [
  { name: "DeepSeek", secret: process.env.DEEPSEEK_API_KEY, url: "https://api.deepseek.com/models" },
  { name: "Groq", secret: process.env.GROQ_API_KEY, url: "https://api.groq.com/openai/v1/models" },
  { name: "Mistral", secret: process.env.MISTRAL_API_KEY, url: "https://api.mistral.ai/v1/models" },
  { name: "OpenRouter", secret: process.env.OPENROUTER_API_KEY, url: "https://openrouter.ai/api/v1/models" },
  { name: "Cohere", secret: process.env.COHERE_API_KEY, url: "https://api.cohere.com/v1/models" },
  { name: "Hugging Face", secret: process.env.HUGGINGFACE_API_KEY, url: "https://huggingface.co/api/whoami-v2" },
];

describe("credenciais do Comitê de IA", () => {
  it("cifra e recupera uma credencial de teste com a chave exclusiva do cofre", () => {
    expect(process.env.CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY?.length ?? 0).toBeGreaterThanOrEqual(32);
    const probe = "credencial-de-teste-nao-publicada";
    const encrypted = encryptAiProviderCredential(probe);
    expect(encrypted).not.toContain(probe);
    expect(decryptAiProviderCredential(encrypted)).toBe(probe);
  });

  it.each(probes.map(probe => [probe.name, probe]))("valida acesso de leitura ao catálogo de %s", async (_name, probe) => {
    if (!probe.secret) {
      expect(probe.secret, `${probe.name}: provedor mantido inativo até receber uma chave substituta`).toBeFalsy();
      return;
    }

    const response = await fetch(probe.url, {
      headers: {
        Authorization: `Bearer ${probe.secret}`,
        ...(probe.headers ?? {}),
      },
      signal: AbortSignal.timeout(15_000),
    });

    expect(response.ok, `${probe.name}: catálogo recusado com HTTP ${response.status}`).toBe(true);
  }, 20_000);
});
