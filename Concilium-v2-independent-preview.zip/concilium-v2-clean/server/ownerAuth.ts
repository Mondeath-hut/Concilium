import { createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { parse } from "cookie";
import { SignJWT, jwtVerify } from "jose";
import { getActiveOwnerSession, getOwnerAccountById, revokeOwnerSession } from "./db";

export const OWNER_SESSION_COOKIE = "concilium_owner_session";
export const OWNER_SETUP_COOKIE = "concilium_owner_setup";
const ISSUER = "concilium-owner-auth";

type SetupCookie = {
  ownerId: string;
  challenge: string;
  purpose: "passkey_registration" | "passkey_authentication" | "totp_setup" | "recovery_code_regeneration" | "api_credential_reauthentication" | "api_credential_update_authorized";
  origin: string;
  rpId: string;
};

type OwnerSessionPayload = { ownerId: string; sessionId: string };

function sessionSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("A chave de sessão não está configurada.");
  return new TextEncoder().encode(secret);
}

function cookieOptions(req: Request) {
  const forwardedProto = String(req.headers["x-forwarded-proto"] ?? "");
  const secure = req.secure || forwardedProto.split(",").some(value => value.trim() === "https") || process.env.NODE_ENV === "production";
  return { httpOnly: true, secure, sameSite: "lax" as const, path: "/" };
}

function readCookie(req: Request, name: string) {
  return parse(req.headers.cookie ?? "")[name];
}

export function requestOrigin(req: Request) {
  const origin = req.headers.origin;
  if (typeof origin === "string" && origin.startsWith("http")) return origin;
  const proto = String(req.headers["x-forwarded-proto"] ?? (req.secure ? "https" : "http")).split(",")[0].trim();
  const host = String(req.headers.host ?? "localhost:3000");
  return `${proto}://${host}`;
}

export function requestRpId(req: Request) {
  return new URL(requestOrigin(req)).hostname;
}

async function sign(payload: Record<string, unknown>, expiresIn: string) {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuer(ISSUER)
    .setIssuedAt()
    .setExpirationTime(expiresIn)
    .sign(sessionSecret());
}

async function verify<T>(token: string | undefined): Promise<T | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, sessionSecret(), { issuer: ISSUER, algorithms: ["HS256"] });
    return payload as T;
  } catch {
    return null;
  }
}

export async function setSetupCookie(res: Response, req: Request, payload: SetupCookie) {
  const token = await sign({ ...payload, scope: "owner_setup" }, "10m");
  res.cookie(OWNER_SETUP_COOKIE, token, { ...cookieOptions(req), maxAge: 10 * 60 * 1000 });
}

export async function readSetupCookie(req: Request, purpose: SetupCookie["purpose"]) {
  const payload = await verify<(SetupCookie & { scope?: string })>(readCookie(req, OWNER_SETUP_COOKIE));
  if (!payload || payload.scope !== "owner_setup" || payload.purpose !== purpose || !payload.ownerId || !payload.challenge) return null;
  return payload;
}

export function clearSetupCookie(res: Response, req: Request) {
  res.clearCookie(OWNER_SETUP_COOKIE, cookieOptions(req));
}

export function hashSessionToken(token: string) {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

export async function setOwnerSession(res: Response, req: Request, payload: OwnerSessionPayload) {
  const token = await sign({ ...payload, scope: "owner_session" }, "12h");
  res.cookie(OWNER_SESSION_COOKIE, token, { ...cookieOptions(req), maxAge: 12 * 60 * 60 * 1000 });
  return { token, tokenHash: hashSessionToken(token) };
}

export async function getOwnerSession(req: Request) {
  const rawToken = readCookie(req, OWNER_SESSION_COOKIE);
  const payload = await verify<(OwnerSessionPayload & { scope?: string })>(rawToken);
  if (!payload || payload.scope !== "owner_session" || !payload.ownerId || !payload.sessionId || !rawToken) return null;

  const session = await getActiveOwnerSession(payload.sessionId);
  if (!session || !timingSafeEqual(Buffer.from(hashSessionToken(rawToken), "hex"), Buffer.from(session.tokenHash, "hex"))) return null;

  const owner = await getOwnerAccountById(payload.ownerId);
  if (!owner || owner.state !== "active") return null;
  return { owner, session };
}

export async function clearOwnerSession(res: Response, req: Request) {
  const session = await getOwnerSession(req);
  if (session) await revokeOwnerSession(session.session.id);
  res.clearCookie(OWNER_SESSION_COOKIE, cookieOptions(req));
}

function encryptionKey() {
  const configured = process.env.CONCILIUM_MFA_ENCRYPTION_KEY;
  if (!configured || configured.length < 32) throw new Error("A chave de cifragem de MFA está ausente ou é curta demais.");
  return createHash("sha256").update(configured, "utf8").digest();
}

function aiCredentialEncryptionKey() {
  const configured = process.env.CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY;
  if (!configured || configured.length < 32) throw new Error("A chave de cifragem do cofre de IA está ausente ou é curta demais.");
  return createHash("sha256").update(configured, "utf8").digest();
}

function aiContextEncryptionKey() {
  const configured = process.env.CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY ?? process.env.CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY;
  if (!configured || configured.length < 32) throw new Error("A chave de cifragem do contexto de IA está ausente ou é curta demais.");
  return createHash("sha256").update(configured, "utf8").digest();
}

export function encryptAiContext(context: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", aiContextEncryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(context, "utf8"), cipher.final()]);
  return [iv, cipher.getAuthTag(), ciphertext].map(part => part.toString("base64url")).join(".");
}

export function decryptAiContext(encrypted: string) {
  const [ivValue, tagValue, ciphertextValue] = encrypted.split(".");
  if (!ivValue || !tagValue || !ciphertextValue) throw new Error("Contexto de IA cifrado inválido.");
  const decipher = createDecipheriv("aes-256-gcm", aiContextEncryptionKey(), Buffer.from(ivValue, "base64url"));
  decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertextValue, "base64url")), decipher.final()]).toString("utf8");
}

export function encryptAiProviderCredential(secret: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", aiCredentialEncryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return [iv, cipher.getAuthTag(), ciphertext].map(part => part.toString("base64url")).join(".");
}

export function decryptAiProviderCredential(encrypted: string) {
  const [ivValue, tagValue, ciphertextValue] = encrypted.split(".");
  if (!ivValue || !tagValue || !ciphertextValue) throw new Error("Credencial de provedor cifrada inválida.");
  const decipher = createDecipheriv("aes-256-gcm", aiCredentialEncryptionKey(), Buffer.from(ivValue, "base64url"));
  decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertextValue, "base64url")), decipher.final()]).toString("utf8");
}

export function encryptTotpSecret(secret: string) {
  const iv = Buffer.from(crypto.getRandomValues(new Uint8Array(12)));
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, ciphertext].map(part => part.toString("base64url")).join(".");
}

export function decryptTotpSecret(encrypted: string) {
  const [ivValue, tagValue, ciphertextValue] = encrypted.split(".");
  if (!ivValue || !tagValue || !ciphertextValue) throw new Error("Segredo TOTP cifrado inválido.");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivValue, "base64url"));
  decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertextValue, "base64url")), decipher.final()]).toString("utf8");
}

export function makeSessionId() {
  return randomUUID();
}
