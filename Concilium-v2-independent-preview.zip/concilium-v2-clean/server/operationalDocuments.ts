import { z } from "zod";
import { ownerOperationalProcedure, router } from "./_core/trpc";
import {
  createOperationalProposal,
  listOperationalDocuments,
  transitionOperationalDocument,
} from "./operationalDb";

const caseId = z.object({ caseId: z.string().min(8).max(36) });
const proposalInput = caseId.extend({
  strategyId: z.string().min(8).max(36),
  title: z.string().trim().min(3).max(220),
  body: z.string().trim().min(10).max(40_000),
});

export const operationalDocumentsRouter = router({
  list: ownerOperationalProcedure.input(caseId).query(({ ctx, input }) =>
    listOperationalDocuments(ctx.operationalIdentity.operationalUserId, input.caseId),
  ),

  createProposal: ownerOperationalProcedure.input(proposalInput).mutation(async ({ ctx, input }) => ({
    documentId: await createOperationalProposal({
      userId: ctx.operationalIdentity.operationalUserId,
      caseId: input.caseId,
      strategyId: input.strategyId,
      title: input.title,
      body: input.body,
    }),
  })),

  send: ownerOperationalProcedure.input(z.object({ documentId: z.string().min(8).max(36) })).mutation(({ ctx, input }) =>
    transitionOperationalDocument({
      userId: ctx.operationalIdentity.operationalUserId,
      documentId: input.documentId,
      // [NOVO v2 / Fase 0] "enviada" -> "apresentada"
      nextStatus: "apresentada",
    }),
  ),
});
