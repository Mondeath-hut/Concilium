import { and, desc, eq, gt, inArray, isNull, like, lt, or } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import {
  type InsertUser,
  ownerAccounts,
  ownerAiAnalysisExecutions,
  ownerAiAnalysisRuns,
  ownerAiArenaSessions,
  ownerAiRoundMessages,
  ownerAiSynthesisComparisons,
  ownerAiSynthesisDestinations,
  ownerAiProviderSettings,
  ownerAuditEvents,
  ownerAuthThrottles,
  ownerCaseArgumentAssessments,
  ownerCaseArgumentComparisons,
  ownerCaseAssets,
  ownerCaseCompendiumEntries,
  ownerCaseResearchRequests,
  ownerCases,
  ownerCaseDocuments,
  ownerCaseDocumentVersions,
  ownerCaseMemorialEntries,
  ownerCaseKnowledgeReferences,
  ownerCaseNegotiationScenarios,
  ownerCaseStrategies,
  ownerStrategyExplorationAnswers,
  ownerStrategyExplorationIdeas,
  ownerStrategyExplorationMessages,
  ownerStrategyExplorationQuestions,
  ownerStrategyExplorationRuns,
  ownerStrategyExplorationSyntheses,
  ownerStrategyExplorationThreads,
  ownerStrategyBranchBundles,
  ownerStrategyBranchProposals,
  ownerEmailVerifications,
  ownerMfa,
  ownerOperationalLinks,
  ownerPasskeys,
  ownerSecretVault,
  ownerSessions,
  type OwnerAccount,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { operationalOpenIdForOwner, type OperationalOwnerIdentity } from "../integration/server/ownerOperationalIdentity";
import { areQuestionsSemanticallySimilar } from "../shared/strategyExploration";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field];
      updateSet[field] = user[field];
    }
  }
  if (user.role !== undefined && user.role !== null) {
    values.role = user.role;
    updateSet.role = user.role;
  }
  if (user.openId === ENV.ownerOpenId && user.role === undefined) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

/**
 * Resolves the single operational identity owned by the authenticated owner.
 * It deliberately creates a normal `user` role: no global admin fallback is
 * allowed in the bridge.
 */
export async function ensureOwnerOperationalIdentity(owner: Pick<OwnerAccount, "id" | "email" | "displayName">): Promise<OperationalOwnerIdentity> {
  const db = requireDb(await getDb());
  const openId = operationalOpenIdForOwner(owner.id);
  const existingLink = (await db.select().from(ownerOperationalLinks).where(eq(ownerOperationalLinks.ownerId, owner.id)).limit(1))[0];
  if (existingLink) {
    const linkedUser = (await db.select().from(users).where(eq(users.id, existingLink.operationalUserId)).limit(1))[0];
    if (!linkedUser || linkedUser.openId !== openId) throw new Error("Vínculo operacional do titular inválido.");
    return { ownerId: owner.id, operationalUserId: linkedUser.id, openId };
  }

  const existingUser = (await db.select().from(users).where(eq(users.openId, openId)).limit(1))[0];
  const operationalUser = existingUser ?? (await db.insert(users).values({
    openId,
    name: owner.displayName,
    email: owner.email,
    loginMethod: "concilium-owner",
    role: "user",
  }).then(async () => (await db.select().from(users).where(eq(users.openId, openId)).limit(1))[0]));
  if (!operationalUser) throw new Error("Não foi possível criar a identidade operacional do titular.");

  await db.insert(ownerOperationalLinks).values({ ownerId: owner.id, operationalUserId: operationalUser.id, openId });
  return { ownerId: owner.id, operationalUserId: operationalUser.id, openId };
}

function requireDb(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("Banco de dados indisponível para ativação do titular.");
  return db;
}

export async function getOwnerAccount() {
  const db = requireDb(await getDb());
  const result = await db.select().from(ownerAccounts).limit(1);
  return result[0];
}

export async function getOwnerAccountById(ownerId: string) {
  const db = requireDb(await getDb());
  const result = await db.select().from(ownerAccounts).where(eq(ownerAccounts.id, ownerId)).limit(1);
  return result[0];
}

export async function createOwnerAccount(account: Pick<OwnerAccount, "id" | "email" | "displayName">) {
  const db = requireDb(await getDb());
  await db.insert(ownerAccounts).values({
    ...account,
    state: "setup_pending",
  });
  return getOwnerAccountById(account.id);
}

export async function updateOwnerAccount(ownerId: string, values: Partial<Pick<OwnerAccount, "state" | "activatedAt" | "bootstrapCodeRetiredAt" | "failedActivationAttempts" | "emailVerifiedAt">>) {
  const db = requireDb(await getDb());
  await db.update(ownerAccounts).set(values).where(eq(ownerAccounts.id, ownerId));
}

export async function getOwnerPasskeys(ownerId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerPasskeys).where(eq(ownerPasskeys.ownerId, ownerId));
}

export async function getOwnerPasskey(credentialId: string) {
  const db = requireDb(await getDb());
  const result = await db.select().from(ownerPasskeys).where(eq(ownerPasskeys.credentialId, credentialId)).limit(1);
  return result[0];
}

export async function saveOwnerPasskey(passkey: typeof ownerPasskeys.$inferInsert) {
  const db = requireDb(await getDb());
  await db.insert(ownerPasskeys).values(passkey);
}

export async function updateOwnerPasskeyUsage(credentialId: string, counter: number) {
  const db = requireDb(await getDb());
  await db.update(ownerPasskeys).set({ counter, lastUsedAt: new Date() }).where(eq(ownerPasskeys.credentialId, credentialId));
}

export async function getOwnerMfa(ownerId: string) {
  const db = requireDb(await getDb());
  const result = await db.select().from(ownerMfa).where(eq(ownerMfa.ownerId, ownerId)).limit(1);
  return result[0];
}

export async function upsertOwnerMfa(values: typeof ownerMfa.$inferInsert) {
  const db = requireDb(await getDb());
  await db.insert(ownerMfa).values(values).onDuplicateKeyUpdate({
    set: {
      totpSecretEncrypted: values.totpSecretEncrypted,
      recoveryCodesHash: values.recoveryCodesHash,
      totpConfiguredAt: values.totpConfiguredAt,
    },
  });
}

export async function listOwnerSecretVaultMetadata(ownerId: string) {
  const db = requireDb(await getDb());
  return db.select({ id: ownerSecretVault.id, name: ownerSecretVault.name, consumer: ownerSecretVault.consumer, algorithm: ownerSecretVault.algorithm, version: ownerSecretVault.version, createdAt: ownerSecretVault.createdAt, updatedAt: ownerSecretVault.updatedAt, revokedAt: ownerSecretVault.revokedAt })
    .from(ownerSecretVault)
    .where(eq(ownerSecretVault.ownerId, ownerId));
}

export async function saveOwnerSecretVaultRecord(record: Omit<typeof ownerSecretVault.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = requireDb(await getDb());
  const id = randomUUID();
  await db.insert(ownerSecretVault).values({ ...record, id }).onDuplicateKeyUpdate({
    set: {
      encryptedValue: record.encryptedValue,
      consumer: record.consumer,
      algorithm: record.algorithm,
      version: record.version,
      revokedAt: null,
      updatedAt: new Date(),
    },
  });
}

export async function revokeOwnerSecretVaultRecord(ownerId: string, name: string) {
  const db = requireDb(await getDb());
  await db.update(ownerSecretVault).set({ revokedAt: new Date() }).where(and(eq(ownerSecretVault.ownerId, ownerId), eq(ownerSecretVault.name, name), isNull(ownerSecretVault.revokedAt)));
}

export async function createOwnerSession(session: typeof ownerSessions.$inferInsert) {
  const db = requireDb(await getDb());
  await db.insert(ownerSessions).values(session);
}

export async function getActiveOwnerSession(sessionId: string) {
  const db = requireDb(await getDb());
  const result = await db.select().from(ownerSessions).where(and(
    eq(ownerSessions.id, sessionId),
    isNull(ownerSessions.revokedAt),
    gt(ownerSessions.expiresAt, new Date()),
  )).limit(1);
  return result[0];
}

export async function revokeOwnerSession(sessionId: string) {
  const db = requireDb(await getDb());
  await db.update(ownerSessions).set({ revokedAt: new Date() }).where(eq(ownerSessions.id, sessionId));
}

export async function revokeOutstandingOwnerEmailVerifications(ownerId: string) {
  const db = requireDb(await getDb());
  await db.update(ownerEmailVerifications)
    .set({ revokedAt: new Date() })
    .where(and(eq(ownerEmailVerifications.ownerId, ownerId), isNull(ownerEmailVerifications.consumedAt), isNull(ownerEmailVerifications.revokedAt)));
}

export async function createOwnerEmailVerification(input: { ownerId: string; tokenHash: string; expiresAt: Date }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input };
  await db.insert(ownerEmailVerifications).values(values);
  return values;
}

/** Consome o token com uma única operação condicional para impedir reutilização concorrente. */
export async function consumeOwnerEmailVerification(tokenHash: string) {
  const db = requireDb(await getDb());
  const verification = (await db.select().from(ownerEmailVerifications)
    .where(and(eq(ownerEmailVerifications.tokenHash, tokenHash), isNull(ownerEmailVerifications.consumedAt), isNull(ownerEmailVerifications.revokedAt), gt(ownerEmailVerifications.expiresAt, new Date())))
    .limit(1))[0];
  if (!verification) return undefined;

  const result = await db.update(ownerEmailVerifications)
    .set({ consumedAt: new Date() })
    .where(and(eq(ownerEmailVerifications.id, verification.id), isNull(ownerEmailVerifications.consumedAt), isNull(ownerEmailVerifications.revokedAt), gt(ownerEmailVerifications.expiresAt, new Date())));
  const affectedRows = Number((result as any)[0]?.affectedRows ?? (result as any).affectedRows ?? 0);
  return affectedRows === 1 ? verification : undefined;
}

export async function recordOwnerAudit(ownerId: string | null, eventType: string, metadata: Record<string, unknown> = {}) {
  const db = requireDb(await getDb());
  await db.insert(ownerAuditEvents).values({
    id: crypto.randomUUID(),
    ownerId,
    eventType,
    metadata: JSON.stringify(metadata),
  });
}

export async function getOwnerAuthThrottle(scopeKey: string) {
  const db = requireDb(await getDb());
  const result = await db.select().from(ownerAuthThrottles).where(eq(ownerAuthThrottles.scopeKey, scopeKey)).limit(1);
  return result[0];
}

export async function recordOwnerAuthFailure(input: { scopeKey: string; ownerId?: string | null; failureCount: number; lockedUntil: Date | null }) {
  const db = requireDb(await getDb());
  const values = {
    scopeKey: input.scopeKey,
    ownerId: input.ownerId ?? null,
    failureCount: input.failureCount,
    lockedUntil: input.lockedUntil,
    lastFailureAt: new Date(),
  };
  await db.insert(ownerAuthThrottles).values(values).onDuplicateKeyUpdate({ set: values });
  return values;
}

export async function clearOwnerAuthThrottle(scopeKey: string) {
  const db = requireDb(await getDb());
  await db.delete(ownerAuthThrottles).where(eq(ownerAuthThrottles.scopeKey, scopeKey));
}

export async function listOwnerCases(ownerId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCases).where(eq(ownerCases.ownerId, ownerId));
}

export async function getOwnerCase(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(ownerCases).where(and(eq(ownerCases.ownerId, ownerId), eq(ownerCases.id, caseId))).limit(1);
  return rows[0];
}

export async function createOwnerCase(input: { ownerId: string; title: string; summary?: string | null }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ownerId: input.ownerId, title: input.title, summary: input.summary ?? null };
  await db.insert(ownerCases).values(values);
  return values;
}

export async function listOwnerCaseStrategies(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseStrategies).where(and(eq(ownerCaseStrategies.ownerId, ownerId), eq(ownerCaseStrategies.caseId, caseId)));
}

export async function createOwnerCaseStrategy(input: { ownerId: string; caseId: string; title: string; notes?: string | null }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ownerId: input.ownerId, caseId: input.caseId, title: input.title, notes: input.notes ?? null };
  await db.insert(ownerCaseStrategies).values(values);
  return values;
}

export async function listOwnerCaseArgumentAssessments(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseArgumentAssessments)
    .where(and(eq(ownerCaseArgumentAssessments.ownerId, ownerId), eq(ownerCaseArgumentAssessments.caseId, caseId)))
    .orderBy(desc(ownerCaseArgumentAssessments.createdAt));
}

export async function getOwnerCaseArgumentAssessment(ownerId: string, caseId: string, assessmentId: string) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(ownerCaseArgumentAssessments).where(and(
    eq(ownerCaseArgumentAssessments.ownerId, ownerId),
    eq(ownerCaseArgumentAssessments.caseId, caseId),
    eq(ownerCaseArgumentAssessments.id, assessmentId),
  )).limit(1);
  return rows[0];
}

export async function createOwnerCaseArgumentAssessment(input: {
  ownerId: string; caseId: string; strategyId?: string | null; sourceSynthesisId?: string | null; explorationRunId?: string | null; explorationIdeaId?: string | null; explorationThreadId?: string | null; runId?: string | null; executionId?: string | null; parentAssessmentId?: string | null;
  formulation: string; legalStatus: "apoiado_por_fonte_vigente" | "possivel_aplicacao" | "controvertido" | "nao_verificado" | "contradito_ou_rejeitado" | "fora_da_jurisdicao";
  confidence?: "high" | "medium" | "low" | "unknown";
  evidenceStrength?: "primary" | "official_structured" | "licensed_secondary" | "secondary" | "none";
  moralEthicalNotes?: string | null; factualDependenciesJson: string; counterpointsJson: string; limitationsJson: string;
  operationalStatus: "licito_para_analise" | "requer_revisao_profissional" | "bloqueado_instrucao_ilicita";
  reviewStatus?: "pending" | "triaged" | "needs_research" | "arena_ready" | "approved_for_use" | "archived";
  sourceSnapshotJson: string; humanDecision?: "pending" | "retain_initial" | "use_intermediate" | "use_refined" | "discard"; decisionNotes?: string | null;
}) {
  const db = requireDb(await getDb());
  const values = {
    id: crypto.randomUUID(), ownerId: input.ownerId, caseId: input.caseId,
    strategyId: input.strategyId ?? null, sourceSynthesisId: input.sourceSynthesisId ?? null, explorationRunId: input.explorationRunId ?? null, explorationIdeaId: input.explorationIdeaId ?? null, explorationThreadId: input.explorationThreadId ?? null,
    runId: input.runId ?? null, executionId: input.executionId ?? null, parentAssessmentId: input.parentAssessmentId ?? null,
    formulation: input.formulation, legalStatus: input.legalStatus, confidence: input.confidence ?? "unknown" as const,
    evidenceStrength: input.evidenceStrength ?? "none" as const, moralEthicalNotes: input.moralEthicalNotes ?? null,
    factualDependenciesJson: input.factualDependenciesJson, counterpointsJson: input.counterpointsJson, limitationsJson: input.limitationsJson,
    operationalStatus: input.operationalStatus, reviewStatus: input.reviewStatus ?? "pending" as const,
    sourceSnapshotJson: input.sourceSnapshotJson, humanDecision: input.humanDecision ?? "pending" as const, decisionNotes: input.decisionNotes ?? null,
  };
  await db.insert(ownerCaseArgumentAssessments).values(values);
  return values;
}

export async function decideOwnerCaseArgumentAssessment(input: {
  ownerId: string; caseId: string; assessmentId: string; humanDecision: "pending" | "retain_initial" | "use_intermediate" | "use_refined" | "discard"; decisionNotes?: string | null;
}) {
  const db = requireDb(await getDb());
  await db.update(ownerCaseArgumentAssessments).set({ humanDecision: input.humanDecision, decisionNotes: input.decisionNotes ?? null, decidedAt: input.humanDecision === "pending" ? null : new Date() })
    .where(and(eq(ownerCaseArgumentAssessments.ownerId, input.ownerId), eq(ownerCaseArgumentAssessments.caseId, input.caseId), eq(ownerCaseArgumentAssessments.id, input.assessmentId)));
  const rows = await db.select().from(ownerCaseArgumentAssessments).where(and(eq(ownerCaseArgumentAssessments.ownerId, input.ownerId), eq(ownerCaseArgumentAssessments.caseId, input.caseId), eq(ownerCaseArgumentAssessments.id, input.assessmentId))).limit(1);
  return rows[0];
}

export async function createOwnerCaseArgumentComparison(input: {
  ownerId: string; caseId: string; leftAssessmentId: string; rightAssessmentId: string; modelId: string; promptHash: string;
  comparisonBody: string; commonPoints: string; differences: string; newEvidence: string; risks: string; questions: string;
}) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, humanDecision: "pending" as const, decisionNotes: null, nextDestination: null, routedAt: null, decidedAt: null, createdAt: new Date() };
  await db.insert(ownerCaseArgumentComparisons).values(values);
  return values;
}

export async function listOwnerCaseArgumentComparisons(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseArgumentComparisons)
    .where(and(eq(ownerCaseArgumentComparisons.ownerId, ownerId), eq(ownerCaseArgumentComparisons.caseId, caseId)))
    .orderBy(desc(ownerCaseArgumentComparisons.createdAt));
}

export async function decideOwnerCaseArgumentComparison(input: {
  ownerId: string; caseId: string; comparisonId: string; humanDecision: "pending" | "retain_left" | "retain_right" | "merge" | "review" | "discard"; decisionNotes?: string | null; nextDestination?: "strategy" | "librarian" | "arena" | "compendium" | "archive" | null;
}) {
  const db = requireDb(await getDb());
  await db.update(ownerCaseArgumentComparisons).set({ humanDecision: input.humanDecision, decisionNotes: input.decisionNotes ?? null, nextDestination: input.nextDestination ?? null, routedAt: input.nextDestination ? new Date() : null, decidedAt: input.humanDecision === "pending" ? null : new Date() }).where(and(
    eq(ownerCaseArgumentComparisons.id, input.comparisonId), eq(ownerCaseArgumentComparisons.ownerId, input.ownerId), eq(ownerCaseArgumentComparisons.caseId, input.caseId),
  ));
  const rows = await db.select().from(ownerCaseArgumentComparisons).where(and(
    eq(ownerCaseArgumentComparisons.id, input.comparisonId), eq(ownerCaseArgumentComparisons.ownerId, input.ownerId), eq(ownerCaseArgumentComparisons.caseId, input.caseId),
  )).limit(1);
  return rows[0];
}

export async function createOwnerStrategyExplorationRun(input: {
  ownerId: string; caseId: string; title: string; objective: string; inputContentHash: string; originalContextEncrypted?: string | null; sourceAssessmentId?: string | null; parentRunId?: string | null; sourceBranchBundleId?: string | null; derivationType?: "initial" | "branch"; evidenceSnapshotJson?: string; strategistBrief?: string | null; strategistModelId?: string | null; consentLabel: string;
}) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, originalContextEncrypted: input.originalContextEncrypted ?? null, sourceAssessmentId: input.sourceAssessmentId ?? null, parentRunId: input.parentRunId ?? null, sourceBranchBundleId: input.sourceBranchBundleId ?? null, derivationType: input.derivationType ?? "initial" as const, evidenceSnapshotJson: input.evidenceSnapshotJson ?? "[]", strategistBrief: input.strategistBrief ?? null, strategistModelId: input.strategistModelId ?? null, status: "active" as const };
  await db.insert(ownerStrategyExplorationRuns).values(values);
  return values;
}

export async function createOwnerDerivedStrategyExploration(input: { ownerId: string; caseId: string; bundleId: string; title: string; objective: string; inputContentHash: string; consentLabel: string }) {
  const db = requireDb(await getDb());
  const [source] = await db.select({ bundle: ownerStrategyBranchBundles, run: ownerStrategyExplorationRuns })
    .from(ownerStrategyBranchBundles)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyBranchBundles.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyBranchBundles.id, input.bundleId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .limit(1);
  if (!source || source.bundle.state !== "submitted") throw new Error("O pacote precisa ser submetido antes de iniciar uma nova exploração.");
  const values = { id: crypto.randomUUID(), ownerId: input.ownerId, caseId: input.caseId, title: input.title, objective: input.objective, inputContentHash: input.inputContentHash, originalContextEncrypted: source.run.originalContextEncrypted, sourceAssessmentId: source.run.sourceAssessmentId, parentRunId: source.run.id, sourceBranchBundleId: source.bundle.id, derivationType: "branch" as const, evidenceSnapshotJson: source.run.evidenceSnapshotJson, strategistBrief: null, strategistModelId: source.run.strategistModelId, consentLabel: input.consentLabel, status: "active" as const };
  await db.insert(ownerStrategyExplorationRuns).values(values);
  return values;
}

export async function getOwnerStrategyExplorationRun(input: { ownerId: string; caseId: string; runId: string }) {
  const db = requireDb(await getDb());
  const [run] = await db.select().from(ownerStrategyExplorationRuns).where(and(eq(ownerStrategyExplorationRuns.id, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId))).limit(1);
  return run;
}

export async function getOwnerStrategyBranchBundle(input: { ownerId: string; caseId: string; bundleId: string }) {
  const db = requireDb(await getDb());
  const [row] = await db.select({ bundle: ownerStrategyBranchBundles, run: ownerStrategyExplorationRuns }).from(ownerStrategyBranchBundles).innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyBranchBundles.runId, ownerStrategyExplorationRuns.id)).where(and(eq(ownerStrategyBranchBundles.id, input.bundleId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId))).limit(1);
  return row;
}

export async function updateOwnerStrategyExplorationBrief(input: { ownerId: string; caseId: string; runId: string; strategistBrief: string }) {
  const db = requireDb(await getDb());
  await db.update(ownerStrategyExplorationRuns).set({ strategistBrief: input.strategistBrief }).where(and(eq(ownerStrategyExplorationRuns.id, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)));
  return input.strategistBrief;
}

export async function createOwnerStrategyExplorationIdea(input: {
  runId: string; modelId: string; perspective: string; ideaBody: string; assumptions?: string | null; risks?: string | null; sourceNeeds?: string | null;
}) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, assumptions: input.assumptions ?? null, risks: input.risks ?? null, sourceNeeds: input.sourceNeeds ?? null, status: "generated" as const };
  await db.insert(ownerStrategyExplorationIdeas).values(values);
  return values;
}

export async function createOwnerStrategyExplorationThread(input: { runId: string; ideaId: string; modelId: string; perspective: string; state?: "active" | "awaiting_owner" | "ceased" | "selected_for_arena" }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, state: input.state ?? "active" as const };
  await db.insert(ownerStrategyExplorationThreads).values(values);
  return values;
}

export async function createOwnerStrategyExplorationQuestion(input: { runId: string; threadId: string; questionBody: string; semanticGroupId?: string | null }) {
  const db = requireDb(await getDb());
  const existingQuestions = await db.select().from(ownerStrategyExplorationQuestions).where(eq(ownerStrategyExplorationQuestions.runId, input.runId));
  const similar = input.semanticGroupId ? null : existingQuestions.find(question => areQuestionsSemanticallySimilar(question.questionBody, input.questionBody));
  const values = { id: crypto.randomUUID(), ...input, semanticGroupId: input.semanticGroupId ?? similar?.semanticGroupId ?? input.threadId, status: "pending" as const };
  await db.insert(ownerStrategyExplorationQuestions).values(values);
  await db.update(ownerStrategyExplorationThreads).set({ state: "awaiting_owner" }).where(eq(ownerStrategyExplorationThreads.id, input.threadId));
  return values;
}

export async function listOwnerStrategyExplorationThreads(ownerId: string, caseId: string, runId: string) {
  const db = requireDb(await getDb());
  const rows = await db.select({ thread: ownerStrategyExplorationThreads })
    .from(ownerStrategyExplorationThreads)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationThreads.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationRuns.ownerId, ownerId), eq(ownerStrategyExplorationRuns.caseId, caseId), eq(ownerStrategyExplorationThreads.runId, runId)));
  return Promise.all(rows.map(async ({ thread }) => ({
    ...thread,
    questions: await db.select().from(ownerStrategyExplorationQuestions).where(eq(ownerStrategyExplorationQuestions.threadId, thread.id)).orderBy(desc(ownerStrategyExplorationQuestions.createdAt)),
    messages: await db.select().from(ownerStrategyExplorationMessages).where(eq(ownerStrategyExplorationMessages.threadId, thread.id)).orderBy(desc(ownerStrategyExplorationMessages.createdAt)),
  })));
}

export async function getOwnerStrategyExplorationThreadContext(input: { ownerId: string; caseId: string; runId: string; threadId: string }) {
  const db = requireDb(await getDb());
  const rows = await db.select({ thread: ownerStrategyExplorationThreads, run: ownerStrategyExplorationRuns })
    .from(ownerStrategyExplorationThreads)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationThreads.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationThreads.id, input.threadId), eq(ownerStrategyExplorationThreads.runId, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .limit(1);
  if (!rows[0]) return null;
  const [messages, questions] = await Promise.all([
    db.select().from(ownerStrategyExplorationMessages).where(eq(ownerStrategyExplorationMessages.threadId, input.threadId)).orderBy(ownerStrategyExplorationMessages.createdAt),
    db.select().from(ownerStrategyExplorationQuestions).where(eq(ownerStrategyExplorationQuestions.threadId, input.threadId)).orderBy(desc(ownerStrategyExplorationQuestions.createdAt)),
  ]);
  return { ...rows[0], messages, questions };
}

export async function createOwnerStrategyExplorationMessage(input: { runId: string; threadId: string; authorType: "model" | "owner" | "system"; body: string; questionId?: string | null; answerId?: string | null }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, questionId: input.questionId ?? null, answerId: input.answerId ?? null, createdAt: new Date() };
  await db.insert(ownerStrategyExplorationMessages).values(values);
  return values;
}

export async function createOwnerStrategyBranchProposal(input: { ownerId: string; caseId: string; runId: string; parentThreadId: string; originQuestionId?: string | null; originMessageId?: string | null; question: string; whyItMatters: string }) {
  const db = requireDb(await getDb());
  const [authorized] = await db.select({ id: ownerStrategyExplorationThreads.id })
    .from(ownerStrategyExplorationThreads)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationThreads.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationThreads.id, input.parentThreadId), eq(ownerStrategyExplorationRuns.id, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .limit(1);
  if (!authorized) throw new Error("Linha de origem não autorizada.");
  const values = { id: randomUUID(), runId: input.runId, parentThreadId: input.parentThreadId, originQuestionId: input.originQuestionId ?? null, originMessageId: input.originMessageId ?? null, question: input.question, whyItMatters: input.whyItMatters, state: "parked" as const };
  await db.insert(ownerStrategyBranchProposals).values(values);
  return values;
}

export async function listOwnerStrategyBranchProposals(input: { ownerId: string; caseId: string; runId: string }) {
  const db = requireDb(await getDb());
  return db.select({ proposal: ownerStrategyBranchProposals })
    .from(ownerStrategyBranchProposals)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyBranchProposals.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyBranchProposals.runId, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .orderBy(desc(ownerStrategyBranchProposals.createdAt));
}

export async function createOwnerStrategyBranchBundle(input: { ownerId: string; caseId: string; runId: string; sourceProposalIds: string[]; sourceThreadIds: string[]; sourceQuestionIds: string[]; draftQuestion: string }) {
  const db = requireDb(await getDb());
  const authorized = await db.select({ id: ownerStrategyBranchProposals.id }).from(ownerStrategyBranchProposals).innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyBranchProposals.runId, ownerStrategyExplorationRuns.id)).where(and(eq(ownerStrategyBranchProposals.runId, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)));
  const allowed = new Set(authorized.map(row => row.id));
  if (input.sourceProposalIds.some(id => !allowed.has(id))) throw new Error("Ramificação não autorizada para este pacote.");
  const values = { id: randomUUID(), runId: input.runId, sourceProposalIdsJson: JSON.stringify(input.sourceProposalIds), sourceThreadIdsJson: JSON.stringify(input.sourceThreadIds), sourceQuestionIdsJson: JSON.stringify(input.sourceQuestionIds), draftQuestion: input.draftQuestion, state: "ready_for_strategist" as const };
  await db.insert(ownerStrategyBranchBundles).values(values);
  await db.update(ownerStrategyBranchProposals).set({ state: "grouped", updatedAt: new Date() }).where(and(eq(ownerStrategyBranchProposals.runId, input.runId), eq(ownerStrategyBranchProposals.state, "parked"), inArray(ownerStrategyBranchProposals.id, input.sourceProposalIds)));
  return values;
}

export async function listOwnerStrategyBranchBundles(input: { ownerId: string; caseId: string; runId: string }) {
  const db = requireDb(await getDb());
  return db.select({ bundle: ownerStrategyBranchBundles }).from(ownerStrategyBranchBundles).innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyBranchBundles.runId, ownerStrategyExplorationRuns.id)).where(and(eq(ownerStrategyBranchBundles.runId, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId))).orderBy(desc(ownerStrategyBranchBundles.createdAt));
}

export async function updateOwnerStrategyBranchBundleState(input: { ownerId: string; caseId: string; runId: string; bundleId: string; state: "submitted" | "resolved" | "dismissed" }) {
  const db = requireDb(await getDb());
  const [authorized] = await db.select({ id: ownerStrategyBranchBundles.id }).from(ownerStrategyBranchBundles).innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyBranchBundles.runId, ownerStrategyExplorationRuns.id)).where(and(eq(ownerStrategyBranchBundles.id, input.bundleId), eq(ownerStrategyBranchBundles.runId, input.runId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId))).limit(1);
  if (!authorized) throw new Error("Pacote de ramificações não encontrado.");
  const result = await db.update(ownerStrategyBranchBundles).set({ state: input.state, updatedAt: new Date() }).where(eq(ownerStrategyBranchBundles.id, input.bundleId));
  const affectedRows = Number((result as any)[0]?.affectedRows ?? (result as any).affectedRows ?? 0);
  if (affectedRows !== 1) throw new Error("Pacote de ramificações não encontrado.");
  return { bundleId: input.bundleId, state: input.state };
}

export async function updateOwnerStrategyExplorationThreadState(threadId: string, state: "active" | "awaiting_owner" | "ceased" | "selected_for_arena") {
  const db = requireDb(await getDb());
  await db.update(ownerStrategyExplorationThreads).set({ state }).where(eq(ownerStrategyExplorationThreads.id, threadId));
}

export async function answerOwnerStrategyExplorationQuestions(input: { ownerId: string; caseId: string; runId: string; questionIds: string[]; semanticGroupId: string; body: string }) {
  const db = requireDb(await getDb());
  const questions = await db.select({ question: ownerStrategyExplorationQuestions, thread: ownerStrategyExplorationThreads })
    .from(ownerStrategyExplorationQuestions)
    .innerJoin(ownerStrategyExplorationThreads, eq(ownerStrategyExplorationQuestions.threadId, ownerStrategyExplorationThreads.id))
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationThreads.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId), eq(ownerStrategyExplorationRuns.id, input.runId)));
  const selected = questions.filter(row => row.question.status === "pending" && (row.question.semanticGroupId ?? input.semanticGroupId) === input.semanticGroupId);
  if (!selected.length) return null;
  const answerId = crypto.randomUUID();
  await db.transaction(async tx => {
    await tx.insert(ownerStrategyExplorationAnswers).values({ id: answerId, runId: input.runId, semanticGroupId: input.semanticGroupId, body: input.body, questionIdsJson: JSON.stringify(input.questionIds), createdAt: new Date() });
    for (const row of selected) {
      await tx.update(ownerStrategyExplorationQuestions).set({ status: "answered" }).where(eq(ownerStrategyExplorationQuestions.id, row.question.id));
      await tx.insert(ownerStrategyExplorationMessages).values({ id: crypto.randomUUID(), runId: input.runId, threadId: row.thread.id, authorType: "owner", body: input.body, questionId: row.question.id, answerId, createdAt: new Date() });
      await tx.update(ownerStrategyExplorationThreads).set({ state: "active" }).where(eq(ownerStrategyExplorationThreads.id, row.thread.id));
    }
  });
  return { answerId, threadIds: selected.map(row => row.thread.id) };
}

export async function createOwnerStrategyExplorationSynthesis(input: { runId: string; stage: "incremental" | "final"; closedThreadId?: string | null; content: string; sourceThreadIds: string[] }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), runId: input.runId, stage: input.stage, closedThreadId: input.closedThreadId ?? null, content: input.content, sourceThreadIdsJson: JSON.stringify(input.sourceThreadIds), createdAt: new Date() };
  await db.insert(ownerStrategyExplorationSyntheses).values(values);
  return values;
}

export async function listOwnerStrategyExplorationSyntheses(runId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerStrategyExplorationSyntheses).where(eq(ownerStrategyExplorationSyntheses.runId, runId)).orderBy(desc(ownerStrategyExplorationSyntheses.createdAt));
}

export async function getOwnerStrategyExplorationSynthesis(input: { ownerId: string; caseId: string; synthesisId: string }) {
  const db = requireDb(await getDb());
  const rows = await db.select({ synthesis: ownerStrategyExplorationSyntheses, run: ownerStrategyExplorationRuns })
    .from(ownerStrategyExplorationSyntheses)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationSyntheses.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationSyntheses.id, input.synthesisId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .limit(1);
  return rows[0] ? { ...rows[0].synthesis, explorationRunId: rows[0].run.id, originalContextEncrypted: rows[0].run.originalContextEncrypted, strategistBrief: rows[0].run.strategistBrief, explorationTitle: rows[0].run.title, explorationObjective: rows[0].run.objective } : null;
}

export async function listOwnerStrategyExplorations(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  const runs = await db.select().from(ownerStrategyExplorationRuns)
    .where(and(eq(ownerStrategyExplorationRuns.ownerId, ownerId), eq(ownerStrategyExplorationRuns.caseId, caseId)))
    .orderBy(desc(ownerStrategyExplorationRuns.createdAt));
  return Promise.all(runs.map(async run => ({
    ...run,
    ideas: await db.select().from(ownerStrategyExplorationIdeas).where(eq(ownerStrategyExplorationIdeas.runId, run.id)).orderBy(desc(ownerStrategyExplorationIdeas.createdAt)),
    syntheses: await db.select().from(ownerStrategyExplorationSyntheses).where(eq(ownerStrategyExplorationSyntheses.runId, run.id)).orderBy(desc(ownerStrategyExplorationSyntheses.createdAt)),
  })));
}

export async function getOwnerStrategyIdeaForArena(input: { ownerId: string; caseId: string; ideaId: string }) {
  const db = requireDb(await getDb());
  const rows = await db.select({ idea: ownerStrategyExplorationIdeas, run: ownerStrategyExplorationRuns })
    .from(ownerStrategyExplorationIdeas)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationIdeas.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationIdeas.id, input.ideaId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .limit(1);
  return rows[0] ? { ...rows[0].idea, explorationRunId: rows[0].run.id } : null;
}

export async function selectOwnerStrategyIdeaForArena(input: { ownerId: string; caseId: string; ideaId: string }) {
  const db = requireDb(await getDb());
  const rows = await db.select({ idea: ownerStrategyExplorationIdeas, run: ownerStrategyExplorationRuns })
    .from(ownerStrategyExplorationIdeas)
    .innerJoin(ownerStrategyExplorationRuns, eq(ownerStrategyExplorationIdeas.runId, ownerStrategyExplorationRuns.id))
    .where(and(eq(ownerStrategyExplorationIdeas.id, input.ideaId), eq(ownerStrategyExplorationRuns.ownerId, input.ownerId), eq(ownerStrategyExplorationRuns.caseId, input.caseId)))
    .limit(1);
  if (!rows[0]) return null;
  await db.update(ownerStrategyExplorationIdeas).set({ status: "selected_for_arena" }).where(eq(ownerStrategyExplorationIdeas.id, input.ideaId));
  return { ...rows[0].idea, explorationRunId: rows[0].run.id };
}

export async function listOwnerCaseMemorialEntries(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseMemorialEntries)
    .where(and(eq(ownerCaseMemorialEntries.ownerId, ownerId), eq(ownerCaseMemorialEntries.caseId, caseId)));
}

export async function createOwnerCaseMemorialEntry(input: {
  ownerId: string; caseId: string; entryType: string; title: string; narrative: string;
  referenceDate?: string | null; chronologyStatus?: "verified" | "pending_confirmation" | "not_applicable";
  chronologyConfidence?: "high" | "medium" | "low" | "unknown";
  sourceReference: string; reviewStatus?: "pending_review" | "verified" | "draft";
}) {
  const db = requireDb(await getDb());
  const values = {
    id: crypto.randomUUID(), ...input, referenceDate: input.referenceDate ?? null,
    chronologyStatus: input.chronologyStatus ?? "pending_confirmation",
    chronologyConfidence: input.chronologyConfidence ?? "unknown",
    reviewStatus: input.reviewStatus ?? "pending_review",
  };
  await db.insert(ownerCaseMemorialEntries).values(values);
  return values;
}

export async function listOwnerCaseAssets(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseAssets)
    .where(and(eq(ownerCaseAssets.ownerId, ownerId), eq(ownerCaseAssets.caseId, caseId)))
    .orderBy(desc(ownerCaseAssets.updatedAt));
}

export async function createOwnerCaseAsset(input: {
  ownerId: string; caseId: string; assetType: string; title: string; details: string;
  sourceReference: string; reviewStatus?: "pending_review" | "verified" | "draft";
}) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, reviewStatus: input.reviewStatus ?? "pending_review" };
  await db.insert(ownerCaseAssets).values(values);
  return values;
}

export async function listOwnerCaseDocuments(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseDocuments)
    .where(and(eq(ownerCaseDocuments.ownerId, ownerId), eq(ownerCaseDocuments.caseId, caseId)))
    .orderBy(desc(ownerCaseDocuments.updatedAt));
}

export async function getOwnerCaseDocument(ownerId: string, caseId: string, documentId: string) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(ownerCaseDocuments)
    .where(and(
      eq(ownerCaseDocuments.ownerId, ownerId),
      eq(ownerCaseDocuments.caseId, caseId),
      eq(ownerCaseDocuments.id, documentId),
    ))
    .limit(1);
  return rows[0];
}

export async function createOwnerCaseDocument(input: {
  ownerId: string; caseId: string; title: string; documentType: string; sourceReference: string;
  storageKey?: string | null; contentHash?: string | null; reviewStatus?: "pending_review" | "verified" | "draft";
}) {
  const db = requireDb(await getDb());
  const values = {
    id: crypto.randomUUID(), ...input, storageKey: input.storageKey ?? null,
    contentHash: input.contentHash ?? null, catalogStatus: "quarantined" as const, suggestedVault: null, confirmedVault: null, catalogSensitivity: "personal" as const, catalogConfidence: "unknown" as const, catalogNotes: null, catalogedAt: null, reviewStatus: input.reviewStatus ?? "pending_review",
  };
  await db.insert(ownerCaseDocuments).values(values);
  return values;
}

export async function createOwnerCaseDocumentVersion(input: { ownerId: string; caseId: string; documentId: string; versionLabel: string; contentHash: string; sourceReference: string; storageKey?: string | null; changeNote: string }) {
  const db = requireDb(await getDb());
  const [document] = await db.select({ id: ownerCaseDocuments.id }).from(ownerCaseDocuments).where(and(eq(ownerCaseDocuments.id, input.documentId), eq(ownerCaseDocuments.ownerId, input.ownerId), eq(ownerCaseDocuments.caseId, input.caseId))).limit(1);
  if (!document) return null;
  const values = { id: crypto.randomUUID(), ...input, storageKey: input.storageKey ?? null };
  await db.insert(ownerCaseDocumentVersions).values(values);
  return values;
}

export async function listOwnerCaseDocumentVersions(input: { ownerId: string; caseId: string; documentId: string }) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseDocumentVersions).where(and(eq(ownerCaseDocumentVersions.documentId, input.documentId), eq(ownerCaseDocumentVersions.ownerId, input.ownerId), eq(ownerCaseDocumentVersions.caseId, input.caseId))).orderBy(desc(ownerCaseDocumentVersions.createdAt));
}

export async function confirmOwnerCaseDocumentCatalog(input: { ownerId: string; caseId: string; documentId: string; confirmedVault: string }) {
  const db = requireDb(await getDb());
  await db.update(ownerCaseDocuments).set({ catalogStatus: "confirmed", confirmedVault: input.confirmedVault }).where(and(eq(ownerCaseDocuments.id, input.documentId), eq(ownerCaseDocuments.ownerId, input.ownerId), eq(ownerCaseDocuments.caseId, input.caseId), eq(ownerCaseDocuments.catalogStatus, "needs_owner_review")));
  const rows = await db.select().from(ownerCaseDocuments).where(and(eq(ownerCaseDocuments.id, input.documentId), eq(ownerCaseDocuments.ownerId, input.ownerId), eq(ownerCaseDocuments.caseId, input.caseId))).limit(1);
  return rows[0];
}

export async function updateOwnerCaseDocumentCatalog(input: { ownerId: string; caseId: string; documentId: string; suggestedVault: string; sensitivity: "ordinary" | "personal" | "sensitive" | "highly_sensitive"; confidence: "high" | "medium" | "low" | "unknown"; catalogNotes: string }) {
  const db = requireDb(await getDb());
  await db.update(ownerCaseDocuments).set({ catalogStatus: "needs_owner_review", suggestedVault: input.suggestedVault, catalogSensitivity: input.sensitivity, catalogConfidence: input.confidence, catalogNotes: input.catalogNotes, catalogedAt: new Date() }).where(and(eq(ownerCaseDocuments.id, input.documentId), eq(ownerCaseDocuments.ownerId, input.ownerId), eq(ownerCaseDocuments.caseId, input.caseId)));
  const rows = await db.select().from(ownerCaseDocuments).where(and(eq(ownerCaseDocuments.id, input.documentId), eq(ownerCaseDocuments.ownerId, input.ownerId), eq(ownerCaseDocuments.caseId, input.caseId))).limit(1);
  return rows[0];
}

export async function listOwnerCaseNegotiationScenarios(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseNegotiationScenarios)
    .where(and(eq(ownerCaseNegotiationScenarios.ownerId, ownerId), eq(ownerCaseNegotiationScenarios.caseId, caseId)))
    .orderBy(desc(ownerCaseNegotiationScenarios.updatedAt));
}

export async function createOwnerCaseNegotiationScenario(input: {
  ownerId: string; caseId: string; title: string; narrative: string; sourceReference: string;
  reviewStatus?: "pending_review" | "verified" | "draft";
}) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, reviewStatus: input.reviewStatus ?? "draft" };
  await db.insert(ownerCaseNegotiationScenarios).values(values);
  return values;
}

export async function saveOwnerKnowledgeReference(input: {
  ownerId: string;
  caseId: string;
  externalEntryId: string;
  title: string;
  summary: string;
  sourceTitle: string;
  sourceUrl?: string | null;
  sourceVersion: string;
  country: string;
  jurisdiction: string;
  authorityLevel: string;
  validityState: string;
  validityCheckedAt?: Date | null;
  supersededBy?: string | null;
  citationsJson: string;
  actionType: "reference" | "clause_compendium";
  clauseDraft?: string | null;
}) {
  const db = requireDb(await getDb());
  const values = {
    id: crypto.randomUUID(),
    ...input,
    sourceUrl: input.sourceUrl ?? null,
    validityCheckedAt: input.validityCheckedAt ?? null,
    supersededBy: input.supersededBy ?? null,
    clauseDraft: input.clauseDraft ?? null,
    refinementStatus: "saved" as const,
  };
  await db.insert(ownerCaseKnowledgeReferences).values(values);
  return values;
}

export async function listOwnerKnowledgeReferences(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseKnowledgeReferences).where(and(
    eq(ownerCaseKnowledgeReferences.ownerId, ownerId),
    eq(ownerCaseKnowledgeReferences.caseId, caseId),
  )).orderBy(desc(ownerCaseKnowledgeReferences.createdAt));
}

export async function getOwnerKnowledgeReference(ownerId: string, caseId: string, referenceId: string) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(ownerCaseKnowledgeReferences).where(and(
    eq(ownerCaseKnowledgeReferences.ownerId, ownerId),
    eq(ownerCaseKnowledgeReferences.caseId, caseId),
    eq(ownerCaseKnowledgeReferences.id, referenceId),
  )).limit(1);
  return rows[0];
}

export async function markOwnerKnowledgeReferenceInArena(ownerId: string, caseId: string, referenceId: string) {
  const db = requireDb(await getDb());
  await db.update(ownerCaseKnowledgeReferences).set({ refinementStatus: "in_arena" }).where(and(
    eq(ownerCaseKnowledgeReferences.ownerId, ownerId),
    eq(ownerCaseKnowledgeReferences.caseId, caseId),
    eq(ownerCaseKnowledgeReferences.id, referenceId),
  ));
  return getOwnerKnowledgeReference(ownerId, caseId, referenceId);
}

export async function createOwnerAiArenaSession(input: { ownerId: string; caseId: string; label: string; teamLabel: string; branchFromRunId?: string | null }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, branchFromRunId: input.branchFromRunId ?? null, status: "active" as const, createdAt: new Date() };
  await db.insert(ownerAiArenaSessions).values(values);
  return values;
}

export async function listOwnerAiArenaSessions(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerAiArenaSessions).where(and(eq(ownerAiArenaSessions.ownerId, ownerId), eq(ownerAiArenaSessions.caseId, caseId))).orderBy(desc(ownerAiArenaSessions.createdAt));
}

export async function setOwnerAiSynthesisUseStatus(input: { ownerId: string; caseId: string; runId: string; status: "homologated" | "not_used" | "requires_review" }) {
  const db = requireDb(await getDb());
  await db.update(ownerAiAnalysisRuns).set({ synthesisUseStatus: input.status, synthesisUsedAt: input.status === "homologated" ? new Date() : null }).where(and(eq(ownerAiAnalysisRuns.ownerId, input.ownerId), eq(ownerAiAnalysisRuns.caseId, input.caseId), eq(ownerAiAnalysisRuns.id, input.runId)));
  return getOwnerAiAnalysisRun(input.ownerId, input.caseId, input.runId);
}

export async function createOwnerCaseCompendiumEntry(input: { ownerId: string; caseId: string; sourceRunId: string; title: string; body: string }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, status: "draft" as const, createdAt: new Date(), updatedAt: new Date() };
  await db.insert(ownerCaseCompendiumEntries).values(values);
  return values;
}

export async function createOwnerCaseResearchRequest(input: { ownerId: string; caseId: string; sourceRunId: string; sourceAssessmentId?: string | null; strategyId?: string | null; query: string }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, sourceAssessmentId: input.sourceAssessmentId ?? null, strategyId: input.strategyId ?? null, resultSnapshotJson: "[]", status: "pending" as const, answeredAt: null, createdAt: new Date() };
  await db.insert(ownerCaseResearchRequests).values(values);
  return values;
}

export async function answerOwnerCaseResearchRequest(input: { ownerId: string; caseId: string; requestId: string; resultSnapshotJson: string }) {
  const db = requireDb(await getDb());
  await db.update(ownerCaseResearchRequests).set({ resultSnapshotJson: input.resultSnapshotJson, status: "answered", answeredAt: new Date() }).where(and(
    eq(ownerCaseResearchRequests.id, input.requestId), eq(ownerCaseResearchRequests.ownerId, input.ownerId), eq(ownerCaseResearchRequests.caseId, input.caseId),
  ));
  const rows = await db.select().from(ownerCaseResearchRequests).where(and(
    eq(ownerCaseResearchRequests.id, input.requestId), eq(ownerCaseResearchRequests.ownerId, input.ownerId), eq(ownerCaseResearchRequests.caseId, input.caseId),
  )).limit(1);
  return rows[0];
}

export async function listOwnerCaseCompendiumEntries(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseCompendiumEntries).where(and(eq(ownerCaseCompendiumEntries.ownerId, ownerId), eq(ownerCaseCompendiumEntries.caseId, caseId))).orderBy(desc(ownerCaseCompendiumEntries.updatedAt));
}

export async function listOwnerCaseResearchRequests(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerCaseResearchRequests).where(and(eq(ownerCaseResearchRequests.ownerId, ownerId), eq(ownerCaseResearchRequests.caseId, caseId))).orderBy(desc(ownerCaseResearchRequests.createdAt));
}

export async function saveOwnerAiSynthesisDestination(input: { ownerId: string; caseId: string; runId: string; destination: "bibliotecario" | "compendio" | "arena" | "arquivo"; note?: string | null }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, note: input.note ?? null, createdAt: new Date() };
  await db.insert(ownerAiSynthesisDestinations).values(values);
  return values;
}

export async function listOwnerAiSynthesisDestinations(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerAiSynthesisDestinations).where(and(eq(ownerAiSynthesisDestinations.ownerId, ownerId), eq(ownerAiSynthesisDestinations.caseId, caseId))).orderBy(desc(ownerAiSynthesisDestinations.createdAt));
}

export async function saveOwnerAiSynthesisComparison(input: { ownerId: string; caseId: string; leftRunId: string; rightRunId: string; commonPoints: string; divergences: string; supervisorQuestions: string; recommendation: string }) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input, createdAt: new Date() };
  await db.insert(ownerAiSynthesisComparisons).values(values);
  return values;
}

export async function listOwnerAiSynthesisComparisons(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  return db.select().from(ownerAiSynthesisComparisons).where(and(eq(ownerAiSynthesisComparisons.ownerId, ownerId), eq(ownerAiSynthesisComparisons.caseId, caseId))).orderBy(desc(ownerAiSynthesisComparisons.createdAt));
}

export async function createOwnerAiAnalysisRun(input: {
  ownerId: string;
  caseId: string;
  title: string;
  objective: string;
  originalContentHash: string;
  visibilityLevel: "integral_autorizado" | "contexto_protegido" | "redigido";
  consentLabel: string;
  consentConfirmedAt: Date;
  roundNumber?: number;
  sessionId?: string | null;
  previousRunId?: string | null;
  supervisorBrief?: string | null;
}) {
  const db = requireDb(await getDb());
  const values = {
    id: crypto.randomUUID(),
    ...input,
    supervisorAccessLevel: "integral_autorizado" as const,
    roundNumber: input.roundNumber ?? 1,
    sessionId: input.sessionId ?? null,
    previousRunId: input.previousRunId ?? null,
    roundState: "active" as const,
    supervisorBrief: input.supervisorBrief ?? null,
  };
  await db.insert(ownerAiAnalysisRuns).values(values);
  return values;
}

export async function createOwnerAiRoundMessage(input: {
  ownerId: string;
  caseId: string;
  runId: string;
  authorType: "owner" | "supervisor" | "system";
  body: string;
}) {
  const db = requireDb(await getDb());
  const previous = await db.select({ sequenceNo: ownerAiRoundMessages.sequenceNo })
    .from(ownerAiRoundMessages)
    .where(and(eq(ownerAiRoundMessages.ownerId, input.ownerId), eq(ownerAiRoundMessages.runId, input.runId)))
    .orderBy(desc(ownerAiRoundMessages.sequenceNo));
  const values = { id: crypto.randomUUID(), ...input, sequenceNo: (previous[0]?.sequenceNo ?? 0) + 1 };
  await db.insert(ownerAiRoundMessages).values(values);
  return values;
}

export async function collapseOwnerAiAnalysisRound(input: { ownerId: string; caseId: string; runId: string; synthesis: string }) {
  const db = requireDb(await getDb());
  const now = new Date();
  await db.update(ownerAiAnalysisRuns).set({
    roundState: "collapsed",
    synthesis: input.synthesis,
    collapsedAt: now,
  }).where(and(
    eq(ownerAiAnalysisRuns.ownerId, input.ownerId),
    eq(ownerAiAnalysisRuns.caseId, input.caseId),
    eq(ownerAiAnalysisRuns.id, input.runId),
    eq(ownerAiAnalysisRuns.roundState, "active"),
  ));
  return getOwnerAiAnalysisRun(input.ownerId, input.caseId, input.runId);
}

export async function approveOwnerAiAnalysisSynthesis(input: { ownerId: string; caseId: string; runId: string }) {
  const db = requireDb(await getDb());
  await db.update(ownerAiAnalysisRuns).set({ synthesisApprovedAt: new Date() }).where(and(
    eq(ownerAiAnalysisRuns.ownerId, input.ownerId),
    eq(ownerAiAnalysisRuns.caseId, input.caseId),
    eq(ownerAiAnalysisRuns.id, input.runId),
    eq(ownerAiAnalysisRuns.roundState, "collapsed"),
  ));
  return getOwnerAiAnalysisRun(input.ownerId, input.caseId, input.runId);
}

export async function createOwnerAiAnalysisExecution(input: {
  runId: string;
  modelId: string;
  role: "critical_auditor" | "draft_advocate" | "mediator";
  visibilityLevel: "integral_autorizado" | "contexto_protegido" | "redigido";
  promptHash: string;
  transmittedContentHash: string;
}) {
  const db = requireDb(await getDb());
  const values = { id: crypto.randomUUID(), ...input };
  await db.insert(ownerAiAnalysisExecutions).values(values);
  return values;
}

export async function completeOwnerAiAnalysisExecution(input: {
  executionId: string;
  responseBody?: string;
  errorSummary?: string;
}) {
  const db = requireDb(await getDb());
  await db.update(ownerAiAnalysisExecutions).set({
    status: input.errorSummary ? "failed" : "completed",
    responseBody: input.responseBody ?? null,
    errorSummary: input.errorSummary ?? null,
    completedAt: new Date(),
  }).where(eq(ownerAiAnalysisExecutions.id, input.executionId));
}

export async function listOwnerAiAnalysisRuns(ownerId: string, caseId: string) {
  const db = requireDb(await getDb());
  const runs = await db.select().from(ownerAiAnalysisRuns)
    .where(and(eq(ownerAiAnalysisRuns.ownerId, ownerId), eq(ownerAiAnalysisRuns.caseId, caseId)))
    .orderBy(desc(ownerAiAnalysisRuns.createdAt));
  return Promise.all(runs.map(async run => ({
    ...run,
    executions: await db.select().from(ownerAiAnalysisExecutions)
      .where(eq(ownerAiAnalysisExecutions.runId, run.id))
      .orderBy(desc(ownerAiAnalysisExecutions.createdAt)),
    messages: await db.select().from(ownerAiRoundMessages)
      .where(eq(ownerAiRoundMessages.runId, run.id))
      .orderBy(ownerAiRoundMessages.sequenceNo),
  })));
}

export async function getOwnerAiAnalysisRun(ownerId: string, caseId: string, runId: string) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(ownerAiAnalysisRuns).where(and(
    eq(ownerAiAnalysisRuns.ownerId, ownerId),
    eq(ownerAiAnalysisRuns.caseId, caseId),
    eq(ownerAiAnalysisRuns.id, runId),
  )).limit(1);
  return rows[0];
}

export async function decideOwnerAiAnalysisRun(input: {
  ownerId: string;
  caseId: string;
  runId: string;
  humanDecision: "use" | "review" | "discard";
  decisionNotes?: string;
}) {
  const db = requireDb(await getDb());
  await db.update(ownerAiAnalysisRuns).set({
    humanDecision: input.humanDecision,
    decisionNotes: input.decisionNotes ?? null,
    decidedAt: new Date(),
  }).where(and(
    eq(ownerAiAnalysisRuns.ownerId, input.ownerId),
    eq(ownerAiAnalysisRuns.caseId, input.caseId),
    eq(ownerAiAnalysisRuns.id, input.runId),
  ));
  return getOwnerAiAnalysisRun(input.ownerId, input.caseId, input.runId);
}

export const aiProviderCatalog = [
  { provider: "deepseek", displayName: "DeepSeek", state: "active", credentialSource: "environment", lastValidationStatus: "valid" },
  { provider: "groq", displayName: "Groq / Llama", state: "active", credentialSource: "environment", lastValidationStatus: "valid" },
  { provider: "mistral", displayName: "Mistral", state: "active", credentialSource: "environment", lastValidationStatus: "valid" },
  { provider: "openrouter", displayName: "OpenRouter", state: "active", credentialSource: "environment", lastValidationStatus: "valid" },
  { provider: "cohere", displayName: "Cohere", state: "active", credentialSource: "environment", lastValidationStatus: "valid" },
  { provider: "huggingface", displayName: "Hugging Face", state: "active", credentialSource: "environment", lastValidationStatus: "valid" },
  { provider: "xai", displayName: "xAI / Grok", state: "inactive", credentialSource: "environment", lastValidationStatus: "rejected" },
  { provider: "together", displayName: "Together AI", state: "inactive", credentialSource: "environment", lastValidationStatus: "rejected" },
  { provider: "qwen", displayName: "Qwen", state: "inactive", credentialSource: "environment", lastValidationStatus: "rejected" },
] as const;

export type AiProviderId = typeof aiProviderCatalog[number]["provider"];
type AiProviderState = "active" | "inactive" | "unconfigured";
type AiCredentialSource = "integrated" | "environment" | "owner_vault";
type AiValidationStatus = "valid" | "rejected" | "not_checked";

export async function ensureOwnerAiProviderSettings(ownerId: string) {
  const db = requireDb(await getDb());
  for (const provider of aiProviderCatalog) {
    await db.insert(ownerAiProviderSettings).values({
      id: crypto.randomUUID(),
      ownerId,
      provider: provider.provider,
      displayName: provider.displayName,
      state: provider.state,
      credentialSource: provider.credentialSource,
      lastValidationStatus: provider.lastValidationStatus,
      lastValidatedAt: new Date(),
    }).onDuplicateKeyUpdate({ set: { displayName: provider.displayName } });
  }
}

export async function listOwnerAiProviderSettings(ownerId: string) {
  const db = requireDb(await getDb());
  await ensureOwnerAiProviderSettings(ownerId);
  const rows = await db.select({
    provider: ownerAiProviderSettings.provider,
    displayName: ownerAiProviderSettings.displayName,
    state: ownerAiProviderSettings.state,
    credentialSource: ownerAiProviderSettings.credentialSource,
    lastValidatedAt: ownerAiProviderSettings.lastValidatedAt,
    lastValidationStatus: ownerAiProviderSettings.lastValidationStatus,
  }).from(ownerAiProviderSettings).where(eq(ownerAiProviderSettings.ownerId, ownerId));
  const order = new Map(aiProviderCatalog.map((item, index) => [item.provider, index]));
  return rows.sort((left, right) => (order.get(left.provider as AiProviderId) ?? 999) - (order.get(right.provider as AiProviderId) ?? 999));
}

export async function getOwnerAiProviderCredential(ownerId: string, provider: AiProviderId) {
  const db = requireDb(await getDb());
  const rows = await db.select({
    encryptedCredential: ownerAiProviderSettings.encryptedCredential,
    credentialSource: ownerAiProviderSettings.credentialSource,
    state: ownerAiProviderSettings.state,
  }).from(ownerAiProviderSettings).where(and(
    eq(ownerAiProviderSettings.ownerId, ownerId),
    eq(ownerAiProviderSettings.provider, provider),
  )).limit(1);
  return rows[0];
}

export async function saveOwnerAiProviderCredential(input: {
  ownerId: string;
  provider: AiProviderId;
  encryptedCredential: string;
  state: AiProviderState;
  lastValidationStatus: AiValidationStatus;
}) {
  const db = requireDb(await getDb());
  const known = aiProviderCatalog.find(item => item.provider === input.provider);
  if (!known) throw new Error("Provedor não reconhecido.");
  await db.insert(ownerAiProviderSettings).values({
    id: crypto.randomUUID(),
    ownerId: input.ownerId,
    provider: input.provider,
    displayName: known.displayName,
    state: input.state,
    credentialSource: "owner_vault" satisfies AiCredentialSource,
    encryptedCredential: input.encryptedCredential,
    lastValidationStatus: input.lastValidationStatus,
    lastValidatedAt: new Date(),
  }).onDuplicateKeyUpdate({ set: {
    state: input.state,
    credentialSource: "owner_vault",
    encryptedCredential: input.encryptedCredential,
    lastValidationStatus: input.lastValidationStatus,
    lastValidatedAt: new Date(),
  } });
}

export async function listOwnerAuditEvents(ownerId: string, input: { limit: number; cursor?: { id: string; createdAt: Date } }) {
  const db = requireDb(await getDb());
  const cursorCondition = input.cursor
    ? or(
        lt(ownerAuditEvents.createdAt, input.cursor.createdAt),
        and(eq(ownerAuditEvents.createdAt, input.cursor.createdAt), lt(ownerAuditEvents.id, input.cursor.id)),
      )
    : undefined;
  return db
    .select()
    .from(ownerAuditEvents)
    .where(and(
      eq(ownerAuditEvents.ownerId, ownerId),
      like(ownerAuditEvents.eventType, "owner.case_%"),
      cursorCondition,
    ))
    .orderBy(desc(ownerAuditEvents.createdAt), desc(ownerAuditEvents.id))
    .limit(input.limit + 1);
}
