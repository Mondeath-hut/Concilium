import { describe, expect, it } from "vitest";
import { buildSecretRoutingPlan, approveSecretRouting } from "@shared/secretRouting";
import { ingestApprovedSecrets } from "./secretIntakeOrchestrator";

describe("orquestrador de ingestão", () => {
  it("só grava entradas aprovadas e limpa o buffer", async () => {
    const plan = approveSecretRouting(
      buildSecretRoutingPlan(["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY"]),
      ["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY"],
    );
    const value = Buffer.from("valor-ficticio");
    const stored: unknown[] = [];
    const result = await ingestApprovedSecrets({
      plan,
      vaultKey: "chave-de-teste-nao-real-com-mais-de-32-caracteres",
      reader: {
        readManifest: async () => JSON.stringify({ secrets: [{ name: "CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY" }] }),
        readApprovedSecrets: async () => [{ name: "CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY", value }],
        close: async () => undefined,
      },
      write: async record => stored.push(record),
    });
    expect(result.stored).toBe(1);
    expect(stored).toHaveLength(1);
    expect(value.every(byte => byte === 0)).toBe(true);
  });

  it("recusa plano ainda pendente antes de ler o pacote", async () => {
    const plan = buildSecretRoutingPlan(["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY"]);
    let read = false;
    await expect(ingestApprovedSecrets({
      plan,
      vaultKey: "chave-de-teste-nao-real-com-mais-de-32-caracteres",
      reader: { readManifest: async () => { read = true; return ""; }, readApprovedSecrets: async () => [] },
      write: async () => undefined,
    })).rejects.toThrow("Nenhuma entrada aprovada para ingestão.");
    expect(read).toBe(false);
  });
});
