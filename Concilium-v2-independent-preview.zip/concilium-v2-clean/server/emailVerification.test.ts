import { describe, expect, it } from "vitest";
import { hashOwnerEmailVerificationToken, makeOwnerEmailVerificationLink, makeOwnerEmailVerificationToken, OWNER_EMAIL_VERIFICATION_TTL_MS } from "./emailVerification";

describe("email verification helpers", () => {
  it("gera token aleatório de alta entropia e armazena somente seu hash", () => {
    const first = makeOwnerEmailVerificationToken();
    const second = makeOwnerEmailVerificationToken();
    expect(first).not.toBe(second);
    expect(first.length).toBeGreaterThanOrEqual(43);
    expect(hashOwnerEmailVerificationToken(first)).toMatch(/^[a-f0-9]{64}$/);
    expect(hashOwnerEmailVerificationToken(first)).not.toContain(first);
  });

  it("constrói o callback no mesmo origin e define uma janela curta de uso", () => {
    const link = makeOwnerEmailVerificationLink("https://concilium.example", "token-seguro");
    expect(link).toBe("https://concilium.example/confirmar-email?token=token-seguro");
    expect(OWNER_EMAIL_VERIFICATION_TTL_MS).toBe(30 * 60 * 1000);
  });
});
