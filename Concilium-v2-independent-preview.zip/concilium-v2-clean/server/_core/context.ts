import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { OwnerAccount, User } from "../../drizzle/schema";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  owner?: OwnerAccount;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  // The Concilium uses its own owner session. No hosting-provider OAuth is
  // consulted here, so deployment platform authentication cannot block access.
  return { req: opts.req, res: opts.res, user: null };
}
