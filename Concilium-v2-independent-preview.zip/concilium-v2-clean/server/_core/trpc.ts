import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { getOwnerSession } from "../ownerAuth";
import { ensureOwnerOperationalIdentity, getUserByOpenId } from "../db";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const ownerProcedure = t.procedure.use(
  t.middleware(async ({ ctx, next }) => {
    const ownerSession = await getOwnerSession(ctx.req);
    if (!ownerSession) throw new TRPCError({ code: "UNAUTHORIZED", message: "Acesso do titular não autenticado." });
    return next({ ctx: { ...ctx, owner: ownerSession.owner } });
  }),
);

/**
 * Owner session plus the narrowly scoped operational identity used by the V1
 * case services. The linked user is never elevated to admin by this bridge.
 */
export const ownerOperationalProcedure = ownerProcedure.use(
  t.middleware(async ({ ctx, next }) => {
    if (!ctx.owner) throw new TRPCError({ code: "UNAUTHORIZED", message: "Acesso do titular não autenticado." });
    const operationalIdentity = await ensureOwnerOperationalIdentity(ctx.owner);
    const user = await getUserByOpenId(operationalIdentity.openId);
    if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Identidade operacional do titular indisponível." });
    return next({ ctx: { ...ctx, operationalIdentity, user } });
  }),
);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== 'admin') {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);
