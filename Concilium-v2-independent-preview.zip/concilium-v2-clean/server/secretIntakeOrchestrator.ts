import { extractSecretNamesFromManifestDocument, validateSecretNames } from "@shared/secretManifest";
import type { SecretRoutingPlanItem } from "@shared/secretRouting";
import { createSecretVaultRecord, clearSensitiveBuffer } from "./secretVault";

export type DecryptedSecretEntry = { name: string; value: Buffer };

export type SecretArchiveReader = {
  readManifest: () => Promise<string>;
  readApprovedSecrets: (names: string[]) => Promise<DecryptedSecretEntry[]>;
  close?: () => Promise<void>;
};

export type SecretVaultWriter = (record: ReturnType<typeof createSecretVaultRecord>) => Promise<void>;

/** Orquestra o fluxo sem conhecer senha nem implementar o formato do arquivo. */
export async function ingestApprovedSecrets(input: {
  reader: SecretArchiveReader;
  plan: SecretRoutingPlanItem[];
  vaultKey: string;
  write: SecretVaultWriter;
}) {
  const approved = input.plan.filter(item => item.decision === "approved");
  if (!approved.length) throw new Error("Nenhuma entrada aprovada para ingestão.");
  if (input.plan.some(item => item.decision === "proposed")) throw new Error("O plano ainda possui entradas aguardando confirmação.");
  if (input.plan.some(item => item.decision === "blocked")) throw new Error("O plano possui entradas bloqueadas.");

  try {
    const manifestContent = await input.reader.readManifest();
    const manifestNames = extractSecretNamesFromManifestDocument(manifestContent);
    const manifestCheck = validateSecretNames({ names: manifestNames });
    if (manifestCheck.unknown.length || manifestCheck.duplicates.length) throw new Error("Manifesto interno inválido.");
    const approvedNames = approved.map(item => item.name);
    if (approvedNames.some(name => !manifestNames.includes(name))) throw new Error("O manifesto não corresponde ao plano aprovado.");

    const entries = await input.reader.readApprovedSecrets(approvedNames);
    const byName = new Map(entries.map(entry => [entry.name, entry]));
    if (entries.length !== approvedNames.length || approvedNames.some(name => !byName.has(name))) throw new Error("O pacote não contém todas as entradas aprovadas.");
    if (entries.some(entry => !approvedNames.includes(entry.name))) throw new Error("O pacote contém entrada fora do plano aprovado.");

    let stored = 0;
    for (const item of approved) {
      const entry = byName.get(item.name)!;
      try {
        const record = createSecretVaultRecord({ name: item.name, consumer: item.consumer as Exclude<typeof item.consumer, "unknown">, secret: entry.value.toString("utf8"), vaultKey: input.vaultKey });
        await input.write(record);
        stored += 1;
      } finally {
        clearSensitiveBuffer(entry.value);
      }
    }
    return { stored, names: approvedNames };
  } finally {
    await input.reader.close?.();
  }
}
