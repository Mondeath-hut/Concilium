import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { ownerActivationRouter } from "./routers/ownerActivation";
import { ownerWorkspaceRouter } from "./routers/ownerWorkspace";
import { operationalCasesRouter } from "./operationalCases";
import { operationalDocumentsRouter } from "./operationalDocuments";
import { operationalAttachmentsRouter } from "./operationalAttachments";
import { knowledgeRouter } from "./routers/knowledge";
import { checklistRouter } from "./checklist";
import { actorChatRouter } from "./actorChat";
import { caseExportRouter } from "./caseExport";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  ownerActivation: ownerActivationRouter,
  ownerWorkspace: ownerWorkspaceRouter,
  operationalCases: operationalCasesRouter,
  operationalDocuments: operationalDocumentsRouter,
  operationalAttachments: operationalAttachmentsRouter,
  knowledge: knowledgeRouter,
  // [NOVO v2 / Fase 0] checklist dinâmico, parâmetros de cenário e transcrição (ao vivo + manual)
  checklist: checklistRouter,
  // [NOVO v2 / Fase 3] chat por ator anônimo (retrato clicável), com voz no front-end
  actorChat: actorChatRouter,
  // [NOVO v2 / Fase 4] exportações completas (síntese, checklist, histórico, JSON/HTML para PDF)
  caseExport: caseExportRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
