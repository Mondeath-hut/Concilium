import { createHash } from "node:crypto";
import { buildAiAnalysisPrompt, projectContentForAi, type AiRole, type AiVisibilityLevel } from "../shared/aiForumPolicy";
import { completeOwnerAiAnalysisExecution, createOwnerAiAnalysisExecution, createOwnerAiAnalysisRun } from "./db";
import { invokeLLM, listLLMModels } from "./_core/llm";

const executionRoles = ["critical_auditor", "draft_advocate", "mediator"] as const;
const promptRoles: AiRole[] = ["auditor_critico", "defensor_da_minuta", "mediador"];
const sha256 = (content: string) => createHash("sha256").update(content).digest("hex");

function textFromResult(result: Awaited<ReturnType<typeof invokeLLM>>) {
  const content = result.choices[0]?.message.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) return content.filter(part => part.type === "text").map(part => part.text).join("\n").trim();
  return "A resposta do modelo não trouxe conteúdo textual.";
}

export async function getAiLabModels() {
  const available = await listLLMModels();
  const preferredIds = ["gpt-5", "claude-sonnet-4-6", "gemini-3.1-pro-preview", "gpt-5-mini", "claude-haiku-4-5"];
  const preferred = available.data.filter(model => preferredIds.includes(model.id));
  return preferred.length ? preferred : available.data.slice(0, 5);
}

export async function executeAiForumRun(input: {
  caseId: string; documentId?: string | null; requestedBy: number; sourceKind: "documento" | "clausula"; title: string;
  sourceContent: string; objective: string; selections: Array<{ modelId: string; visibilityLevel: AiVisibilityLevel }>;
}) {
  const availableModels = await getAiLabModels();
  const selections = input.selections.filter((selection, index, all) => all.findIndex(item => item.modelId === selection.modelId) === index);
  if (!selections.length || selections.length > 3) throw new Error("Selecione de uma a três IAs para esta rodada.");
  const models = selections.map(selection => ({ ...selection, model: availableModels.find(model => model.id === selection.modelId) }));
  if (models.some(item => !item.model)) throw new Error("Uma das IAs selecionadas não está disponível no catálogo atual.");
  const mostPermissiveLevel: AiVisibilityLevel = models.some(item => item.visibilityLevel === "integral_autorizado")
    ? "integral_autorizado"
    : models.some(item => item.visibilityLevel === "contexto_protegido")
      ? "contexto_protegido"
      : "redigido";
  const consentLabel = `Titular confirmou o envio para: ${models.map(item => `${item.modelId} (${item.visibilityLevel})`).join(", ")}.`;
  const run = await createOwnerAiAnalysisRun({
    ownerId: String(input.requestedBy),
    caseId: input.caseId,
    title: input.title,
    objective: input.objective,
    originalContentHash: sha256(input.sourceContent),
    visibilityLevel: mostPermissiveLevel,
    consentLabel,
    consentConfirmedAt: new Date(),
  });
  const executions = await Promise.all(models.map(async (selection, index) => {
    const selectedModel = selection.model!;
    const role = executionRoles[index];
    const promptRole = promptRoles[index];
    const projectedContent = projectContentForAi(input.sourceContent, selection.visibilityLevel);
    const prompt = buildAiAnalysisPrompt({ title: input.title, content: projectedContent, objective: input.objective, role: promptRole, visibilityLevel: selection.visibilityLevel });
    const execution = await createOwnerAiAnalysisExecution({
      runId: run.id,
      modelId: selection.modelId,
      role,
      visibilityLevel: selection.visibilityLevel,
      promptHash: sha256(prompt),
      transmittedContentHash: sha256(projectedContent),
    });
    try {
      const response = await invokeLLM({ model: selectedModel.id, messages: [{ role: "user", content: prompt }], maxTokens: 1400 });
      const responseBody = textFromResult(response);
      await completeOwnerAiAnalysisExecution({ executionId: execution.id, responseBody });
      return { executionId: execution.id, modelId: selection.modelId, role, visibilityLevel: selection.visibilityLevel, status: "concluida" as const, responseBody };
    } catch (error) {
      const errorSummary = error instanceof Error ? error.message : "Falha não identificada ao consultar a IA.";
      await completeOwnerAiAnalysisExecution({ executionId: execution.id, errorSummary });
      return { executionId: execution.id, modelId: selection.modelId, role, visibilityLevel: selection.visibilityLevel, status: "falhou" as const, errorSummary };
    }
  }));
  return { runId: run.id, executions };
}
