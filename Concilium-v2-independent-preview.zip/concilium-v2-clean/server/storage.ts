import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { ENV } from "./_core/env";

function getStorageClient() {
  if (!ENV.storageBucket || !ENV.storageAccessKeyId || !ENV.storageSecretAccessKey) {
    throw new Error("Private object storage is not configured. Set S3_BUCKET, S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY.");
  }
  return new S3Client({
    region: ENV.storageRegion,
    endpoint: ENV.storageEndpoint || undefined,
    forcePathStyle: Boolean(ENV.storageEndpoint),
    credentials: { accessKeyId: ENV.storageAccessKeyId, secretAccessKey: ENV.storageSecretAccessKey },
  });
}

function normalizeKey(relKey: string): string {
  return relKey.replace(/^\/+/, "");
}

function appendHashSuffix(relKey: string): string {
  const hash = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  const lastDot = relKey.lastIndexOf(".");
  if (lastDot === -1) return `${relKey}_${hash}`;
  return `${relKey.slice(0, lastDot)}_${hash}${relKey.slice(lastDot)}`;
}

export async function storagePut(relKey: string, data: Buffer | Uint8Array | string, contentType = "application/octet-stream") {
  const client = getStorageClient();
  const key = appendHashSuffix(normalizeKey(relKey));
  const body = typeof data === "string" ? Buffer.from(data) : Buffer.from(data);
  await client.send(new PutObjectCommand({ Bucket: ENV.storageBucket, Key: key, Body: body, ContentType: contentType, ServerSideEncryption: ENV.storageEndpoint ? undefined : "AES256" }));
  return { key, url: `/storage/${encodeURIComponent(key).replace(/%2F/g, "/")}` };
}

export async function storageGet(relKey: string) {
  const key = normalizeKey(relKey);
  return { key, url: `/storage/${encodeURIComponent(key).replace(/%2F/g, "/")}` };
}

export async function storageGetSignedUrl(relKey: string): Promise<string> {
  const client = getStorageClient();
  const key = normalizeKey(relKey);
  return getSignedUrl(client, new GetObjectCommand({ Bucket: ENV.storageBucket, Key: key }), { expiresIn: 300 });
}
