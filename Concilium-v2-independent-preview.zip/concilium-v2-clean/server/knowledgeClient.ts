import { randomUUID } from "node:crypto";
import { canUseAsCurrentFoundation, knowledgeSearchResponseSchema, type KnowledgeSearchInput, type KnowledgeSearchResponse } from "../shared/knowledgeService";

const serviceUrl = () => process.env.CONCILIUM_KNOWLEDGE_URL?.replace(/\/$/, "") ?? "";
const serviceKey = () => process.env.CONCILIUM_KNOWLEDGE_API_KEY ?? "";

export async function searchKnowledgeService(input: KnowledgeSearchInput): Promise<KnowledgeSearchResponse> {
  const baseUrl = serviceUrl();
  if (!baseUrl) {
    return {
      configured: false,
      results: [],
      notice: "O servidor de conhecimento ainda não está conectado. A busca não foi enviada para nenhum serviço externo.",
    };
  }

  const response = await fetch(`${baseUrl}/v1/search`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json",
      ...(serviceKey() ? { authorization: `Bearer ${serviceKey()}` } : {}),
      "x-concilium-request-id": randomUUID(),
    },
    body: JSON.stringify(input),
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new Error("O servidor de conhecimento não respondeu à busca.");
  const payload = await response.json();
  const parsed = knowledgeSearchResponseSchema.parse(payload);
  const results = input.requireCurrent
    ? parsed.results.filter(result => canUseAsCurrentFoundation({
        validityState: result.validityState,
        country: result.country,
        requestedCountry: input.country,
        jurisdiction: result.jurisdiction,
        requestedJurisdiction: input.jurisdiction,
      }))
    : parsed.results;
  return {
    ...parsed,
    results,
    notice: results.length < parsed.results.length
      ? "Alguns resultados foram ocultados por estarem fora da jurisdição, superados ou sem vigência confirmada."
      : parsed.notice,
  };
}
