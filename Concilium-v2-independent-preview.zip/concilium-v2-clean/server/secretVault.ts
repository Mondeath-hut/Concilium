import { createCipheriv, createDecipheriv, pbkdf2Sync, randomBytes, createHash } from "node:crypto";
import type { SecretConsumer } from "@shared/secretManifest";

const PREFIX = "sv2";
const LEGACY_PREFIX = "sv1";

// [NOVO v2 / Fase 2] Antes, a chave do cofre vinha de um SHA-256 simples, sem sal e sem
// custo computacional — um único hash é rápido demais para resistir a força bruta offline
// se o valor cifrado vazar. A versão construída na plataforma Grok resolve isso corretamente
// (PBKDF2 com sal, tudo no navegador); aqui aplicamos a mesma técnica no cofre do servidor.
// 210.000 iterações segue a recomendação atual da OWASP para PBKDF2-HMAC-SHA256.
const PBKDF2_ITERATIONS = 210_000;
const SALT_BYTES = 16;

function deriveVaultKeyV2(vaultKey: string, salt: Buffer) {
  if (!vaultKey || vaultKey.length < 32) throw new Error("A chave do cofre precisa ter pelo menos 32 caracteres.");
  return pbkdf2Sync(vaultKey, salt, PBKDF2_ITERATIONS, 32, "sha256");
}

/** Mantido só para decifrar registros antigos (sv1); nunca usado para cifrar registros novos. */
function deriveVaultKeyLegacyV1(vaultKey: string) {
  if (!vaultKey || vaultKey.length < 32) throw new Error("A chave do cofre precisa ter pelo menos 32 caracteres.");
  return createHash("sha256").update(vaultKey, "utf8").digest();
}

/** Cifra um valor em memória. O retorno não contém o valor em claro. */
export function encryptSecretForVault(secret: string, vaultKey: string) {
  if (!secret) throw new Error("Não é permitido armazenar segredo vazio.");
  const salt = randomBytes(SALT_BYTES);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", deriveVaultKeyV2(vaultKey, salt), iv);
  const ciphertext = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return [PREFIX, salt, iv, cipher.getAuthTag(), ciphertext].map(part => part.toString("base64url")).join(".");
}

/** Uso interno controlado para entregar um segredo ao módulo autorizado. */
export function decryptSecretForVault(encrypted: string, vaultKey: string) {
  const parts = encrypted.split(".");
  const [prefix] = parts;

  if (prefix === LEGACY_PREFIX) {
    // Compatibilidade com registros gravados antes da Fase 2 (sem sal). Ao regravar
    // esse segredo (rotacionar), ele passa a usar deriveVaultKeyV2 automaticamente.
    const [, ivValue, tagValue, ciphertextValue] = parts;
    if (!ivValue || !tagValue || !ciphertextValue) throw new Error("Registro cifrado do cofre inválido.");
    const decipher = createDecipheriv("aes-256-gcm", deriveVaultKeyLegacyV1(vaultKey), Buffer.from(ivValue, "base64url"));
    decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
    return Buffer.concat([decipher.update(Buffer.from(ciphertextValue, "base64url")), decipher.final()]).toString("utf8");
  }

  const [, saltValue, ivValue, tagValue, ciphertextValue] = parts;
  if (prefix !== PREFIX || !saltValue || !ivValue || !tagValue || !ciphertextValue) throw new Error("Registro cifrado do cofre inválido.");
  const salt = Buffer.from(saltValue, "base64url");
  const decipher = createDecipheriv("aes-256-gcm", deriveVaultKeyV2(vaultKey, salt), Buffer.from(ivValue, "base64url"));
  decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertextValue, "base64url")), decipher.final()]).toString("utf8");
}

export function createSecretVaultRecord(input: { name: string; consumer: SecretConsumer; secret: string; vaultKey: string }) {
  return {
    name: input.name,
    consumer: input.consumer,
    encryptedValue: encryptSecretForVault(input.secret, input.vaultKey),
    algorithm: "aes-256-gcm+pbkdf2-sha256",
    version: PREFIX,
    createdAt: new Date().toISOString(),
  };
}

/** Limpa uma cópia mutável após o uso. Não substitui o controle de ciclo de vida do runtime. */
export function clearSensitiveBuffer(buffer: Buffer) {
  buffer.fill(0);
}
