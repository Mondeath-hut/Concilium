import { describe, expect, it } from "vitest";
import { ownerAuthThrottles } from "../drizzle/schema";

describe("schema runtime exports", () => {
  it("exports the owner authentication throttle table consumed by server repositories", () => {
    expect(ownerAuthThrottles).toBeDefined();
    expect(ownerAuthThrottles.scopeKey).toBeDefined();
  });
});
