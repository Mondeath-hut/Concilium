import { createHash } from "node:crypto";
import { z } from "zod";
import { ownerOperationalProcedure, router } from "./_core/trpc";
import { storageGetSignedUrl, storagePut } from "./storage";
import {
  getOperationalAttachment,
  listOperationalAttachments,
  recordOperationalAttachment,
} from "./operationalDb";

const caseInput = z.object({ caseId: z.string().min(8).max(36) });
const MAX_BYTES = 20 * 1024 * 1024;
const uploadInput = caseInput.extend({
  title: z.string().trim().min(3).max(220),
  mimeType: z.string().trim().min(3).max(160),
  contentBase64: z.string().min(1).max(30_000_000),
});

function safeExtension(mimeType: string) {
  const normalized = mimeType.toLowerCase();
  if (normalized === "application/pdf") return "pdf";
  if (normalized === "text/plain") return "txt";
  if (normalized === "text/html") return "html";
  if (normalized.includes("word")) return "docx";
  if (normalized.includes("sheet") || normalized.includes("excel")) return "xlsx";
  return "bin";
}

function decodeContent(contentBase64: string) {
  const normalized = contentBase64.replace(/^data:[^;]+;base64,/, "");
  const content = Buffer.from(normalized, "base64");
  if (!content.length || content.length > MAX_BYTES) {
    throw new Error("O anexo excede o limite de 20 MB ou não possui conteúdo válido.");
  }
  return content;
}

export const operationalAttachmentsRouter = router({
  list: ownerOperationalProcedure.input(caseInput).query(({ ctx, input }) =>
    listOperationalAttachments(ctx.operationalIdentity.operationalUserId, input.caseId),
  ),

  upload: ownerOperationalProcedure.input(uploadInput).mutation(async ({ ctx, input }) => {
    const content = decodeContent(input.contentBase64);
    const contentHash = createHash("sha256").update(content).digest("hex");
    const extension = safeExtension(input.mimeType);
    const objectName = input.title.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").toLowerCase();
    const result = await storagePut(
      `cases/${input.caseId}/private/${objectName}-${contentHash.slice(0, 12)}.${extension}`,
      content,
      input.mimeType,
    );
    return recordOperationalAttachment({
      userId: ctx.operationalIdentity.operationalUserId,
      caseId: input.caseId,
      title: input.title,
      storageKey: result.key,
      storageUrl: result.url,
      mimeType: input.mimeType,
      byteSize: content.byteLength,
      contentHash,
    });
  }),

  open: ownerOperationalProcedure.input(caseInput.extend({ attachmentId: z.string().min(8).max(36) })).mutation(async ({ ctx, input }) => {
    const attachment = await getOperationalAttachment(ctx.operationalIdentity.operationalUserId, input.caseId, input.attachmentId);
    if (!attachment) throw new Error("Anexo não encontrado ou não autorizado.");
    const url = await storageGetSignedUrl(attachment.storageKey);
    return { url };
  }),
});
