import { and, desc, eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import {
  concilium_checklistItems,
  concilium_scenarioParameters,
  concilium_transcriptReviews,
  concilium_transcriptSegments,
  ownerCaseNegotiationScenarios,
} from "../drizzle/schema";
import { getDb } from "./db";
import { hearingChecklistAlert, type ChecklistItemState, type ChecklistItemType, type ChecklistPriority } from "../shared/hearingChecklist";
import { assertValidScenarioMigration, type ScenarioStage } from "../shared/scenarioParameters";
import {
  analyzeTranscriptSegment,
  type ChecklistItemForMatching,
  type MatchCascadeProviders,
} from "../shared/transcriptMatching";
import type { TranscriptSegment } from "../shared/transcriptionReview";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db;
}

async function requireOwnedScenario(db: Awaited<ReturnType<typeof requireDb>>, ownerId: string, scenarioId: string) {
  const rows = await db.select().from(ownerCaseNegotiationScenarios).where(
    and(eq(ownerCaseNegotiationScenarios.id, scenarioId), eq(ownerCaseNegotiationScenarios.ownerId, ownerId)),
  ).limit(1);
  const scenario = rows[0];
  if (!scenario) throw new Error("Cenário não encontrado para este titular.");
  return scenario;
}

// ---------------------------------------------------------------------------
// Checklist dinâmico (Manual v2, seção 9)
// ---------------------------------------------------------------------------

export async function listChecklistItems(ownerId: string, scenarioId: string) {
  const db = await requireDb();
  await requireOwnedScenario(db, ownerId, scenarioId);
  const rows = await db.select().from(concilium_checklistItems).where(
    and(eq(concilium_checklistItems.ownerId, ownerId), eq(concilium_checklistItems.scenarioId, scenarioId)),
  ).orderBy(desc(concilium_checklistItems.updatedAt));
  return rows.map(row => ({
    ...row,
    canonicalKeywords: JSON.parse(row.canonicalKeywordsJson) as string[],
    alert: hearingChecklistAlert({ itemType: row.itemType, priority: row.priority, state: row.state }),
  }));
}

export async function createChecklistItem(input: {
  ownerId: string;
  caseId: string;
  scenarioId: string;
  groupLabel: string;
  description: string;
  itemType: ChecklistItemType;
  priority: ChecklistPriority;
  justification?: string;
  riskLevel?: "baixo" | "medio" | "alto";
  relatedDocumentId?: string;
  canonicalKeywords: string[];
}) {
  const db = await requireDb();
  await requireOwnedScenario(db, input.ownerId, input.scenarioId);
  const id = nanoid(24);
  await db.insert(concilium_checklistItems).values({
    id,
    ownerId: input.ownerId,
    caseId: input.caseId,
    scenarioId: input.scenarioId,
    groupLabel: input.groupLabel,
    description: input.description,
    itemType: input.itemType,
    priority: input.priority,
    state: "pendente",
    justification: input.justification,
    riskLevel: input.riskLevel ?? "baixo",
    relatedDocumentId: input.relatedDocumentId,
    canonicalKeywordsJson: JSON.stringify(input.canonicalKeywords),
  });
  return { id };
}

export async function updateChecklistItemState(input: {
  ownerId: string;
  checklistItemId: string;
  nextState: ChecklistItemState;
}) {
  const db = await requireDb();
  const rows = await db.select().from(concilium_checklistItems).where(
    and(eq(concilium_checklistItems.id, input.checklistItemId), eq(concilium_checklistItems.ownerId, input.ownerId)),
  ).limit(1);
  const item = rows[0];
  if (!item) throw new Error("Item de checklist não encontrado para este titular.");
  await db.update(concilium_checklistItems).set({ state: input.nextState }).where(eq(concilium_checklistItems.id, input.checklistItemId));
  return { id: input.checklistItemId, state: input.nextState };
}

// ---------------------------------------------------------------------------
// Parâmetros dinâmicos de cenário (Manual v2, seção 10)
// ---------------------------------------------------------------------------

export async function setScenarioParameter(input: {
  ownerId: string;
  caseId: string;
  scenarioId: string;
  parameterKey: string;
  label: string;
  valueType: "numeric" | "date" | "text" | "boolean";
  minValue?: string;
  idealValue?: string;
  maxValue?: string;
  hardFloor?: string;
  unit?: string;
}) {
  const db = await requireDb();
  await requireOwnedScenario(db, input.ownerId, input.scenarioId);
  const existing = await db.select().from(concilium_scenarioParameters).where(
    and(eq(concilium_scenarioParameters.scenarioId, input.scenarioId), eq(concilium_scenarioParameters.parameterKey, input.parameterKey)),
  ).limit(1);

  if (existing[0]) {
    await db.update(concilium_scenarioParameters).set({
      label: input.label, valueType: input.valueType, minValue: input.minValue, idealValue: input.idealValue,
      maxValue: input.maxValue, hardFloor: input.hardFloor, unit: input.unit,
    }).where(eq(concilium_scenarioParameters.id, existing[0].id));
    return { id: existing[0].id };
  }

  const id = nanoid(24);
  await db.insert(concilium_scenarioParameters).values({
    id, ownerId: input.ownerId, caseId: input.caseId, scenarioId: input.scenarioId,
    parameterKey: input.parameterKey, label: input.label, valueType: input.valueType,
    minValue: input.minValue, idealValue: input.idealValue, maxValue: input.maxValue,
    hardFloor: input.hardFloor, unit: input.unit,
  });
  return { id };
}

export async function listScenarioParameters(ownerId: string, scenarioId: string) {
  const db = await requireDb();
  await requireOwnedScenario(db, ownerId, scenarioId);
  return db.select().from(concilium_scenarioParameters).where(
    and(eq(concilium_scenarioParameters.ownerId, ownerId), eq(concilium_scenarioParameters.scenarioId, scenarioId)),
  );
}

/** Migração de estágio do cenário (Manual v2, seção 7) — sempre exige motivo, nunca é automática. */
export async function migrateScenarioStage(input: {
  ownerId: string;
  scenarioId: string;
  to: ScenarioStage;
  reason: string;
  migratedBy: string;
}) {
  const db = await requireDb();
  const scenario = await requireOwnedScenario(db, input.ownerId, input.scenarioId);
  assertValidScenarioMigration({ from: scenario.stage, to: input.to, reason: input.reason });

  await db.update(ownerCaseNegotiationScenarios).set({
    stage: input.to,
    previousScenarioVersionId: scenario.id,
    migrationReason: input.reason,
    migratedBy: input.migratedBy,
    migratedAt: new Date(),
  }).where(eq(ownerCaseNegotiationScenarios.id, input.scenarioId));

  return { id: input.scenarioId, stage: input.to };
}

// ---------------------------------------------------------------------------
// Transcrição — modo ao vivo e modo manual (Manual v2, seção 9-A)
// ---------------------------------------------------------------------------

export async function ingestTranscriptChunk(input: {
  ownerId: string;
  caseId: string;
  scenarioId: string;
  source: "audio_ao_vivo" | "ditado_manual";
  speaker?: string;
  startMs?: number;
  endMs?: number;
  textOriginal: string;
  confidence?: number;
  providers?: MatchCascadeProviders;
}) {
  const db = await requireDb();
  const items = await listChecklistItems(input.ownerId, input.scenarioId);
  const checklistItemsForMatching: ChecklistItemForMatching[] = items.map(item => ({
    id: item.id,
    description: item.description,
    canonicalKeywords: item.canonicalKeywords,
  }));

  const segmentId = nanoid(24);
  const segment: TranscriptSegment = {
    id: segmentId,
    startMs: input.startMs ?? 0,
    endMs: input.endMs ?? 0,
    textOriginal: input.textOriginal,
    speaker: input.speaker,
    confidence: input.confidence,
  };

  const analysis = await analyzeTranscriptSegment(segment, checklistItemsForMatching, input.providers ?? {});

  await db.insert(concilium_transcriptSegments).values({
    id: segmentId,
    ownerId: input.ownerId,
    caseId: input.caseId,
    source: input.source,
    speaker: input.speaker,
    startMs: input.startMs,
    endMs: input.endMs,
    textOriginal: input.textOriginal,
    confidence: input.confidence !== undefined ? String(input.confidence) : undefined,
  });

  if (analysis.reviews.length === 0) {
    return { segmentId, reviews: [], checklistMatches: analysis.checklistMatches, spokenNumbers: analysis.spokenNumbers };
  }

  const bestMatch = analysis.checklistMatches[0];
  const reviewRows = await Promise.all(analysis.reviews.map(async review => {
    const reviewId = nanoid(24);
    await db.insert(concilium_transcriptReviews).values({
      id: reviewId,
      segmentId,
      kind: review.kind,
      reason: review.reason,
      matchedChecklistItemId: bestMatch?.checklistItemId,
      matchMethod: bestMatch?.method,
      matchConfidence: bestMatch !== undefined ? String(bestMatch.confidence) : undefined,
      resolvedByOwner: "pendente",
    });
    return { id: reviewId, ...review };
  }));

  return { segmentId, reviews: reviewRows, checklistMatches: analysis.checklistMatches, spokenNumbers: analysis.spokenNumbers };
}

export async function listTranscriptReviews(ownerId: string, caseId: string) {
  const db = await requireDb();
  const segments = await db.select().from(concilium_transcriptSegments).where(
    and(eq(concilium_transcriptSegments.ownerId, ownerId), eq(concilium_transcriptSegments.caseId, caseId)),
  ).orderBy(desc(concilium_transcriptSegments.createdAt));
  const segmentIds = segments.map(segment => segment.id);
  if (segmentIds.length === 0) return [];

  const reviews = await db.select().from(concilium_transcriptReviews);
  const bySegment = new Map(segments.map(segment => [segment.id, segment]));
  return reviews
    .filter(review => bySegment.has(review.segmentId))
    .map(review => ({ ...review, segment: bySegment.get(review.segmentId) }));
}

/** O titular confirma ou descarta — é o único jeito de um alerta virar mudança de estado real. */
export async function resolveTranscriptReview(input: {
  ownerId: string;
  reviewId: string;
  resolution: "confirmado" | "descartado";
}) {
  const db = await requireDb();
  await db.update(concilium_transcriptReviews).set({
    resolvedByOwner: input.resolution,
    resolvedAt: new Date(),
  }).where(eq(concilium_transcriptReviews.id, input.reviewId));
  return { id: input.reviewId, resolution: input.resolution };
}
