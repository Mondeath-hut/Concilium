import { createHash, randomBytes } from "crypto";

export const OWNER_EMAIL_VERIFICATION_TTL_MS = 30 * 60 * 1000;

export function makeOwnerEmailVerificationToken() {
  return randomBytes(32).toString("base64url");
}

export function hashOwnerEmailVerificationToken(token: string) {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

export function makeOwnerEmailVerificationLink(origin: string, token: string) {
  const url = new URL("/confirmar-email", origin);
  url.searchParams.set("token", token);
  return url.toString();
}

export async function sendOwnerEmailVerification(input: { to: string; verificationLink: string }) {
  const apiKey = process.env.RESEND_API_KEY?.trim();
  const from = process.env.RESEND_FROM_EMAIL?.trim();
  if (!apiKey || !from) throw new Error("O envio de confirmação ainda não está configurado.");

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: [input.to],
      subject: "Confirme o e-mail institucional do Concilium",
      text: `Confirme seu e-mail institucional no Concilium: ${input.verificationLink}\n\nEste link expira em 30 minutos e pode ser usado uma única vez. Se você não iniciou esta ativação, ignore esta mensagem.`,
      html: `<p>Confirme seu e-mail institucional no Concilium.</p><p><a href="${input.verificationLink}">Confirmar e-mail institucional</a></p><p>Este link expira em 30 minutos e pode ser usado uma única vez. Se você não iniciou esta ativação, ignore esta mensagem.</p>`,
    }),
  });
  if (!response.ok) throw new Error(`Resend recusou o envio (HTTP ${response.status}).`);
  return response.json() as Promise<{ id: string }>;
}
