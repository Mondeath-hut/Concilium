import { createHash } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import {
  caseAttachments,
  caseMembers,
  documentEvents,
  negotiationCases,
  negotiationDocuments,
  strategies,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";
import { assertValidDocumentTransition, type DocumentStatus } from "../shared/negotiationRules";
import { nextDocumentVisibility } from "../shared/workspacePolicy";

const DEFAULT_STRATEGIES = [
  ["aurora", "Aurora", "Reabre o diálogo por pontos de convergência, com metas graduais e um primeiro compromisso verificável.", "Reduz atrito e permite avançar com segurança.", "Oferece previsibilidade sem exigir decisão definitiva imediata.", 82, 0],
  ["horizonte", "Horizonte", "Organiza uma transição patrimonial por marcos, prazos e revisões objetivas entre as partes.", "Dá tempo para estruturar recursos e prioridades.", "Define cronograma claro, garantias e pontos de conferência.", 74, -4],
  ["equilibrio", "Equilíbrio", "Busca equivalência material por uma composição proporcional de direitos, deveres e compensações.", "Protege o interesse patrimonial com critérios transparentes.", "Permite contrapartidas objetivas e tratamento paritário.", 67, -8],
  ["independencia", "Independência", "Constrói autonomia para cada parte por meio de divisão progressiva de responsabilidades e ativos.", "Acelera a organização individual de longo prazo.", "Estabelece limites claros e reduz dependências futuras.", 55, -13],
  ["dissolucao", "Dissolução", "Planeja a extinção ordenada dos vínculos patrimoniais, preservando a documentação e a dignidade das partes.", "Viabiliza um encerramento estruturado e rastreável.", "Diminui incerteza sobre obrigações remanescentes.", 35, -22],
  ["judicial", "Judicial", "Registra a alternativa de judicialização somente após documentadas as tentativas consensuais disponíveis.", "Preserva histórico objetivo de tentativas e posições.", "Garante acesso organizado a uma via formal de solução.", 12, -35],
] as const;

async function requireOperationalDb() {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db;
}

export async function listOperationalCases(userId: number) {
  const db = await requireOperationalDb();
  const rows = await db
    .select({ case: negotiationCases, memberRole: caseMembers.role })
    .from(caseMembers)
    .innerJoin(negotiationCases, eq(caseMembers.caseId, negotiationCases.id))
    .where(and(eq(caseMembers.userId, userId), eq(caseMembers.inviteStatus, "aceito")))
    .orderBy(desc(negotiationCases.updatedAt));
  return rows.map(row => ({ ...row.case, memberRole: row.memberRole }));
}

export async function getOperationalCaseOverview(userId: number, caseId: string) {
  const db = await requireOperationalDb();
  const caseRows = await db.select().from(negotiationCases).where(eq(negotiationCases.id, caseId)).limit(1);
  const caseRow = caseRows[0];
  if (!caseRow) return undefined;

  const memberRows = await db.select().from(caseMembers).where(and(
    eq(caseMembers.caseId, caseId),
    eq(caseMembers.userId, userId),
    eq(caseMembers.inviteStatus, "aceito"),
  )).limit(1);
  if (!memberRows[0]) return undefined;

  const [strategyRows, documentRows, eventRows] = await Promise.all([
    db.select().from(strategies).where(eq(strategies.caseId, caseId)).orderBy(strategies.position),
    db.select().from(negotiationDocuments).where(eq(negotiationDocuments.caseId, caseId)).orderBy(desc(negotiationDocuments.createdAt)),
    db.select().from(documentEvents).where(eq(documentEvents.caseId, caseId)).orderBy(desc(documentEvents.occurredAt)),
  ]);

  const status = caseRow.status === "negociacao" ? "negotiation" : caseRow.status === "acordo" ? "settled" : caseRow.status === "encerrado" ? "archived" : "draft";
  return {
    ownerCase: { id: caseRow.id, title: caseRow.title, summary: caseRow.description, status },
    strategies: strategyRows.map(strategy => ({ ...strategy, title: strategy.name, notes: strategy.description })),
    memorialEntries: [] as Array<{
      id: string;
      title: string;
      narrative: string;
      entryType: string;
      reviewStatus: "pending_review" | "verified" | "draft";
      chronologyStatus: "verified" | "pending_confirmation" | "not_applicable";
      referenceDate: string | null;
      chronologyConfidence: "high" | "medium" | "low" | "unknown";
      sourceReference: string;
    }>,
    assets: [] as Array<{
      id: string;
      title: string;
      details: string;
      assetType: string;
      reviewStatus: "pending_review" | "verified" | "draft";
      sourceReference: string;
    }>,
    documents: documentRows.map(document => ({
      id: document.id,
      title: document.title,
      documentType: document.documentType,
      sourceReference: "Documento operacional do caso",
      reviewStatus: document.currentStatus === "rascunho_interno" ? "draft" : "verified", // [NOVO v2 / Fase 0]
      hasStoredFile: false,
      body: document.body,
      currentStatus: document.currentStatus,
    })),
    scenarios: [],
    events: eventRows,
  };
}

export async function createOperationalCase(input: {
  title: string;
  description?: string | null;
  ownerId: number;
}) {
  const db = await requireOperationalDb();
  const caseId = nanoid(24);
  await db.transaction(async tx => {
    await tx.insert(negotiationCases).values({
      id: caseId,
      title: input.title,
      description: input.description ?? null,
      status: "preparacao",
      consensuality: 100,
      createdBy: input.ownerId,
    });
    await tx.insert(caseMembers).values({
      id: nanoid(24),
      caseId,
      userId: input.ownerId,
      role: "parte_principal",
      inviteStatus: "aceito",
      invitedBy: input.ownerId,
      claimedAt: new Date(),
    });
    await tx.insert(strategies).values(DEFAULT_STRATEGIES.map(([code, name, description, primaryBenefit, counterpartyBenefit, strategicPostureScore, cooperationTradeoff], position) => ({
      id: nanoid(24),
      caseId,
      code,
      name,
      description,
      primaryBenefit,
      counterpartyBenefit,
      // [NOVO v2 / Fase 4] "agreementChance" -> "strategicPostureScore" (nunca é previsão de resultado)
      strategicPostureScore,
      cooperationTradeoff,
      position: position + 1,
      releaseState: position === 0 ? ("liberada" as const) : ("reservada" as const),
      ...(position === 0 ? { releasedAt: new Date(), releasedAtUtcMs: Date.now(), releasedBy: input.ownerId } : {}),
    })));
  });
  return caseId;
}

async function requireCasePrincipal(userId: number, caseId: string) {
  const db = await requireOperationalDb();
  const rows = await db.select({ caseRow: negotiationCases, member: caseMembers })
    .from(caseMembers)
    .innerJoin(negotiationCases, eq(caseMembers.caseId, negotiationCases.id))
    .where(and(
      eq(negotiationCases.id, caseId),
      eq(caseMembers.userId, userId),
      eq(caseMembers.inviteStatus, "aceito"),
      eq(caseMembers.role, "parte_principal"),
    ))
    .limit(1);
  if (!rows[0]) throw new Error("Caso não encontrado ou não autorizado.");
  return rows[0].caseRow;
}

const contentHash = (input: { caseId: string; strategyId?: string | null; title: string; body: string; type: string }) =>
  createHash("sha256").update(JSON.stringify(input), "utf8").digest("hex");

export async function createOperationalStrategy(input: {
  userId: number;
  caseId: string;
  title: string;
  notes?: string | null;
}) {
  await requireCasePrincipal(input.userId, input.caseId);
  const db = await requireOperationalDb();
  const existing = await db.select({ position: strategies.position }).from(strategies)
    .where(eq(strategies.caseId, input.caseId)).orderBy(desc(strategies.position));
  const position = (existing[0]?.position ?? 0) + 1;
  const id = nanoid(24);
  const code = `custom-${nanoid(8).toLowerCase()}`;
  const description = input.notes?.trim() || input.title;
  await db.insert(strategies).values({
    id,
    caseId: input.caseId,
    code,
    name: input.title,
    description,
    primaryBenefit: "Benefícios a validar pelo titular.",
    counterpartyBenefit: "Contrapartidas a validar na negociação.",
    strategicPostureScore: 50,
    cooperationTradeoff: 0,
    position,
    releaseState: "reservada",
  });
  return { id, title: input.title, notes: input.notes ?? null, releaseState: "reservada" as const };
}

export async function listOperationalDocuments(userId: number, caseId: string) {
  await requireCasePrincipal(userId, caseId);
  const db = await requireOperationalDb();
  return db.select().from(negotiationDocuments)
    .where(eq(negotiationDocuments.caseId, caseId))
    .orderBy(desc(negotiationDocuments.createdAt));
}

export async function createOperationalProposal(input: {
  userId: number;
  caseId: string;
  strategyId: string;
  title: string;
  body: string;
}) {
  await requireCasePrincipal(input.userId, input.caseId);
  const db = await requireOperationalDb();
  const strategy = (await db.select().from(strategies).where(and(
    eq(strategies.id, input.strategyId),
    eq(strategies.caseId, input.caseId),
    eq(strategies.releaseState, "liberada"),
  )).limit(1))[0];
  if (!strategy) throw new Error("O cenário precisa estar liberado antes de formar a proposta.");

  const id = nanoid(24);
  const now = new Date();
  const nowMs = now.getTime();
  const hash = contentHash({ caseId: input.caseId, strategyId: input.strategyId, title: input.title, body: input.body, type: "proposta" });
  await db.transaction(async tx => {
    await tx.insert(negotiationDocuments).values({
      id,
      caseId: input.caseId,
      strategyId: input.strategyId,
      documentType: "proposta",
      title: input.title,
      body: input.body,
      contentHash: hash,
      visibility: "privado_titular",
      authoredBy: input.userId,
      currentStatus: "rascunho_interno", // [NOVO v2 / Fase 0] "rascunho" -> "rascunho_interno"
      createdAt: now,
      createdAtUtcMs: nowMs,
    });
    await tx.insert(documentEvents).values({
      id: nanoid(24), caseId: input.caseId, documentId: id, actorId: input.userId,
      eventType: "criada", details: "Proposta criada como rascunho privado.", occurredAt: now, occurredAtUtcMs: nowMs,
    });
  });
  return id;
}

export async function transitionOperationalDocument(input: {
  userId: number;
  documentId: string;
  nextStatus: Exclude<DocumentStatus, "rascunho_interno">;
}) {
  const db = await requireOperationalDb();
  const rows = await db.select().from(negotiationDocuments).where(eq(negotiationDocuments.id, input.documentId)).limit(1);
  const document = rows[0];
  if (!document) throw new Error("Documento não encontrado.");
  await requireCasePrincipal(input.userId, document.caseId);
  // [NOVO v2 / Fase 0] "enviada" -> "apresentada"
  if (document.authoredBy !== input.userId && input.nextStatus === "apresentada") throw new Error("Somente o autor pode enviar o rascunho.");
  assertValidDocumentTransition(document.currentStatus as DocumentStatus, input.nextStatus);
  const now = new Date();
  const nowMs = now.getTime();
  await db.transaction(async tx => {
    await tx.update(negotiationDocuments).set({
      currentStatus: input.nextStatus,
      visibility: nextDocumentVisibility(document.visibility, input.nextStatus),
      ...(input.nextStatus === "apresentada" ? { submittedAt: now, submittedAtUtcMs: nowMs } : {}),
    }).where(and(eq(negotiationDocuments.id, input.documentId), eq(negotiationDocuments.currentStatus, document.currentStatus)));
    await tx.insert(documentEvents).values({
      id: nanoid(24), caseId: document.caseId, documentId: document.id, actorId: input.userId,
      eventType: input.nextStatus, details: `Transição documental: ${document.currentStatus} → ${input.nextStatus}.`, occurredAt: now, occurredAtUtcMs: nowMs,
    });
  });
  return { id: document.id, status: input.nextStatus };
}

export async function listOperationalAttachments(userId: number, caseId: string) {
  await requireCasePrincipal(userId, caseId);
  const db = await requireOperationalDb();
  return db.select({
    id: caseAttachments.id,
    caseId: caseAttachments.caseId,
    title: caseAttachments.title,
    mimeType: caseAttachments.mimeType,
    byteSize: caseAttachments.byteSize,
    contentHash: caseAttachments.contentHash,
    visibility: caseAttachments.visibility,
    createdAt: caseAttachments.createdAt,
  }).from(caseAttachments)
    .where(eq(caseAttachments.caseId, caseId))
    .orderBy(desc(caseAttachments.createdAt));
}

export async function recordOperationalAttachment(input: {
  userId: number;
  caseId: string;
  title: string;
  storageKey: string;
  storageUrl: string;
  mimeType: string;
  byteSize: number;
  contentHash: string;
}) {
  await requireCasePrincipal(input.userId, input.caseId);
  const db = await requireOperationalDb();
  const id = nanoid(24);
  const now = new Date();
  await db.insert(caseAttachments).values({
    id,
    caseId: input.caseId,
    title: input.title,
    storageKey: input.storageKey,
    storageUrl: input.storageUrl,
    mimeType: input.mimeType,
    byteSize: input.byteSize,
    contentHash: input.contentHash,
    visibility: "privado_titular",
    createdBy: input.userId,
    createdAt: now,
    createdAtUtcMs: now.getTime(),
  });
  return { id, title: input.title, mimeType: input.mimeType, byteSize: input.byteSize, contentHash: input.contentHash };
}

export async function getOperationalAttachment(userId: number, caseId: string, attachmentId: string) {
  await requireCasePrincipal(userId, caseId);
  const db = await requireOperationalDb();
  const rows = await db.select().from(caseAttachments).where(and(
    eq(caseAttachments.id, attachmentId),
    eq(caseAttachments.caseId, caseId),
  )).limit(1);
  return rows[0];
}

export async function getOperationalUser(userId: number) {
  const db = await requireOperationalDb();
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return rows[0];
}
