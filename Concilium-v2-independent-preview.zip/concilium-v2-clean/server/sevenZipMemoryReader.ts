import SevenZip from "7z-wasm";
import { SECRET_MANIFEST_FILENAME } from "@shared/secretManifest";
import { sanitizeArchiveDisplayName } from "@shared/secretIntake";
import type { DecryptedSecretEntry, SecretArchiveReader } from "./secretIntakeOrchestrator";

type SevenZipInstance = Awaited<ReturnType<typeof SevenZip>>;

const ARCHIVE_NAME = "__concilium_input.7z";

/** Leitor 7z isolado no filesystem virtual do WASM. Não cria diretório temporário. */
export class SevenZipMemoryReader implements SecretArchiveReader {
  private readonly archiveData: Uint8Array;
  private readonly passwordBytes: Uint8Array;
  private wasm: SevenZipInstance | null = null;
  private closed = false;

  constructor(input: { archiveData: Uint8Array; password: string }) {
    if (!input.archiveData.length) throw new Error("Pacote 7z vazio.");
    if (!input.password) throw new Error("A senha do pacote é obrigatória.");
    this.archiveData = new Uint8Array(input.archiveData);
    this.passwordBytes = new TextEncoder().encode(input.password);
  }

  private async getWasm() {
    if (this.closed) throw new Error("Leitor 7z já encerrado.");
    if (this.wasm) return this.wasm;
    this.wasm = await SevenZip();
    const stream = this.wasm.FS.open(ARCHIVE_NAME, "w+");
    this.wasm.FS.write(stream, this.archiveData, 0, this.archiveData.length);
    this.wasm.FS.close(stream);
    this.archiveData.fill(0);
    return this.wasm;
  }

  private passwordArgument() {
    return `-p${new TextDecoder().decode(this.passwordBytes)}`;
  }

  private async extract(name: string) {
    const wasm = await this.getWasm();
    const safeName = sanitizeArchiveDisplayName(name);
    if (safeName !== name || name.includes("/") || name.includes("\\")) throw new Error("Nome de entrada não permitido.");
    const exitCode = await Promise.resolve(wasm.callMain(["x", ARCHIVE_NAME, name, this.passwordArgument(), "-y", "-bd"]) as unknown as number);
    if (exitCode !== 0) throw new Error("Não foi possível extrair a entrada 7z solicitada.");
    try {
      return new Uint8Array(wasm.FS.readFile(name));
    } finally {
      try { wasm.FS.unlink(name); } catch { /* entrada pode não ter sido criada após falha */ }
    }
  }

  async readManifest() {
    return new TextDecoder().decode(await this.extract(SECRET_MANIFEST_FILENAME));
  }

  async readApprovedSecrets(names: string[]): Promise<DecryptedSecretEntry[]> {
    const entries: DecryptedSecretEntry[] = [];
    try {
      for (const name of names) {
        const bytes = await this.extract(name);
        entries.push({ name, value: Buffer.from(bytes) });
        bytes.fill(0);
      }
      return entries;
    } catch (error) {
      for (const entry of entries) entry.value.fill(0);
      throw error;
    }
  }

  async close() {
    if (this.closed) return;
    this.closed = true;
    this.passwordBytes.fill(0);
    this.archiveData.fill(0);
    if (this.wasm) {
      try { this.wasm.FS.unlink(ARCHIVE_NAME); } catch { /* já removido */ }
      this.wasm = null;
    }
  }
}
