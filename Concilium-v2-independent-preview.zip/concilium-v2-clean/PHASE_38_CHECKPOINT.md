# Concilium — checkpoint da fase 38

## Estrategista central do Laboratório
O Estrategista passou a ser tratado como coordenador central da exploração, em paralelo ao papel de supervisor da Arena.

### Fluxo

1. o titular envia a solicitação e o contexto integral;
2. o Estrategista recebe a íntegra autorizada;
3. o Estrategista cria uma pauta com o âmago do pedido, fatos que não podem ser perdidos, eixos e lacunas;
4. as IAs do Laboratório recebem uma projeção protegida da pauta e do contexto;
5. cada linha mantém seu próprio raciocínio e histórico;
6. novas respostas do titular retornam ao Estrategista para atualização da pauta;
7. somente a parte pertinente é repassada à linha correspondente;
8. linhas podem continuar, encerrar ou receber nova pergunta, sem fusão automática.

## Persistência
A exploração passou a guardar:

- `strategistBrief`;
- `strategistModelId`;
- hash do conteúdo integral recebido;
- evidências compartilhadas;
- consentimento que registra a diferença entre acesso integral do Estrategista e projeção protegida do Laboratório.

## Implementação
- `buildStrategistCoordinatorPrompt`;
- `buildStrategistContinuationPrompt`;
- coordenação inicial antes da criação das linhas;
- coordenação novamente quando o titular responde;
- pauta atualizada persistida;
- pauta protegida incluída nas linhas;
- migração `0025_strategist_coordination.sql`;
- testes de coordenação em `shared/strategyExploration.test.ts`.

## Bibliotecário → Estrategista
O Bibliotecário continua enviando um pacote neutro e triado. A partir dele, o Estrategista recebe o âmago necessário para compreender a solicitação e pode decidir se deve levar o material ao Estrategista principal ou ao Laboratório, sem exigir que o Bibliotecário conheça o caso integral.

## Estado
A coordenação central está preparada no código. A validação com banco, build, modelos e transcrições reais continua pendente.
