# Concilium — checkpoint da fase 73

## Transparência das leituras documentais

A revisão visual agora pode expandir as leituras individuais dos papéis do ensemble.

### Exibe

- papel que analisou;
- status da análise;
- cofre sugerido por papel;
- sensibilidade sugerida;
- confiança declarada.

### Regras

- leituras são apresentadas como sugestões;
- falha de um papel permanece visível;
- divergência não é escondida por uma classificação única;
- nenhum texto é convertido em autenticidade ou prova;
- confirmação continua sendo decisão do titular.

## Arquivos

- `client/src/components/DocumentCatalogReview.tsx`;
- `PHASE_73_CHECKPOINT.md`.
