# Concilium — checkpoint da fase 5

## Avanço realizado
O primeiro módulo operacional de documentos foi conectado à sessão titular V2:

- listagem de documentos/propostas do caso;
- criação de proposta como rascunho privado;
- vínculo obrigatório com cenário liberado;
- hash de conteúdo para rastreabilidade;
- registro da criação na auditoria documental;
- envio expresso do rascunho;
- transição protegida para `enviada`;
- bloqueio de edição retroativa preservado;
- tela de negociação do `OwnerWorkspace` passou a exibir o formulário de proposta e os documentos do caso.

Também foi ligada a criação de estratégias personalizadas ao núcleo operacional, sem usar o cadastro paralelo da V2.

## Segurança preservada
- todas as operações exigem sessão titular e vínculo operacional;
- não há consulta global por papel administrativo;
- propostas não são enviadas automaticamente;
- o titular precisa escolher cenário e salvar explicitamente;
- o modo de simulação não chama mutações.

## Limitações atuais
- contraproposta depende de participante/parte autorizada e será conectada na próxima fatia;
- upload de arquivos reais e criptografia por documento ainda não foram ativados;
- validação contra banco real e build completo ainda dependem das migrações consolidadas.

## Próximo marco
Implementar biblioteca/anexos com armazenamento protegido e preparar a contraproposta com controle de participante, mantendo o caso real fora dos testes até a validação.
