# Biblioteca jurídica expansível — Knowledge Service

## Decisão
A biblioteca geral não ficará acoplada ao banco operacional do Concilium. O Concilium continuará responsável por:

- contas, passkeys e sessões;
- casos e participantes;
- documentos e anexos do caso;
- propostas, contrapropostas e auditoria;
- Arena de IAs e consentimentos.

O **Knowledge Service** ficará responsável pelo acervo jurídico geral:

- legislação, regulamentos, jurisprudência e doutrina autorizada;
- modelos e cláusulas catalogados;
- materiais por área: família, criminal, contratos, contábil, trabalhista, empresarial, processual, constitucional, tributário e geral;
- versões, vigência, jurisdição, fonte e localização da citação;
- índice lexical e índice semântico;
- relações entre assuntos próximos.

## Como o usuário consulta
A busca aparece dentro do Concilium, mas o banco não é carregado para o navegador. O fluxo é:

```text
Pergunta do titular
      ↓
Bibliotecário/assessor interpreta objetivo e área
      ↓
Knowledge Service faz busca lexical + semântica
      ↓
Resultados específicos + relacionados
      ↓
Fonte, versão, vigência, jurisdição e citação
      ↓
Titular decide se leva algo para uma minuta ou rodada da Arena
```

A resposta do bibliotecário é recuperação e organização de material. Não é parecer, decisão nem recomendação vinculante.

## Privacidade
Por padrão, a consulta envia somente a pergunta e os filtros. Contexto do caso só pode ser incluído se:

1. o titular autorizar;
2. o contexto já estiver minimizado;
3. identificadores, contatos, endereços e valores forem removidos;
4. a consulta registrar essa autorização na auditoria.

A situação jurídica relevante — por exemplo, coabitação pós-separação, regime patrimonial, filhos, áreas comuns e limites de convivência — pode ser preservada sem revelar nomes, CPF ou endereço.

## A consulta não termina no resultado
Cada resultado pode seguir três caminhos, sempre por ação explícita do titular:

1. **Salvar referência no caso** — guarda um snapshot auditável da fonte, versão, jurisdição, validade e citação, sem copiar o acervo inteiro;
2. **Adicionar ao compêndio de cláusulas** — cria um rascunho marcado como não aprovado, pronto para refinamento e teste;
3. **Refinar na Arena** — prepara a referência no caso e abre uma nova rodada, onde a formulação é confrontada por papéis distintos e submetida à revisão humana.

Uma referência não vira automaticamente cláusula válida. Uma cláusula do compêndio não vira automaticamente proposta ou acordo.

## Contrato inicial da API
`POST /v1/search`

Entrada:

- `query`;
- `areas`;
- `country` (Brasil por padrão, mas explícito no contrato);
- `jurisdiction`;
- `asOf` (data de referência);
- `requireCurrent` (verdadeiro por padrão);
- `includeRelated`;
- `contextSummary` opcional e já minimizado.

Saída:

- resultados ordenados;
- área e relevância;
- país e jurisdição;
- nível de autoridade da fonte;
- fonte e URL, quando pública;
- versão e vigência;
- status `vigente`, `revogada`, `superada`, `expirada` ou `pendente_verificacao`;
- data da última verificação e eventual substituição;
- citações/localizadores com indicação de verificação;
- assuntos relacionados;
- aviso de limites.

Quando `requireCurrent` estiver ativo, materiais revogados, superados, expirados, pendentes ou fora do país/jurisdição solicitados não entram como fundamento principal. Podem permanecer no serviço como histórico, mas não são entregues como resposta atual.

## Separação operacional
O servidor do Knowledge Service deve ter banco, índice, filas de ingestão e observabilidade próprios. O Concilium consulta apenas a API, com timeout, limite de resultados e cache curto. Assim, o crescimento do acervo não transforma a interface de casos em um arquivo pesado.

## Próxima implementação
- serviço separado com PostgreSQL e extensão de busca vetorial ou mecanismo equivalente;
- pipeline de ingestão com revisão de fonte e versão;
- taxonomia editável;
- busca híbrida;
- bibliotecário interpretativo com resposta citada;
- pipeline editorial periódico para validade, revogação e superação;
- integração de referências aprovadas com compêndio e Arena.
