# Concilium — checkpoint da fase 15

## Critério de finalização das respostas
Foi criado um protocolo para não confundir uma resposta concluída com uma oferta genérica de continuidade.

### Resposta finalizada
A linha é encerrada quando:

- respondeu ao objetivo atual;
- não há informação indispensável faltando;
- nenhuma nova informação provavelmente mudaria materialmente a alternativa;
- não existe pergunta bloqueante pendente.

### Pergunta que mantém a linha aberta
A linha permanece aguardando o titular somente quando a pergunta:

- é objetiva;
- está ligada àquela linha;
- pede uma informação indispensável;
- pode alterar materialmente a alternativa, o prazo, a viabilidade ou o próximo passo;
- não é apenas uma forma de oferecer ajuda adicional.

### Oferta opcional
Frases como “você gostaria que eu montasse uma estratégia?” ou “posso verificar outras opções?” são classificadas como `OFERTA_PROXIMA_ACAO`. Elas não reabrem a linha e não criam pergunta pendente.

## Formato controlado
As IAs devem declarar:

- `ESTADO: ENCERRADA`; ou
- `ESTADO: AGUARDANDO_RESPOSTA` + `PERGUNTA_BLOQUEANTE:`; ou
- `OFERTA_PROXIMA_ACAO:` para um próximo passo opcional.

O servidor só cria uma nova pergunta quando encontra uma `PERGUNTA_BLOQUEANTE` válida. Uma pergunta genérica de continuidade não é suficiente.

## Resultado
Uma IA pode concluir na primeira resposta, enquanto outra permanece em diálogo por precisar de dados patrimoniais, familiares ou processuais. A decisão é feita por linha, sem obrigar todas a continuar nem encerrar todas juntas.
