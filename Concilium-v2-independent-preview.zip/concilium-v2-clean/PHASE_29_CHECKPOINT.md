# Concilium — checkpoint da fase 29

## Decisão humana sobre versões
O comparador de argumentos agora possui uma etapa explícita de decisão humana. Depois de comparar a formulação inicial, enriquecida ou refinada, o titular pode registrar:

- manter a versão inicial;
- usar a versão refinada;
- mesclar com revisão;
- manter em revisão;
- futuramente descartar.

A comparação continua preservada e nenhuma versão anterior é sobrescrita.

## Implementação
- função `decideOwnerCaseArgumentComparison`;
- rota protegida `decideArgumentComparison`;
- botões na área de Estratégias;
- auditoria da decisão humana;
- estado `humanDecision` persistido na comparação.

## Regra de segurança
A decisão registrada não transforma automaticamente a formulação em acordo, parecer ou documento de assinatura. Ela apenas registra a escolha do titular sobre qual versão deve seguir para a próxima etapa.

## Estado de validação
Código preparado, sem build, testes, migração ou execução real confirmados.
