# Inventário documental recebido — 21 de agosto de 2026

Este inventário registra exclusivamente a **proveniência, categoria e limite de uso** dos anexos autorizados pelo titular. Não reproduz números de documentos, CPF, dados biométricos, endereços, contas, códigos de autenticação ou valores financeiros.

| Grupo | Fontes recebidas | Classificação inicial | Limite de uso nesta fase |
| --- | --- | --- | --- |
| Estado civil e identificação | Certidão de casamento, CNH digital do titular e fotografia de documento de identidade da outra parte | Documento civil e identificação | Metadados restritos; não exibir números nem imagens na interface geral |
| Filiação | Certidões de nascimento de dois filhos, com fotografias repetidas da mesma face documental | Documento civil familiar | Registrar a existência e a origem; revisar duplicidade antes de vincular ao caso |
| Patrimônio imobiliário | Cinco imagens sequenciais de escritura pública e um extrato de parcelas de terreno | Documento patrimonial | Relacionar ao item patrimonial já existente; manter como pendente de revisão jurídica |
| Vínculo associativo | Imagem de título e carteiras de clube | Documento patrimonial/associativo | Registrar como evidência de vínculo, sem presumir valor patrimonial ou titularidade exclusiva |
| Renda do titular | Holerites de janeiro, fevereiro, março, maio e junho de 2026; alguns incluem comprovante de pagamento | Documento financeiro | Conservar o conjunto completo; usar recorte recente somente como análise técnica, sem cálculo automático de pensão |
| Obrigações e dívidas | Relatório de dívidas | Documento financeiro | Classificar e revisar antes de associar qualquer obrigação a cenário de negociação |

## Observações de controle

1. Os holerites atualmente enviados cobrem **cinco competências não contínuas**; não há, neste lote, holerite de abril ou de julho de 2026.
2. Há imagens que aparentam ser duplicatas fotográficas de certidões. O vínculo definitivo dependerá da conferência de conteúdo e hash do arquivo.
3. Nenhum dado acima constitui conclusão sobre alimentos, patrimônio, responsabilidade, divisão de bens ou autenticidade documental. Tudo permanece sujeito à revisão jurídica humana.
4. A leitura visual inicial confirmou que as fotografias recebidas formam a frente integral de um documento de identidade civil da outra parte, contendo imagem facial e elemento de impressão digital. Assim, a documentação de identidade dela **já está presente neste lote**. Imagem facial, impressão digital, nome, dados de filiação, datas, assinatura e números documentais não serão extraídos, reproduzidos neste inventário ou exibidos em telas gerais.
5. A primeira sequência de fotografias de certidão foi confirmada como certidão de nascimento e indica filiação comum das partes. A segunda sequência foi visualmente conferida como **cópia do mesmo documento**, devendo ser tratada como duplicata até a conferência de hash. A última sequência confirma uma **segunda certidão de nascimento distinta**, também vinculada à filiação comum das partes. Por envolver dados de menor, o sistema registrará somente a existência, a categoria, a origem e a necessidade de revisão; dados de registro, nascimento, filiação e endereço não serão apresentados no memorial ou na Biblioteca geral. As duas certidões serão vinculadas por categoria, sem criar perfis individuais de menores.
6. A certidão de casamento foi visualmente confirmada como documento de estado civil e registra, em seu próprio texto, regime de **comunhão parcial de bens**. Essa anotação será mantida apenas como dado de origem documental sujeito à revisão jurídica; não será convertida pela plataforma em conclusão sobre partilha, titularidade ou responsabilidade patrimonial.
