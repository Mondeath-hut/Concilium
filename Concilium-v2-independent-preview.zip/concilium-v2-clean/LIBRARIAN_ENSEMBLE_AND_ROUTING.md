# Bibliotecário — ensemble neutro e roteamento

## Princípio
O Bibliotecário não deve ser uma única voz que decide o caso. Ele é um serviço de recuperação e qualificação de conhecimento. Pode distribuir uma consulta a agentes independentes por função, mas a consolidação só pode afirmar o que estiver apoiado em fontes e metadados verificáveis.

## Agentes do Knowledge Service

1. **Fonte primária** — legislação, atos oficiais e bases institucionais.
2. **Jurisprudência** — decisões e entendimentos relevantes, com tribunal, classe, data e localizador.
3. **Vigência e jurisdição** — verifica país, competência, versão, vigência, revogação e superação.
4. **Curador de cláusulas** — localiza cláusulas, minutas e padrões de redação como material não normativo.
5. **Fonte contrária** — procura limites, exceções, entendimento divergente e risco de extrapolação.

Esses agentes não recebem o caso protegido por padrão e não precisam compartilhar uma cadeia de raciocínio. A consolidação recebe resultados, fontes, metadados, divergências e lacunas.

## Quatro modos de consulta

### 1. Pesquisa contextual ampla

É o padrão para uma pergunta normal do usuário. O Bibliotecário não tenta adivinhar uma única busca estreita. Ele expande a pergunta em um mapa de pesquisa com:

- conceitos jurídicos relacionados;
- fontes primárias e jurisprudência;
- cláusulas e padrões de minuta pertinentes;
- requisitos, exceções e limites;
- fontes contrárias;
- lacunas que o Estrategista ou o Laboratório deverá esclarecer.

A entrega é um pacote neutro, não uma conclusão. Por padrão, segue para o Laboratório de Alternativas quando a pergunta comporta exploração de possibilidades.

### 2. Fontes e precedentes
Para perguntas como:

> Quais regras atuais tratam da partilha de imóvel no divórcio?

O Bibliotecário retorna fontes, vigência, jurisdição, autoridade, citações e relações.

### 3. Cláusulas e modelos de minuta
Para perguntas como:

> Quais modelos de cláusula são usados para copropriedade temporária após o divórcio?

O Bibliotecário pode apresentar padrões e minutas de trabalho, informando:

- origem e natureza do modelo;
- se é norma, contrato, formulário ou exemplo doutrinário;
- jurisdição e data;
- requisitos e limites;
- pontos que exigem adaptação;
- fontes contrárias ou ausência de validação.

Ele não afirma que a cláusula é válida para o caso nem escolhe a redação final.

### 4. Encaminhamento ao Estrategista
Para perguntas como:

> Qual estratégia devo usar no meu caso para negociar o imóvel?

O Bibliotecário pode pesquisar fontes neutras, mas sinaliza que a escolha deve seguir para o Estrategista. A pergunta pode ser carregada no Laboratório como uma nova exploração. O encaminhamento leva a pergunta original, o pacote neutro e os resultados recuperados com seus metadados disponíveis, em vez de transportar apenas uma palavra-chave. Isso não transforma a pesquisa em recomendação nem autoriza o Bibliotecário a conhecer o caso integral.

## Regra de fronteira

- **Bibliotecário:** “o que existe, onde está, qual a autoridade, está vigente, quais modelos e limites aparecem”.
- **Estrategista:** “quais alternativas podem ser formuladas para este contexto e quais premissas cada uma exige”.
- **Arena:** “quais alternativas resistem à crítica, às fontes, aos riscos e às objeções”.
- **Titular:** escolhe, aprova, descarta ou solicita nova rodada.

## Implementação preparada

- `shared/librarianWorkflow.ts` classifica o modo e define agentes funcionais;
- `knowledgeService.ts` aceita `researchMode` e `agentRoles`;
- o Knowledge Service recebe o modo e o conjunto de funções ativadas;
- a interface permite selecionar fontes, cláusulas/modelos ou encaminhamento estratégico;
- perguntas classificadas como estratégicas podem ser carregadas no Laboratório;
- nenhum contexto de caso é enviado ao Bibliotecário por padrão.

## Estado
A camada de contrato e roteamento está implementada. A execução real do ensemble depende da conexão do Knowledge Service, que ainda não foi configurada nem validada com fontes reais.
