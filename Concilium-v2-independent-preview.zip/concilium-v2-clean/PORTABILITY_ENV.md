# Concilium — infraestrutura independente

A aplicação não depende de autenticação, runtime, armazenamento ou proxy de IA de uma plataforma de desenvolvimento.

## Obrigatórias

- `DATABASE_URL` — MySQL
- `JWT_SECRET` — segredo das sessões
- `CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY` — chave de cifragem das credenciais de IA
- `AI_API_BASE_URL` — endpoint compatível com a API OpenAI (por exemplo, `https://openrouter.ai/api/v1`)
- `AI_API_KEY` — credencial do provedor de IA
- `S3_BUCKET` — bucket privado
- `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` — credenciais do armazenamento

## Armazenamento

Para Cloudflare R2, informe também `S3_ENDPOINT` e `S3_REGION=auto`. O endpoint é privado e os arquivos continuam sendo entregues pelo proxy autenticado do próprio Concilium.

## Opcionais

- `AI_DEFAULT_MODEL`
- `S3_ENDPOINT`
- `OWNER_NOTIFICATION_EMAIL` + `RESEND_API_KEY` para notificações por e-mail

## Observação

Documentos históricos que mencionam ambientes anteriores foram preservados como registro de proveniência. Eles não são carregados pela aplicação em produção e não participam do runtime.
