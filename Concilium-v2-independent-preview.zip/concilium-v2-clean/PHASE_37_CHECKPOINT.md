# Concilium — checkpoint da fase 37

## Estrategista integral e Laboratório protegido
A permissão foi refinada conforme a diferença entre quem recebe a pergunta e quem recebe uma projeção para explorar alternativas.

### Estrategista

O Estrategista pode receber integralmente a solicitação contextualizada pelo titular, desde que haja autorização da rodada. Isso é necessário para não destruir detalhes relevantes antes da formulação e da triagem.

A triagem direta do argumento passou a registrar `integral_autorizado` para a formulação e `redigido` para a pesquisa enviada ao Knowledge Service.

### Laboratório

As IAs divergentes não recebem automaticamente a íntegra. O servidor projeta:

- contexto;
- objetivo;
- histórico da linha;
- pergunta de continuação;
- resposta do titular.

A projeção usa `LAB_DEFAULT_ACCESS_LEVEL = contexto_protegido`, mascara identificadores e nomes declarados e preserva a semântica necessária para raciocinar sobre relações, moradia, patrimônio, despesas e limites.

### Regra de isolamento

O acesso integral do Estrategista não é repassado por herança às IAs do Laboratório. Cada transmissão tem sua própria projeção e seu próprio hash/auditoria quando persistida.

## Arquivos

- `shared/aiForumPolicy.ts`;
- `shared/workspacePolicy.ts`;
- `server/routers/ownerWorkspace.ts`;
- `shared/aiForumPolicy.test.ts`;
- `REFINEMENT_FLOW.md`.

## Estado
Política e aplicação preparadas. A comprovação com provedor real continua pendente de ambiente, credenciais seguras, build e testes executáveis.
