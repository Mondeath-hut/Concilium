# Concilium — checkpoint da fase 18

## Homologação e encaminhamento
A síntese de cada rodada agora possui dois momentos separados:

1. homologação para uso;
2. escolha do destino de trabalho.

Depois de homologada, pode ser encaminhada para:

- Bibliotecário, para conferir fundamentos e fontes;
- Compêndio, para transformar a conclusão em rascunho de cláusula;
- próxima Arena, para novo estresse ou equipe alternativa;
- arquivo, quando não for utilizada.

A aplicação não dispara uma nova consulta nem altera uma minuta somente porque um destino foi selecionado. O encaminhamento é registrado como decisão do titular.

## Regra
Síntese não homologada não pode ser encaminhada para trabalho ativo. Pode ser marcada para revisão, não utilizada ou arquivada.

## Estado
Banco, endpoints e controles iniciais de interface foram adicionados. A validação de build, migração e execução com banco real ainda está pendente.
