# Concilium — checkpoint da fase 3

## Avanço realizado
A primeira fatia funcional da ponte foi criada na cópia de consolidação `concilium-consolidado-v0.1`:

- tabela `concilium_owner_operational_links` para vínculo 1:1 entre titular V2 e usuário operacional;
- resolução determinística de identidade operacional sem fallback para administrador global;
- procedimento tRPC `ownerOperationalProcedure` que exige sessão titular e carrega a identidade vinculada;
- schema operacional da V1 incorporado à cópia de consolidação;
- router inicial `operationalCases` com listagem e criação de caso;
- criação inicial de caso com as seis estratégias e liberação controlada do primeiro cenário.

## Limitação conhecida
O router inicial já está montado, mas ainda depende da consolidação das migrações SQL e do primeiro teste com banco real. O `OwnerWorkspace` visual ainda usa seus próprios procedimentos `ownerWorkspace`; a próxima integração substituirá gradualmente esses pontos pela fonte operacional única.

## Próximo marco
- consolidar migrações do schema;
- adicionar visão geral operacional ao espaço protegido;
- trocar consultas duplicadas da V2 por consultas da fonte V1;
- criar teste de isolamento: um titular não pode listar ou abrir caso de outro titular.
