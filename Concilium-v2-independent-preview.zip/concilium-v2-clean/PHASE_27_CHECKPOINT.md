# Concilium — checkpoint da fase 27

## Comparação de versões do argumento
Foi preparada a comparação entre avaliações de um mesmo argumento, permitindo acompanhar:

- formulação inicial;
- formulação enriquecida por fontes;
- formulação refinada na Arena;
- pontos comuns;
- diferenças;
- evidências novas;
- riscos;
- perguntas para decisão humana.

## Regras

- o comparador não escolhe automaticamente uma versão vencedora;
- teses moralmente controvertidas continuam visíveis quando juridicamente arguíveis;
- fonte nova não elimina automaticamente a formulação anterior;
- a decisão humana pode manter a versão inicial, adotar a intermediária, usar a refinada, mesclar com revisão ou descartar;
- as avaliações permanecem preservadas e ligadas por origem.

## Implementação
- tabela `ownerCaseArgumentComparisons`;
- migração `0022_argument_comparisons.sql`;
- funções de criação e listagem no `server/db.ts`;
- rota protegida `compareArgumentAssessments`;
- interface de comparação na área de Estratégias.

## Estado de validação
A estrutura está preparada, mas ainda não foi executada com build, banco, migrações ou provedor de IA reais.
