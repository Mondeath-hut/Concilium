# Estrategista, Laboratório e Arena

## Não são o mesmo ambiente

### 1. Estrategista

É a figura central de formulação e coordenação. Recebe a solicitação contextualizada do titular com acesso integral autorizado.

Funções:

- compreender o pedido completo;
- identificar o âmago e os fatos que não podem ser perdidos;
- abrir linhas que o titular ainda não mencionou, quando forem relevantes;
- distribuir pautas às IAs independentes;
- acompanhar perguntas e respostas;
- decidir quais linhas continuam, encerram ou precisam de nova divisão;
- produzir um contexto estratégico amplo;
- encaminhar esse contexto para a Arena.

### 2. Laboratório de Alternativas

É a área de desenvolvimento divergente dentro do fluxo do Estrategista.

Não é a Arena e não tem objetivo de derrubar uma alternativa. As linhas devem ampliar o espaço de possibilidades, inclusive investigando dimensões não levantadas inicialmente.

Exemplos de linhas para a pergunta sobre alimentos:

- necessidade atual e vulnerabilidade;
- autonomia econômica, trabalho e tempo fora do mercado;
- idade e condições pessoais relevantes;
- natureza da obrigação alimentar;
- despesas e formas de cumprimento;
- prova e formalização;
- negociação e execução;
- riscos processuais.

Cada IA mantém uma linha própria. Perguntas podem ser agrupadas apenas para coletar a resposta do titular; o histórico e a resposta são roteados somente às linhas correspondentes.

### 3. Arena de IA

É a etapa posterior de estresse adversarial.

A Arena recebe o contexto estratégico amplo e o contexto original autorizado necessário para o supervisor. Seu objetivo não é abrir o maior número possível de hipóteses, mas testar as hipóteses formuladas.

Papéis:

- **supervisor:** coordena com acesso integral autorizado;
- **defesa:** procura preservar e fortalecer alternativas juridicamente plausíveis;
- **acusação/advogado do diabo:** procura fragilidades, contradições, obstáculos e razões para a alternativa falhar;
- **mediador:** organiza convergências, divergências, interesses e perguntas de decisão.

O ataque da acusação não significa bloqueio moral. Só devem ser bloqueadas instruções operacionais ilícitas. Teses desconfortáveis podem permanecer como possibilidades controvertidas quando forem juridicamente arguíveis e operacionalmente lícitas.

## Fluxo recomendado

```text
Pergunta integral do titular
        ↓
Estrategista central
        ↓
Laboratório de Alternativas
(amplia e desenvolve possibilidades)
        ↓
Contexto estratégico amplo
        ↓
Arena de IA
(estressa com defesa, acusação e mediador)
        ↓
Síntese robusta
        ↓
Decisão humana
```

## Por que não usar a Arena para tudo

Misturar geração divergente e ataque adversarial na mesma etapa pode eliminar cedo uma possibilidade ainda não desenvolvida. A separação preserva a exploração antes do teste.

A Arena pode abrir uma nova linha exploratória quando o supervisor identificar lacuna, mas isso deve ser uma decisão explícita da rodada, não o comportamento padrão.
