# Concilium — checkpoint da fase 45

## Agente de catalogação documental
Foi preparada a primeira camada de um catalogador de documentos com quarentena e cofres temáticos.

### Política

- documento novo entra em quarentena;
- IA sugere, titular confirma;
- nenhuma movimentação, arquivamento ou eliminação automática;
- autenticidade e verdade não são inferidas pela classificação;
- identidade e dados de terceiros permanecem protegidos;
- fatos documentais, narrativas, hipóteses e interpretações ficam separados;
- hash, origem, versão e relações devem acompanhar o item.

### Cofres

Identidade, Família, Patrimônio, Renda e despesas, Jurídico/processual, Acordos e estratégias, Evidências, Comunicações, Pesquisa, Quarentena e Arquivo.

### Funções possíveis do ensemble

- classificador documental;
- extrator de fatos e cronologia;
- leitor de relevância jurídica;
- guardião de privacidade;
- verificador de duplicidade e versões.

## Implementação inicial

- `shared/documentCatalog.ts`;
- `shared/documentCatalog.test.ts`;
- campos de catalogação na tabela de documentos;
- `drizzle/0027_document_catalog_quarantine.sql`;
- função de atualização da sugestão;
- rota protegida `catalogDocument` com consentimento explícito e texto extraído fornecido pelo titular;
- `DOCUMENT_CATALOG_AGENT.md`.

A interface de ingestão automática ainda não foi ligada porque o fluxo atual de documentos e OCR precisa ser integrado primeiro. Isso evita catalogar um arquivo sem conteúdo extraído ou fazer a IA receber documentos sem uma confirmação clara.
