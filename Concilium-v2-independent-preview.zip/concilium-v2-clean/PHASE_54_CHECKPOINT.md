# Concilium — checkpoint da fase 54

## Leitor 7z em memória
Foi criado um adaptador específico com `7z-wasm`.

### Características

- filesystem virtual do WASM;
- nenhum diretório temporário;
- arquivo copiado para a memória do módulo;
- extração pontual do manifesto e das entradas aprovadas;
- rejeição de nomes com caminho ou traversal;
- remoção das entradas virtuais após leitura;
- limpeza dos buffers do arquivo e da senha no encerramento;
- fechamento garantido pelo `finally` do orquestrador.

### Dependência

```text
7z-wasm ^1.2.0
```

### Limites

O adaptador ainda não foi executado neste ambiente porque as dependências do projeto não estão instaladas. A integração real, especialmente com o pacote protegido do usuário, continua pendente de build, instalação, testes e validação controlada. Nenhuma senha foi usada.
