# Estado funcional dos módulos internos

## Delimitação da versão atual

O espaço interno do Concilium é acessível somente com uma sessão própria do titular e está organizado sob as rotas `/espaco` e `/espaco/:section`. Esta delimitação substitui a alegação de que todos os módulos do histórico importado estariam operacionais: nesta versão, somente os fluxos descritos como **reais** abaixo consultam ou gravam dados protegidos. Os demais permanecem visíveis para preservar a arquitetura de navegação, mas informam explicitamente que não estão disponíveis e não simulam informações, convites, documentos ou análises.

| Rota | Módulo | Estado | Dados e controles atuais |
|---|---|---|---|
| `/espaco` | Visão geral | Real | Lista e cria casos exclusivamente do titular por sessão própria. O estado vazio não contém dados pré-inseridos. |
| `/espaco/estrategias` | Estratégias | Real, dependente de caso | Consulta e cria estratégias somente para um caso pertencente ao titular autenticado. |
| `/espaco/governanca` | Governança | Real, somente leitura | Exibe estado da conta, confirmação de e-mail sem endereço, total de passkeys, contingência TOTP e códigos de recuperação restantes. Não habilita convites. |
| `/espaco/auditoria` | Auditoria | Real, somente leitura | Exibe tipo e momento de eventos do titular com cursor, limite máximo de 25 e retorno sem metadados sensíveis. |
| `/espaco/negociacao` | Negociação | Indisponível | Não há propostas, contrapropostas ou mensagens persistidas nesta versão. |
| `/espaco/biblioteca` | Biblioteca | Indisponível | Não há upload, armazenamento ou visualização de documentos nesta versão. |
| `/espaco/comite-ia` | Comitê de IA | Indisponível | Não há envio de conteúdo a modelos, análise automatizada ou resultado simulado. |

## Garantias de escopo

Os procedimentos do espaço de trabalho verificam a sessão própria do titular. As consultas de casos, estratégias e auditoria recebem o identificador dessa sessão no servidor, e não um identificador escolhido pelo navegador. Na Auditoria, apenas `id`, `eventType` e `createdAt` retornam à interface; metadados de eventos, códigos, tokens e credenciais permanecem fora da resposta.

Os módulos futuros deverão ser construídos sob contratos próprios, com autorização por caso, trilha de auditoria e revisão de privacidade antes de armazenarem qualquer documento, convite, proposta ou conteúdo enviado para IA. As análises futuras terão caráter técnico e não constituirão parecer jurídico.
