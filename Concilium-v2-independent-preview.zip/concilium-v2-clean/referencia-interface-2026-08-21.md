# Referência de Interface — 21 de agosto de 2026

## Fontes examinadas

| Fonte | Constatação verificável | Limite de uso nesta versão |
|---|---|---|
| Vídeo fornecido pelo titular | Interface escura com destaque dourado, menu lateral recolhível e módulos de caso, documentos, cláusulas, histórico, governança e Comitê de IA. | Serve como referência visual e funcional; não autoriza importar dados, convites ou segredos apresentados no vídeo. |
| `https://concilium-wlq3xsnq.manus.space` | Página pública acessível com o título “Negociações conduzidas com clareza e registro” e entrada por autenticação Manus. | A área interna não ficou disponível nesta sessão de comparação; seus dados não foram acessados nem alterados. |

## Elementos prioritários de restauração

| Área | Elementos comprovadamente visíveis | Estado seguro pretendido no projeto atual |
|---|---|---|
| Linguagem visual | Fundo grafite/preto, serifas nos títulos, dourado queimado como destaque e cartões discretos. | Manter como variante visual coerente com os temas atuais, sem degradar contraste ou responsividade. |
| Navegação | Visão Geral, Estratégias, Negociação, Documentos, Cláusulas, Histórico, Governança e Comitê de IA. | Associar cada rota somente a dados protegidos existentes; convites e participantes permanecem fora do escopo até haver backend e autorização próprios. |
| Comitê de IA | Papéis técnicos, seleção de modelos e níveis de conteúdo integral, protegido ou redigido. | Preservar consentimento explícito, minimização, auditoria e decisão humana; não transmitir conteúdo sem ação do titular. |
| Documentos e cláusulas | Cofre de anexos, minutas privadas e biblioteca de cláusulas. | Abrir somente anexos já armazenados e autenticados; rascunhos permanecem técnicos, sem envio, assinatura ou protocolo. |

## Observações de segurança

Nenhum segredo, token, dado pessoal, convite, participante ou conteúdo do caso foi copiado da referência. A comparação visual não substitui a sessão própria de titular nem autoriza a migração de credenciais entre contas.
