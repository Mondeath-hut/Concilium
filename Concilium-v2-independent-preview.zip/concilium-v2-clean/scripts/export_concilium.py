#!/usr/bin/env python3
"""Gera um ZIP portátil do Concilium sem segredos nem artefatos de execução."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT.parent / "concilium-consolidado-v0.1-export.zip"
EXCLUDED_DIRS = {"node_modules", "dist", "build", ".git", ".cache", "incoming"}
EXCLUDED_NAMES = {".env", ".env.local", ".env.production", "concilium-cofre-chaves.7z", "documentos-divorcio-cloud.7z"}
EXCLUDED_SUFFIXES = {".pem", ".key", ".p12", ".pfx"}

files = []
for path in ROOT.rglob("*"):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        continue
    if path.name in EXCLUDED_NAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
        continue
    files.append(rel.as_posix())
files.sort()

manifest = {"format": "concilium-portable-export-v1", "root": ROOT.name, "fileCount": len(files), "excluded": sorted(EXCLUDED_DIRS | EXCLUDED_NAMES), "files": files}
(ROOT / "EXPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
with ZipFile(DEST, "w", ZIP_DEFLATED) as archive:
    for rel in files:
        archive.write(ROOT / rel, f"{ROOT.name}/{rel}")
print(f"created {DEST} ({len(files)} files)")
