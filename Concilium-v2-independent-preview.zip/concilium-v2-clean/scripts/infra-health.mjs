import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(new URL("..", import.meta.url).pathname);
const requiredEnv = [
  "DATABASE_URL",
  "CONCILIUM_BOOTSTRAP_CODE",
  "CONCILIUM_MFA_ENCRYPTION_KEY",
  "CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY",
  "CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY",
  "RESEND_API_KEY",
  "RESEND_FROM_EMAIL",
];

const state = name => (process.env[name]?.trim() ? "configurado" : "não configurado");
const migrationsDir = resolve(projectRoot, "drizzle");
const migrationCount = existsSync(migrationsDir)
  ? readFileSync(resolve(migrationsDir, "0000_brainy_dragon_man.sql"), "utf8") &&
    Array.from({ length: 1 }).filter(() => existsSync(migrationsDir)).length
  : 0;

const checks = {
  servidor: existsSync(resolve(projectRoot, "server/index.ts")) ? "presente" : "ausente",
  banco: state("DATABASE_URL"),
  migracoes: migrationCount > 0 ? "arquivos presentes; aplicação remota não executada" : "ausentes",
  armazenamento: existsSync(resolve(projectRoot, "server/storage.ts")) ? "adaptador presente" : "ausente",
  autenticacao: existsSync(resolve(projectRoot, "server/ownerAuth.ts")) ? "adaptador presente" : "ausente",
  resend: {
    RESEND_API_KEY: state("RESEND_API_KEY"),
    RESEND_FROM_EMAIL: state("RESEND_FROM_EMAIL"),
  },
};

console.log(JSON.stringify({
  status: Object.values(checks).every(value => typeof value === "string" ? !value.includes("ausente") : Object.values(value).every(item => item === "configurado")) ? "parcialmente configurado" : "pendencias detectadas",
  checks,
  expectedEnvironment: requiredEnv,
  safety: {
    valuesPrinted: false,
    remoteMigrationsExecuted: false,
    protectedArchivesOpened: false,
  },
}, null, 2));
