# Concilium — pacote de integração para o Manus

## Objetivo

Este documento orienta a retomada do Concilium em um ambiente Manus com servidor, banco e provedores configuráveis. O trabalho existente deve ser **preservado**. A integração deve adaptar interfaces de infraestrutura sem alterar as regras de segurança, o modelo de autorização ou o fluxo Estrategista → Laboratório → Arena.

Documentos complementares:

- `APPLICATION_OPERATING_GUIDE.md`: funcionamento da aplicação;
- `MANUS_DATABASE_SYNC.md`: sincronização do banco;
- `SENSITIVE_DOCUMENT_MIGRATION.md`: importação e tratamento de documentos sensíveis.

## Instrução principal ao integrador

> Não reescrever, simplificar ou remover funcionalidades do Concilium. Não substituir políticas por atalhos. Adaptar somente os pontos necessários para conectar servidor, banco, armazenamento, autenticação, modelos e arquivos ao ambiente Manus. Toda alteração deve ser registrada, reversível e acompanhada de teste.

## Ordem obrigatória

1. Fazer cópia do projeto antes de qualquer alteração.
2. Ler `PHASE_20_CHECKPOINT.md` até o checkpoint mais recente.
3. Ler `SECURE_SECRET_INTAKE.md`, `DOCUMENT_INTAKE_GATE.md` e `ARENA_TRIAGE_POLICY.md`.
4. Instalar dependências e executar `check`, testes e build.
5. Configurar banco de teste; nunca começar pelo banco de produção.
6. Gerar/aplicar migrações em teste, incluindo `0028_secret_vault.sql`.
7. Validar autenticação do titular e auditoria.
8. Validar o fluxo de documentos em quarentena.
9. Validar o fluxo Estrategista → Laboratório → Arena.
10. Só depois conectar provedores reais e armazenamento de produção.

## Pontos de adaptação permitidos

- conexão `DATABASE_URL` e driver compatível;
- execução de migrações Drizzle;
- armazenamento de arquivos e referências documentais;
- autenticação/passkeys/MFA conforme APIs do servidor;
- adaptadores de modelos e Knowledge Service;
- execução do `7z-wasm` no runtime suportado;
- variáveis de ambiente e secrets manager;
- observabilidade sem conteúdo sensível.

## Invariantes que não podem ser alteradas

- nenhum segredo no chat, resposta, log ou auditoria;
- senha do `.7z` somente no wizard seguro;
- nenhuma chave Mestre/Cifragem distribuída por inferência nominal;
- documentos novos permanecem em quarentena até confirmação humana;
- IA não transforma narrativa em fato provado nem decide pelo titular;
- autorização integral do supervisor não é herdada pelas IAs derivadas;
- Laboratório expande possibilidades; Arena faz estresse adversarial;
- fontes jurídicas são triadas por jurisdição, vigência, autoridade e verificabilidade;
- nenhuma ação externa ou destrutiva sem confirmação adequada;
- contexto original permanece cifrado em repouso.

## Segredos e configuração

Não transportar valores secretos neste arquivo, no chat, no Git ou em tickets. O integrador deve usar o secret manager do ambiente Manus e preencher o manifesto apenas com nomes e finalidades.

Variáveis já previstas no projeto incluem `DATABASE_URL`, `CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY`, `CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY`, `CONCILIUM_MFA_ENCRYPTION_KEY` e credenciais de provedores. Validar finalidade individual antes de configurar. `CHAVE_MESTRE` e `CHAVE_DE_CIFRAGEM` continuam sem contrato definido.

## Checklist de aceite

- [ ] instalação reproduzível;
- [ ] `pnpm check` aprovado;
- [ ] testes aprovados;
- [ ] build aprovado;
- [ ] migrações revisadas e aplicadas em teste;
- [ ] tabela `concilium_owner_secret_vault` criada;
- [ ] listagem do cofre nunca retorna `encryptedValue`;
- [ ] rotação e revogação testadas;
- [ ] leitor 7z testado com pacote fictício protegido;
- [ ] nenhuma senha real usada em teste automatizado;
- [ ] fluxo de quarentena testado;
- [ ] auditoria sem valores sensíveis;
- [ ] relatório de adaptações produzido antes da publicação.

## Resultado esperado

O Manus deve entregar um relatório contendo: arquivos alterados, motivos, migrações executadas, testes, variáveis apenas por nome, limitações, riscos pendentes e instruções de rollback. Se uma adaptação exigir mudança de política, deve parar e solicitar decisão humana em vez de modificar silenciosamente.
