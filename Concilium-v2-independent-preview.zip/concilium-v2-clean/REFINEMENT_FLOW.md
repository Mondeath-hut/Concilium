# Fluxo bidirecional de formulação e refinamento

## Princípio
O Concilium formula, organiza e compara cenários. Ele não transforma automaticamente uma conversa anterior, uma resposta de IA, uma cláusula ou uma estratégia em decisão jurídica, acordo ou fundamento vigente.

Tudo que for importado do histórico entra inicialmente como trabalho de refinamento. Mesmo uma proposta aparentemente consolidada deve conservar sua origem e passar por revisão, porque a conversa original pode conter versões posteriores, correções, alternativas abandonadas ou incerteza sobre a decisão prevalecente.

## Fluxo principal

```text
Histórico / fato / ideia
          ↓
Formulação de cenário pelo Concilium
          ↓
Estrategista ↔ Bibliotecário
          ↓
Arena de IAs
          ↓
Escolha humana: inicial, intermediária ou refinada
          ↓
Compêndio / negociação / novo ciclo
```

## Duas entradas possíveis

### Estratégia → Bibliotecário
Uma estratégia já existente pode ser enviada novamente ao Bibliotecário para:

- localizar fundamentos atuais;
- conferir jurisdição e autoridade;
- verificar vigência, revogação, superação e substituição;
- identificar se a formulação é juridicamente possível, limitada ou dependente de consenso;
- apontar quando uma resposta antiga pode estar obsoleta;
- separar fundamento encontrado de hipótese estratégica.

O resultado não aprova a estratégia. Ele cria referências e pendências verificáveis.

### Bibliotecário → Estratégia
## Pacote Estrategista → Arena

Quando uma síntese final é encaminhada, a Arena pode abrir um pacote composto por:

- contexto original integral, cifrado em repouso e liberado ao supervisor após autorização;
- contexto estratégico amplo produzido pelo Estrategista;
- pauta do Estrategista;
- síntese final e sua origem no Laboratório;
- vínculo com o caso e com a rodada.

O supervisor recebe esse pacote integral autorizado. Defesa, acusação/advogado do diabo e mediador continuam sujeitos à projeção de visibilidade da rodada. A abertura do pacote exige a chave de contexto configurada; sem ela, o sistema não envia o material como se o handoff seguro estivesse disponível.

Uma referência ou conjunto de fontes pode retornar ao Estrategista para:

- formular cenários compatíveis com o material encontrado;
- comparar alternativas mais conservadoras e mais complexas;
- identificar condições, riscos e fatos ainda necessários;
- propor redações preliminares sem apresentá-las como cláusula final.

## Papel da Arena

A Arena recebe tanto:

- cenários formulados pelo Estrategista;
- estratégias antigas importadas do histórico;
- cláusulas ou referências que precisam ser estressadas;
- divergências entre fontes, alternativas ou interpretações.

Ela confronta, critica, media e sintetiza. Não escolhe automaticamente a melhor solução. A decisão de manter a formulação inicial, adotar uma forma intermediária ou utilizar a versão refinada pertence ao titular após revisão apropriada.

## Estados recomendados

- `importado_para_revisao`;
- `cenario_em_formulacao`;
- `aguarda_fontes`;
- `fontes_em_verificacao`;
- `pronto_para_arena`;
- `em_refinamento_na_arena`;
- `versao_inicial_preservada`;
- `versao_intermediaria`;
- `versao_refinada`;
- `aguarda_decisao_humana`;
- `arquivado_sem_uso`.

Nenhum estado de refinamento equivale a homologação. A homologação precisa ser registrada separadamente, com fontes e decisão humana.

## Permissões e projeção de contexto

O Estrategista e o supervisor recebem a solicitação integral quando o titular a autoriza, porque precisam compreender o pedido e o contexto completo. Isso não elimina a triagem jurídica nem autoriza uma conclusão automática.

O Estrategista funciona como figura central do Laboratório: recebe a conversa integral, coordena os eixos, distribui uma pauta protegida às linhas independentes, acompanha suas perguntas e pode atualizar a divisão conforme novas respostas do titular. Ele mantém o raciocínio contínuo sem fundir automaticamente os históricos.

Quando o Estrategista abre o Laboratório, as IAs divergentes recebem uma projeção `contexto_protegido`: identificadores, nomes declarados, endereços, valores e números são mascarados, enquanto a semântica relacional, doméstica, patrimonial e jurídica necessária é preservada. Cada linha permanece isolada e o pacote transmitido é auditável.

A busca no Bibliotecário continua minimizada por padrão. O Bibliotecário recebe a pergunta e o perímetro de pesquisa, não o caso integral.

## Estrategista com triagem jurídica incorporada

O Estrategista não deve depender de uma passagem obrigatória pelo Bibliotecário para começar a trabalhar. Ele já nasce com uma camada de triagem de referências: cada linha de raciocínio formula alternativas, procura fundamentos por meio do contrato de conhecimento e classifica o suporte encontrado antes de apresentar uma estratégia ao titular.

Isso não elimina o Bibliotecário. Muda sua posição no fluxo: ele deixa de ser um balcão obrigatório e passa a ser um serviço especializado de pesquisa profunda, atualização editorial, conferência de fontes difíceis e auditoria de validade quando a triagem estratégica indicar necessidade.

### Classificação que o Estrategista deve mostrar

- `fundamento_atual_confirmado`: fonte original rastreável, país e jurisdição adequados, validade conferida e citação localizável;
- `possivel_controvertido`: há fundamento ou linha interpretativa, mas a aplicação depende de fatos, prova, interpretação judicial ou convencimento;
- `nao_verificado`: a ideia não foi confirmada por fonte suficiente; ausência de fonte não equivale a prova de ilegalidade;
- `fora_de_jurisdicao`: material estrangeiro, estadual/local inadequado ou sem competência para o caso;
- `incompativel_com_fonte_atual`: a hipótese colide com fonte vigente ou com requisito jurídico verificável;
- `fonte_obsoleta_ou_rejeitada`: material revogado, superado, substituído, expirado, inventado ou sem origem rastreável.

### Barreira em camadas

1. **Bloqueio de fundamento ativo:** itens incompatíveis, obsoletos, inventados ou fora da jurisdição não entram como fundamento atual de minuta ou recomendação.
2. **Aviso forte, mas não apagamento:** hipóteses controversas ou não verificadas permanecem visíveis como hipóteses de pesquisa, com explicação do risco e da lacuna.
3. **Possibilidade preservada:** uma tese improvável não deve ser chamada de impossível quando depender de interpretação judicial, prova ou convencimento. Ela deve aparecer como `possivel_controvertido`, não como estratégia validada.
4. **Exceção explícita:** o titular pode solicitar que um item bloqueado seja levado à Arena como objeto de crítica ou pesquisa, mas o sistema mantém o alerta e impede que ele seja apresentado como fundamento confirmado.

O Estrategista deve diferenciar “não encontrei suporte” de “encontrei fonte que contradiz”. Essa distinção evita tanto deixar passar uma elucubração quanto eliminar prematuramente uma tese juridicamente discutível.

### Linhas independentes com pacote comum de evidências

Cada IA mantém seu próprio raciocínio e não recebe a resposta das outras. Elas podem receber o mesmo pacote de evidências triadas — fonte, versão, jurisdição, citação, limites e status — para discutir a mesma questão sem contaminar os históricos. O pacote comum não transforma a fonte em decisão; apenas fornece uma base verificável para a divergência.

### Casos anteriores importados

Um processo ou documento de outro caso pode entrar como material de comparação, mas deve ser separado em:

- fatos do caso de origem;
- estratégia utilizada naquele caso;
- resultado conhecido;
- fontes jurídicas citadas;
- analogias possíveis;
- diferenças que impedem transposição automática.

O Estrategista nunca deve tratar o êxito de outro caso como prova de validade para este caso. Identificadores e documentos de terceiros devem ser minimizados, e a reutilização precisa ser autorizada.

## Rastreabilidade mínima

Cada cenário ou formulação deve conservar:

- origem no histórico ou documento;
- versão original, intermediária e refinada;
- estratégia ou exploração que a produziu;
- referências consultadas;
- rodadas da Arena;
- divergências e pendências;
- decisão do titular;
- destino escolhido.

Não sobrescrever a formulação anterior. Criar nova versão vinculada à anterior.
