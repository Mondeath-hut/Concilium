# Concilium — checkpoint da fase 48

## Pré-validação local do pacote
A tela do wizard agora faz uma pré-validação local do arquivo selecionado.

### O que é verificado

- nome exibido sem caminho;
- tamanho local;
- cabeçalho mágico do formato 7z;
- confirmação explícita do titular;
- senha mantida somente no estado temporário da tela.

A validação lê somente os primeiros bytes para reconhecer o formato. Não abre, extrai, envia ou grava o conteúdo.

### Estados

- arquivo selecionado;
- formato validado;
- senha pronta;
- manifesto pendente;
- aguardando confirmação;
- armazenado;
- rejeitado.

## Arquivos

- `shared/secretIntake.ts`;
- `shared/secretIntake.test.ts`;
- `client/src/components/SecretIntakePanel.tsx`;
- `PHASE_48_CHECKPOINT.md`.

## Limite
A descriptografia real do 7z e a gravação dos segredos continuam desativadas até a validação do pipeline seguro.
