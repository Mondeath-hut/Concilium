ALTER TABLE `concilium_owner_ai_analysis_runs`
  ADD COLUMN `supervisorAccessLevel` enum('integral_autorizado') NOT NULL DEFAULT 'integral_autorizado',
  ADD COLUMN `roundNumber` int NOT NULL DEFAULT 1,
  ADD COLUMN `previousRunId` varchar(64),
  ADD COLUMN `roundState` enum('active','collapsed','closed') NOT NULL DEFAULT 'active',
  ADD COLUMN `supervisorBrief` text,
  ADD COLUMN `synthesis` text,
  ADD COLUMN `synthesisApprovedAt` timestamp NULL,
  ADD COLUMN `collapsedAt` timestamp NULL;
--> statement-breakpoint
CREATE INDEX `owner_ai_runs_owner_round_idx` ON `concilium_owner_ai_analysis_runs` (`ownerId`,`caseId`,`roundNumber`);
--> statement-breakpoint
CREATE TABLE `concilium_owner_ai_round_messages` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `authorType` enum('owner','supervisor','system') NOT NULL,
  `body` text NOT NULL,
  `sequenceNo` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_ai_round_messages_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_ai_round_messages_run_idx` ON `concilium_owner_ai_round_messages` (`ownerId`,`caseId`,`runId`,`sequenceNo`);
