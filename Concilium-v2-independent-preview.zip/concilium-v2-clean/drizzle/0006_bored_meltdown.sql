CREATE TABLE `concilium_owner_ai_analysis_executions` (
	`id` varchar(64) NOT NULL,
	`runId` varchar(64) NOT NULL,
	`provider` enum('integrated_manus') NOT NULL DEFAULT 'integrated_manus',
	`modelId` varchar(160) NOT NULL,
	`role` enum('critical_auditor','draft_advocate','mediator') NOT NULL,
	`visibilityLevel` enum('integral_autorizado','contexto_protegido','redigido') NOT NULL,
	`promptHash` varchar(128) NOT NULL,
	`transmittedContentHash` varchar(128) NOT NULL,
	`responseBody` text,
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`errorSummary` varchar(800),
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `concilium_owner_ai_analysis_executions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_ai_analysis_runs` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`caseId` varchar(64) NOT NULL,
	`title` varchar(220) NOT NULL,
	`objective` text NOT NULL,
	`originalContentHash` varchar(128) NOT NULL,
	`visibilityLevel` enum('integral_autorizado','contexto_protegido','redigido') NOT NULL,
	`consentLabel` varchar(280) NOT NULL,
	`consentConfirmedAt` timestamp NOT NULL,
	`humanDecision` enum('pending','use','review','discard') NOT NULL DEFAULT 'pending',
	`decisionNotes` text,
	`decidedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `concilium_owner_ai_analysis_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_ai_executions_run_idx` ON `concilium_owner_ai_analysis_executions` (`runId`);--> statement-breakpoint
CREATE INDEX `owner_ai_executions_status_idx` ON `concilium_owner_ai_analysis_executions` (`status`);--> statement-breakpoint
CREATE INDEX `owner_ai_runs_owner_case_idx` ON `concilium_owner_ai_analysis_runs` (`ownerId`,`caseId`);--> statement-breakpoint
CREATE INDEX `owner_ai_runs_owner_created_idx` ON `concilium_owner_ai_analysis_runs` (`ownerId`,`createdAt`);