ALTER TABLE `concilium_owner_case_argument_comparisons`
  ADD COLUMN `nextDestination` enum('strategy','librarian','arena','compendium','archive') NULL AFTER `decisionNotes`,
  ADD COLUMN `routedAt` timestamp NULL AFTER `nextDestination`;
