ALTER TABLE `concilium_owner_strategy_exploration_runs`
  ADD COLUMN `originalContextEncrypted` text NULL AFTER `inputContentHash`;
