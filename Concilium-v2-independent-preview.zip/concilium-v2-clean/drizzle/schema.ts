import { bigint, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing the legacy OAuth flow. It remains isolated from the
 * native Concilium owner identity introduced below.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const ownerAccountStates = ["setup_pending", "active", "recovery_hold", "suspended"] as const;

export const ownerAccounts = mysqlTable("concilium_owner_accounts", {
  id: varchar("id", { length: 64 }).primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  state: mysqlEnum("state", ownerAccountStates).default("setup_pending").notNull(),
  emailVerifiedAt: timestamp("emailVerifiedAt"),
  activatedAt: timestamp("activatedAt"),
  bootstrapCodeRetiredAt: timestamp("bootstrapCodeRetiredAt"),
  failedActivationAttempts: int("failedActivationAttempts").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const ownerPasskeys = mysqlTable("concilium_owner_passkeys", {
  credentialId: varchar("credentialId", { length: 1024 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  publicKey: text("publicKey").notNull(),
  counter: int("counter").default(0).notNull(),
  transports: varchar("transports", { length: 320 }),
  deviceType: varchar("deviceType", { length: 64 }).notNull(),
  backedUp: int("backedUp").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastUsedAt: timestamp("lastUsedAt"),
}, table => [index("owner_passkeys_owner_idx").on(table.ownerId)]);

export const ownerMfa = mysqlTable("concilium_owner_mfa", {
  ownerId: varchar("ownerId", { length: 64 }).primaryKey(),
  totpSecretEncrypted: text("totpSecretEncrypted"),
  recoveryCodesHash: text("recoveryCodesHash").notNull(),
  totpConfiguredAt: timestamp("totpConfiguredAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const ownerSecretVault = mysqlTable("concilium_owner_secret_vault", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  consumer: varchar("consumer", { length: 64 }).notNull(),
  encryptedValue: text("encryptedValue").notNull(),
  algorithm: varchar("algorithm", { length: 64 }).notNull(),
  version: varchar("version", { length: 16 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  revokedAt: timestamp("revokedAt"),
}, table => [
  uniqueIndex("owner_secret_vault_name_uq").on(table.ownerId, table.name),
  index("owner_secret_vault_owner_idx").on(table.ownerId),
]);

export const ownerSessions = mysqlTable("concilium_owner_sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  revokedAt: timestamp("revokedAt"),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("owner_sessions_owner_idx").on(table.ownerId)]);

/** Links de confirmação: o token em texto puro nunca é persistido. */
export const ownerEmailVerifications = mysqlTable("concilium_owner_email_verifications", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  consumedAt: timestamp("consumedAt"),
  revokedAt: timestamp("revokedAt"),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_email_verifications_owner_idx").on(table.ownerId),
  index("owner_email_verifications_expiry_idx").on(table.expiresAt),
]);

export const ownerAuditEvents = mysqlTable("concilium_owner_audit_events", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }),
  eventType: varchar("eventType", { length: 96 }).notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("owner_audit_owner_idx").on(table.ownerId), index("owner_audit_event_idx").on(table.eventType)]);

/**
 * Persists a hash-derived technical scope rather than a raw address, e-mail or
 * authentication secret, allowing throttling to survive service restarts.
 */
export const ownerAuthThrottles = mysqlTable("concilium_owner_auth_throttles", {
  scopeKey: varchar("scopeKey", { length: 128 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }),
  failureCount: int("failureCount").default(0).notNull(),
  lockedUntil: timestamp("lockedUntil"),
  lastFailureAt: timestamp("lastFailureAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("owner_auth_throttles_owner_idx").on(table.ownerId), index("owner_auth_throttles_locked_idx").on(table.lockedUntil)]);

/**
 * Ponte explícita para o modelo operacional legado. A relação é 1:1 e não
 * concede privilégios administrativos; ela só permite reaproveitar os
 * serviços de casos durante a consolidação.
 */
export const ownerOperationalLinks = mysqlTable("concilium_owner_operational_links", {
  ownerId: varchar("ownerId", { length: 64 }).primaryKey(),
  operationalUserId: int("operationalUserId").notNull().unique(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("owner_operational_links_user_idx").on(table.operationalUserId)]);

/** Casos pertencem exclusivamente ao titular nativo e nunca à identidade OAuth legada. */
export const ownerCaseStatuses = ["draft", "negotiation", "review", "settled", "archived"] as const;

export const ownerCases = mysqlTable("concilium_owner_cases", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  summary: text("summary"),
  status: mysqlEnum("status", ownerCaseStatuses).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_cases_owner_idx").on(table.ownerId),
  index("owner_cases_owner_status_idx").on(table.ownerId, table.status),
]);

/** Estratégias são notas estruturadas por caso; não armazenam decisões automatizadas. */
export const ownerCaseStrategies = mysqlTable("concilium_owner_case_strategies", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_strategies_owner_case_idx").on(table.ownerId, table.caseId),
]);

/** Explorações divergentes: geram alternativas independentes e não constituem decisão ou validação jurídica. */
export const ownerStrategyExplorationRuns = mysqlTable("concilium_owner_strategy_exploration_runs", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  title: varchar("title", { length: 220 }).notNull(),
  objective: text("objective").notNull(),
  inputContentHash: varchar("inputContentHash", { length: 128 }).notNull(),
  originalContextEncrypted: text("originalContextEncrypted"),
  sourceAssessmentId: varchar("sourceAssessmentId", { length: 64 }),
  parentRunId: varchar("parentRunId", { length: 64 }),
  sourceBranchBundleId: varchar("sourceBranchBundleId", { length: 64 }),
  derivationType: mysqlEnum("derivationType", ["initial", "branch"] ).default("initial").notNull(),
  evidenceSnapshotJson: text("evidenceSnapshotJson").notNull().default("[]"),
  strategistBrief: text("strategistBrief"),
  strategistModelId: varchar("strategistModelId", { length: 160 }),
  consentLabel: varchar("consentLabel", { length: 280 }).notNull(),
  status: mysqlEnum("status", ["active", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_strategy_exploration_owner_case_idx").on(table.ownerId, table.caseId),
  index("owner_strategy_exploration_source_assessment_idx").on(table.sourceAssessmentId),
]);

export const ownerStrategyExplorationIdeas = mysqlTable("concilium_owner_strategy_exploration_ideas", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  modelId: varchar("modelId", { length: 160 }).notNull(),
  perspective: varchar("perspective", { length: 120 }).notNull(),
  ideaBody: text("ideaBody").notNull(),
  assumptions: text("assumptions"),
  risks: text("risks"),
  sourceNeeds: text("sourceNeeds"),
  status: mysqlEnum("status", ["generated", "selected_for_arena", "discarded"]).default("generated").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_strategy_exploration_ideas_run_idx").on(table.runId),
]);

/** Cada alternativa possui uma linha de raciocínio isolada, com ciclo próprio de perguntas e encerramento. */
export const ownerStrategyExplorationThreads = mysqlTable("concilium_owner_strategy_exploration_threads", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  ideaId: varchar("ideaId", { length: 64 }).notNull(),
  modelId: varchar("modelId", { length: 160 }).notNull(),
  perspective: varchar("perspective", { length: 120 }).notNull(),
  state: mysqlEnum("state", ["active", "awaiting_owner", "ceased", "selected_for_arena"]).default("awaiting_owner").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_strategy_exploration_threads_run_idx").on(table.runId),
  index("owner_strategy_exploration_threads_idea_idx").on(table.ideaId),
]);

/** Perguntas podem compartilhar grupo sem compartilhar histórico: o agrupamento é só para a coleta da resposta do titular. */
export const ownerStrategyExplorationQuestions = mysqlTable("concilium_owner_strategy_exploration_questions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  threadId: varchar("threadId", { length: 64 }).notNull(),
  questionBody: text("questionBody").notNull(),
  semanticGroupId: varchar("semanticGroupId", { length: 64 }),
  status: mysqlEnum("status", ["pending", "answered", "closed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_strategy_exploration_questions_run_idx").on(table.runId),
  index("owner_strategy_exploration_questions_group_idx").on(table.semanticGroupId),
]);

/** Uma resposta agrupada é materializada separadamente em cada thread destinatária; nenhum histórico de outra IA é anexado. */
export const ownerStrategyExplorationAnswers = mysqlTable("concilium_owner_strategy_exploration_answers", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  semanticGroupId: varchar("semanticGroupId", { length: 64 }).notNull(),
  body: text("body").notNull(),
  questionIdsJson: text("questionIdsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_strategy_exploration_answers_run_idx").on(table.runId),
  index("owner_strategy_exploration_answers_group_idx").on(table.semanticGroupId),
]);

export const ownerStrategyExplorationSyntheses = mysqlTable("concilium_owner_strategy_exploration_syntheses", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  stage: mysqlEnum("stage", ["incremental", "final"]).notNull(),
  closedThreadId: varchar("closedThreadId", { length: 64 }),
  content: text("content").notNull(),
  sourceThreadIdsJson: text("sourceThreadIdsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_strategy_exploration_syntheses_run_idx").on(table.runId, table.createdAt),
]);

export const ownerStrategyExplorationMessages = mysqlTable("concilium_owner_strategy_exploration_messages", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  threadId: varchar("threadId", { length: 64 }).notNull(),
  authorType: mysqlEnum("authorType", ["model", "owner", "system"]).notNull(),
  body: text("body").notNull(),
  questionId: varchar("questionId", { length: 64 }),
  answerId: varchar("answerId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_strategy_exploration_messages_thread_idx").on(table.threadId, table.createdAt),
]);

export const ownerStrategyBranchProposals = mysqlTable("concilium_owner_strategy_branch_proposals", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  parentThreadId: varchar("parentThreadId", { length: 64 }).notNull(),
  originQuestionId: varchar("originQuestionId", { length: 64 }),
  originMessageId: varchar("originMessageId", { length: 64 }),
  question: text("question").notNull(),
  whyItMatters: text("whyItMatters").notNull(),
  state: mysqlEnum("state", ["parked", "grouped", "ready_for_strategist", "submitted", "resolved", "dismissed"]).default("parked").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_strategy_branch_proposals_run_idx").on(table.runId, table.createdAt),
  index("owner_strategy_branch_proposals_thread_idx").on(table.parentThreadId, table.createdAt),
]);

export const ownerStrategyBranchBundles = mysqlTable("concilium_owner_strategy_branch_bundles", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  sourceProposalIdsJson: text("sourceProposalIdsJson").notNull(),
  sourceThreadIdsJson: text("sourceThreadIdsJson").notNull(),
  sourceQuestionIdsJson: text("sourceQuestionIdsJson").notNull(),
  draftQuestion: text("draftQuestion").notNull(),
  state: mysqlEnum("state", ["ready_for_strategist", "submitted", "resolved", "dismissed"]).default("ready_for_strategist").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_strategy_branch_bundles_run_idx").on(table.runId, table.createdAt),
]);

/** Triagem por argumento: legalidade, incerteza, riscos e origem ficam separados da decisão humana. */
export const ownerCaseArgumentAssessments = mysqlTable("concilium_owner_case_argument_assessments", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  strategyId: varchar("strategyId", { length: 64 }),
  sourceSynthesisId: varchar("sourceSynthesisId", { length: 64 }),
  explorationRunId: varchar("explorationRunId", { length: 64 }),
  explorationIdeaId: varchar("explorationIdeaId", { length: 64 }),
  explorationThreadId: varchar("explorationThreadId", { length: 64 }),
  runId: varchar("runId", { length: 64 }),
  executionId: varchar("executionId", { length: 64 }),
  parentAssessmentId: varchar("parentAssessmentId", { length: 64 }),
  formulation: text("formulation").notNull(),
  legalStatus: mysqlEnum("legalStatus", ["apoiado_por_fonte_vigente", "possivel_aplicacao", "controvertido", "nao_verificado", "contradito_ou_rejeitado", "fora_da_jurisdicao"]).notNull(),
  confidence: mysqlEnum("confidence", ["high", "medium", "low", "unknown"]).default("unknown").notNull(),
  evidenceStrength: mysqlEnum("evidenceStrength", ["primary", "official_structured", "licensed_secondary", "secondary", "none"]).default("none").notNull(),
  moralEthicalNotes: text("moralEthicalNotes"),
  factualDependenciesJson: text("factualDependenciesJson").notNull(),
  counterpointsJson: text("counterpointsJson").notNull(),
  limitationsJson: text("limitationsJson").notNull(),
  operationalStatus: mysqlEnum("operationalStatus", ["licito_para_analise", "requer_revisao_profissional", "bloqueado_instrucao_ilicita"]).notNull(),
  reviewStatus: mysqlEnum("reviewStatus", ["pending", "triaged", "needs_research", "arena_ready", "approved_for_use", "archived"]).default("pending").notNull(),
  sourceSnapshotJson: text("sourceSnapshotJson").notNull(),
  humanDecision: mysqlEnum("humanDecision", ["pending", "retain_initial", "use_intermediate", "use_refined", "discard"]).default("pending").notNull(),
  decisionNotes: text("decisionNotes"),
  decidedAt: timestamp("decidedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_argument_assessments_owner_case_idx").on(table.ownerId, table.caseId, table.createdAt),
  index("owner_case_argument_assessments_strategy_idx").on(table.strategyId),
  index("owner_case_argument_assessments_synthesis_idx").on(table.sourceSynthesisId),
  index("owner_case_argument_assessments_exploration_idea_idx").on(table.explorationIdeaId),
  index("owner_case_argument_assessments_exploration_thread_idx").on(table.explorationThreadId),
  index("owner_case_argument_assessments_run_idx").on(table.runId),
  index("owner_case_argument_assessments_status_idx").on(table.reviewStatus),
]);

/** Comparação entre versões de um argumento: não escolhe vencedora automaticamente. */
export const ownerCaseArgumentComparisons = mysqlTable("concilium_owner_case_argument_comparisons", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  leftAssessmentId: varchar("leftAssessmentId", { length: 64 }).notNull(),
  rightAssessmentId: varchar("rightAssessmentId", { length: 64 }).notNull(),
  modelId: varchar("modelId", { length: 160 }).notNull(),
  promptHash: varchar("promptHash", { length: 128 }).notNull(),
  comparisonBody: text("comparisonBody").notNull(),
  commonPoints: text("commonPoints").notNull(),
  differences: text("differences").notNull(),
  newEvidence: text("newEvidence").notNull(),
  risks: text("risks").notNull(),
  questions: text("questions").notNull(),
  humanDecision: mysqlEnum("humanDecision", ["pending", "retain_left", "retain_right", "merge", "review", "discard"]).default("pending").notNull(),
  decisionNotes: text("decisionNotes"),
  nextDestination: mysqlEnum("nextDestination", ["strategy", "librarian", "arena", "compendium", "archive"]),
  routedAt: timestamp("routedAt"),
  decidedAt: timestamp("decidedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_case_argument_comparisons_owner_case_idx").on(table.ownerId, table.caseId, table.createdAt),
  index("owner_case_argument_comparisons_left_idx").on(table.leftAssessmentId),
  index("owner_case_argument_comparisons_right_idx").on(table.rightAssessmentId),
]);

/** Entradas do memorial preservam a fonte e o estado de revisão, sem concluir questões jurídicas automaticamente. */
export const ownerCaseMemorialEntries = mysqlTable("concilium_owner_case_memorial_entries", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  entryType: varchar("entryType", { length: 48 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  narrative: text("narrative").notNull(),
  referenceDate: varchar("referenceDate", { length: 32 }),
  chronologyStatus: mysqlEnum("chronologyStatus", ["verified", "pending_confirmation", "not_applicable"]).default("pending_confirmation").notNull(),
  chronologyConfidence: mysqlEnum("chronologyConfidence", ["high", "medium", "low", "unknown"]).default("unknown").notNull(),
  sourceReference: varchar("sourceReference", { length: 500 }).notNull(),
  reviewStatus: mysqlEnum("reviewStatus", ["pending_review", "verified", "draft"]).default("pending_review").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_memorial_owner_case_idx").on(table.ownerId, table.caseId),
  index("owner_case_memorial_case_date_idx").on(table.caseId, table.referenceDate),
]);

/** Itens patrimoniais descrevem evidências e hipóteses de organização, não avaliações ou partilhas definitivas. */
export const ownerCaseAssets = mysqlTable("concilium_owner_case_assets", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  assetType: varchar("assetType", { length: 48 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  details: text("details").notNull(),
  sourceReference: varchar("sourceReference", { length: 500 }).notNull(),
  reviewStatus: mysqlEnum("reviewStatus", ["pending_review", "verified", "draft"]).default("pending_review").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_assets_owner_case_idx").on(table.ownerId, table.caseId),
]);

/** Biblioteca armazena metadados e origem; bytes permanecem fora do banco e só entram após fluxo de upload autorizado. */
export const ownerCaseDocuments = mysqlTable("concilium_owner_case_documents", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  documentType: varchar("documentType", { length: 64 }).notNull(),
  sourceReference: varchar("sourceReference", { length: 500 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }),
  contentHash: varchar("contentHash", { length: 128 }),
  catalogStatus: mysqlEnum("catalogStatus", ["unclassified", "suggested", "needs_owner_review", "confirmed", "quarantined", "archived"]).default("quarantined").notNull(),
  suggestedVault: varchar("suggestedVault", { length: 64 }),
  confirmedVault: varchar("confirmedVault", { length: 64 }),
  catalogSensitivity: mysqlEnum("catalogSensitivity", ["ordinary", "personal", "sensitive", "highly_sensitive"]).default("personal").notNull(),
  catalogConfidence: mysqlEnum("catalogConfidence", ["high", "medium", "low", "unknown"]).default("unknown").notNull(),
  catalogNotes: text("catalogNotes"),
  catalogedAt: timestamp("catalogedAt"),
  reviewStatus: mysqlEnum("reviewStatus", ["pending_review", "verified", "draft"]).default("pending_review").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_documents_owner_case_idx").on(table.ownerId, table.caseId),
]);

export const ownerCaseDocumentVersions = mysqlTable("concilium_owner_case_document_versions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  documentId: varchar("documentId", { length: 64 }).notNull(),
  versionLabel: varchar("versionLabel", { length: 80 }).notNull(),
  contentHash: varchar("contentHash", { length: 128 }).notNull(),
  sourceReference: varchar("sourceReference", { length: 500 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }),
  changeNote: text("changeNote").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_case_document_versions_document_idx").on(table.documentId, table.createdAt),
  index("owner_case_document_versions_owner_case_idx").on(table.ownerId, table.caseId),
]);

/** Referências do Knowledge Service salvas no caso: snapshot auditável, sem copiar o acervo inteiro. */
export const ownerCaseKnowledgeReferences = mysqlTable("concilium_owner_case_knowledge_references", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  externalEntryId: varchar("externalEntryId", { length: 180 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  summary: text("summary").notNull(),
  sourceTitle: varchar("sourceTitle", { length: 320 }).notNull(),
  sourceUrl: varchar("sourceUrl", { length: 1024 }),
  sourceVersion: varchar("sourceVersion", { length: 120 }).notNull(),
  country: varchar("country", { length: 80 }).notNull(),
  jurisdiction: varchar("jurisdiction", { length: 160 }).notNull(),
  authorityLevel: varchar("authorityLevel", { length: 48 }).notNull(),
  validityState: varchar("validityState", { length: 48 }).notNull(),
  validityCheckedAt: timestamp("validityCheckedAt"),
  supersededBy: varchar("supersededBy", { length: 180 }),
  citationsJson: text("citationsJson").notNull(),
  actionType: mysqlEnum("actionType", ["reference", "clause_compendium"]).default("reference").notNull(),
  clauseDraft: text("clauseDraft"),
  refinementStatus: mysqlEnum("refinementStatus", ["saved", "in_arena", "approved", "discarded"]).default("saved").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_knowledge_refs_owner_case_idx").on(table.ownerId, table.caseId),
  index("owner_case_knowledge_refs_external_idx").on(table.externalEntryId),
]);

/** Os 5 estágios nomeados de progressão de cenário (Manual funcional, seção 7). Migrar entre eles sempre exige motivo. */
export const negotiationScenarioStages = [
  "cooperativo",
  "cooperativo_protegido",
  "equilibrado",
  "defensivo",
  "impasse",
] as const;

/** Cenários são rascunhos de trabalho do titular e nunca constituem proposta enviada ou acordo aceito. */
export const ownerCaseNegotiationScenarios = mysqlTable("concilium_owner_case_negotiation_scenarios", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  narrative: text("narrative").notNull(),
  sourceReference: varchar("sourceReference", { length: 500 }).notNull(),
  reviewStatus: mysqlEnum("reviewStatus", ["pending_review", "verified", "draft"]).default("draft").notNull(),
  // [NOVO v2 / Fase 1] progressão nomeada e trilha de migração — ver shared/scenarioParameters.ts
  stage: mysqlEnum("stage", negotiationScenarioStages).default("cooperativo").notNull(),
  previousScenarioVersionId: varchar("previousScenarioVersionId", { length: 64 }),
  migrationReason: text("migrationReason"),
  migratedBy: varchar("migratedBy", { length: 64 }),
  migratedAt: timestamp("migratedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_scenarios_owner_case_idx").on(table.ownerId, table.caseId),
]);

export type OwnerCaseNegotiationScenario = typeof ownerCaseNegotiationScenarios.$inferSelect;

/**
 * Parâmetros dinâmicos de um cenário (Manual funcional, seção 10).
 * Cada linha é um parâmetro configurável (valor da quota, prazos, reserva mínima etc.),
 * nunca um valor solto em texto livre — para permitir comparação automática com o que
 * é dito na negociação (ver shared/transcriptMatching.ts).
 */
export const concilium_scenarioParameters = mysqlTable("concilium_scenario_parameters", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  scenarioId: varchar("scenarioId", { length: 64 }).notNull(),
  parameterKey: varchar("parameterKey", { length: 120 }).notNull(),
  label: varchar("label", { length: 200 }).notNull(),
  valueType: mysqlEnum("valueType", ["numeric", "date", "text", "boolean"]).notNull(),
  minValue: varchar("minValue", { length: 64 }),
  idealValue: varchar("idealValue", { length: 64 }),
  maxValue: varchar("maxValue", { length: 64 }),
  hardFloor: varchar("hardFloor", { length: 64 }),
  unit: varchar("unit", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("scenario_parameters_owner_case_idx").on(table.ownerId, table.caseId),
  index("scenario_parameters_scenario_idx").on(table.scenarioId),
  uniqueIndex("scenario_parameters_key_unique").on(table.scenarioId, table.parameterKey),
]);

export type ScenarioParameter = typeof concilium_scenarioParameters.$inferSelect;

/**
 * Item de checklist dinâmico (Manual funcional, seção 9).
 * As regras de estado/alerta já existem em shared/hearingChecklist.ts — esta tabela
 * é só a persistência que faltava para virar funcionalidade de fato.
 */
export const concilium_checklistItems = mysqlTable("concilium_checklist_items", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  scenarioId: varchar("scenarioId", { length: 64 }).notNull(),
  groupLabel: varchar("groupLabel", { length: 160 }).notNull(),
  description: text("description").notNull(),
  itemType: mysqlEnum("itemType", ["negociavel", "inegociavel_exige_pausa", "pendente_de_prova"]).notNull(),
  priority: mysqlEnum("priority", ["critica", "alta", "normal", "baixa"]).default("normal").notNull(),
  state: mysqlEnum("state", ["pendente", "aceito", "recusado", "parcialmente_aceito", "substituido", "dependente_confirmacao"]).default("pendente").notNull(),
  justification: text("justification"),
  riskLevel: mysqlEnum("riskLevel", ["baixo", "medio", "alto"]).default("baixo").notNull(),
  relatedDocumentId: varchar("relatedDocumentId", { length: 36 }),
  // [NOVO v2] "dicionário de contexto amplo" deste item — usado pela Camada C (léxica) do matcher.
  canonicalKeywordsJson: text("canonicalKeywordsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("checklist_items_owner_case_idx").on(table.ownerId, table.caseId),
  index("checklist_items_scenario_idx").on(table.scenarioId),
]);

export type ChecklistItemRow = typeof concilium_checklistItems.$inferSelect;

/**
 * Segmento de transcrição — vem tanto da captação ao vivo (áudio importado/transcrito)
 * quanto do modo manual (ditado direto na sala). Ver shared/transcriptMatching.ts e
 * TRANSCRICAO_AUDIENCIA_INTEGRACAO.md para as regras de consentimento e retenção.
 */
export const concilium_transcriptSegments = mysqlTable("concilium_transcript_segments", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  source: mysqlEnum("source", ["audio_ao_vivo", "ditado_manual"]).notNull(),
  speaker: varchar("speaker", { length: 120 }),
  startMs: bigint("startMs", { mode: "number" }),
  endMs: bigint("endMs", { mode: "number" }),
  textOriginal: text("textOriginal").notNull(),
  confidence: varchar("confidence", { length: 8 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("transcript_segments_owner_case_idx").on(table.ownerId, table.caseId, table.createdAt),
]);

export type TranscriptSegmentRow = typeof concilium_transcriptSegments.$inferSelect;

/**
 * Resultado da análise de um segmento (shared/transcriptionReview.ts + shared/transcriptMatching.ts).
 * Sempre requiresHumanConfirmation — o titular confirma ou descarta, nunca é automático.
 */
export const concilium_transcriptReviews = mysqlTable("concilium_transcript_reviews", {
  id: varchar("id", { length: 64 }).primaryKey(),
  segmentId: varchar("segmentId", { length: 64 }).notNull(),
  kind: mysqlEnum("kind", ["possivel_proposta", "possivel_aceite", "possivel_recusa", "valor_ou_prazo", "fala_ambigua"]).notNull(),
  reason: text("reason").notNull(),
  matchedChecklistItemId: varchar("matchedChecklistItemId", { length: 64 }),
  matchMethod: mysqlEnum("matchMethod", ["online", "local_offline", "lexico"]),
  matchConfidence: varchar("matchConfidence", { length: 8 }),
  resolvedByOwner: mysqlEnum("resolvedByOwner", ["pendente", "confirmado", "descartado"]).default("pendente").notNull(),
  resolvedAt: timestamp("resolvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("transcript_reviews_segment_idx").on(table.segmentId),
  index("transcript_reviews_matched_item_idx").on(table.matchedChecklistItemId),
]);

export type TranscriptReviewRow = typeof concilium_transcriptReviews.$inferSelect;

/** Sessões da Arena permitem equipes/linhas alternativas sem apagar ou reiniciar a sessão anterior. */
export const ownerAiArenaSessions = mysqlTable("concilium_owner_ai_arena_sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  label: varchar("label", { length: 180 }).notNull(),
  teamLabel: varchar("teamLabel", { length: 180 }).notNull(),
  branchFromRunId: varchar("branchFromRunId", { length: 64 }),
  status: mysqlEnum("status", ["active", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_ai_arena_sessions_owner_case_idx").on(table.ownerId, table.caseId),
]);

/** Artefatos de síntese podem virar rascunho do compêndio sem se tornarem cláusula aprovada. */
export const ownerCaseCompendiumEntries = mysqlTable("concilium_owner_case_compendium_entries", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  sourceRunId: varchar("sourceRunId", { length: 64 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  body: text("body").notNull(),
  status: mysqlEnum("status", ["draft", "approved", "archived"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("owner_case_compendium_owner_case_idx").on(table.ownerId, table.caseId),
  index("owner_case_compendium_source_idx").on(table.sourceRunId),
]);

/** Pedidos de pesquisa derivados de uma síntese homologada, aguardando consulta do Bibliotecário. */
export const ownerCaseResearchRequests = mysqlTable("concilium_owner_case_research_requests", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  sourceRunId: varchar("sourceRunId", { length: 64 }).notNull(),
  sourceAssessmentId: varchar("sourceAssessmentId", { length: 64 }),
  strategyId: varchar("strategyId", { length: 64 }),
  query: text("query").notNull(),
  resultSnapshotJson: text("resultSnapshotJson").notNull().default("[]"),
  status: mysqlEnum("status", ["pending", "answered", "archived"]).default("pending").notNull(),
  answeredAt: timestamp("answeredAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_case_research_requests_owner_case_idx").on(table.ownerId, table.caseId, table.createdAt),
  index("owner_case_research_requests_assessment_idx").on(table.sourceAssessmentId),
  index("owner_case_research_requests_strategy_idx").on(table.strategyId),
]);

/** Rodadas privadas iniciadas pelo titular; o contexto de origem só pode ser persistido cifrado para handoff autorizado ao supervisor. */
export const ownerAiAnalysisRuns = mysqlTable("concilium_owner_ai_analysis_runs", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  title: varchar("title", { length: 220 }).notNull(),
  objective: text("objective").notNull(),
  originalContentHash: varchar("originalContentHash", { length: 128 }).notNull(),
  visibilityLevel: mysqlEnum("visibilityLevel", ["integral_autorizado", "contexto_protegido", "redigido"]).notNull(),
  supervisorAccessLevel: mysqlEnum("supervisorAccessLevel", ["integral_autorizado"]).default("integral_autorizado").notNull(),
  consentLabel: varchar("consentLabel", { length: 280 }).notNull(),
  consentConfirmedAt: timestamp("consentConfirmedAt").notNull(),
  roundNumber: int("roundNumber").default(1).notNull(),
  sessionId: varchar("sessionId", { length: 64 }),
  previousRunId: varchar("previousRunId", { length: 64 }),
  roundState: mysqlEnum("roundState", ["active", "collapsed", "closed"]).default("active").notNull(),
  synthesisUseStatus: mysqlEnum("synthesisUseStatus", ["pending", "homologated", "not_used", "requires_review"]).default("pending").notNull(),
  synthesisUsedAt: timestamp("synthesisUsedAt"),
  supervisorBrief: text("supervisorBrief"),
  synthesis: text("synthesis"),
  synthesisApprovedAt: timestamp("synthesisApprovedAt"),
  humanDecision: mysqlEnum("humanDecision", ["pending", "use", "review", "discard"]).default("pending").notNull(),
  decisionNotes: text("decisionNotes"),
  decidedAt: timestamp("decidedAt"),
  collapsedAt: timestamp("collapsedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_ai_runs_owner_case_idx").on(table.ownerId, table.caseId),
  index("owner_ai_runs_owner_created_idx").on(table.ownerId, table.createdAt),
  index("owner_ai_runs_owner_round_idx").on(table.ownerId, table.caseId, table.roundNumber),
]);

/** Uma execução independente por modelo, com rastreabilidade do que foi autorizado sem armazenar o prompt em claro. */
export const ownerAiAnalysisExecutions = mysqlTable("concilium_owner_ai_analysis_executions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull(),
  provider: mysqlEnum("provider", ["deepseek", "groq", "mistral", "openrouter", "cohere", "huggingface", "xai", "together", "qwen"]).default("openrouter").notNull(),
  modelId: varchar("modelId", { length: 160 }).notNull(),
  role: mysqlEnum("role", ["critical_auditor", "draft_advocate", "mediator"]).notNull(),
  visibilityLevel: mysqlEnum("visibilityLevel", ["integral_autorizado", "contexto_protegido", "redigido"]).notNull(),
  promptHash: varchar("promptHash", { length: 128 }).notNull(),
  transmittedContentHash: varchar("transmittedContentHash", { length: 128 }).notNull(),
  responseBody: text("responseBody"),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  errorSummary: varchar("errorSummary", { length: 800 }),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_ai_executions_run_idx").on(table.runId),
  index("owner_ai_executions_status_idx").on(table.status),
]);

/** Intervenções e coordenação da rodada. O supervisor recebe conteúdo integral autorizado; as respostas derivadas passam pelo filtro de visibilidade de cada IA. */
export const ownerAiRoundMessages = mysqlTable("concilium_owner_ai_round_messages", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  runId: varchar("runId", { length: 64 }).notNull(),
  authorType: mysqlEnum("authorType", ["owner", "supervisor", "system"]).notNull(),
  body: text("body").notNull(),
  sequenceNo: int("sequenceNo").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_ai_round_messages_run_idx").on(table.ownerId, table.caseId, table.runId, table.sequenceNo),
]);

/** Destino escolhido pelo titular para uma síntese já revisada, sem disparar envio automático. */
export const ownerAiSynthesisDestinations = mysqlTable("concilium_owner_ai_synthesis_destinations", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  runId: varchar("runId", { length: 64 }).notNull(),
  destination: mysqlEnum("destination", ["bibliotecario", "compendio", "arena", "arquivo"]).notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_ai_synthesis_destinations_owner_case_idx").on(table.ownerId, table.caseId, table.createdAt),
  index("owner_ai_synthesis_destinations_run_idx").on(table.runId),
]);

/** Comparações assistidas entre sínteses; o comparador não decide qual alternativa deve prevalecer. */
export const ownerAiSynthesisComparisons = mysqlTable("concilium_owner_ai_synthesis_comparisons", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  caseId: varchar("caseId", { length: 64 }).notNull(),
  leftRunId: varchar("leftRunId", { length: 64 }).notNull(),
  rightRunId: varchar("rightRunId", { length: 64 }).notNull(),
  commonPoints: text("commonPoints").notNull(),
  divergences: text("divergences").notNull(),
  supervisorQuestions: text("supervisorQuestions").notNull(),
  recommendation: text("recommendation").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("owner_ai_synthesis_comparisons_owner_case_idx").on(table.ownerId, table.caseId, table.createdAt),
]);

/** Estado privado dos provedores do Comitê. Chaves substituídas pelo titular são cifradas; chaves de ambiente nunca são copiadas para o banco. */
export const ownerAiProviderSettings = mysqlTable("concilium_owner_ai_provider_settings", {
  id: varchar("id", { length: 64 }).primaryKey(),
  ownerId: varchar("ownerId", { length: 64 }).notNull(),
  provider: mysqlEnum("provider", ["deepseek", "groq", "mistral", "openrouter", "cohere", "huggingface", "xai", "together", "qwen"]).notNull(),
  displayName: varchar("displayName", { length: 80 }).notNull(),
  state: mysqlEnum("state", ["active", "inactive", "unconfigured"]).default("unconfigured").notNull(),
  credentialSource: mysqlEnum("credentialSource", ["integrated", "environment", "owner_vault"]).notNull(),
  encryptedCredential: text("encryptedCredential"),
  lastValidatedAt: timestamp("lastValidatedAt"),
  lastValidationStatus: mysqlEnum("lastValidationStatus", ["valid", "rejected", "not_checked"]).default("not_checked").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  uniqueIndex("owner_ai_provider_owner_provider_unique").on(table.ownerId, table.provider),
  index("owner_ai_provider_owner_state_idx").on(table.ownerId, table.state),
]);

/**
 * Modelo operacional preservado da V1. Durante a consolidação ele é a fonte
 * dos fluxos de negociação; o vínculo com ownerAccounts é feito por
 * ownerOperationalLinks e não por privilégios administrativos.
 */
export const negotiationCases = mysqlTable("negotiationCases", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["preparacao", "negociacao", "acordo", "encerrado"])
    .default("preparacao")
    .notNull(),
  consensuality: int("consensuality").default(100).notNull(),
  createdBy: int("createdBy")
    .notNull()
    .references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const caseMembers = mysqlTable(
  "caseMembers",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    userId: int("userId").references(() => users.id),
    displayName: varchar("displayName", { length: 180 }),
    email: varchar("email", { length: 320 }),
    role: mysqlEnum("role", ["parte_principal", "assessor_juridico", "convidado"])
      .notNull(),
    inviteStatus: mysqlEnum("inviteStatus", ["ativo", "aceito", "revogado"])
      .default("ativo")
      .notNull(),
    inviteTokenHash: varchar("inviteTokenHash", { length: 128 }).unique(),
    invitedBy: int("invitedBy")
      .notNull()
      .references(() => users.id),
    claimedAt: timestamp("claimedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("case_members_case_idx").on(table.caseId),
    uniqueIndex("case_members_case_user_unique").on(table.caseId, table.userId),
  ],
);

/** Histórico imutável das mudanças de acesso, separado da auditoria documental. */
export const caseMemberEvents = mysqlTable(
  "caseMemberEvents",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    memberId: varchar("memberId", { length: 36 })
      .notNull()
      .references(() => caseMembers.id),
    actorId: int("actorId")
      .notNull()
      .references(() => users.id),
    eventType: mysqlEnum("eventType", ["convidado", "papel_alterado", "acesso_revogado"])
      .notNull(),
    previousRole: mysqlEnum("previousRole", ["parte_principal", "assessor_juridico", "convidado"]),
    nextRole: mysqlEnum("nextRole", ["parte_principal", "assessor_juridico", "convidado"]),
    details: text("details"),
    occurredAt: timestamp("occurredAt").defaultNow().notNull(),
    occurredAtUtcMs: bigint("occurredAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [
    index("case_member_events_case_idx").on(table.caseId),
    index("case_member_events_member_idx").on(table.memberId),
  ],
);

export const strategies = mysqlTable(
  "strategies",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    code: varchar("code", { length: 32 }).notNull(),
    name: varchar("name", { length: 64 }).notNull(),
    description: text("description").notNull(),
    primaryBenefit: text("primaryBenefit").notNull(),
    counterpartyBenefit: text("counterpartyBenefit").notNull(),
    // [NOVO v2 / Fase 4] "agreementChance" soava perto demais de "chance de vitória", que o
    // Manual funcional (seção 12) proíbe explicitamente. Renomeado para deixar claro que é
    // uma nota de postura estratégica interna, não uma previsão de resultado ou aceitação.
    // O índice comparativo de verdade (multi-dimensão, com pesos) está em
    // shared/interestAlignmentIndex.ts — este campo aqui é só o placar dos 6 cartões de
    // estratégia padrão (Aurora, Horizonte...), não o índice do Manual seção 12.
    strategicPostureScore: int("strategicPostureScore").notNull(),
    cooperationTradeoff: int("cooperationTradeoff").default(0).notNull(),
    position: int("position").notNull(),
    releaseState: mysqlEnum("releaseState", ["reservada", "liberada"]).default("reservada").notNull(),
    releasedAt: timestamp("releasedAt"),
    releasedAtUtcMs: bigint("releasedAtUtcMs", { mode: "number" }),
    releasedBy: int("releasedBy").references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("strategies_case_idx").on(table.caseId),
    uniqueIndex("strategies_case_code_unique").on(table.caseId, table.code),
  ],
);

export const negotiationDocuments = mysqlTable(
  "negotiationDocuments",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    parentDocumentId: varchar("parentDocumentId", { length: 36 }),
    strategyId: varchar("strategyId", { length: 36 }).references(() => strategies.id),
    documentType: mysqlEnum("documentType", ["proposta", "contraproposta"])
      .notNull(),
    // [NOVO v2 / Fase 0] migrado de 5 para os 9 estados de shared/hearingChecklist.ts
    // (NegotiationProposalStatus), para permitir "aceita parcialmente", "contraproposta
    // recebida" e "substituída" — hoje impossíveis de registrar. Migração de dados:
    // "rascunho" -> "rascunho_interno", "enviada" -> "apresentada"; os demais mantêm o nome.
    currentStatus: mysqlEnum("currentStatus", [
      "rascunho_interno",
      "apresentada",
      "recebida",
      "aceita",
      "recusada",
      "aceita_parcialmente",
      "contraproposta_recebida",
      "substituida",
      "encerrada",
    ])
      .default("rascunho_interno")
      .notNull(),
    title: varchar("title", { length: 220 }).notNull(),
    body: text("body").notNull(),
    contentHash: varchar("contentHash", { length: 128 }).notNull(),
    visibility: mysqlEnum("visibility", ["privado_titular", "partes", "contexto_protegido", "homologado"])
      .default("privado_titular")
      .notNull(),
    authoredBy: int("authoredBy")
      .notNull()
      .references(() => users.id),
    submittedAt: timestamp("submittedAt"),
    submittedAtUtcMs: bigint("submittedAtUtcMs", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    createdAtUtcMs: bigint("createdAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [
    index("documents_case_idx").on(table.caseId),
    index("documents_parent_idx").on(table.parentDocumentId),
  ],
);

/** Compartilhamento de uma peça isolada, sem expor o restante do caso. */
export const documentShares = mysqlTable(
  "documentShares",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    documentId: varchar("documentId", { length: 36 })
      .notNull()
      .references(() => negotiationDocuments.id),
    memberId: varchar("memberId", { length: 36 })
      .notNull()
      .references(() => caseMembers.id),
    grantedBy: int("grantedBy")
      .notNull()
      .references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    createdAtUtcMs: bigint("createdAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [
    index("document_shares_document_idx").on(table.documentId),
    index("document_shares_member_idx").on(table.memberId),
    uniqueIndex("document_shares_unique").on(table.documentId, table.memberId),
  ],
);

/** Metadados de anexos: o arquivo fica no armazenamento, não no banco. */
export const caseAttachments = mysqlTable(
  "caseAttachments",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    title: varchar("title", { length: 220 }).notNull(),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    storageUrl: varchar("storageUrl", { length: 1024 }).notNull(),
    mimeType: varchar("mimeType", { length: 160 }).notNull(),
    byteSize: int("byteSize").notNull().default(0),
    contentHash: varchar("contentHash", { length: 128 }).notNull(),
    visibility: mysqlEnum("visibility", ["privado_titular", "partes", "contexto_protegido", "homologado"])
      .default("privado_titular")
      .notNull(),
    createdBy: int("createdBy")
      .notNull()
      .references(() => users.id),
    releasedAt: timestamp("releasedAt"),
    releasedAtUtcMs: bigint("releasedAtUtcMs", { mode: "number" }),
    releasedBy: int("releasedBy").references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    createdAtUtcMs: bigint("createdAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [index("case_attachments_case_idx").on(table.caseId)],
);

/** Compartilhamento individual de anexo, separado da visibilidade de documentos. */
export const attachmentShares = mysqlTable(
  "attachmentShares",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    attachmentId: varchar("attachmentId", { length: 36 })
      .notNull()
      .references(() => caseAttachments.id),
    memberId: varchar("memberId", { length: 36 })
      .notNull()
      .references(() => caseMembers.id),
    grantedBy: int("grantedBy")
      .notNull()
      .references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    createdAtUtcMs: bigint("createdAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [
    index("attachment_shares_attachment_idx").on(table.attachmentId),
    index("attachment_shares_member_idx").on(table.memberId),
    uniqueIndex("attachment_shares_unique").on(table.attachmentId, table.memberId),
  ],
);

export const documentEvents = mysqlTable(
  "documentEvents",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    documentId: varchar("documentId", { length: 36 })
      .notNull()
      .references(() => negotiationDocuments.id),
    actorId: int("actorId")
      .notNull()
      .references(() => users.id),
    // [NOVO v2 / Fase 0] acompanha o enum de 9 estados de NegotiationProposalStatus, mais "criada"
    eventType: mysqlEnum("eventType", [
      "criada",
      "rascunho_interno",
      "apresentada",
      "recebida",
      "aceita",
      "recusada",
      "aceita_parcialmente",
      "contraproposta_recebida",
      "substituida",
      "encerrada",
    ])
      .notNull(),
    details: text("details"),
    occurredAt: timestamp("occurredAt").defaultNow().notNull(),
    occurredAtUtcMs: bigint("occurredAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [
    index("document_events_case_idx").on(table.caseId),
    index("document_events_document_idx").on(table.documentId),
  ],
);

/** Rodada privada iniciada exclusivamente pelo titular para análise externa ou integrada de uma peça. */
export const aiAnalysisRuns = mysqlTable(
  "aiAnalysisRuns",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    caseId: varchar("caseId", { length: 36 })
      .notNull()
      .references(() => negotiationCases.id),
    documentId: varchar("documentId", { length: 36 }).references(() => negotiationDocuments.id),
    requestedBy: int("requestedBy")
      .notNull()
      .references(() => users.id),
    sourceKind: mysqlEnum("sourceKind", ["documento", "clausula"]).notNull(),
    title: varchar("title", { length: 220 }).notNull(),
    originalContentHash: varchar("originalContentHash", { length: 128 }).notNull(),
    visibilityLevel: mysqlEnum("visibilityLevel", ["integral_autorizado", "contexto_protegido", "redigido"])
      .notNull(),
    consentConfirmedAt: timestamp("consentConfirmedAt").notNull(),
    consentLabel: varchar("consentLabel", { length: 280 }).notNull(),
    objective: text("objective").notNull(),
    humanDecision: mysqlEnum("humanDecision", ["pendente", "aproveitar", "revisar", "descartar"])
      .default("pendente")
      .notNull(),
    decisionNotes: text("decisionNotes"),
    decidedAt: timestamp("decidedAt"),
    decidedAtUtcMs: bigint("decidedAtUtcMs", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    createdAtUtcMs: bigint("createdAtUtcMs", { mode: "number" }).notNull(),
  },
  table => [
    index("ai_analysis_runs_case_idx").on(table.caseId),
    index("ai_analysis_runs_document_idx").on(table.documentId),
    index("ai_analysis_runs_requester_idx").on(table.requestedBy),
  ],
);

/** Uma execução por modelo/provedor; armazena apenas o conteúdo efetivamente encaminhado e sua resposta. */
export const aiAnalysisExecutions = mysqlTable(
  "aiAnalysisExecutions",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    runId: varchar("runId", { length: 36 })
      .notNull()
      .references(() => aiAnalysisRuns.id),
    provider: mysqlEnum("provider", ["openrouter", "atalho_externo"])
      .default("openrouter")
      .notNull(),
    modelId: varchar("modelId", { length: 160 }).notNull(),
    modelLabel: varchar("modelLabel", { length: 180 }).notNull(),
    role: mysqlEnum("role", ["auditor_critico", "defensor_da_minuta", "mediador"]).notNull(),
    visibilityLevel: mysqlEnum("visibilityLevel", ["integral_autorizado", "contexto_protegido", "redigido"])
      .notNull(),
    promptHash: varchar("promptHash", { length: 128 }).notNull(),
    transmittedContentHash: varchar("transmittedContentHash", { length: 128 }).notNull(),
    responseBody: text("responseBody"),
    status: mysqlEnum("status", ["pendente", "concluida", "falhou"])
      .default("pendente")
      .notNull(),
    errorSummary: varchar("errorSummary", { length: 800 }),
    executedAt: timestamp("executedAt").defaultNow().notNull(),
    executedAtUtcMs: bigint("executedAtUtcMs", { mode: "number" }).notNull(),
    completedAt: timestamp("completedAt"),
    completedAtUtcMs: bigint("completedAtUtcMs", { mode: "number" }),
  },
  table => [
    index("ai_analysis_executions_run_idx").on(table.runId),
    index("ai_analysis_executions_status_idx").on(table.status),
  ],
);



export type OwnerAccount = typeof ownerAccounts.$inferSelect;
export type OwnerPasskey = typeof ownerPasskeys.$inferSelect;
export type OwnerEmailVerification = typeof ownerEmailVerifications.$inferSelect;
export type OwnerCase = typeof ownerCases.$inferSelect;
export type NegotiationCase = typeof negotiationCases.$inferSelect;
export type CaseMember = typeof caseMembers.$inferSelect;
export type CaseMemberEvent = typeof caseMemberEvents.$inferSelect;
export type Strategy = typeof strategies.$inferSelect;
export type NegotiationDocument = typeof negotiationDocuments.$inferSelect;
export type DocumentEvent = typeof documentEvents.$inferSelect;
export type DocumentShare = typeof documentShares.$inferSelect;
export type CaseAttachment = typeof caseAttachments.$inferSelect;
export type AiAnalysisRun = typeof aiAnalysisRuns.$inferSelect;
export type AiAnalysisExecution = typeof aiAnalysisExecutions.$inferSelect;
