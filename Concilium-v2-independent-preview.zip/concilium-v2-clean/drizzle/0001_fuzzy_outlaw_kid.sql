CREATE TABLE `concilium_owner_auth_throttles` (
	`scopeKey` varchar(128) NOT NULL,
	`ownerId` varchar(64),
	`failureCount` int NOT NULL DEFAULT 0,
	`lockedUntil` timestamp,
	`lastFailureAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_auth_throttles_scopeKey` PRIMARY KEY(`scopeKey`)
);
--> statement-breakpoint
ALTER TABLE `concilium_owner_accounts` ADD `bootstrapCodeRetiredAt` timestamp;--> statement-breakpoint
CREATE INDEX `owner_auth_throttles_owner_idx` ON `concilium_owner_auth_throttles` (`ownerId`);--> statement-breakpoint
CREATE INDEX `owner_auth_throttles_locked_idx` ON `concilium_owner_auth_throttles` (`lockedUntil`);