CREATE TABLE `concilium_owner_secret_vault` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `name` varchar(160) NOT NULL,
  `consumer` varchar(64) NOT NULL,
  `encryptedValue` text NOT NULL,
  `algorithm` varchar(64) NOT NULL,
  `version` varchar(16) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `revokedAt` timestamp NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `owner_secret_vault_name_uq` (`ownerId`, `name`),
  KEY `owner_secret_vault_owner_idx` (`ownerId`)
);
