CREATE TABLE `concilium_owner_case_argument_comparisons` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `leftAssessmentId` varchar(64) NOT NULL,
  `rightAssessmentId` varchar(64) NOT NULL,
  `modelId` varchar(160) NOT NULL,
  `promptHash` varchar(128) NOT NULL,
  `comparisonBody` text NOT NULL,
  `commonPoints` text NOT NULL,
  `differences` text NOT NULL,
  `newEvidence` text NOT NULL,
  `risks` text NOT NULL,
  `questions` text NOT NULL,
  `humanDecision` enum('pending','retain_left','retain_right','merge','review','discard') NOT NULL DEFAULT 'pending',
  `decisionNotes` text,
  `decidedAt` timestamp NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `concilium_owner_case_argument_comparisons_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_comparisons_owner_case_idx` ON `concilium_owner_case_argument_comparisons` (`ownerId`,`caseId`,`createdAt`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_comparisons_left_idx` ON `concilium_owner_case_argument_comparisons` (`leftAssessmentId`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_comparisons_right_idx` ON `concilium_owner_case_argument_comparisons` (`rightAssessmentId`);
