CREATE TABLE `concilium_owner_email_verifications` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`tokenHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`consumedAt` timestamp,
	`revokedAt` timestamp,
	`sentAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `concilium_owner_email_verifications_id` PRIMARY KEY(`id`),
	CONSTRAINT `concilium_owner_email_verifications_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE INDEX `owner_email_verifications_owner_idx` ON `concilium_owner_email_verifications` (`ownerId`);--> statement-breakpoint
CREATE INDEX `owner_email_verifications_expiry_idx` ON `concilium_owner_email_verifications` (`expiresAt`);