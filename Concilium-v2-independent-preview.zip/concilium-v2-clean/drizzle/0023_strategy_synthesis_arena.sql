ALTER TABLE `concilium_owner_case_argument_assessments`
  ADD COLUMN `sourceSynthesisId` varchar(64) NULL AFTER `strategyId`;
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_synthesis_idx` ON `concilium_owner_case_argument_assessments` (`sourceSynthesisId`);
