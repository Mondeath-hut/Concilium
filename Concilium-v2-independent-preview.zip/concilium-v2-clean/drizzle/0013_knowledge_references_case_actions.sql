CREATE TABLE `concilium_owner_case_knowledge_references` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `externalEntryId` varchar(180) NOT NULL,
  `title` varchar(240) NOT NULL,
  `summary` text NOT NULL,
  `sourceTitle` varchar(320) NOT NULL,
  `sourceUrl` varchar(1024),
  `sourceVersion` varchar(120) NOT NULL,
  `country` varchar(80) NOT NULL,
  `jurisdiction` varchar(160) NOT NULL,
  `authorityLevel` varchar(48) NOT NULL,
  `validityState` varchar(48) NOT NULL,
  `validityCheckedAt` timestamp NULL,
  `supersededBy` varchar(180),
  `citationsJson` text NOT NULL,
  `actionType` enum('reference','clause_compendium') NOT NULL DEFAULT 'reference',
  `clauseDraft` text,
  `refinementStatus` enum('saved','in_arena','approved','discarded') NOT NULL DEFAULT 'saved',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_case_knowledge_references_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_case_knowledge_refs_owner_case_idx` ON `concilium_owner_case_knowledge_references` (`ownerId`,`caseId`);
--> statement-breakpoint
CREATE INDEX `owner_case_knowledge_refs_external_idx` ON `concilium_owner_case_knowledge_references` (`externalEntryId`);
