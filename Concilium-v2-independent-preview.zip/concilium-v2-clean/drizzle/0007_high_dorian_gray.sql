CREATE TABLE `concilium_owner_ai_provider_settings` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`provider` enum('integrated_manus','deepseek','groq','mistral','openrouter','cohere','huggingface','xai','together','qwen') NOT NULL,
	`displayName` varchar(80) NOT NULL,
	`state` enum('active','inactive','unconfigured') NOT NULL DEFAULT 'unconfigured',
	`credentialSource` enum('integrated','environment','owner_vault') NOT NULL,
	`encryptedCredential` text,
	`lastValidatedAt` timestamp,
	`lastValidationStatus` enum('valid','rejected','not_checked') NOT NULL DEFAULT 'not_checked',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_ai_provider_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `owner_ai_provider_owner_provider_unique` UNIQUE(`ownerId`,`provider`)
);
--> statement-breakpoint
CREATE INDEX `owner_ai_provider_owner_state_idx` ON `concilium_owner_ai_provider_settings` (`ownerId`,`state`);