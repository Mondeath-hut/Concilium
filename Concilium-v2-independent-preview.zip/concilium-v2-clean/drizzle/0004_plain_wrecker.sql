CREATE TABLE `concilium_owner_case_assets` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`caseId` varchar(64) NOT NULL,
	`assetType` varchar(48) NOT NULL,
	`title` varchar(240) NOT NULL,
	`details` text NOT NULL,
	`sourceReference` varchar(500) NOT NULL,
	`reviewStatus` enum('pending_review','verified','draft') NOT NULL DEFAULT 'pending_review',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_case_assets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_case_documents` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`caseId` varchar(64) NOT NULL,
	`title` varchar(240) NOT NULL,
	`documentType` varchar(64) NOT NULL,
	`sourceReference` varchar(500) NOT NULL,
	`storageKey` varchar(512),
	`contentHash` varchar(128),
	`reviewStatus` enum('pending_review','verified','draft') NOT NULL DEFAULT 'pending_review',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_case_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_case_memorial_entries` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`caseId` varchar(64) NOT NULL,
	`entryType` varchar(48) NOT NULL,
	`title` varchar(240) NOT NULL,
	`narrative` text NOT NULL,
	`referenceDate` varchar(32),
	`sourceReference` varchar(500) NOT NULL,
	`reviewStatus` enum('pending_review','verified','draft') NOT NULL DEFAULT 'pending_review',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_case_memorial_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_case_negotiation_scenarios` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`caseId` varchar(64) NOT NULL,
	`title` varchar(240) NOT NULL,
	`narrative` text NOT NULL,
	`sourceReference` varchar(500) NOT NULL,
	`reviewStatus` enum('pending_review','verified','draft') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_case_negotiation_scenarios_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_case_assets_owner_case_idx` ON `concilium_owner_case_assets` (`ownerId`,`caseId`);--> statement-breakpoint
CREATE INDEX `owner_case_documents_owner_case_idx` ON `concilium_owner_case_documents` (`ownerId`,`caseId`);--> statement-breakpoint
CREATE INDEX `owner_case_memorial_owner_case_idx` ON `concilium_owner_case_memorial_entries` (`ownerId`,`caseId`);--> statement-breakpoint
CREATE INDEX `owner_case_memorial_case_date_idx` ON `concilium_owner_case_memorial_entries` (`caseId`,`referenceDate`);--> statement-breakpoint
CREATE INDEX `owner_case_scenarios_owner_case_idx` ON `concilium_owner_case_negotiation_scenarios` (`ownerId`,`caseId`);