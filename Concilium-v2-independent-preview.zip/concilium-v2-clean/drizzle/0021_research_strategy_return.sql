ALTER TABLE `concilium_owner_case_research_requests`
  ADD COLUMN `sourceAssessmentId` varchar(64) NULL AFTER `sourceRunId`,
  ADD COLUMN `strategyId` varchar(64) NULL AFTER `sourceAssessmentId`,
  ADD COLUMN `resultSnapshotJson` text NOT NULL DEFAULT '[]' AFTER `query`,
  ADD COLUMN `answeredAt` timestamp NULL AFTER `status`;
--> statement-breakpoint
CREATE INDEX `owner_case_research_requests_assessment_idx` ON `concilium_owner_case_research_requests` (`sourceAssessmentId`);
--> statement-breakpoint
CREATE INDEX `owner_case_research_requests_strategy_idx` ON `concilium_owner_case_research_requests` (`strategyId`);
