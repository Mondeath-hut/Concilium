ALTER TABLE `concilium_owner_case_documents`
  ADD COLUMN `catalogStatus` enum('unclassified','suggested','needs_owner_review','confirmed','quarantined','archived') NOT NULL DEFAULT 'quarantined' AFTER `contentHash`,
  ADD COLUMN `suggestedVault` varchar(64) NULL AFTER `catalogStatus`,
  ADD COLUMN `confirmedVault` varchar(64) NULL AFTER `suggestedVault`,
  ADD COLUMN `catalogSensitivity` enum('ordinary','personal','sensitive','highly_sensitive') NOT NULL DEFAULT 'personal' AFTER `confirmedVault`,
  ADD COLUMN `catalogConfidence` enum('high','medium','low','unknown') NOT NULL DEFAULT 'unknown' AFTER `catalogSensitivity`,
  ADD COLUMN `catalogNotes` text NULL AFTER `catalogConfidence`,
  ADD COLUMN `catalogedAt` timestamp NULL AFTER `catalogNotes`;
