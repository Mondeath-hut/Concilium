CREATE TABLE `concilium_owner_case_document_versions` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `documentId` varchar(64) NOT NULL,
  `versionLabel` varchar(80) NOT NULL,
  `contentHash` varchar(128) NOT NULL,
  `sourceReference` varchar(500) NOT NULL,
  `storageKey` varchar(512),
  `changeNote` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `owner_case_document_versions_document_idx` (`documentId`,`createdAt`),
  KEY `owner_case_document_versions_owner_case_idx` (`ownerId`,`caseId`)
);
