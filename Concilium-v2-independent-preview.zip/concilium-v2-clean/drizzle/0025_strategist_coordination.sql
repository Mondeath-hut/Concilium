ALTER TABLE `concilium_owner_strategy_exploration_runs`
  ADD COLUMN `strategistBrief` text NULL AFTER `evidenceSnapshotJson`,
  ADD COLUMN `strategistModelId` varchar(160) NULL AFTER `strategistBrief`;
