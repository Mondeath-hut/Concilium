CREATE TABLE IF NOT EXISTS `negotiationCases` (
  `id` varchar(36) NOT NULL,
  `title` varchar(180) NOT NULL,
  `description` text,
  `status` enum('preparacao','negociacao','acordo','encerrado') NOT NULL DEFAULT 'preparacao',
  `consensuality` int NOT NULL DEFAULT 100,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `negotiationCases_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `strategies` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `primaryBenefit` text NOT NULL,
  `counterpartyBenefit` text NOT NULL,
  `agreementChance` int NOT NULL,
  `consensualityImpact` int NOT NULL DEFAULT 0,
  `position` int NOT NULL,
  `releaseState` enum('reservada','liberada') NOT NULL DEFAULT 'reservada',
  `releasedAt` timestamp,
  `releasedAtUtcMs` bigint,
  `releasedBy` int,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `strategies_id` PRIMARY KEY (`id`),
  CONSTRAINT `strategies_case_code_unique` UNIQUE (`caseId`,`code`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `caseMembers` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `userId` int,
  `displayName` varchar(180),
  `email` varchar(320),
  `role` enum('parte_principal','assessor_juridico','convidado') NOT NULL,
  `inviteStatus` enum('ativo','aceito','revogado') NOT NULL DEFAULT 'ativo',
  `inviteTokenHash` varchar(128),
  `invitedBy` int NOT NULL,
  `claimedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `caseMembers_id` PRIMARY KEY (`id`),
  CONSTRAINT `caseMembers_inviteTokenHash_unique` UNIQUE (`inviteTokenHash`),
  CONSTRAINT `case_members_case_user_unique` UNIQUE (`caseId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `negotiationDocuments` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `parentDocumentId` varchar(36),
  `strategyId` varchar(36),
  `documentType` enum('proposta','contraproposta') NOT NULL,
  `currentStatus` enum('rascunho','enviada','recebida','aceita','recusada') NOT NULL DEFAULT 'rascunho',
  `title` varchar(220) NOT NULL,
  `body` text NOT NULL,
  `contentHash` varchar(128) NOT NULL,
  `visibility` enum('privado_titular','partes','contexto_protegido','homologado') NOT NULL DEFAULT 'privado_titular',
  `authoredBy` int NOT NULL,
  `submittedAt` timestamp,
  `submittedAtUtcMs` bigint,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `createdAtUtcMs` bigint NOT NULL,
  CONSTRAINT `negotiationDocuments_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
ALTER TABLE `negotiationCases` ADD CONSTRAINT `negotiationCases_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `strategies` ADD CONSTRAINT `strategies_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `strategies` ADD CONSTRAINT `strategies_releasedBy_users_id_fk` FOREIGN KEY (`releasedBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `caseMembers` ADD CONSTRAINT `caseMembers_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `caseMembers` ADD CONSTRAINT `caseMembers_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `caseMembers` ADD CONSTRAINT `caseMembers_invitedBy_users_id_fk` FOREIGN KEY (`invitedBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `negotiationDocuments` ADD CONSTRAINT `negotiationDocuments_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `negotiationDocuments` ADD CONSTRAINT `negotiationDocuments_strategyId_strategies_id_fk` FOREIGN KEY (`strategyId`) REFERENCES `strategies`(`id`);
--> statement-breakpoint
ALTER TABLE `negotiationDocuments` ADD CONSTRAINT `negotiationDocuments_authoredBy_users_id_fk` FOREIGN KEY (`authoredBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
CREATE INDEX `case_members_case_idx` ON `caseMembers` (`caseId`);
--> statement-breakpoint
CREATE INDEX `strategies_case_idx` ON `strategies` (`caseId`);
--> statement-breakpoint
CREATE INDEX `documents_case_idx` ON `negotiationDocuments` (`caseId`);
--> statement-breakpoint
CREATE INDEX `documents_parent_idx` ON `negotiationDocuments` (`parentDocumentId`);
