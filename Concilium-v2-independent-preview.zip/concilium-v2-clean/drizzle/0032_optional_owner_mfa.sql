ALTER TABLE `concilium_owner_mfa` MODIFY COLUMN `totpSecretEncrypted` text NULL;
ALTER TABLE `concilium_owner_mfa` MODIFY COLUMN `totpConfiguredAt` timestamp NULL DEFAULT (now());
