-- Portability migration: remove the former integrated provider labels from active schema.
UPDATE `concilium_owner_ai_provider_settings` SET `provider` = 'openrouter' WHERE `provider` = 'integrated_manus';
UPDATE `concilium_owner_ai_analysis_executions` SET `provider` = 'openrouter' WHERE `provider` = 'integrated_manus';
UPDATE `aiAnalysisExecutions` SET `provider` = 'openrouter' WHERE `provider` = 'integrado_manus';

ALTER TABLE `concilium_owner_ai_provider_settings` MODIFY COLUMN `provider` enum('deepseek','groq','mistral','openrouter','cohere','huggingface','xai','together','qwen') NOT NULL;
ALTER TABLE `concilium_owner_ai_analysis_executions` MODIFY COLUMN `provider` enum('deepseek','groq','mistral','openrouter','cohere','huggingface','xai','together','qwen') NOT NULL DEFAULT 'openrouter';
ALTER TABLE `aiAnalysisExecutions` MODIFY COLUMN `provider` enum('openrouter','atalho_externo') NOT NULL DEFAULT 'openrouter';
