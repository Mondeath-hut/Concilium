CREATE TABLE `concilium_owner_accounts` (
	`id` varchar(64) NOT NULL,
	`email` varchar(320) NOT NULL,
	`displayName` varchar(160) NOT NULL,
	`state` enum('setup_pending','active','recovery_hold','suspended') NOT NULL DEFAULT 'setup_pending',
	`emailVerifiedAt` timestamp,
	`activatedAt` timestamp,
	`failedActivationAttempts` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `concilium_owner_accounts_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_audit_events` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64),
	`eventType` varchar(96) NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `concilium_owner_audit_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_mfa` (
	`ownerId` varchar(64) NOT NULL,
	`totpSecretEncrypted` text NOT NULL,
	`recoveryCodesHash` text NOT NULL,
	`totpConfiguredAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_mfa_ownerId` PRIMARY KEY(`ownerId`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_passkeys` (
	`credentialId` varchar(1024) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`publicKey` text NOT NULL,
	`counter` int NOT NULL DEFAULT 0,
	`transports` varchar(320),
	`deviceType` varchar(64) NOT NULL,
	`backedUp` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`lastUsedAt` timestamp,
	CONSTRAINT `concilium_owner_passkeys_credentialId` PRIMARY KEY(`credentialId`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_sessions` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`tokenHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`revokedAt` timestamp,
	`lastSeenAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `concilium_owner_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `concilium_owner_sessions_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `owner_audit_owner_idx` ON `concilium_owner_audit_events` (`ownerId`);--> statement-breakpoint
CREATE INDEX `owner_audit_event_idx` ON `concilium_owner_audit_events` (`eventType`);--> statement-breakpoint
CREATE INDEX `owner_passkeys_owner_idx` ON `concilium_owner_passkeys` (`ownerId`);--> statement-breakpoint
CREATE INDEX `owner_sessions_owner_idx` ON `concilium_owner_sessions` (`ownerId`);