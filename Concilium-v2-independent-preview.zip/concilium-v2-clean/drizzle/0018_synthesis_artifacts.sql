CREATE TABLE `concilium_owner_case_compendium_entries` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `sourceRunId` varchar(64) NOT NULL,
  `title` varchar(240) NOT NULL,
  `body` text NOT NULL,
  `status` enum('draft','approved','archived') NOT NULL DEFAULT 'draft',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_case_compendium_entries_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_case_research_requests` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `sourceRunId` varchar(64) NOT NULL,
  `query` text NOT NULL,
  `status` enum('pending','answered','archived') NOT NULL DEFAULT 'pending',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_case_research_requests_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_case_compendium_owner_case_idx` ON `concilium_owner_case_compendium_entries` (`ownerId`,`caseId`);
--> statement-breakpoint
CREATE INDEX `owner_case_compendium_source_idx` ON `concilium_owner_case_compendium_entries` (`sourceRunId`);
--> statement-breakpoint
CREATE INDEX `owner_case_research_requests_owner_case_idx` ON `concilium_owner_case_research_requests` (`ownerId`,`caseId`,`createdAt`);
