CREATE TABLE `concilium_owner_strategy_exploration_runs` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `title` varchar(220) NOT NULL,
  `objective` text NOT NULL,
  `inputContentHash` varchar(128) NOT NULL,
  `consentLabel` varchar(280) NOT NULL,
  `status` enum('active','archived') NOT NULL DEFAULT 'active',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_runs_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_strategy_exploration_ideas` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `modelId` varchar(160) NOT NULL,
  `perspective` varchar(120) NOT NULL,
  `ideaBody` text NOT NULL,
  `assumptions` text,
  `risks` text,
  `sourceNeeds` text,
  `status` enum('generated','selected_for_arena','discarded') NOT NULL DEFAULT 'generated',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_ideas_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_owner_case_idx` ON `concilium_owner_strategy_exploration_runs` (`ownerId`,`caseId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_ideas_run_idx` ON `concilium_owner_strategy_exploration_ideas` (`runId`);
