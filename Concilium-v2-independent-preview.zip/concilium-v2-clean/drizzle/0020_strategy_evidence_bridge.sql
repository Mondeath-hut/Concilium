ALTER TABLE `concilium_owner_strategy_exploration_runs`
  ADD COLUMN `sourceAssessmentId` varchar(64) NULL AFTER `inputContentHash`,
  ADD COLUMN `evidenceSnapshotJson` text NOT NULL DEFAULT '[]' AFTER `sourceAssessmentId`;
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_source_assessment_idx` ON `concilium_owner_strategy_exploration_runs` (`sourceAssessmentId`);
