ALTER TABLE `concilium_owner_strategy_exploration_runs`
  ADD COLUMN `parentRunId` varchar(64) NULL AFTER `sourceAssessmentId`,
  ADD COLUMN `sourceBranchBundleId` varchar(64) NULL AFTER `parentRunId`,
  ADD COLUMN `derivationType` enum('initial','branch') NOT NULL DEFAULT 'initial' AFTER `sourceBranchBundleId`,
  ADD KEY `owner_strategy_exploration_parent_run_idx` (`parentRunId`),
  ADD KEY `owner_strategy_exploration_branch_bundle_idx` (`sourceBranchBundleId`);
