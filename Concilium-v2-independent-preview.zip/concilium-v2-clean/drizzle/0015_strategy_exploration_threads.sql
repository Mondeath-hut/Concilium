CREATE TABLE `concilium_owner_strategy_exploration_threads` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `ideaId` varchar(64) NOT NULL,
  `modelId` varchar(160) NOT NULL,
  `perspective` varchar(120) NOT NULL,
  `state` enum('active','awaiting_owner','ceased','selected_for_arena') NOT NULL DEFAULT 'awaiting_owner',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_threads_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_strategy_exploration_questions` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `threadId` varchar(64) NOT NULL,
  `questionBody` text NOT NULL,
  `semanticGroupId` varchar(64),
  `status` enum('pending','answered','closed') NOT NULL DEFAULT 'pending',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_questions_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_strategy_exploration_answers` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `semanticGroupId` varchar(64) NOT NULL,
  `body` text NOT NULL,
  `questionIdsJson` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_answers_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_strategy_exploration_syntheses` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `stage` enum('incremental','final') NOT NULL,
  `closedThreadId` varchar(64),
  `content` text NOT NULL,
  `sourceThreadIdsJson` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_syntheses_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_syntheses_run_idx` ON `concilium_owner_strategy_exploration_syntheses` (`runId`,`createdAt`);
--> statement-breakpoint
CREATE TABLE `concilium_owner_strategy_exploration_messages` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `threadId` varchar(64) NOT NULL,
  `authorType` enum('model','owner','system') NOT NULL,
  `body` text NOT NULL,
  `questionId` varchar(64),
  `answerId` varchar(64),
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_strategy_exploration_messages_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_threads_run_idx` ON `concilium_owner_strategy_exploration_threads` (`runId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_threads_idea_idx` ON `concilium_owner_strategy_exploration_threads` (`ideaId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_questions_run_idx` ON `concilium_owner_strategy_exploration_questions` (`runId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_questions_group_idx` ON `concilium_owner_strategy_exploration_questions` (`semanticGroupId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_answers_run_idx` ON `concilium_owner_strategy_exploration_answers` (`runId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_answers_group_idx` ON `concilium_owner_strategy_exploration_answers` (`semanticGroupId`);
--> statement-breakpoint
CREATE INDEX `owner_strategy_exploration_messages_thread_idx` ON `concilium_owner_strategy_exploration_messages` (`threadId`,`createdAt`);
