CREATE TABLE `concilium_owner_strategy_branch_proposals` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `parentThreadId` varchar(64) NOT NULL,
  `originQuestionId` varchar(64),
  `originMessageId` varchar(64),
  `question` text NOT NULL,
  `whyItMatters` text NOT NULL,
  `state` enum('parked','grouped','ready_for_strategist','submitted','resolved','dismissed') NOT NULL DEFAULT 'parked',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `owner_strategy_branch_proposals_run_idx` (`runId`,`createdAt`),
  KEY `owner_strategy_branch_proposals_thread_idx` (`parentThreadId`,`createdAt`)
);

CREATE TABLE `concilium_owner_strategy_branch_bundles` (
  `id` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `sourceProposalIdsJson` text NOT NULL,
  `sourceThreadIdsJson` text NOT NULL,
  `sourceQuestionIdsJson` text NOT NULL,
  `draftQuestion` text NOT NULL,
  `state` enum('ready_for_strategist','submitted','resolved','dismissed') NOT NULL DEFAULT 'ready_for_strategist',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `owner_strategy_branch_bundles_run_idx` (`runId`,`createdAt`)
);
