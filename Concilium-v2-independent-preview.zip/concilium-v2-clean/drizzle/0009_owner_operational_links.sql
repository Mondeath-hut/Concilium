CREATE TABLE IF NOT EXISTS `concilium_owner_operational_links` (
  `ownerId` varchar(64) NOT NULL,
  `operationalUserId` int NOT NULL,
  `openId` varchar(64) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `concilium_owner_operational_links_ownerId` PRIMARY KEY (`ownerId`),
  CONSTRAINT `concilium_owner_operational_links_user_unique` UNIQUE (`operationalUserId`),
  CONSTRAINT `concilium_owner_operational_links_openId_unique` UNIQUE (`openId`)
);
--> statement-breakpoint
CREATE INDEX `owner_operational_links_user_idx` ON `concilium_owner_operational_links` (`operationalUserId`);
