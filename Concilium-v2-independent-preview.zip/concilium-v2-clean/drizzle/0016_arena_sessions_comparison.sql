CREATE TABLE `concilium_owner_ai_arena_sessions` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `label` varchar(180) NOT NULL,
  `teamLabel` varchar(180) NOT NULL,
  `branchFromRunId` varchar(64),
  `status` enum('active','archived') NOT NULL DEFAULT 'active',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_ai_arena_sessions_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
ALTER TABLE `concilium_owner_ai_analysis_runs`
  ADD COLUMN `sessionId` varchar(64),
  ADD COLUMN `synthesisUseStatus` enum('pending','homologated','not_used','requires_review') NOT NULL DEFAULT 'pending',
  ADD COLUMN `synthesisUsedAt` timestamp NULL;
--> statement-breakpoint
CREATE TABLE `concilium_owner_ai_synthesis_comparisons` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `leftRunId` varchar(64) NOT NULL,
  `rightRunId` varchar(64) NOT NULL,
  `commonPoints` text NOT NULL,
  `divergences` text NOT NULL,
  `supervisorQuestions` text NOT NULL,
  `recommendation` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_ai_synthesis_comparisons_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_ai_arena_sessions_owner_case_idx` ON `concilium_owner_ai_arena_sessions` (`ownerId`,`caseId`);
--> statement-breakpoint
CREATE INDEX `owner_ai_synthesis_comparisons_owner_case_idx` ON `concilium_owner_ai_synthesis_comparisons` (`ownerId`,`caseId`,`createdAt`);
