CREATE TABLE `concilium_owner_case_strategies` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`caseId` varchar(64) NOT NULL,
	`title` varchar(200) NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_case_strategies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concilium_owner_cases` (
	`id` varchar(64) NOT NULL,
	`ownerId` varchar(64) NOT NULL,
	`title` varchar(200) NOT NULL,
	`summary` text,
	`status` enum('draft','negotiation','review','settled','archived') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concilium_owner_cases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_case_strategies_owner_case_idx` ON `concilium_owner_case_strategies` (`ownerId`,`caseId`);--> statement-breakpoint
CREATE INDEX `owner_cases_owner_idx` ON `concilium_owner_cases` (`ownerId`);--> statement-breakpoint
CREATE INDEX `owner_cases_owner_status_idx` ON `concilium_owner_cases` (`ownerId`,`status`);