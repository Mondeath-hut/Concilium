CREATE TABLE IF NOT EXISTS `documentShares` (
  `id` varchar(36) NOT NULL,
  `documentId` varchar(36) NOT NULL,
  `memberId` varchar(36) NOT NULL,
  `grantedBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `createdAtUtcMs` bigint NOT NULL,
  CONSTRAINT `documentShares_id` PRIMARY KEY (`id`),
  CONSTRAINT `document_shares_unique` UNIQUE (`documentId`,`memberId`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `caseAttachments` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `title` varchar(220) NOT NULL,
  `storageKey` varchar(512) NOT NULL,
  `storageUrl` varchar(1024) NOT NULL,
  `mimeType` varchar(160) NOT NULL,
  `byteSize` int NOT NULL DEFAULT 0,
  `contentHash` varchar(128) NOT NULL,
  `visibility` enum('privado_titular','partes','contexto_protegido','homologado') NOT NULL DEFAULT 'privado_titular',
  `createdBy` int NOT NULL,
  `releasedAt` timestamp,
  `releasedAtUtcMs` bigint,
  `releasedBy` int,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `createdAtUtcMs` bigint NOT NULL,
  CONSTRAINT `caseAttachments_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `attachmentShares` (
  `id` varchar(36) NOT NULL,
  `attachmentId` varchar(36) NOT NULL,
  `memberId` varchar(36) NOT NULL,
  `grantedBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `createdAtUtcMs` bigint NOT NULL,
  CONSTRAINT `attachmentShares_id` PRIMARY KEY (`id`),
  CONSTRAINT `attachment_shares_unique` UNIQUE (`attachmentId`,`memberId`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `documentEvents` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `documentId` varchar(36) NOT NULL,
  `actorId` int NOT NULL,
  `eventType` enum('criada','enviada','recebida','aceita','recusada') NOT NULL,
  `details` text,
  `occurredAt` timestamp NOT NULL DEFAULT (now()),
  `occurredAtUtcMs` bigint NOT NULL,
  CONSTRAINT `documentEvents_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `caseMemberEvents` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `memberId` varchar(36) NOT NULL,
  `actorId` int NOT NULL,
  `eventType` enum('convidado','papel_alterado','acesso_revogado') NOT NULL,
  `previousRole` enum('parte_principal','assessor_juridico','convidado'),
  `nextRole` enum('parte_principal','assessor_juridico','convidado'),
  `details` text,
  `occurredAt` timestamp NOT NULL DEFAULT (now()),
  `occurredAtUtcMs` bigint NOT NULL,
  CONSTRAINT `caseMemberEvents_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `aiAnalysisRuns` (
  `id` varchar(36) NOT NULL,
  `caseId` varchar(36) NOT NULL,
  `documentId` varchar(36),
  `requestedBy` int NOT NULL,
  `sourceKind` enum('documento','clausula') NOT NULL,
  `title` varchar(220) NOT NULL,
  `originalContentHash` varchar(128) NOT NULL,
  `visibilityLevel` enum('integral_autorizado','contexto_protegido','redigido') NOT NULL,
  `consentConfirmedAt` timestamp NOT NULL,
  `consentLabel` varchar(280) NOT NULL,
  `objective` text NOT NULL,
  `humanDecision` enum('pendente','aproveitar','revisar','descartar') NOT NULL DEFAULT 'pendente',
  `decisionNotes` text,
  `decidedAt` timestamp,
  `decidedAtUtcMs` bigint,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `createdAtUtcMs` bigint NOT NULL,
  CONSTRAINT `aiAnalysisRuns_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `aiAnalysisExecutions` (
  `id` varchar(36) NOT NULL,
  `runId` varchar(36) NOT NULL,
  `provider` enum('integrado_manus','atalho_externo') NOT NULL DEFAULT 'integrado_manus',
  `modelId` varchar(160) NOT NULL,
  `modelLabel` varchar(180) NOT NULL,
  `role` enum('auditor_critico','defensor_da_minuta','mediador') NOT NULL,
  `visibilityLevel` enum('integral_autorizado','contexto_protegido','redigido') NOT NULL,
  `promptHash` varchar(128) NOT NULL,
  `transmittedContentHash` varchar(128) NOT NULL,
  `responseBody` text,
  `status` enum('pendente','concluida','falhou') NOT NULL DEFAULT 'pendente',
  `errorSummary` varchar(800),
  `executedAt` timestamp NOT NULL DEFAULT (now()),
  `executedAtUtcMs` bigint NOT NULL,
  `completedAt` timestamp,
  `completedAtUtcMs` bigint,
  CONSTRAINT `aiAnalysisExecutions_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
ALTER TABLE `documentShares` ADD CONSTRAINT `documentShares_documentId_negotiationDocuments_id_fk` FOREIGN KEY (`documentId`) REFERENCES `negotiationDocuments`(`id`);
--> statement-breakpoint
ALTER TABLE `documentShares` ADD CONSTRAINT `documentShares_memberId_caseMembers_id_fk` FOREIGN KEY (`memberId`) REFERENCES `caseMembers`(`id`);
--> statement-breakpoint
ALTER TABLE `documentShares` ADD CONSTRAINT `documentShares_grantedBy_users_id_fk` FOREIGN KEY (`grantedBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `caseAttachments` ADD CONSTRAINT `caseAttachments_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `caseAttachments` ADD CONSTRAINT `caseAttachments_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `caseAttachments` ADD CONSTRAINT `caseAttachments_releasedBy_users_id_fk` FOREIGN KEY (`releasedBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `attachmentShares` ADD CONSTRAINT `attachmentShares_attachmentId_caseAttachments_id_fk` FOREIGN KEY (`attachmentId`) REFERENCES `caseAttachments`(`id`);
--> statement-breakpoint
ALTER TABLE `attachmentShares` ADD CONSTRAINT `attachmentShares_memberId_caseMembers_id_fk` FOREIGN KEY (`memberId`) REFERENCES `caseMembers`(`id`);
--> statement-breakpoint
ALTER TABLE `attachmentShares` ADD CONSTRAINT `attachmentShares_grantedBy_users_id_fk` FOREIGN KEY (`grantedBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `documentEvents` ADD CONSTRAINT `documentEvents_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `documentEvents` ADD CONSTRAINT `documentEvents_documentId_negotiationDocuments_id_fk` FOREIGN KEY (`documentId`) REFERENCES `negotiationDocuments`(`id`);
--> statement-breakpoint
ALTER TABLE `documentEvents` ADD CONSTRAINT `documentEvents_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `caseMemberEvents` ADD CONSTRAINT `caseMemberEvents_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `caseMemberEvents` ADD CONSTRAINT `caseMemberEvents_memberId_caseMembers_id_fk` FOREIGN KEY (`memberId`) REFERENCES `caseMembers`(`id`);
--> statement-breakpoint
ALTER TABLE `caseMemberEvents` ADD CONSTRAINT `caseMemberEvents_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `aiAnalysisRuns` ADD CONSTRAINT `aiAnalysisRuns_caseId_negotiationCases_id_fk` FOREIGN KEY (`caseId`) REFERENCES `negotiationCases`(`id`);
--> statement-breakpoint
ALTER TABLE `aiAnalysisRuns` ADD CONSTRAINT `aiAnalysisRuns_documentId_negotiationDocuments_id_fk` FOREIGN KEY (`documentId`) REFERENCES `negotiationDocuments`(`id`);
--> statement-breakpoint
ALTER TABLE `aiAnalysisRuns` ADD CONSTRAINT `aiAnalysisRuns_requestedBy_users_id_fk` FOREIGN KEY (`requestedBy`) REFERENCES `users`(`id`);
--> statement-breakpoint
ALTER TABLE `aiAnalysisExecutions` ADD CONSTRAINT `aiAnalysisExecutions_runId_aiAnalysisRuns_id_fk` FOREIGN KEY (`runId`) REFERENCES `aiAnalysisRuns`(`id`);
--> statement-breakpoint
CREATE INDEX `document_shares_document_idx` ON `documentShares` (`documentId`);
--> statement-breakpoint
CREATE INDEX `document_shares_member_idx` ON `documentShares` (`memberId`);
--> statement-breakpoint
CREATE INDEX `case_attachments_case_idx` ON `caseAttachments` (`caseId`);
--> statement-breakpoint
CREATE INDEX `attachment_shares_attachment_idx` ON `attachmentShares` (`attachmentId`);
--> statement-breakpoint
CREATE INDEX `attachment_shares_member_idx` ON `attachmentShares` (`memberId`);
--> statement-breakpoint
CREATE INDEX `document_events_case_idx` ON `documentEvents` (`caseId`);
--> statement-breakpoint
CREATE INDEX `document_events_document_idx` ON `documentEvents` (`documentId`);
--> statement-breakpoint
CREATE INDEX `case_member_events_case_idx` ON `caseMemberEvents` (`caseId`);
--> statement-breakpoint
CREATE INDEX `case_member_events_member_idx` ON `caseMemberEvents` (`memberId`);
--> statement-breakpoint
CREATE INDEX `ai_analysis_runs_case_idx` ON `aiAnalysisRuns` (`caseId`);
--> statement-breakpoint
CREATE INDEX `ai_analysis_runs_document_idx` ON `aiAnalysisRuns` (`documentId`);
--> statement-breakpoint
CREATE INDEX `ai_analysis_executions_run_idx` ON `aiAnalysisExecutions` (`runId`);
