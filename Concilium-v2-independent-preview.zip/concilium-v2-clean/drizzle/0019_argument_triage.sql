CREATE TABLE `concilium_owner_case_argument_assessments` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `strategyId` varchar(64),
  `explorationRunId` varchar(64),
  `explorationIdeaId` varchar(64),
  `explorationThreadId` varchar(64),
  `runId` varchar(64),
  `executionId` varchar(64),
  `parentAssessmentId` varchar(64),
  `formulation` text NOT NULL,
  `legalStatus` enum('apoiado_por_fonte_vigente','possivel_aplicacao','controvertido','nao_verificado','contradito_ou_rejeitado','fora_da_jurisdicao') NOT NULL,
  `confidence` enum('high','medium','low','unknown') NOT NULL DEFAULT 'unknown',
  `evidenceStrength` enum('primary','official_structured','licensed_secondary','secondary','none') NOT NULL DEFAULT 'none',
  `moralEthicalNotes` text,
  `factualDependenciesJson` text NOT NULL,
  `counterpointsJson` text NOT NULL,
  `limitationsJson` text NOT NULL,
  `operationalStatus` enum('licito_para_analise','requer_revisao_profissional','bloqueado_instrucao_ilicita') NOT NULL,
  `reviewStatus` enum('pending','triaged','needs_research','arena_ready','approved_for_use','archived') NOT NULL DEFAULT 'pending',
  `sourceSnapshotJson` text NOT NULL,
  `humanDecision` enum('pending','retain_initial','use_intermediate','use_refined','discard') NOT NULL DEFAULT 'pending',
  `decisionNotes` text,
  `decidedAt` timestamp NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `concilium_owner_case_argument_assessments_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_owner_case_idx` ON `concilium_owner_case_argument_assessments` (`ownerId`,`caseId`,`createdAt`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_strategy_idx` ON `concilium_owner_case_argument_assessments` (`strategyId`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_exploration_idea_idx` ON `concilium_owner_case_argument_assessments` (`explorationIdeaId`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_exploration_thread_idx` ON `concilium_owner_case_argument_assessments` (`explorationThreadId`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_run_idx` ON `concilium_owner_case_argument_assessments` (`runId`);
--> statement-breakpoint
CREATE INDEX `owner_case_argument_assessments_status_idx` ON `concilium_owner_case_argument_assessments` (`reviewStatus`);
