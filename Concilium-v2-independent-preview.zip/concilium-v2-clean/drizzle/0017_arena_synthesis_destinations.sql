CREATE TABLE `concilium_owner_ai_synthesis_destinations` (
  `id` varchar(64) NOT NULL,
  `ownerId` varchar(64) NOT NULL,
  `caseId` varchar(64) NOT NULL,
  `runId` varchar(64) NOT NULL,
  `destination` enum('bibliotecario','compendio','arena','arquivo') NOT NULL,
  `note` text,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `concilium_owner_ai_synthesis_destinations_id` PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE INDEX `owner_ai_synthesis_destinations_owner_case_idx` ON `concilium_owner_ai_synthesis_destinations` (`ownerId`,`caseId`,`createdAt`);
--> statement-breakpoint
CREATE INDEX `owner_ai_synthesis_destinations_run_idx` ON `concilium_owner_ai_synthesis_destinations` (`runId`);
