# Fase 0 + Fase 2 + Fase 3 + Fase 4 (com PDF de verdade) — pacote completo

Como não tenho acesso ao seu repositório de verdade (nem internet neste sandbox pra
instalar dependências e rodar `tsc`/`vitest`), o código foi escrito e revisado à mão,
seguindo exatamente as convenções já usadas no seu projeto (mesmos nomes de função,
mesmo estilo de router/db, mesmos padrões de teste). **Rode `npm install`, depois
`npm run check` e `npm run test`** depois de aplicar, antes de publicar. Com isso, as 5
fases do plano original (0 a 4) estão todas cobertas nesta entrega.

## Biblioteca de PDF escolhida: `pdf-lib`

Você pediu pra eu escolher — fui com **pdf-lib** em vez de Puppeteer/Playwright (que
renderizariam o HTML de `caseExport.ts` com fidelidade maior, mas exigem baixar um
Chromium inteiro, ~300MB, e sobem a complexidade de deploy). `pdf-lib` é puro
JavaScript, sem binário nativo, ~1MB de dependência, e roda igual em qualquer host —
combina com a filosofia "sem firula" que já guiava o resto do projeto. A troca: o
layout é desenhado à mão em `server/caseExportPdf.ts` (não reaproveita o HTML/CSS de
`caseExport.ts` diretamente), mas o texto sai selecionável e pesquisável, com quebra de
página automática. As três exportações (JSON, HTML-para-impressão, PDF) descrevem
sempre o mesmo `CaseExportBundle` — só o formato final muda.

## Como aplicar

Copie estes arquivos por cima dos correspondentes no seu projeto (mesma estrutura de
pastas: `drizzle/`, `shared/`, `server/`, `client/`), e rode `npm install` para puxar o
`pdf-lib` novo listado em `package.json`:

| Arquivo | O que mudou |
|---|---|
| `drizzle/schema.ts` | Enum de status da Mesa Formal migrado de 5 → 9 estados; `ownerCaseNegotiationScenarios` ganhou `stage`/`previousScenarioVersionId`/`migrationReason`; 3 tabelas novas de checklist/parâmetros/transcrição; `documentEvents.eventType` acompanhou o novo enum; **[Fase 4]** `strategies.agreementChance`/`consensualityImpact` renomeados para `strategicPostureScore`/`cooperationTradeoff` |
| `shared/hearingChecklist.ts` | Adicionado `NEGOTIATION_PROPOSAL_STATUSES` e o grafo de transição de 9 estados |
| `shared/negotiationRules.ts` | Reescrito como alias do enum canônico acima |
| `shared/workspacePolicy.ts` | `nextDocumentVisibility` ampliado para os novos nomes de status |
| `shared/scenarioParameters.ts` | **novo** — 5 estágios nomeados de cenário, migração com motivo, avaliação de parâmetro |
| `shared/transcriptMatching.ts` | **novo** — cascata online → local offline → léxica; extração de número por extenso |
| `server/checklistDb.ts` / `server/checklist.ts` | **novos** — dados e router do checklist dinâmico |
| `server/operationalDb.ts`, `server/operationalDocuments.ts` | Novos nomes de status; **[Fase 4]** `strategicPostureScore`/`cooperationTradeoff` |
| `server/secretVault.ts` | **[Fase 2]** PBKDF2-HMAC-SHA256 (210.000 iterações) com sal por registro, compatível com registros antigos `sv1` |
| `shared/actorRoles.ts` / `server/actorChat.ts` / `client/src/components/ActorRoster.tsx` | **[Fase 3, novos]** os 6 papéis anônimos, o router de chat por papel, e o componente de retratos clicáveis com voz |
| `shared/interestAlignmentIndex.ts` | **[Fase 4, novo]** índice comparativo de atendimento dos interesses — multi-dimensão, com pesos visíveis e "não calculado" quando falta dado. Substitui a lógica antiga que só existia como `agreementChance` |
| `client/src/lib/strategyPreview.ts` | **[Fase 4]** `agreementChance`/`consensualityImpact` → `strategicPostureScore`/`cooperationTradeoff` (nomes que não soam como previsão de resultado) |
| `shared/caseExport.ts` / `server/caseExport.ts` | **[Fase 4, novos]** monta a síntese de uma página, checklist, pontos inegociáveis, perguntas de audiência e histórico formal — exporta em JSON e em HTML autônomo (sem chamada externa) pronto para "imprimir → salvar como PDF" |
| `server/caseExportPdf.ts` | **[Fase 4, novo]** gera um PDF de verdade (texto selecionável, com paginação automática) a partir do mesmo `CaseExportBundle`, usando `pdf-lib` |
| `package.json` | Adiciona a dependência `pdf-lib` |
| `server/routers.ts` | Registra `checklistRouter`, `actorChatRouter` e `caseExportRouter` |
| `*.test.ts` | Testes novos/ampliados para tudo acima |

## Como usar o `ActorRoster` numa página

```tsx
import { ActorRoster } from "@/components/ActorRoster";

<ActorRoster
  caseId={activeCase.id}
  title={activeCase.title}
  objective="Preparar a próxima rodada de negociação"
  rawCaseContent={casoResumoCompleto} // string com o conteúdo do caso; a redação por nível de acesso acontece no servidor
/>
```

## Como gerar uma exportação

```ts
const { printableHtml, json, pdfBase64 } = await trpc.caseExport.buildBundle.mutate({
  scenarioId,
  caseTitle: "Caso — Divórcio",
  currentStage: "equilibrado",
  keyFacts: ["..."],
  topRisks: ["..."],
  nextSteps: ["..."],
  formalHistory: (await trpc.operationalDocuments.list.query({ caseId })).map(doc => ({
    id: doc.id, documentType: doc.documentType, title: doc.title,
    currentStatus: doc.currentStatus, createdAtIso: doc.createdAt,
  })),
});
// printableHtml: abrir numa nova aba e usar "imprimir -> salvar como PDF"
// json: exportação estruturada completa
// pdfBase64: decodificar (atob) e baixar como arquivo .pdf — texto selecionável, com páginas
```

## Migração de dados (se já existir base publicada)

Antes de aplicar o novo enum em produção, rode uma migração que converta:

```sql
UPDATE negotiationDocuments SET currentStatus = 'rascunho_interno' WHERE currentStatus = 'rascunho';
UPDATE negotiationDocuments SET currentStatus = 'apresentada'      WHERE currentStatus = 'enviada';
```

(Se ainda não há dado real em produção — o que parece ser o seu caso —, pode ignorar
esta seção e só rodar `db:push` normalmente.)

Segredos já gravados com o cofre antigo (`sv1`) continuam sendo lidos normalmente —
`decryptSecretForVault` reconhece os dois formatos. Eles só passam a usar PBKDF2+sal
quando forem regravados (rotacionados).

## O que ficou pendente (fora do escopo desta entrega)

- **Camadas A (online) e B (local offline)** do matcher de transcrição ainda não têm um
  provedor real conectado — cai direto para a Camada C (léxica), que já funciona sozinha.
- **Captura de áudio em si** (tab/system audio do navegador) não foi escrita — o pipeline
  recebe o texto já transcrito. Alinhado com `TRANSCRICAO_AUDIENCIA_INTEGRACAO.md`.
- **Histórico do chat por ator não é persistido** — vive só no estado do React durante a
  sessão. Persistir é um bom próximo passo (tabela `concilium_actor_chat_messages`, por
  exemplo), mas não bloqueia o uso.
- **Testes de integração do router com banco/LLM mockado** não foram escritos — os testes
  desta entrega cobrem a lógica pura em `shared/`.
- `server/caseExportPdf.ts` usa `page.drawCircle(...)` do pdf-lib (bolinha colorida do
  alerta verde/amarelo/vermelho no checklist). Não consegui rodar `npm install`/`vitest`
  neste sandbox pra confirmar esse método na versão exata que vier a ser instalada — se
  o `npm run test` acusar erro nesse ponto, troque por `page.drawEllipse({ x, y, xScale:
  3, yScale: 3, color })`, que é equivalente e existe desde as primeiras versões do
  pdf-lib.


## O que ficou pendente (fora do escopo desta entrega)

- **Camadas A (online) e B (local offline)** do matcher ainda não têm um provedor
  real conectado — a cascata cai direto para a Camada C (léxica), que já funciona
  sozinha. Ligar um provedor é passar uma função em `providers.online` /
  `providers.localOffline` ao chamar `ingestTranscriptChunk` — a assinatura já está
  pronta em `shared/transcriptMatching.ts`.
- **Captura de áudio em si** (tab/system audio do navegador) não foi escrita — o que
  existe é o pipeline que recebe o texto já transcrito (`ingestTranscriptChunk` com
  `source: "audio_ao_vivo"`). Isso está de propósito alinhado com
  `TRANSCRICAO_AUDIENCIA_INTEGRACAO.md`, que já definia que a primeira publicação usa
  importação de transcrição, não captura ao vivo direta.
- **Front-end**: nenhuma tela nova — só o backend (schema + regras + rotas). O
  protótipo `checklist-audiencia-concilium-v2.html` que já existe no seu projeto já
  cobre boa parte da interface e da Camada C (função `obterContextoLocalOffline`);
  vale conectá-lo a estas rotas em vez de recriar a tela do zero.
- **Testes de integração do router com banco mockado** (estilo `ownerActivation.test.ts`
  com `vi.mock("./db")`) não foram escritos — os testes desta entrega cobrem a lógica
  pura em `shared/`, que é onde está o essencial. Escrever os testes de integração é
  um bom próximo passo antes de publicar.
- **Renomear `agreementChance`** (apontado no gap 5 da análise anterior) — não mexi
  nisso agora porque é uma mudança em `strategies`, fora do escopo desta Fase 0.
