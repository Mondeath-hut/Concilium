# Concilium — checkpoint da fase 31

## Retorno efetivo para Estratégia e Arena
O encaminhamento registrado na comparação agora produz efeito nos dois destinos prioritários:

- `Arena`: quando a decisão é manter a versão inicial ou refinada, a aplicação abre o Comitê de IA com a avaliação correspondente;
- `Estrategista`: quando a decisão é compatível com uma versão selecionada, a formulação é carregada no Laboratório como fonte da próxima exploração.

Para evitar encaminhamento sem escolha real, Estratégia e Arena exigem uma decisão de versão diferente de `pending`. Compêndio, Bibliotecário e Arquivo continuam como destinos explicitamente registrados, sem executar operação automática até que suas interfaces especializadas sejam conectadas.

## Preservação
- a comparação permanece íntegra;
- a avaliação original não é sobrescrita;
- `nextDestination` e `routedAt` indicam o encaminhamento;
- a auditoria registra a decisão e o destino.

## Estado de validação
Fluxo de interface e callbacks preparados. Ainda não houve build, type-check, migração ou execução contra banco/provedor real.
