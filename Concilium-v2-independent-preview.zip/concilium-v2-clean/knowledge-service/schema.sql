-- Banco separado do Concilium. PostgreSQL recomendado para busca híbrida.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- CREATE EXTENSION IF NOT EXISTS vector; -- habilitar quando o índice semântico estiver disponível.

CREATE TABLE IF NOT EXISTS knowledge_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  publisher text NOT NULL,
  source_url text,
  jurisdiction text NOT NULL,
  source_type text NOT NULL CHECK (source_type IN ('legislacao','jurisprudencia','doutrina','modelo','clausula','guia','outro')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS knowledge_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid NOT NULL REFERENCES knowledge_sources(id),
  area text NOT NULL,
  title text NOT NULL,
  summary text NOT NULL,
  normalized_text text NOT NULL,
  version text NOT NULL,
  country text NOT NULL DEFAULT 'Brasil',
  jurisdiction text NOT NULL,
  authority_level text NOT NULL CHECK (authority_level IN ('primaria','jurisprudencia_relevante','secundaria','modelo_nao_normativo')),
  validity_state text NOT NULL DEFAULT 'pendente_verificacao' CHECK (validity_state IN ('vigente','revogada','superada','expirada','pendente_verificacao')),
  validity_checked_at timestamptz,
  superseded_by uuid REFERENCES knowledge_entries(id),
  effective_date date,
  valid_until date,
  review_status text NOT NULL DEFAULT 'pending' CHECK (review_status IN ('pending','reviewed','retired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS knowledge_chunks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id uuid NOT NULL REFERENCES knowledge_entries(id) ON DELETE CASCADE,
  ordinal int NOT NULL,
  locator text NOT NULL,
  body text NOT NULL,
  lexical tsvector GENERATED ALWAYS AS (to_tsvector('portuguese', body)) STORED,
  UNIQUE(entry_id, ordinal)
);

CREATE TABLE IF NOT EXISTS knowledge_relations (
  entry_id uuid NOT NULL REFERENCES knowledge_entries(id) ON DELETE CASCADE,
  related_entry_id uuid NOT NULL REFERENCES knowledge_entries(id) ON DELETE CASCADE,
  reason text NOT NULL,
  PRIMARY KEY(entry_id, related_entry_id)
);

CREATE INDEX IF NOT EXISTS knowledge_chunks_lexical_idx ON knowledge_chunks USING gin (lexical);
CREATE INDEX IF NOT EXISTS knowledge_entries_area_idx ON knowledge_entries (area, jurisdiction, review_status);
CREATE INDEX IF NOT EXISTS knowledge_entries_dates_idx ON knowledge_entries (effective_date, valid_until);
