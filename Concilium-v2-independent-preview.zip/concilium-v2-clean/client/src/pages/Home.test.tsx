import React from "react";
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ThemeProvider } from "@/contexts/ThemeContext";

vi.mock("@/components/OwnerAccessButton", () => ({
  OwnerAccessButton: ({ children, className }: { children: React.ReactNode; className?: string }) => <button className={className}>{children}</button>,
}));

import Home from "./Home";

function renderHome() {
  return render(<ThemeProvider defaultTheme="navy" switchable><Home /></ThemeProvider>);
}

describe("Home", () => {
  const scrollIntoView = vi.fn();

  beforeEach(() => {
    scrollIntoView.mockReset();
    localStorage.clear();
    document.documentElement.dataset.conciliumTheme = "";
    Object.defineProperty(HTMLElement.prototype, "scrollIntoView", {
      configurable: true,
      value: scrollIntoView,
    });
  });

  afterEach(() => cleanup());

  it("altera a explicação exibida ao selecionar uma etapa do fluxo", async () => {
    const user = userEvent.setup();
    renderHome();

    await user.click(screen.getByRole("button", { name: /O acesso começa pelo caso/i }));

    expect(screen.getByRole("heading", { name: "O acesso começa pelo caso." })).toBeDefined();
    expect(screen.getByText("Escopo mínimo")).toBeDefined();
  });

  it("abre o menu móvel e navega para a seção escolhida", async () => {
    const user = userEvent.setup();
    renderHome();

    await user.click(screen.getByLabelText("Abrir menu"));
    const menu = screen.getByRole("navigation", { name: "Navegação móvel" });

    await user.click(within(menu).getByRole("button", { name: "Mobilidade" }));

    expect(scrollIntoView).toHaveBeenCalledWith({ behavior: "smooth", block: "start" });
    expect(screen.queryByRole("navigation", { name: "Navegação móvel" })).toBeNull();
  });

  it("abre as configurações e persiste a preferência de tema", async () => {
    const user = userEvent.setup();
    renderHome();

    await user.click(screen.getAllByLabelText("Abrir configurações")[0]);
    expect(screen.getByRole("dialog")).toBeDefined();
    expect(screen.getByRole("dialog").className).toContain("concilium-settings-dialog");

    await user.click(screen.getByRole("button", { name: /Âmbar original/i }));

    expect(localStorage.getItem("concilium-theme")).toBe("amber");
    expect(document.documentElement.dataset.conciliumTheme).toBe("amber");
    expect(document.documentElement.classList.contains("dark")).toBe(false);
  });

  it("exibe a entrada de acesso próprio sem iniciar OAuth externo", () => {
    renderHome();
    const accessButtons = screen.getAllByRole("button", { name: "Acessar" });

    expect(accessButtons.length).toBeGreaterThan(0);
  });

  it.each([
    ["navy", "Azul-noturno", true],
    ["ivory", "Claro editorial", false],
    ["forest", "Verde-pinho", true],
    ["slate", "Grafite", true],
    ["amber", "Âmbar original", false],
  ])("aplica e persiste o tema %s", async (theme, label, isDark) => {
    const user = userEvent.setup();
    renderHome();

    await user.click(screen.getAllByLabelText("Abrir configurações")[0]);
    await user.click(screen.getByRole("button", { name: new RegExp(label, "i") }));

    expect(localStorage.getItem("concilium-theme")).toBe(theme);
    expect(document.documentElement.dataset.conciliumTheme).toBe(theme);
    expect(document.documentElement.classList.contains("dark")).toBe(isDark);
  });

  it("usa superfícies semânticas para o herói, demonstrações e encerramento", () => {
    renderHome();

    expect(document.getElementById("inicio")?.className).toContain("concilium-hero");
    expect(document.getElementById("seguranca")?.className).toContain("concilium-surface-alt");
    expect(screen.getByRole("heading", { name: /Conciliação exige discrição/i }).className).toContain("c-deep-ink");
    expect(screen.getByText("Mediação · documentos privados").parentElement?.className).toContain("concilium-showcase");
    expect(screen.getByRole("heading", { name: /Pronto para conciliar/i }).parentElement?.parentElement?.parentElement?.className).toContain("concilium-callout");
  });
});
