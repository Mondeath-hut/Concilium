import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { startAuthentication } from "@simplewebauthn/browser";
import {
  Archive,
  BookOpenCheck,
  BrainCircuit,
  FileLock2,
  FileStack,
  FlaskConical,
  Gavel,
  Languages,
  LogOut,
  Menu,
  Moon,
  PanelLeftOpen,
  Plus,
  Scale,
  Settings,
  ShieldCheck,
  Sun,
  UsersRound,
  Waypoints,
} from "lucide-react";
import React, { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SecretIntakePanel } from "@/components/SecretIntakePanel";
import { StrategyBranchInbox } from "@/components/StrategyBranchInbox";
import { ExplorationLineageComparison } from "@/components/ExplorationLineageComparison";
import { DocumentCatalogReview } from "@/components/DocumentCatalogReview";
import { DocumentVersionHistory } from "@/components/DocumentVersionHistory";
import { conciliumThemes, useTheme } from "@/contexts/ThemeContext";
import { defaultLanguagePackId, languagePacks, type LanguagePackId } from "@/lib/languagePacks";
import { getOwnerDashboardRedirectPath } from "./OwnerDashboard";
import { knowledgeAreas, type KnowledgeArea, type KnowledgeResult } from "@shared/knowledgeService";
import type { LibrarianResearchMode } from "@shared/librarianWorkflow";

type WorkspaceSection =
  | "visao-geral"
  | "estrategias"
  | "negociacao"
  | "biblioteca"
  | "governanca"
  | "auditoria"
  | "comite-ia"
  | "configuracoes";

const simulationCase = {
  id: "00000000-0000-4000-8000-000000000001",
  title: "Caso de demonstração local",
  summary: "Exemplo isolado para testar a navegação. Nenhum dado real, documento ou decisão é usado ou salvo.",
  status: "draft",
};

const sectionConfig: Array<{
  id: WorkspaceSection;
  label: string;
  icon: typeof Scale;
  eyebrow: string;
  title: string;
  description: string;
}> = [
  { id: "visao-geral", label: "Visão geral", icon: Scale, eyebrow: "Painel de controle", title: "Casos e acordos", description: "Acompanhe a condução reservada de cada caso, seus documentos e decisões verificáveis." },
  { id: "estrategias", label: "Estratégias", icon: Waypoints, eyebrow: "Painel de estratégias", title: "Cenários e próximos passos", description: "Organize cenários antes de formalizar qualquer proposta, mantendo a decisão humana como referência." },
  { id: "negociacao", label: "Negociação", icon: Gavel, eyebrow: "Mesa de negociação", title: "Propostas e contrapropostas", description: "A área de negociação reunirá as rodadas e os registros formais de cada acordo em contexto protegido." },
  { id: "biblioteca", label: "Biblioteca", icon: FileStack, eyebrow: "Acervo documental", title: "Biblioteca protegida", description: "Documentos e anexos ficarão disponíveis por caso, com registro de visibilidade e acesso controlado." },
  { id: "governanca", label: "Governança", icon: UsersRound, eyebrow: "Governança de acesso", title: "Pessoas e permissões", description: "Você, como titular, administrará permissões por caso. Convites permanecem desativados até a abertura segura de um caso." },
  { id: "auditoria", label: "Auditoria", icon: Archive, eyebrow: "Histórico do caso", title: "Decisões do caso", description: "Ações do caso serão preservadas com contexto, data e autoria para acompanhamento objetivo." },
  { id: "comite-ia", label: "Comitê de IA", icon: BrainCircuit, eyebrow: "Ambiente reservado", title: "Comitê de IA", description: "O laboratório de análise assistida permanecerá exclusivo ao titular e só receberá conteúdo quando você autorizar uma análise." },
  { id: "configuracoes", label: "Configurações", icon: Settings, eyebrow: "Preferências do titular", title: "Configurações", description: "Ajuste a experiência do Concilium sem alterar a sua identidade, passkeys ou controles de segurança." },
];

function workspaceSectionFromPath(pathname: string): WorkspaceSection {
  const candidate = pathname.split("/").filter(Boolean)[1] as WorkspaceSection | undefined;
  return sectionConfig.some(section => section.id === candidate) ? candidate! : "visao-geral";
}

const LANGUAGE_PACKS_STORAGE_KEY = "concilium-installed-language-packs";
const LANGUAGE_SELECTION_STORAGE_KEY = "concilium-language-pack";

function readInstalledLanguagePacks(): LanguagePackId[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(LANGUAGE_PACKS_STORAGE_KEY) ?? "[]") as unknown;
    if (Array.isArray(parsed)) {
      const known = parsed.filter((id): id is LanguagePackId => typeof id === "string" && id in languagePacks);
      return Array.from(new Set([defaultLanguagePackId, ...known]));
    }
  } catch {
    // Uma preferência local inválida não impede a abertura do espaço protegido.
  }
  return [defaultLanguagePackId];
}

function readSelectedLanguagePack(): LanguagePackId {
  try {
    const stored = localStorage.getItem(LANGUAGE_SELECTION_STORAGE_KEY);
    if (stored && stored in languagePacks) return stored as LanguagePackId;
  } catch {
    // localStorage pode estar indisponível em contexto restrito.
  }
  return defaultLanguagePackId;
}

export function getSettingsToggleDestination(activeSection: WorkspaceSection, sectionBeforeSettings: WorkspaceSection): WorkspaceSection {
  return activeSection === "configuracoes" ? sectionBeforeSettings : "configuracoes";
}

type Governance = {
  passkeyCount: number;
  remainingRecoveryCodes: number;
  totpContingencyConfigured: boolean;
  accountState: string;
  emailVerified: boolean;
};

function WorkspaceContent({
  section,
  ownerName,
  governance,
  selectedCaseId,
  onSelectCase,
  onOpenSecurity,
  onLogout,
  isLoggingOut,
  simulationMode,
  onSimulationModeChange,
}: {
  section: WorkspaceSection;
  ownerName: string;
  governance: Governance;
  selectedCaseId: string | null;
  onSelectCase: (caseId: string) => void;
  onOpenSecurity: () => void;
  onLogout: () => void;
  isLoggingOut: boolean;
  simulationMode: boolean;
  onSimulationModeChange: (enabled: boolean) => void;
}) {
  const current = sectionConfig.find(item => item.id === section) ?? sectionConfig[0];
  const Icon = current.icon;
  const { theme, setTheme } = useTheme();
  const [languagePackId, setLanguagePackId] = useState<LanguagePackId>(readSelectedLanguagePack);
  const [installedLanguagePackIds, setInstalledLanguagePackIds] = useState<LanguagePackId[]>(readInstalledLanguagePacks);
  const [installingLanguagePackId, setInstallingLanguagePackId] = useState<LanguagePackId | null>(null);
  const languagePack = languagePacks[languagePackId];
  const currentCopy = languagePack.sections[current.id];

  const selectLanguagePack = (id: LanguagePackId) => {
    if (!installedLanguagePackIds.includes(id)) return;
    setLanguagePackId(id);
    try {
      localStorage.setItem(LANGUAGE_SELECTION_STORAGE_KEY, id);
      document.documentElement.lang = languagePacks[id].locale;
    } catch {
      // O idioma continua ativo durante a sessão quando o armazenamento é bloqueado.
    }
  };

  const installLanguagePack = (id: LanguagePackId) => {
    if (installedLanguagePackIds.includes(id) || installingLanguagePackId) return;
    setInstallingLanguagePackId(id);
    window.setTimeout(() => {
      setInstalledLanguagePackIds(currentIds => {
        const nextIds = Array.from(new Set([...currentIds, id]));
        try { localStorage.setItem(LANGUAGE_PACKS_STORAGE_KEY, JSON.stringify(nextIds)); } catch { /* Preferência transitória. */ }
        return nextIds;
      });
      setLanguagePackId(id);
      try {
        localStorage.setItem(LANGUAGE_SELECTION_STORAGE_KEY, id);
        document.documentElement.lang = languagePacks[id].locale;
      } catch {
        // O idioma recém-instalado permanece ativo durante a sessão.
      }
      setInstallingLanguagePackId(null);
    }, 650);
  };
  const isOverview = current.id === "visao-geral";
  const isStrategies = current.id === "estrategias";
  const isNegotiation = current.id === "negociacao";
  const isLibrary = current.id === "biblioteca";
  const isGovernance = current.id === "governanca";
  const isAudit = current.id === "auditoria";
  const isAi = current.id === "comite-ia";
  const isSettings = current.id === "configuracoes";
  const [createOpen, setCreateOpen] = useState(false);
  const [caseTitle, setCaseTitle] = useState("");
  const [caseSummary, setCaseSummary] = useState("");
  const [strategyTitle, setStrategyTitle] = useState("");
  const [strategyNotes, setStrategyNotes] = useState("");
  const [exploreTitle, setExploreTitle] = useState("");
  const [exploreObjective, setExploreObjective] = useState("");
  const [exploreSource, setExploreSource] = useState("");
  const [exploreSourceAssessmentId, setExploreSourceAssessmentId] = useState<string | null>(null);
  const [exploreModels, setExploreModels] = useState<string[]>([]);
  const [exploreConsent, setExploreConsent] = useState(false);
  const [activeExplorationRunId, setActiveExplorationRunId] = useState<string | null>(null);
  const [explorationAnswer, setExplorationAnswer] = useState("");
  const [proposalStrategyId, setProposalStrategyId] = useState("");
  const [proposalTitle, setProposalTitle] = useState("");
  const [proposalBody, setProposalBody] = useState("");
  const [attachmentTitle, setAttachmentTitle] = useState("");
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
  const [knowledgeQuery, setKnowledgeQuery] = useState("");
  const [knowledgeResearchMode, setKnowledgeResearchMode] = useState<LibrarianResearchMode>("contextual_research");
  const [activeResearchRequestId, setActiveResearchRequestId] = useState<string | null>(null);
  const [knowledgeArea, setKnowledgeArea] = useState<KnowledgeArea>("geral");
  const [knowledgeIncludeRelated, setKnowledgeIncludeRelated] = useState(true);
  const [knowledgeResults, setKnowledgeResults] = useState<KnowledgeResult[]>([]);
  const [auditCursor, setAuditCursor] = useState<{ id: string; createdAt: Date }>();
  const [auditEvents, setAuditEvents] = useState<Array<{ id: string; eventType: string; createdAt: Date }>>([]);
  const [openingDocumentId, setOpeningDocumentId] = useState<string | null>(null);
  const [documentAccessError, setDocumentAccessError] = useState<string | null>(null);
  const [aiTitle, setAiTitle] = useState("");
  const [aiObjective, setAiObjective] = useState("");
  const [aiSourceContent, setAiSourceContent] = useState("");
  const [strategistContext, setStrategistContext] = useState("");
  const [aiVisibilityLevel, setAiVisibilityLevel] = useState<"integral_autorizado" | "contexto_protegido" | "redigido">("contexto_protegido");
  const [selectedAiModels, setSelectedAiModels] = useState<string[]>([]);
  const [aiConsentConfirmed, setAiConsentConfirmed] = useState(false);
  const [previousRunId, setPreviousRunId] = useState<string | undefined>(() => typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("previous") ?? undefined : undefined);
  const [arenaSessionId, setArenaSessionId] = useState<string | undefined>(() => typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("session") ?? undefined : undefined);
  const [supervisorInstruction, setSupervisorInstruction] = useState("");
  const [roundMessage, setRoundMessage] = useState("");
  const [arenaSessionLabel, setArenaSessionLabel] = useState("");
  const [arenaTeamLabel, setArenaTeamLabel] = useState("");
  const [comparisonLeftRunId, setComparisonLeftRunId] = useState("");
  const [comparisonRightRunId, setComparisonRightRunId] = useState("");
  const [synthesisDraft, setSynthesisDraft] = useState("");
  const [argumentCompareLeftId, setArgumentCompareLeftId] = useState("");
  const [argumentCompareRightId, setArgumentCompareRightId] = useState("");
  const [comparisonDestinations, setComparisonDestinations] = useState<Record<string, "strategy" | "librarian" | "arena" | "compendium" | "archive">>({});
  const [credentialProvider, setCredentialProvider] = useState<string | null>(null);
  const [credentialDraft, setCredentialDraft] = useState("");
  const [credentialNotice, setCredentialNotice] = useState<string | null>(null);

  const cases = trpc.operationalCases.list.useQuery(undefined, { enabled: !simulationMode });
  const createCase = trpc.operationalCases.create.useMutation({
    onSuccess: ({ caseId }) => {
      setCreateOpen(false);
      setCaseTitle("");
      setCaseSummary("");
      onSelectCase(caseId);
      void cases.refetch();
    },
  });
  const caseOverviewInput = useMemo(() => ({ caseId: selectedCaseId ?? simulationCase.id }), [selectedCaseId]);
  const activeCase = trpc.operationalCases.overview.useQuery(caseOverviewInput, { enabled: Boolean(selectedCaseId) && !simulationMode });
  const createStrategy = trpc.operationalCases.createStrategy.useMutation({
    onSuccess: () => {
      setStrategyTitle("");
      setStrategyNotes("");
      void activeCase.refetch();
    },
  });
  const exploreStrategies = trpc.ownerWorkspace.exploreStrategies.useMutation({
    onSuccess: () => {
      setExploreTitle("");
      setExploreObjective("");
      setExploreSource("");
      setExploreSourceAssessmentId(null);
      setExploreConsent(false);
      void strategyExplorations.refetch();
    },
  });
  const selectStrategyIdeaForArena = trpc.ownerWorkspace.selectStrategyIdeaForArena.useMutation({
    onSuccess: ({ id }) => window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&strategyIdea=${id}`, "_blank", "noopener,noreferrer"),
  });
  const answerStrategyQuestions = trpc.ownerWorkspace.answerStrategyExplorationQuestions.useMutation({
    onSuccess: () => { setExplorationAnswer(""); void explorationThreads.refetch(); void strategyExplorations.refetch(); },
  });
  const createProposal = trpc.operationalDocuments.createProposal.useMutation({
    onSuccess: () => {
      setProposalStrategyId("");
      setProposalTitle("");
      setProposalBody("");
      void activeCase.refetch();
    },
  });
  const sendProposal = trpc.operationalDocuments.send.useMutation({
    onSuccess: () => void activeCase.refetch(),
  });
  const attachments = trpc.operationalAttachments.list.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: isLibrary && Boolean(selectedCaseId) && !simulationMode },
  );
  const compendiumEntries = trpc.ownerWorkspace.listCompendiumEntries.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: isLibrary && Boolean(selectedCaseId) && !simulationMode },
  );
  const researchRequests = trpc.ownerWorkspace.listResearchRequests.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: isLibrary && Boolean(selectedCaseId) && !simulationMode },
  );
  const uploadAttachment = trpc.operationalAttachments.upload.useMutation({
    onSuccess: () => {
      setAttachmentTitle("");
      setAttachmentFile(null);
      void attachments.refetch();
    },
  });
  const openAttachment = trpc.operationalAttachments.open.useMutation();
  const answerResearchRequest = trpc.ownerWorkspace.answerResearchRequest.useMutation({
    onSuccess: () => { setActiveResearchRequestId(null); void researchRequests.refetch(); },
  });
  const knowledgeSearch = trpc.knowledge.search.useMutation({
    onSuccess: response => {
      setKnowledgeResults(response.results);
      if (activeResearchRequestId && selectedCaseId) answerResearchRequest.mutate({ caseId: selectedCaseId, requestId: activeResearchRequestId, results: response.results });
    },
  });
  const knowledgeReferences = trpc.knowledge.listReferences.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: isLibrary && Boolean(selectedCaseId) && !simulationMode },
  );
  const saveKnowledgeReference = trpc.knowledge.saveReference.useMutation();
  const saveKnowledgeClause = trpc.knowledge.saveClause.useMutation();
  const prepareKnowledgeArena = trpc.knowledge.prepareArena.useMutation();
  const documentAccess = trpc.ownerWorkspace.requestDocumentAccess.useMutation();
  const auditInput = useMemo(() => ({ limit: 15, ...(auditCursor ? { cursor: auditCursor } : {}) }), [auditCursor]);
  const audit = trpc.ownerWorkspace.audit.useQuery(auditInput, { enabled: isAudit && !simulationMode });
  const aiModels = trpc.ownerWorkspace.listAiModels.useQuery(undefined, { enabled: isAi && !simulationMode });
  const strategyAiModels = trpc.ownerWorkspace.listAiModels.useQuery(undefined, { enabled: isStrategies && !simulationMode });
  const strategyExplorations = trpc.ownerWorkspace.listStrategyExplorations.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: isStrategies && Boolean(selectedCaseId) && !simulationMode },
  );
  const argumentAssessments = trpc.ownerWorkspace.listArgumentAssessments.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: (isStrategies || isAi) && Boolean(selectedCaseId) && !simulationMode },
  );
  const argumentComparisons = trpc.ownerWorkspace.listArgumentComparisons.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id },
    { enabled: (isStrategies || isAi) && Boolean(selectedCaseId) && !simulationMode },
  );
  const explorationThreads = trpc.ownerWorkspace.listStrategyExplorationThreads.useQuery(
    { caseId: selectedCaseId ?? simulationCase.id, runId: activeExplorationRunId ?? "00000000-0000-4000-8000-000000000001" },
    { enabled: isStrategies && Boolean(selectedCaseId) && Boolean(activeExplorationRunId) && !simulationMode },
  );
  const aiProviders = trpc.ownerWorkspace.listAiProviders.useQuery(undefined, { enabled: isSettings && !simulationMode });
  const beginApiCredentialReauthentication = trpc.ownerActivation.beginApiCredentialReauthentication.useMutation();
  const finishApiCredentialReauthentication = trpc.ownerActivation.finishApiCredentialReauthentication.useMutation();
  const updateAiProviderCredential = trpc.ownerWorkspace.updateAiProviderCredential.useMutation();
  const aiRunInput = useMemo(() => ({ caseId: selectedCaseId ?? simulationCase.id }), [selectedCaseId]);
  const aiRuns = trpc.ownerWorkspace.listAiRuns.useQuery(aiRunInput, { enabled: isAi && Boolean(selectedCaseId) && !simulationMode });
  const arenaSessions = trpc.ownerWorkspace.listArenaSessions.useQuery(aiRunInput, { enabled: isAi && Boolean(selectedCaseId) && !simulationMode });
  const aiComparisons = trpc.ownerWorkspace.listAiComparisons.useQuery(aiRunInput, { enabled: isAi && Boolean(selectedCaseId) && !simulationMode });
  const aiSynthesisDestinations = trpc.ownerWorkspace.listAiSynthesisDestinations.useQuery(aiRunInput, { enabled: isAi && Boolean(selectedCaseId) && !simulationMode });
  const aiRoundPageId = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("round") : null;
  const knowledgeReferenceId = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("knowledgeReference") : null;
  const strategyIdeaId = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("strategyIdea") : null;
  const argumentAssessmentId = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("argumentAssessment") : null;
  const strategySynthesisId = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("strategySynthesis") : null;
  const knowledgeReference = trpc.knowledge.getReference.useQuery(
    { caseId: selectedCaseId ?? "00000000-0000-4000-8000-000000000001", referenceId: knowledgeReferenceId ?? "00000000-0000-4000-8000-000000000001" },
    { enabled: isAi && Boolean(selectedCaseId) && Boolean(knowledgeReferenceId) && !simulationMode },
  );
  const strategyIdea = trpc.ownerWorkspace.getStrategyIdeaForArena.useQuery(
    { caseId: selectedCaseId ?? "00000000-0000-4000-8000-000000000001", ideaId: strategyIdeaId ?? "00000000-0000-4000-8000-000000000001" },
    { enabled: isAi && Boolean(selectedCaseId) && Boolean(strategyIdeaId) && !simulationMode },
  );
  const strategyArenaHandoff = trpc.ownerWorkspace.getStrategyArenaHandoff.useQuery(
    { caseId: selectedCaseId ?? "00000000-0000-4000-8000-000000000001", synthesisId: strategySynthesisId ?? "00000000-0000-4000-8000-000000000001" },
    { enabled: isAi && Boolean(selectedCaseId) && Boolean(strategySynthesisId) && !simulationMode },
  );
  const visibleAiRuns = aiRoundPageId ? aiRuns.data?.filter(run => run.id === aiRoundPageId) : aiRuns.data;
  const runAiCommittee = trpc.ownerWorkspace.runAiCommittee.useMutation({
    onSuccess: () => {
      setAiTitle("");
      setAiObjective("");
      setAiSourceContent("");
      setStrategistContext("");
      setAiConsentConfirmed(false);
      setPreviousRunId(undefined);
      setSupervisorInstruction("");
      void aiRuns.refetch();
    },
  });
  const decideAiRun = trpc.ownerWorkspace.decideAiRun.useMutation({ onSuccess: () => void aiRuns.refetch() });
  const addAiRoundMessage = trpc.ownerWorkspace.addAiRoundMessage.useMutation({ onSuccess: () => { setRoundMessage(""); void aiRuns.refetch(); } });
  const collapseAiRound = trpc.ownerWorkspace.collapseAiRound.useMutation({ onSuccess: () => void aiRuns.refetch() });
  const approveAiSynthesis = trpc.ownerWorkspace.approveAiSynthesis.useMutation({ onSuccess: () => void aiRuns.refetch() });
  const setSynthesisStatus = trpc.ownerWorkspace.setAiSynthesisStatus.useMutation({ onSuccess: () => void aiRuns.refetch() });
  const createArenaSession = trpc.ownerWorkspace.createArenaSession.useMutation({
    onSuccess: session => { setArenaSessionLabel(""); setArenaTeamLabel(""); void arenaSessions.refetch(); window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&session=${session.id}${session.branchFromRunId ? `&previous=${session.branchFromRunId}` : ""}`, "_blank", "noopener,noreferrer"); },
  });
  const compareAiSyntheses = trpc.ownerWorkspace.compareAiSyntheses.useMutation({ onSuccess: () => void aiComparisons.refetch() });
  const routeAiSynthesis = trpc.ownerWorkspace.routeAiSynthesis.useMutation({ onSuccess: result => { void aiSynthesisDestinations.refetch(); if (result.artifact?.type === "arena" && selectedCaseId) window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&session=${result.artifact.id}&previous=${result.destination.runId ?? ""}`, "_blank", "noopener,noreferrer"); } });
  const createArgumentAssessment = trpc.ownerWorkspace.createArgumentAssessment.useMutation({ onSuccess: () => void argumentAssessments.refetch() });
  const triageArgument = trpc.ownerWorkspace.triageArgument.useMutation({ onSuccess: () => void argumentAssessments.refetch() });
  const compareArgumentAssessments = trpc.ownerWorkspace.compareArgumentAssessments.useMutation({ onSuccess: () => void argumentComparisons.refetch() });
  const decideArgumentComparison = trpc.ownerWorkspace.decideArgumentComparison.useMutation({
    onSuccess: comparison => {
      void argumentComparisons.refetch();
      if (!selectedCaseId || !comparison.nextDestination) return;
      const selectedAssessmentId = comparison.humanDecision === "retain_left" ? comparison.leftAssessmentId : comparison.humanDecision === "retain_right" ? comparison.rightAssessmentId : null;
      const selectedAssessment = selectedAssessmentId ? argumentAssessments.data?.find(item => item.id === selectedAssessmentId) : null;
      if (comparison.nextDestination === "arena" && selectedAssessmentId) window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&argumentAssessment=${selectedAssessmentId}`, "_blank", "noopener,noreferrer");
      if (comparison.nextDestination === "strategy" && selectedAssessment) prepareAssessmentForExploration(selectedAssessment);
    },
  });
  const selectStrategySynthesisForArena = trpc.ownerWorkspace.selectStrategySynthesisForArena.useMutation({ onSuccess: result => { if (selectedCaseId) window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&argumentAssessment=${result.assessment.id}&strategySynthesis=${result.synthesisId}`, "_blank", "noopener,noreferrer"); } });

  useEffect(() => {
    if (!isAudit || simulationMode) {
      setAuditCursor(undefined);
      setAuditEvents(currentEvents => (currentEvents.length === 0 ? currentEvents : []));
      return;
    }
    if (!audit.data?.events) return;
    setAuditEvents(currentEvents => {
      const next = auditCursor
        ? [...currentEvents.filter(event => !audit.data!.events.some(incoming => incoming.id === event.id)), ...audit.data!.events]
        : audit.data!.events;
      return currentEvents.length === next.length && currentEvents.every((event, index) => event.id === next[index]?.id) ? currentEvents : next;
    });
  }, [audit.data, auditCursor, isAudit, simulationMode]);
  useEffect(() => {
    if (!previousRunId || !aiRuns.data) return;
    const previous = aiRuns.data.find(run => run.id === previousRunId);
    if (!previous) return;
    setAiTitle(current => current || `Rodada ${previous.roundNumber + 1} — continuidade`);
    setAiObjective(current => current || "Aprofundar a análise a partir da síntese aprovada da rodada anterior.");
  }, [aiRuns.data, previousRunId]);
  useEffect(() => {
    if (!knowledgeReference.data) return;
    setAiTitle(current => current || `Refinamento: ${knowledgeReference.data!.title}`);
    setAiObjective(current => current || "Estressar a referência, testar sua viabilidade e identificar limites, riscos e pontos que exigem revisão humana.");
    setAiSourceContent(current => current || `${knowledgeReference.data!.title}\n\n${knowledgeReference.data!.clauseDraft || knowledgeReference.data!.summary}`);
  }, [knowledgeReference.data]);
  useEffect(() => {
    if (!strategyIdea.data) return;
    setAiTitle(current => current || `Estresse estratégico: ${strategyIdea.data!.perspective}`);
    setAiObjective(current => current || "Testar a viabilidade da alternativa, seus limites, riscos, condições e compatibilidade com o caso.");
    setAiSourceContent(current => current || strategyIdea.data!.ideaBody);
  }, [strategyIdea.data]);
  useEffect(() => {
    if (!strategyArenaHandoff.data) return;
    setAiTitle(current => current || `Arena: ${strategyArenaHandoff.data!.explorationTitle}`);
    setAiObjective(current => current || "Estressar o contexto estratégico amplo com defesa, acusação/advogado do diabo e mediador, preservando o contexto original para o supervisor.");
    setAiSourceContent(current => current || strategyArenaHandoff.data!.originalContext);
    setStrategistContext(current => current || `${strategyArenaHandoff.data!.strategyContext}\n\nPAUTA DO ESTRATEGISTA:\n${strategyArenaHandoff.data!.strategistBrief}`);
    setAiVisibilityLevel("contexto_protegido");
  }, [strategyArenaHandoff.data]);
  useEffect(() => {
    if (!isStrategies) return;
    let handoff: { query: string; target?: "strategist" | "alternatives_lab" | "none"; packet?: unknown; results?: unknown[] } | null = null;
    try {
      const raw = sessionStorage.getItem("concilium-librarian-strategy-handoff");
      if (raw) sessionStorage.removeItem("concilium-librarian-strategy-handoff");
      if (raw) {
        const parsed = JSON.parse(raw) as { query?: unknown; target?: unknown; packet?: unknown; results?: unknown };
        if (typeof parsed.query === "string") handoff = { query: parsed.query, target: parsed.target === "alternatives_lab" ? "alternatives_lab" : "strategist", packet: parsed.packet, results: Array.isArray(parsed.results) ? parsed.results : [] };
      }
    } catch { /* O formulário continua disponível sem o preenchimento automático. */ }
    if (!handoff) return;
    const librarianContext = [
      `PERGUNTA ORIGINAL DO TITULAR:\n${handoff.query}`,
      handoff.packet ? `PACOTE NEUTRO TRIADO PELO BIBLIOTECÁRIO:\n${JSON.stringify(handoff.packet)}` : "",
      handoff.results?.length ? `FONTES E RESULTADOS RECUPERADOS:\n${JSON.stringify(handoff.results)}` : "",
    ].filter(Boolean).join("\n\n");
    setExploreTitle(handoff.target === "alternatives_lab" ? "Mapa contextual encaminhado pelo Bibliotecário" : "Pergunta encaminhada pelo Bibliotecário");
    setExploreObjective(handoff.target === "alternatives_lab" ? "Explorar possibilidades independentes a partir do mapa contextual e das fontes triadas, preservando divergências e sem transformar a pesquisa em recomendação automática." : "Contextualizar a pergunta e as fontes triadas em linhas independentes, sem transformar a pesquisa neutra em recomendação automática.");
    setExploreSource(librarianContext.slice(0, 11_500));
    setExploreConsent(false);
  }, [isStrategies]);
  useEffect(() => {
    if (!argumentAssessmentId || !argumentAssessments.data) return;
    const assessment = argumentAssessments.data.find(item => item.id === argumentAssessmentId);
    if (!assessment) return;
    setAiTitle(current => current || "Refinamento de argumento triado");
    setAiObjective(current => current || "Estressar o argumento, preservar possibilidades controvertidas e separar fontes, riscos e limites antes da decisão humana.");
    setAiSourceContent(current => current || assessment.formulation);
  }, [argumentAssessmentId, argumentAssessments.data]);

  const caseList: Array<{ id: string; title: string; summary: string | null; status: string }> = simulationMode
    ? [simulationCase]
    : (cases.data ?? []).map(ownerCase => ({
        id: ownerCase.id,
        title: ownerCase.title,
        summary: ownerCase.description,
        status: ownerCase.status,
      }));
  useEffect(() => {
    if (simulationMode || cases.isLoading || caseList.length === 0) return;
    const selectedCaseStillExists = selectedCaseId && caseList.some(ownerCase => ownerCase.id === selectedCaseId);
    if (!selectedCaseStillExists) onSelectCase(caseList[0].id);
  }, [caseList, cases.isLoading, onSelectCase, selectedCaseId, simulationMode]);
  const simulationNotice = simulationMode ? <p role="status" className="c-tint c-accent-strong mt-5 rounded-xl px-4 py-3 text-xs font-bold">Modo de simulação ativo. Este conteúdo existe somente neste navegador e não será salvo.</p> : null;
  const openPrivateDocument = async (documentId: string) => {
    if (!selectedCaseId || documentAccess.isPending) return;
    setDocumentAccessError(null);
    setOpeningDocumentId(documentId);
    const target = window.open("about:blank", "_blank");
    if (target) target.opener = null;
    try {
      const { url } = await documentAccess.mutateAsync({ caseId: selectedCaseId, documentId });
      if (target) target.location.replace(url);
      else window.location.assign(url);
    } catch {
      target?.close();
      setDocumentAccessError("Não foi possível abrir este anexo. Sua sessão e o vínculo do documento não foram alterados.");
    } finally {
      setOpeningDocumentId(null);
    }
  };
  const submitAttachment = async () => {
    if (!selectedCaseId || !attachmentFile || !attachmentTitle.trim() || uploadAttachment.isPending) return;
    const contentBase64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Não foi possível ler o arquivo."));
      reader.onerror = () => reject(reader.error ?? new Error("Não foi possível ler o arquivo."));
      reader.readAsDataURL(attachmentFile);
    });
    uploadAttachment.mutate({
      caseId: selectedCaseId,
      title: attachmentTitle.trim(),
      mimeType: attachmentFile.type || "application/octet-stream",
      contentBase64,
    });
  };
  const submitKnowledgeSearch = () => {
    if (knowledgeQuery.trim().length < 3 || knowledgeSearch.isPending) return;
    knowledgeSearch.mutate({
      query: knowledgeQuery.trim(),
      areas: knowledgeArea === "geral" ? [] : [knowledgeArea as typeof knowledgeAreas[number]],
      includeRelated: knowledgeIncludeRelated,
      researchMode: knowledgeResearchMode,
    });
  };
  const handoffKnowledgeQuestionToStrategy = () => {
    if (knowledgeQuery.trim().length < 3) return;
    try {
      sessionStorage.setItem("concilium-librarian-strategy-handoff", JSON.stringify({
        query: knowledgeQuery.trim(),
        target: knowledgeSearch.data?.routing?.handoffTarget ?? "strategist",
        packet: knowledgeSearch.data?.packet ?? null,
        results: knowledgeResults.slice(0, 20),
      }));
    } catch { /* O encaminhamento ainda pode ser feito manualmente. */ }
    window.location.assign("/espaco/estrategias");
  };
  const saveKnowledgeResult = async (result: typeof knowledgeResults[number], mode: "reference" | "clause" | "arena") => {
    if (!selectedCaseId) return;
    try {
      const saved = mode === "clause"
        ? await saveKnowledgeClause.mutateAsync({ caseId: selectedCaseId, result, clauseDraft: `Rascunho inicial baseado em “${result.title}”:\n\n${result.summary}` })
        : await saveKnowledgeReference.mutateAsync({ caseId: selectedCaseId, result });
      await knowledgeReferences.refetch();
      if (mode === "arena") {
        await prepareKnowledgeArena.mutateAsync({ caseId: selectedCaseId, referenceId: saved.id });
        window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&knowledgeReference=${saved.id}`, "_blank", "noopener,noreferrer");
      }
    } catch {
      // O estado de erro de cada mutação permanece disponível para a interface.
    }
  };
  const openPrivateAttachment = async (attachmentId: string) => {
    if (!selectedCaseId || openAttachment.isPending) return;
    setDocumentAccessError(null);
    try {
      const { url } = await openAttachment.mutateAsync({ caseId: selectedCaseId, attachmentId });
      window.open(url, "_blank", "noopener,noreferrer");
    } catch {
      setDocumentAccessError("Não foi possível abrir este anexo protegido.");
    }
  };
  const toggleExploreModel = (modelId: string) => {
    setExploreModels(currentModels => currentModels.includes(modelId)
      ? currentModels.filter(currentModel => currentModel !== modelId)
      : currentModels.length < 5 ? [...currentModels, modelId] : currentModels);
  };
  const submitStrategyExploration = () => {
    if (!selectedCaseId || !exploreConsent || exploreModels.length < 2) return;
    exploreStrategies.mutate({ caseId: selectedCaseId, title: exploreTitle.trim(), objective: exploreObjective.trim(), sourceContent: exploreSource.trim(), modelIds: exploreModels, consentConfirmed: true, ...(exploreSourceAssessmentId ? { sourceAssessmentId: exploreSourceAssessmentId } : {}) });
  };
  const prepareAssessmentForExploration = (assessment: { id: string; formulation: string }) => {
    setExploreSourceAssessmentId(assessment.id);
    setExploreTitle("Exploração derivada da triagem");
    setExploreObjective("Mapear alternativas, pontos cegos, riscos e condições da formulação triada antes de submetê-la à Arena.");
    setExploreSource(assessment.formulation);
    window.setTimeout(() => window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" }), 0);
  };

  const startStrategyTriage = (strategy: { id: string; title: string; notes: string | null }) => {
    const modelId = strategyAiModels.data?.[0]?.id;
    if (!selectedCaseId || !modelId || triageArgument.isPending) return;
    triageArgument.mutate({
      caseId: selectedCaseId,
      strategyId: strategy.id,
      formulation: `${strategy.title}${strategy.notes ? `\n\n${strategy.notes}` : ""}`,
      researchQuery: strategy.title,
      modelId,
      consentConfirmed: true,
    });
  };
  const toggleAiModel = (modelId: string) => {
    setSelectedAiModels(currentModels => currentModels.includes(modelId)
      ? currentModels.filter(currentModel => currentModel !== modelId)
      : currentModels.length < 3 ? [...currentModels, modelId] : currentModels);
  };
  const submitAiCommittee = () => {
    if (!selectedCaseId || !aiConsentConfirmed || selectedAiModels.length === 0) return;
    runAiCommittee.mutate({
      caseId: selectedCaseId,
      title: aiTitle.trim(),
      objective: aiObjective.trim(),
      sourceContent: aiSourceContent.trim(),
      ...(strategistContext.trim() ? { strategistContext: strategistContext.trim() } : {}),
      visibilityLevel: aiVisibilityLevel,
      modelIds: selectedAiModels,
      consentConfirmed: true,
      ...(previousRunId ? { previousRunId } : {}),
      ...(arenaSessionId ? { sessionId: arenaSessionId } : {}),
      ...(supervisorInstruction.trim() ? { supervisorInstruction: supervisorInstruction.trim() } : {}),
    });
  };
  const saveAiProviderCredential = async () => {
    if (!credentialProvider || !credentialDraft.trim()) return;
    setCredentialNotice(null);
    try {
      const options = await beginApiCredentialReauthentication.mutateAsync();
      const response = await startAuthentication({ optionsJSON: options });
      await finishApiCredentialReauthentication.mutateAsync({ response });
      await updateAiProviderCredential.mutateAsync({ provider: credentialProvider as any, credential: credentialDraft.trim() });
      setCredentialDraft("");
      setCredentialNotice("Nova chave cifrada e salva. O provedor permanece inativo até a próxima validação.");
      void aiProviders.refetch();
    } catch {
      setCredentialNotice("A chave não foi alterada. Confirme a passkey e tente novamente.");
    }
  };

  const createCaseForm = (
    <div className="grid gap-4">
      <Button className="c-deep-button rounded-xl" aria-expanded={createOpen} disabled={simulationMode} onClick={() => setCreateOpen(open => !open)}>
        <Plus size={16} /> {simulationMode ? "Criação indisponível na simulação" : "Criar caso"}
      </Button>
      {createOpen && !simulationMode && (
        <section aria-label="Abrir um caso reservado" className="c-tint c-border mt-2 grid gap-4 rounded-2xl border p-5 text-left">
          <div>
            <p className="c-ink text-sm font-bold">Abrir um caso reservado</p>
            <p className="c-copy mt-1 text-xs leading-5">Apenas você verá este registro nesta fase. Convites e participantes não são adicionados automaticamente.</p>
          </div>
          <Input value={caseTitle} onChange={event => setCaseTitle(event.target.value)} placeholder="Título do caso" aria-label="Título do caso" maxLength={200} />
          <Textarea value={caseSummary} onChange={event => setCaseSummary(event.target.value)} placeholder="Contexto inicial opcional" aria-label="Contexto inicial do caso" maxLength={5000} />
          <div className="flex flex-wrap justify-end gap-2">
            <Button variant="outline" className="c-border c-ink" onClick={() => setCreateOpen(false)}>Cancelar</Button>
            <Button className="c-deep-button" disabled={caseTitle.trim().length < 3 || createCase.isPending} onClick={() => createCase.mutate({ title: caseTitle.trim(), description: caseSummary.trim() || undefined })}>{createCase.isPending ? "Criando…" : "Confirmar criação"}</Button>
          </div>
        </section>
      )}
    </div>
  );

  return (
    <section aria-labelledby="workspace-title" className="mx-auto max-w-5xl pb-12">
      <div className="border-b border-[var(--concilium-card-border)] pb-8">
        <div className="c-tint c-accent inline-flex rounded-2xl p-3"><Icon size={22} /></div>
        <p className="c-accent-strong mt-7 text-[10px] font-bold uppercase tracking-[0.2em]">{currentCopy.eyebrow}</p>
        <h1 id="workspace-title" className="font-editorial c-ink mt-3 text-4xl tracking-[-0.05em] sm:text-5xl">{currentCopy.title}</h1>
        <p className="c-copy mt-4 max-w-2xl text-sm leading-7 sm:text-[15px]">{currentCopy.description}</p>
        {simulationNotice}
      </div>

      {isAi && (
        <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8">
          {simulationMode ? <div><p className="c-ink text-lg font-bold">O Comitê de IA não executa na simulação.</p><p className="c-copy mt-2 text-sm leading-6">Nenhum conteúdo demonstrativo é enviado a modelos.</p></div> : !selectedCaseId ? <div><p className="c-ink text-lg font-bold">Selecione um caso antes de abrir o Comitê.</p><p className="c-copy mt-2 text-sm leading-6">Cada rodada fica vinculada ao caso, à sua sessão e a uma autorização explícita de conteúdo.</p></div> : <>
            <div className="flex flex-wrap items-start justify-between gap-4"><div><p className="c-ink text-lg font-bold">Arena de IA — estresse adversarial</p><p className="c-copy mt-2 max-w-2xl text-sm leading-6">A Arena recebe o contexto estratégico amplo depois da exploração. Aqui, supervisor, defesa, acusação/advogado do diabo e mediadores testam fragilidades, contrapontos, fontes e riscos. Esta área não substitui o Laboratório de Alternativas.</p></div><span className="c-tint c-accent-strong rounded-full px-3 py-2 text-[10px] font-bold uppercase tracking-[0.14em]">{activeCase.data?.ownerCase.title ?? "Caso selecionado"}</span></div>{strategyArenaHandoff.data && <section className="c-tint c-border mt-5 rounded-2xl border p-4" aria-label="Pacote recebido do Estrategista"><p className="c-ink text-sm font-bold">Pacote recebido do Estrategista</p><p className="c-copy mt-2 text-xs leading-5">A síntese foi trazida com o contexto original cifrado em repouso. Nesta rodada, o supervisor receberá a íntegra autorizada; as funções derivadas receberão projeções conforme o nível abaixo.</p><div className="mt-3 grid gap-2 text-xs sm:grid-cols-3"><div className="c-border rounded-xl border p-3"><p className="c-ink font-semibold">Supervisor</p><p className="c-success-ink mt-1">Integral autorizado</p></div><div className="c-border rounded-xl border p-3"><p className="c-ink font-semibold">Defesa</p><p className="c-copy mt-1">{aiVisibilityLevel.replaceAll("_", " ")}</p></div><div className="c-border rounded-xl border p-3"><p className="c-ink font-semibold">Acusação e mediador</p><p className="c-copy mt-1">Projeção automática por papel</p></div></div><details className="mt-3"><summary className="c-ink cursor-pointer text-xs font-semibold">Ver contexto estratégico encaminhado</summary><p className="c-copy mt-2 whitespace-pre-wrap text-xs leading-5">{strategyArenaHandoff.data.strategyContext}</p></details></section>}{strategyArenaHandoff.error && <p role="alert" className="c-accent-strong mt-5 rounded-xl border border-[var(--concilium-card-border)] px-4 py-3 text-xs">O pacote estratégico não pôde ser aberto com segurança. Gere uma nova exploração com a chave de contexto configurada.</p>}
            <section className="c-tint c-border mt-6 grid gap-4 rounded-2xl border p-5" aria-label="Nova rodada do Comitê de IA">
              <div><p className="c-ink text-sm font-bold">Nova rodada da Arena</p><p className="c-copy mt-1 text-xs leading-5">O supervisor recebe o contexto integral autorizado e organiza o estresse adversarial. Defesa, acusação/advogado do diabo e mediadores recebem somente a projeção compatível com seu papel e com o limite que você escolheu. A geração divergente de possibilidades acontece antes, no Laboratório do Estrategista.</p></div>
              <Input value={supervisorInstruction} onChange={event => setSupervisorInstruction(event.target.value)} placeholder="Orientação opcional ao supervisor: o que destravar ou aprofundar" aria-label="Orientação ao supervisor" maxLength={4000} />
              <Input value={aiTitle} onChange={event => setAiTitle(event.target.value)} placeholder="Título da rodada" aria-label="Título da rodada de IA" maxLength={220} />
              <Textarea value={aiObjective} onChange={event => setAiObjective(event.target.value)} placeholder="Objetivo técnico da consulta" aria-label="Objetivo técnico da rodada de IA" maxLength={4000} />
              <Textarea value={aiSourceContent} onChange={event => setAiSourceContent(event.target.value)} placeholder="Conteúdo que você autoriza analisar nesta rodada" aria-label="Conteúdo autorizado para análise de IA" maxLength={12000} className="min-h-36" />
              <label className="grid gap-2 text-xs"><span className="c-ink font-semibold">Limite máximo de visibilidade da rodada</span><select value={aiVisibilityLevel} onChange={event => setAiVisibilityLevel(event.target.value as typeof aiVisibilityLevel)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2"><option value="contexto_protegido">Contexto protegido</option><option value="redigido">Conteúdo redigido</option><option value="integral_autorizado">Conteúdo integral autorizado</option></select></label>
              <div><p className="c-ink text-xs font-semibold">Modelos integrados (até três)</p><p className="c-copy mt-1 text-xs leading-5">Regra automática: o supervisor vê integralmente; a acusação/advogado do diabo recebe conteúdo redigido quando há dados sensíveis; mediador e defesa recebem contexto protegido, salvo autorização integral.</p>{aiModels.isLoading ? <p className="c-copy mt-2 text-xs">Carregando modelos disponíveis…</p> : aiModels.error ? <p role="alert" className="c-copy mt-2 text-xs">Não foi possível carregar os modelos integrados agora.</p> : <div className="mt-3 grid gap-2 sm:grid-cols-2">{aiModels.data?.map(model => <label key={model.id} className={cn("c-border flex items-center gap-3 rounded-xl border p-3 text-xs", selectedAiModels.includes(model.id) && "c-tint")}><input type="checkbox" checked={selectedAiModels.includes(model.id)} onChange={() => toggleAiModel(model.id)} disabled={!selectedAiModels.includes(model.id) && selectedAiModels.length >= 3} /><span className="c-ink font-medium">{model.id}</span></label>)}</div>}</div>
              <label className="c-border flex items-start gap-3 rounded-xl border p-4 text-xs leading-5"><input className="mt-0.5" type="checkbox" checked={aiConsentConfirmed} onChange={event => setAiConsentConfirmed(event.target.checked)} /><span className="c-copy">Confirmo que posso autorizar o conteúdo no nível selecionado para os modelos escolhidos nesta rodada e que a resposta será somente apoio técnico sujeito à minha revisão.</span></label>
              {runAiCommittee.error && <p role="alert" className="c-accent-strong text-xs">Não foi possível concluir a rodada: {runAiCommittee.error.message}</p>}
              <Button className="c-deep-button w-fit rounded-xl" disabled={aiTitle.trim().length < 3 || aiObjective.trim().length < 12 || aiSourceContent.trim().length < 20 || selectedAiModels.length === 0 || !aiConsentConfirmed || runAiCommittee.isPending} onClick={submitAiCommittee}><BrainCircuit size={16} />{runAiCommittee.isPending ? "Consultando modelos…" : "Autorizar e iniciar rodada"}</Button>
            </section>
            <section className="mt-7"><p className="c-ink text-sm font-bold">Rodadas registradas</p>{aiRuns.isLoading ? <p className="c-copy mt-3 text-sm">Carregando rodadas do caso…</p> : aiRuns.error ? <p role="alert" className="c-copy mt-3 text-sm">Não foi possível consultar as rodadas deste caso.</p> : visibleAiRuns?.length ? <div className="mt-4 grid gap-4">{visibleAiRuns.map(run => <details key={run.id} open={run.roundState === "active"} className="c-tint c-border rounded-2xl border p-5"><summary className="c-ink cursor-pointer list-none text-sm font-bold">Rodada {run.roundNumber} · {run.title} <span className="c-soft ml-2 text-[10px] uppercase tracking-[0.14em]">{run.roundState === "active" ? "aberta" : "recolhida"}</span></summary><div className="mt-4 flex flex-wrap items-start justify-between gap-3"><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" onClick={() => window.open(`/espaco/comite-ia?round=${run.id}`, "_blank", "noopener,noreferrer")}>Abrir página desta rodada</Button><div><p className="c-ink text-sm font-bold">{run.title}</p><p className="c-copy mt-1 text-xs leading-5">{run.objective}</p></div><span className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.14em]">Decisão: {run.humanDecision === "pending" ? "pendente" : run.humanDecision}</span></div><p className="c-soft mt-3 text-[10px] leading-5">Visibilidade autorizada: {run.visibilityLevel.replaceAll("_", " ")} · consentimento registrado em {new Date(run.consentConfirmedAt).toLocaleString("pt-BR")} · síntese: {run.synthesisUseStatus.replaceAll("_", " ")}</p>{run.messages?.length ? <div className="c-border mt-4 grid gap-2 rounded-xl border p-3">{run.messages.map(message => <p key={message.id} className="c-copy text-xs leading-5"><span className="c-ink font-bold">{message.authorType === "supervisor" ? "Supervisor" : message.authorType === "owner" ? "Você" : "Sistema"}:</span> {message.body}</p>)}</div> : null}<div className="mt-4 grid gap-3">{run.executions.map(execution => <section key={execution.id} className="c-border rounded-xl border p-4"><p className="c-ink text-xs font-bold">{execution.role === "critical_auditor" ? "Acusação / advogado do diabo" : execution.role === "draft_advocate" ? "Defesa / redator técnico" : "Mediador"} · {execution.modelId}</p><p className="c-soft mt-1 text-[10px] uppercase tracking-[0.12em]">{execution.status === "completed" ? "resposta registrada" : execution.status === "failed" ? "falha registrada" : "em processamento"}</p>{execution.responseBody && <p className="c-copy mt-3 whitespace-pre-wrap text-xs leading-6">{execution.responseBody}</p>}{execution.errorSummary && <p className="c-accent-strong mt-3 text-xs leading-5">{execution.errorSummary}</p>}</section>)}</div>{run.roundState === "active" && <div className="c-border mt-5 grid gap-3 rounded-xl border p-4"><p className="c-ink text-xs font-bold">Acompanhar e intervir</p><Textarea value={roundMessage} onChange={event => setRoundMessage(event.target.value)} placeholder="Intervenção ou pergunta para o supervisor continuar a rodada" aria-label="Intervenção na rodada" maxLength={8000} className="min-h-20" /><div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={!roundMessage.trim() || addAiRoundMessage.isPending} onClick={() => addAiRoundMessage.mutate({ caseId: selectedCaseId, runId: run.id, body: roundMessage.trim() })}>Registrar intervenção</Button><Button size="sm" className="c-deep-button rounded-xl" disabled={synthesisDraft.trim().length < 20 || collapseAiRound.isPending} onClick={() => collapseAiRound.mutate({ caseId: selectedCaseId, runId: run.id, synthesis: synthesisDraft.trim() })}>Recolher com síntese</Button></div><Textarea value={synthesisDraft} onChange={event => setSynthesisDraft(event.target.value)} placeholder="Síntese, definições e considerações finais da rodada" aria-label="Síntese da rodada" maxLength={12000} className="min-h-24" /></div>}{run.roundState === "collapsed" && <div className="c-border mt-5 grid gap-3 rounded-xl border p-4"><p className="c-ink text-xs font-bold">Síntese da rodada</p><p className="c-copy whitespace-pre-wrap text-xs leading-6">{run.synthesis || "Síntese ainda não registrada."}</p>{run.synthesisApprovedAt ? <p className="c-success-ink text-xs font-bold">Síntese aprovada como ponto de partida.</p> : <Button size="sm" variant="outline" className="c-border c-ink w-fit rounded-xl" disabled={approveAiSynthesis.isPending} onClick={() => approveAiSynthesis.mutate({ caseId: selectedCaseId, runId: run.id })}>Aprovar síntese para próxima rodada</Button>}{run.synthesisApprovedAt && <Button size="sm" className="c-deep-button w-fit rounded-xl" onClick={() => { const nextUrl = `/espaco/comite-ia?previous=${run.id}`; const target = window.open(nextUrl, "_blank", "noopener,noreferrer"); if (!target) { setPreviousRunId(run.id); setAiTitle(`Rodada ${run.roundNumber + 1} — continuidade`); setAiObjective("Aprofundar a análise a partir da síntese aprovada da rodada anterior."); window.scrollTo({ top: 0, behavior: "smooth" }); } }}>Iniciar próxima rodada a partir desta</Button>}</div>}{run.roundState === "collapsed" && run.synthesis && <div className="c-border mt-4 flex flex-wrap gap-2 rounded-xl border p-3"><span className="c-ink self-center text-xs font-bold">Destino da síntese</span><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={setSynthesisStatus.isPending} onClick={() => setSynthesisStatus.mutate({ caseId: selectedCaseId, runId: run.id, status: "homologated" })}>Homologar para uso</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={setSynthesisStatus.isPending} onClick={() => setSynthesisStatus.mutate({ caseId: selectedCaseId, runId: run.id, status: "requires_review" })}>Marcar para revisão</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={setSynthesisStatus.isPending} onClick={() => setSynthesisStatus.mutate({ caseId: selectedCaseId, runId: run.id, status: "not_used" })}>Não utilizar</Button><span className="c-ink self-center text-xs font-bold">Encaminhar:</span><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={routeAiSynthesis.isPending || run.synthesisUseStatus !== "homologated"} onClick={() => routeAiSynthesis.mutate({ caseId: selectedCaseId, runId: run.id, destination: "bibliotecario" })}>Bibliotecário</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={routeAiSynthesis.isPending || run.synthesisUseStatus !== "homologated"} onClick={() => routeAiSynthesis.mutate({ caseId: selectedCaseId, runId: run.id, destination: "compendio" })}>Compêndio</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={routeAiSynthesis.isPending || run.synthesisUseStatus !== "homologated"} onClick={() => routeAiSynthesis.mutate({ caseId: selectedCaseId, runId: run.id, destination: "arena" })}>Próxima Arena</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={routeAiSynthesis.isPending} onClick={() => routeAiSynthesis.mutate({ caseId: selectedCaseId, runId: run.id, destination: "arquivo" })}>Arquivar</Button></div>}{run.humanDecision === "pending" && <div className="mt-4 flex flex-wrap gap-2"><Button variant="outline" className="c-border c-ink rounded-xl" disabled={decideAiRun.isPending} onClick={() => decideAiRun.mutate({ caseId: selectedCaseId, runId: run.id, humanDecision: "review" })}>Manter em revisão</Button><Button variant="outline" className="c-border c-ink rounded-xl" disabled={decideAiRun.isPending} onClick={() => decideAiRun.mutate({ caseId: selectedCaseId, runId: run.id, humanDecision: "use" })}>Usar como subsídio</Button><Button variant="outline" className="c-border c-ink rounded-xl" disabled={decideAiRun.isPending} onClick={() => decideAiRun.mutate({ caseId: selectedCaseId, runId: run.id, humanDecision: "discard" })}>Descartar</Button></div>}</details>)}</div> : <div className="c-tint c-border mt-4 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Nenhuma rodada registrada para este caso.</p><p className="c-copy mt-2 text-xs leading-5">Selecione modelos, autorize o conteúdo e confirme o consentimento para iniciar uma análise técnica privada.</p></div>}</section>
          </>}
        </article>
      )}

      {isAi && selectedCaseId && !simulationMode && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.16em]">Argumentos triados</p><h2 className="c-ink mt-2 text-lg font-bold">Linhas ligadas à estratégia e às rodadas</h2><p className="c-copy mt-2 text-sm leading-6">A Arena recebe linhas com a origem preservada e separa possibilidade jurídica, incerteza, risco ético e licitude operacional. Uma tese controvertida permanece visível; apenas instruções ilícitas são bloqueadas.</p>{argumentAssessments.data?.length ? <div className="mt-5 grid gap-3">{argumentAssessments.data.slice(0, 8).map(assessment => <article key={assessment.id} className="c-tint c-border rounded-2xl border p-4"><div className="flex flex-wrap items-center justify-between gap-3"><p className="c-ink text-xs font-bold">{assessment.legalStatus.replaceAll("_", " ")}</p><span className="c-soft text-[10px] uppercase tracking-[0.12em]">{assessment.reviewStatus.replaceAll("_", " ")}</span></div><p className="c-copy mt-2 whitespace-pre-wrap text-xs leading-5">{assessment.formulation}</p><p className="c-soft mt-2 text-[10px]">Confiança: {assessment.confidence} · origem: {assessment.runId ? "rodada da Arena" : assessment.explorationIdeaId ? "linha do Estrategista" : "estratégia"}</p></article>)}</div> : <p className="c-copy mt-5 text-sm">Nenhum argumento triado foi vinculado a este caso.</p>}</article>}

      {isAi && selectedCaseId && !simulationMode && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-ink text-lg font-bold">Sessões, equipes e comparação</p><p className="c-copy mt-2 max-w-2xl text-sm leading-6">Uma nova equipe pode partir de qualquer rodada recolhida sem alterar a sessão anterior. Depois, duas sínteses podem ser comparadas sem escolher automaticamente uma vencedora.</p><section className="c-tint c-border mt-5 grid gap-3 rounded-2xl border p-4"><p className="c-ink text-sm font-bold">Abrir sessão alternativa</p><div className="grid gap-3 sm:grid-cols-2"><Input value={arenaSessionLabel} onChange={event => setArenaSessionLabel(event.target.value)} placeholder="Nome da nova sessão" aria-label="Nome da nova sessão" /><Input value={arenaTeamLabel} onChange={event => setArenaTeamLabel(event.target.value)} placeholder="Nome da equipe" aria-label="Nome da equipe" /></div><select value="" onChange={event => { const branchFromRunId = event.target.value; if (branchFromRunId && arenaSessionLabel.trim() && arenaTeamLabel.trim()) createArenaSession.mutate({ caseId: selectedCaseId, label: arenaSessionLabel.trim(), teamLabel: arenaTeamLabel.trim(), branchFromRunId }); }} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2 text-sm"><option value="">Escolha uma rodada recolhida para criar a equipe</option>{aiRuns.data?.filter(run => run.roundState === "collapsed" && run.synthesis).map(run => <option key={run.id} value={run.id}>Rodada {run.roundNumber} — {run.title}</option>)}</select><p className="c-soft text-xs">A seleção cria uma sessão separada. O conteúdo precisará ser autorizado novamente na primeira rodada da nova equipe.</p></section>{arenaSessions.data?.length ? <div className="mt-5 grid gap-2">{arenaSessions.data.map(session => <p key={session.id} className="c-copy c-tint rounded-xl px-3 py-2 text-xs">{session.label} · {session.teamLabel}{session.branchFromRunId ? " · sessão derivada" : " · sessão original"}</p>)}</div> : null}<section className="c-tint c-border mt-5 grid gap-3 rounded-2xl border p-4"><p className="c-ink text-sm font-bold">Comparar sínteses</p><div className="grid gap-3 sm:grid-cols-2"><select value={comparisonLeftRunId} onChange={event => setComparisonLeftRunId(event.target.value)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2 text-sm"><option value="">Primeira síntese</option>{aiRuns.data?.filter(run => run.roundState === "collapsed" && run.synthesis).map(run => <option key={run.id} value={run.id}>Rodada {run.roundNumber} — {run.title}</option>)}</select><select value={comparisonRightRunId} onChange={event => setComparisonRightRunId(event.target.value)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2 text-sm"><option value="">Segunda síntese</option>{aiRuns.data?.filter(run => run.roundState === "collapsed" && run.synthesis).map(run => <option key={run.id} value={run.id}>Rodada {run.roundNumber} — {run.title}</option>)}</select></div><Button className="c-deep-button w-fit rounded-xl" disabled={!comparisonLeftRunId || !comparisonRightRunId || comparisonLeftRunId === comparisonRightRunId || compareAiSyntheses.isPending} onClick={() => compareAiSyntheses.mutate({ caseId: selectedCaseId, leftRunId: comparisonLeftRunId, rightRunId: comparisonRightRunId })}>{compareAiSyntheses.isPending ? "Comparando…" : "Comparar sínteses"}</Button>{aiComparisons.data?.slice(0, 3).map(comparison => <article key={comparison.id} className="c-border rounded-xl border p-4"><p className="c-ink text-xs font-bold">Comparação registrada</p><p className="c-ink mt-3 text-xs font-semibold">Pontos em comum</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.commonPoints}</p><p className="c-ink mt-3 text-xs font-semibold">Divergências</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.divergences}</p><p className="c-ink mt-3 text-xs font-semibold">Perguntas para o supervisor</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.supervisorQuestions}</p><p className="c-ink mt-3 text-xs font-semibold">Auxílio à decisão humana</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.recommendation}</p></article>)}</section></article>}

      {isOverview && (
        <div className="mt-8 grid gap-5 lg:grid-cols-[1.3fr_0.7fr]">
          <article className="concilium-card c-border rounded-3xl border p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div><p className="c-ink text-lg font-bold">Seus casos reservados</p><p className="c-copy mt-2 max-w-xl text-sm leading-6">{ownerName}, os casos abaixo pertencem exclusivamente à sua conta titular.</p></div>
              {createCaseForm}
            </div>
            {simulationMode ? <div className="mt-7 grid gap-3">{caseList.map(ownerCase => <button key={ownerCase.id} onClick={() => onSelectCase(ownerCase.id)} className={cn("c-border rounded-2xl border p-5 text-left transition-colors hover:[background:var(--concilium-tint)]", ownerCase.id === selectedCaseId && "c-tint")}><p className="c-ink font-bold">{ownerCase.title}</p><p className="c-copy mt-1 text-xs leading-5">{ownerCase.summary}</p><p className="c-accent-strong mt-3 text-[10px] font-bold uppercase tracking-[0.14em]">Somente demonstração</p></button>)}</div> : cases.isLoading ? <p className="c-copy mt-7 text-sm">Carregando seus casos…</p> : cases.error ? <div className="c-tint c-border mt-7 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Não foi possível consultar seus casos.</p><p className="c-copy mt-2 text-xs leading-5">A sessão não foi alterada. Verifique a conexão e tente novamente.</p><Button variant="outline" className="c-border c-ink mt-4" onClick={() => cases.refetch()}>Tentar novamente</Button></div> : caseList.length === 0 ? <div className="c-tint c-border mt-7 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Nenhum caso criado ainda.</p><p className="c-copy mt-2 text-xs leading-5">Não foram inseridos casos, documentos ou participantes fictícios. Crie o primeiro registro quando estiver pronto.</p></div> : <div className="mt-7 grid gap-3">{caseList.map(ownerCase => <button key={ownerCase.id} onClick={() => onSelectCase(ownerCase.id)} className={cn("c-border rounded-2xl border p-5 text-left transition-colors hover:[background:var(--concilium-tint)]", ownerCase.id === selectedCaseId && "c-tint")}><p className="c-ink font-bold">{ownerCase.title}</p><p className="c-copy mt-1 text-xs leading-5">{ownerCase.summary || "Sem contexto inicial registrado."}</p><p className="c-accent-strong mt-3 text-[10px] font-bold uppercase tracking-[0.14em]">{ownerCase.status === "draft" ? "Em preparação" : ownerCase.status}</p></button>)}</div>}
          </article>
          <article className="concilium-card c-border rounded-3xl border p-6"><ShieldCheck className="c-accent" size={21} /><h2 className="c-ink mt-6 text-sm font-bold">Sessão do titular</h2><p className="c-copy mt-2 text-xs leading-5">A área permanece vinculada à passkey e à sessão própria do Concilium, sem reutilizar a autenticação de outro projeto.</p></article>
        </div>
      )}

      {isOverview && selectedCaseId && !simulationMode && (
        <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8">
          {activeCase.isLoading ? <p className="c-copy text-sm">Carregando memorial do caso…</p> : activeCase.data ? <><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="c-ink text-lg font-bold">Memorial e patrimônio</p><p className="c-copy mt-2 max-w-2xl text-sm leading-6">Itens vinculados ao caso selecionado, com origem registrada e estado de revisão. A lista não representa uma linha do tempo; só datas confirmadas são exibidas como referência cronológica.</p></div><span className="c-tint c-accent-strong rounded-full px-3 py-2 text-[10px] font-bold uppercase tracking-[0.14em]">{activeCase.data.ownerCase.title}</span></div><div className="mt-6 grid gap-4 lg:grid-cols-2"><section className="c-tint c-border rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Memorial</p><div className="mt-4 grid gap-3">{activeCase.data.memorialEntries.length ? activeCase.data.memorialEntries.map(entry => <article key={entry.id} className="c-border rounded-xl border p-3"><p className="c-ink text-sm font-semibold">{entry.title}</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{entry.narrative}</p><p className="c-soft mt-3 text-[10px] uppercase tracking-[0.12em]">{entry.entryType} · {entry.reviewStatus === "verified" ? "verificado" : "em revisão"}</p><p className="c-soft mt-1 text-[10px]">{entry.chronologyStatus === "verified" && entry.referenceDate ? `Data de referência verificada: ${new Date(entry.referenceDate).toLocaleDateString("pt-BR")} · confiança ${entry.chronologyConfidence}.` : entry.chronologyStatus === "not_applicable" ? "Sem marco cronológico aplicável a este registro." : "Cronologia pendente de confirmação — a posição na conversa não foi usada como data."}</p><p className="c-soft mt-1 text-[10px]">Fonte: {entry.sourceReference}</p></article>) : <p className="c-copy text-xs leading-5">Nenhuma entrada de memorial registrada.</p>}</div></section><section className="c-tint c-border rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Patrimônio e referências</p><div className="mt-4 grid gap-3">{activeCase.data.assets.length ? activeCase.data.assets.map(asset => <article key={asset.id} className="c-border rounded-xl border p-3"><p className="c-ink text-sm font-semibold">{asset.title}</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{asset.details}</p><p className="c-soft mt-3 text-[10px] uppercase tracking-[0.12em]">{asset.assetType} · {asset.reviewStatus === "verified" ? "verificado" : "em revisão"}</p><p className="c-soft mt-1 text-[10px]">Fonte: {asset.sourceReference}</p></article>) : <p className="c-copy text-xs leading-5">Nenhuma referência patrimonial registrada.</p>}</div></section></div></> : <p className="c-copy text-sm">Não foi possível abrir os registros do caso selecionado.</p>}
        </article>
      )}

      {isStrategies && (
        <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8">
          {simulationMode ? <div><p className="c-ink text-lg font-bold">Estratégias não são criadas na simulação.</p><p className="c-copy mt-3 text-sm leading-7">O caso demonstrativo serve apenas para testar a navegação. Nenhuma estratégia, nota ou outro registro será enviado ao servidor.</p></div> : !selectedCaseId ? <><p className="c-ink text-lg font-bold">Selecione ou crie um caso primeiro.</p><p className="c-copy mt-3 text-sm leading-7">As estratégias são sempre vinculadas a um caso titular, para evitar misturar contextos jurídicos sensíveis.</p></> : <><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="c-ink text-lg font-bold">Estratégias do caso</p><p className="c-copy mt-2 text-sm">{activeCase.data?.ownerCase.title ?? "Carregando caso…"}</p></div></div><div className="c-tint c-border mt-6 grid gap-3 rounded-2xl border p-4"><Input value={strategyTitle} onChange={event => setStrategyTitle(event.target.value)} placeholder="Título da estratégia" aria-label="Título da estratégia" maxLength={200} /><Textarea value={strategyNotes} onChange={event => setStrategyNotes(event.target.value)} placeholder="Notas privadas e não automatizadas" aria-label="Notas da estratégia" maxLength={10000} /><Button className="c-deep-button w-fit rounded-xl" disabled={strategyTitle.trim().length < 3 || createStrategy.isPending} onClick={() => selectedCaseId && createStrategy.mutate({ caseId: selectedCaseId, title: strategyTitle.trim(), notes: strategyNotes.trim() || undefined })}>{createStrategy.isPending ? "Salvando…" : "Adicionar estratégia"}</Button></div><div className="mt-5 grid gap-3">{activeCase.data?.strategies.length ? activeCase.data.strategies.map(strategy => <article key={strategy.id} className="c-border rounded-2xl border p-4"><p className="c-ink text-sm font-bold">{strategy.title}</p>{strategy.notes && <p className="c-copy mt-2 whitespace-pre-wrap text-xs leading-5">{strategy.notes}</p>}<div className="mt-4 flex flex-wrap gap-2"><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={triageArgument.isPending || !strategyAiModels.data?.length} onClick={() => startStrategyTriage(strategy)}>{triageArgument.isPending ? "Pesquisando e triando…" : "Pesquisar e triar"}</Button></div></article>) : <p className="c-copy text-sm">Nenhuma estratégia registrada neste caso.</p>}</div></>}
        </article>
      )}

      {isStrategies && selectedCaseId && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.16em]">Triagem jurídica das estratégias</p><h2 className="c-ink mt-2 text-lg font-bold">Referências e pontos cegos ligados ao Estrategista</h2><p className="c-copy mt-2 max-w-2xl text-sm leading-6">A estratégia pode começar aqui sem passar obrigatoriamente pelo Bibliotecário. Cada avaliação preserva a formulação original, separa possibilidade jurídica de risco moral e pode retornar à linha antes de seguir para a Arena.</p>{argumentAssessments.isLoading ? <p className="c-copy mt-5 text-sm">Carregando triagens…</p> : argumentAssessments.data?.length ? <div className="mt-5 grid gap-3">{argumentAssessments.data.slice(0, 8).map(assessment => <article key={assessment.id} className="c-tint c-border rounded-2xl border p-4"><div className="flex flex-wrap items-center justify-between gap-3"><p className="c-ink text-sm font-bold">{assessment.legalStatus.replaceAll("_", " ")}</p><span className="c-soft text-[10px] uppercase tracking-[0.12em]">{assessment.reviewStatus.replaceAll("_", " ")}</span></div><p className="c-copy mt-3 whitespace-pre-wrap text-xs leading-5">{assessment.formulation}</p><p className="c-soft mt-3 text-[10px]">Confiança: {assessment.confidence} · evidência: {assessment.evidenceStrength} · operação: {assessment.operationalStatus.replaceAll("_", " ")}</p><div className="mt-4 flex flex-wrap gap-2"><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" onClick={() => prepareAssessmentForExploration(assessment)}>Usar no Laboratório</Button><Button size="sm" className="c-deep-button rounded-xl" onClick={() => window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&argumentAssessment=${assessment.id}`, "_blank", "noopener,noreferrer")}>Levar à Arena</Button></div></article>)}</div> : <p className="c-copy mt-5 text-sm">Nenhuma estratégia foi enviada à triagem ainda.</p>}</article>}

      {isStrategies && selectedCaseId && argumentAssessments.data && argumentAssessments.data.length >= 2 && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.16em]">Comparação de versões</p><h2 className="c-ink mt-2 text-lg font-bold">Original, enriquecida ou refinada?</h2><p className="c-copy mt-2 text-sm leading-6">Compare duas avaliações sem escolher automaticamente uma vencedora. A comparação mostra mudanças, fontes novas, riscos e perguntas para a decisão humana.</p><div className="mt-5 grid gap-3 sm:grid-cols-2"><select value={argumentCompareLeftId} onChange={event => setArgumentCompareLeftId(event.target.value)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2"><option value="">Versão inicial</option>{argumentAssessments.data.map(item => <option key={item.id} value={item.id}>{item.legalStatus.replaceAll("_", " ")} · {item.id.slice(0, 8)}</option>)}</select><select value={argumentCompareRightId} onChange={event => setArgumentCompareRightId(event.target.value)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2"><option value="">Versão refinada</option>{argumentAssessments.data.map(item => <option key={item.id} value={item.id}>{item.legalStatus.replaceAll("_", " ")} · {item.id.slice(0, 8)}</option>)}</select></div><Button className="c-deep-button mt-4 rounded-xl" disabled={!argumentCompareLeftId || !argumentCompareRightId || argumentCompareLeftId === argumentCompareRightId || compareArgumentAssessments.isPending || !strategyAiModels.data?.[0]?.id} onClick={() => selectedCaseId && strategyAiModels.data?.[0]?.id && compareArgumentAssessments.mutate({ caseId: selectedCaseId, leftAssessmentId: argumentCompareLeftId, rightAssessmentId: argumentCompareRightId, modelId: strategyAiModels.data?.[0]?.id ?? "", consentConfirmed: true })}>{compareArgumentAssessments.isPending ? "Comparando…" : "Comparar versões"}</Button>{argumentComparisons.data?.slice(0, 3).map(comparison => <article key={comparison.id} className="c-tint c-border mt-5 rounded-2xl border p-4"><p className="c-ink text-xs font-bold">Comparação registrada</p><p className="c-ink mt-3 text-xs font-semibold">Pontos comuns</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.commonPoints}</p><p className="c-ink mt-3 text-xs font-semibold">Diferenças</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.differences}</p><p className="c-ink mt-3 text-xs font-semibold">Novas evidências</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.newEvidence}</p><p className="c-ink mt-3 text-xs font-semibold">Perguntas</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{comparison.questions}</p><p className="c-soft mt-4 text-[10px] uppercase tracking-[0.12em]">Decisão humana: {comparison.humanDecision}</p><div className="mt-3 flex flex-wrap gap-2"><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={decideArgumentComparison.isPending} onClick={() => selectedCaseId && decideArgumentComparison.mutate({ caseId: selectedCaseId, comparisonId: comparison.id, humanDecision: "retain_left" })}>Manter inicial</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={decideArgumentComparison.isPending} onClick={() => selectedCaseId && decideArgumentComparison.mutate({ caseId: selectedCaseId, comparisonId: comparison.id, humanDecision: "retain_right" })}>Usar refinada</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={decideArgumentComparison.isPending} onClick={() => selectedCaseId && decideArgumentComparison.mutate({ caseId: selectedCaseId, comparisonId: comparison.id, humanDecision: "merge" })}>Mesclar com revisão</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={decideArgumentComparison.isPending} onClick={() => selectedCaseId && decideArgumentComparison.mutate({ caseId: selectedCaseId, comparisonId: comparison.id, humanDecision: "review" })}>Manter em revisão</Button></div><div className="c-border mt-4 flex flex-wrap items-center gap-2 rounded-xl border p-3"><label className="c-copy text-xs" htmlFor={`destination-${comparison.id}`}>Próximo destino</label><select id={`destination-${comparison.id}`} value={comparisonDestinations[comparison.id] ?? ""} onChange={event => setComparisonDestinations(current => ({ ...current, [comparison.id]: event.target.value as "strategy" | "librarian" | "arena" | "compendium" | "archive" }))} className="c-border c-ink rounded-lg border bg-transparent px-2 py-1 text-xs"><option value="">Escolher</option><option value="strategy">Estrategista</option><option value="librarian">Bibliotecário</option><option value="arena">Arena</option><option value="compendium">Compêndio</option><option value="archive">Arquivo</option></select><Button size="sm" className="c-deep-button rounded-xl" disabled={!comparisonDestinations[comparison.id] || decideArgumentComparison.isPending || ((comparisonDestinations[comparison.id] === "strategy" || comparisonDestinations[comparison.id] === "arena") && comparison.humanDecision === "pending")} onClick={() => selectedCaseId && comparisonDestinations[comparison.id] && decideArgumentComparison.mutate({ caseId: selectedCaseId, comparisonId: comparison.id, humanDecision: comparison.humanDecision, nextDestination: comparisonDestinations[comparison.id] })}>Registrar encaminhamento</Button>{comparison.nextDestination && <span className="c-soft text-[10px]">Registrado: {comparison.nextDestination}</span>}</div></article>)}</article>}

      {isStrategies && selectedCaseId && activeExplorationRunId && <StrategyBranchInbox caseId={selectedCaseId} runId={activeExplorationRunId} />}

      {isStrategies && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.16em]">Laboratório de Alternativas</p><h2 className="c-ink mt-2 text-lg font-bold">Explore soluções antes de escolher o que será estressado na Arena</h2><p className="c-copy mt-2 max-w-2xl text-sm leading-6">O Estrategista central recebe o contexto integral autorizado, organiza os eixos e distribui uma projeção protegida às IAs independentes. Elas não debatem entre si nem validam uma solução: geram possibilidades complementares ou conflitantes, enquanto o Estrategista acompanha perguntas, encerra linhas e atualiza a pauta.</p>{simulationMode ? <p className="c-tint c-copy mt-5 rounded-xl px-4 py-3 text-xs">A simulação não consulta modelos nem grava alternativas.</p> : !selectedCaseId ? <p className="c-copy mt-5 text-sm">Selecione um caso para explorar alternativas.</p> : <><section className="c-tint c-border mt-6 grid gap-4 rounded-2xl border p-5">{exploreSourceAssessmentId && <p className="c-copy rounded-xl border border-[var(--concilium-card-border)] px-3 py-2 text-xs">Esta exploração usará o pacote de evidências da avaliação selecionada, sem compartilhar as respostas entre as IAs.</p>}<Input value={exploreTitle} onChange={event => setExploreTitle(event.target.value)} placeholder="Título da exploração" aria-label="Título da exploração" maxLength={220} /><Textarea value={exploreObjective} onChange={event => setExploreObjective(event.target.value)} placeholder="Objetivo estratégico — ex.: ganhar tempo para recomprar a parte do imóvel sem venda imediata" aria-label="Objetivo da exploração" maxLength={4000} /><Textarea value={exploreSource} onChange={event => setExploreSource(event.target.value)} placeholder="Contexto autorizado: descreva a situação, restrições, interesses e alternativas já consideradas" aria-label="Contexto autorizado da exploração" maxLength={12000} className="min-h-36" /><div><p className="c-ink text-xs font-semibold">IAs independentes — escolha de 2 a 5</p><div className="mt-3 grid gap-2 sm:grid-cols-2">{strategyAiModels.data?.map(model => <label key={model.id} className={cn("c-border flex items-center gap-3 rounded-xl border p-3 text-xs", exploreModels.includes(model.id) && "c-tint")}><input type="checkbox" checked={exploreModels.includes(model.id)} onChange={() => toggleExploreModel(model.id)} disabled={!exploreModels.includes(model.id) && exploreModels.length >= 5} /><span className="c-ink font-medium">{model.id}</span></label>)}</div></div><label className="c-border flex items-start gap-3 rounded-xl border p-4 text-xs leading-5"><input className="mt-0.5" type="checkbox" checked={exploreConsent} onChange={event => setExploreConsent(event.target.checked)} /><span className="c-copy">Autorizo a geração divergente do contexto indicado por cada IA selecionada. Entendo que as alternativas são hipóteses de trabalho e ainda não foram testadas, validadas ou submetidas à Arena.</span></label><Button className="c-deep-button w-fit rounded-xl" disabled={exploreTitle.trim().length < 3 || exploreObjective.trim().length < 12 || exploreSource.trim().length < 20 || exploreModels.length < 2 || !exploreConsent || exploreStrategies.isPending} onClick={submitStrategyExploration}>{exploreStrategies.isPending ? "Gerando alternativas…" : "Explorar com múltiplas IAs"}</Button>{exploreStrategies.error && <p role="alert" className="c-accent-strong text-xs">Não foi possível gerar a exploração: {exploreStrategies.error.message}</p>}</section><section className="mt-7"><p className="c-ink text-sm font-bold">Explorações anteriores</p>{strategyExplorations.isLoading ? <p className="c-copy mt-3 text-sm">Carregando explorações…</p> : strategyExplorations.data?.length ? <div className="mt-4 grid gap-4">{strategyExplorations.data.map(run => <details key={run.id} className="c-tint c-border rounded-2xl border p-5"><summary className="c-ink cursor-pointer list-none text-sm font-bold">{run.title}<span className="c-soft ml-2 text-[10px] uppercase tracking-[0.14em]">{run.ideas.length} alternativas</span></summary><p className="c-copy mt-3 text-xs leading-5">{run.objective}</p>{run.strategistBrief && <details className="c-border mt-4 rounded-xl border p-3"><summary className="c-ink cursor-pointer text-xs font-semibold">Pauta do Estrategista central</summary><p className="c-copy mt-2 whitespace-pre-wrap text-xs leading-5">{run.strategistBrief}</p></details>}<Button size="sm" variant="outline" className="c-border c-ink mt-4 rounded-xl" onClick={() => setActiveExplorationRunId(run.id)}>{activeExplorationRunId === run.id ? "Linhas abertas abaixo" : "Acompanhar perguntas"}</Button><div className="mt-4 grid gap-3">{run.ideas.map(idea => <article key={idea.id} className="c-border rounded-xl border p-4"><div className="flex flex-wrap items-start justify-between gap-3"><p className="c-ink text-xs font-bold">{idea.perspective} · {idea.modelId}</p><Button size="sm" className="c-deep-button rounded-xl" disabled={idea.status === "selected_for_arena" || selectStrategyIdeaForArena.isPending} onClick={() => selectedCaseId && selectStrategyIdeaForArena.mutate({ caseId: selectedCaseId, ideaId: idea.id })}>{idea.status === "selected_for_arena" ? "Selecionada para Arena" : "Levar à Arena"}</Button></div><p className="c-copy mt-3 whitespace-pre-wrap text-xs leading-6">{idea.ideaBody}</p>{idea.risks && <p className="c-accent-strong mt-3 text-xs leading-5"><strong>Riscos/pendências:</strong> {idea.risks}</p>}</article>)}</div>{run.syntheses?.length ? <section className="c-border mt-5 rounded-xl border p-4"><p className="c-ink text-xs font-bold">Sínteses progressivas</p>{run.syntheses.slice().reverse().map(synthesis => <div key={synthesis.id} className="mt-3"><p className="c-soft text-[10px] uppercase tracking-[0.12em]">{synthesis.stage === "final" ? "síntese final" : "linha consolidada"}</p><p className="c-copy mt-1 whitespace-pre-wrap text-xs leading-5">{synthesis.content}</p>{synthesis.stage === "final" && <Button size="sm" className="c-deep-button mt-3 rounded-xl" disabled={selectStrategySynthesisForArena.isPending} onClick={() => selectedCaseId && selectStrategySynthesisForArena.mutate({ caseId: selectedCaseId, synthesisId: synthesis.id, consentConfirmed: true })}>{selectStrategySynthesisForArena.isPending ? "Preparando Arena…" : "Levar síntese final à Arena"}</Button>}</div>)}</section> : null}</details>)}</div> : <p className="c-copy mt-3 text-sm">Nenhuma exploração registrada neste caso.</p>}{activeExplorationRunId && <section className="c-tint c-border mt-6 rounded-2xl border p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="c-ink text-sm font-bold">Linhas de raciocínio em acompanhamento</p><p className="c-copy mt-1 text-xs leading-5">Cada IA permanece em sua própria janela lógica. Perguntas semelhantes podem ser agrupadas na coleta, mas a resposta é devolvida somente às linhas correspondentes.</p></div><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" onClick={() => setActiveExplorationRunId(null)}>Fechar acompanhamento</Button></div>{explorationThreads.isLoading ? <p className="c-copy mt-4 text-sm">Carregando linhas…</p> : explorationThreads.data?.length ? <div className="mt-4 grid gap-3">{explorationThreads.data.map(thread => <article key={thread.id} className="c-border rounded-xl border p-4"><div className="flex flex-wrap items-center justify-between gap-2"><p className="c-ink text-xs font-bold">{thread.perspective} · {thread.modelId}</p><span className="c-soft text-[10px] uppercase tracking-[0.12em]">{thread.state.replaceAll("_", " ")}</span></div>{thread.messages.slice(0, 4).map(message => <p key={message.id} className="c-copy mt-3 text-xs leading-5"><strong className="c-ink">{message.authorType === "owner" ? "Você" : "IA"}:</strong> {message.body}</p>)}{thread.questions.filter(question => question.status === "pending").map(question => <div key={question.id} className="c-tint mt-4 rounded-xl p-3"><p className="c-ink text-xs font-semibold">Pergunta desta linha</p><p className="c-copy mt-2 text-xs leading-5">{question.questionBody}</p><Textarea value={explorationAnswer} onChange={event => setExplorationAnswer(event.target.value)} placeholder="Sua resposta para esta pergunta" aria-label={`Resposta para ${thread.perspective}`} className="mt-3 min-h-20" /><Button size="sm" className="c-deep-button mt-3 rounded-xl" disabled={!explorationAnswer.trim() || answerStrategyQuestions.isPending} onClick={() => selectedCaseId && answerStrategyQuestions.mutate({ caseId: selectedCaseId, runId: thread.runId, questionIds: [question.id], semanticGroupId: question.semanticGroupId ?? thread.id, body: explorationAnswer.trim() })}>Responder somente a esta linha</Button></div>)}{thread.state === "ceased" && <p className="c-soft mt-4 text-xs">Esta linha encerrou a exploração e não fará novas perguntas.</p>}</article>)}</div> : <p className="c-copy mt-4 text-sm">Nenhuma linha interativa registrada.</p>}</section>}</section></>}</article>}

      {isNegotiation && <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8">
        {simulationMode ? <p className="c-copy text-sm">A simulação não cria cenários nem documentos.</p> : !selectedCaseId ? <><p className="c-ink text-lg font-bold">Selecione um caso para iniciar a negociação.</p><p className="c-copy mt-2 text-sm leading-6">Propostas são vinculadas ao caso e permanecem como rascunhos até uma ação expressa do titular.</p></> : activeCase.isLoading ? <p className="c-copy text-sm">Carregando negociação…</p> : <>
          <p className="c-ink text-lg font-bold">Mesa de negociação</p>
          <p className="c-copy mt-2 max-w-2xl text-sm leading-6">A primeira proposta será criada como documento privado, vinculada a um cenário liberado e sem qualquer envio automático.</p>
          <section className="c-tint c-border mt-6 grid gap-4 rounded-2xl border p-5" aria-label="Criar proposta privada">
            <p className="c-ink text-sm font-bold">Nova proposta privada</p>
            <select value={proposalStrategyId} onChange={event => setProposalStrategyId(event.target.value)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2 text-sm" aria-label="Cenário da proposta">
              <option value="">Escolha o cenário liberado</option>
              {activeCase.data?.strategies.filter(strategy => strategy.releaseState === "liberada").map(strategy => <option key={strategy.id} value={strategy.id}>{strategy.title}</option>)}
            </select>
            <Input value={proposalTitle} onChange={event => setProposalTitle(event.target.value)} placeholder="Título da proposta" aria-label="Título da proposta" maxLength={220} />
            <Textarea value={proposalBody} onChange={event => setProposalBody(event.target.value)} placeholder="Texto da proposta para revisão" aria-label="Texto da proposta" maxLength={40000} className="min-h-44" />
            <Button className="c-deep-button w-fit rounded-xl" disabled={!proposalStrategyId || proposalTitle.trim().length < 3 || proposalBody.trim().length < 10 || createProposal.isPending} onClick={() => createProposal.mutate({ caseId: selectedCaseId, strategyId: proposalStrategyId, title: proposalTitle.trim(), body: proposalBody.trim() })}>{createProposal.isPending ? "Salvando…" : "Salvar como rascunho"}</Button>
            {createProposal.error && <p role="alert" className="c-accent-strong text-xs">Não foi possível salvar a proposta: {createProposal.error.message}</p>}
          </section>
          <section className="mt-7"><p className="c-ink text-sm font-bold">Documentos do caso</p><div className="mt-4 grid gap-3">{activeCase.data?.documents.length ? activeCase.data.documents.map(document => <article key={document.id} className="c-tint c-border rounded-2xl border p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="c-ink text-sm font-bold">{document.title}</p><p className="c-soft mt-1 text-[10px] uppercase tracking-[0.12em]">{document.documentType} · {document.currentStatus}</p></div>{document.currentStatus === "rascunho" && <Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={sendProposal.isPending} onClick={() => sendProposal.mutate({ documentId: document.id })}>Enviar</Button>}</div><p className="c-copy mt-3 whitespace-pre-wrap text-xs leading-6">{document.body}</p></article>) : <div className="c-tint c-border rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Nenhuma proposta criada.</p><p className="c-copy mt-2 text-xs leading-5">O primeiro documento poderá ser criado acima como rascunho privado.</p></div>}</div></section>
        </>}
      </article>}

      {isLibrary && <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8">{simulationMode ? <p className="c-copy text-sm">A simulação não acessa a biblioteca.</p> : !selectedCaseId ? <><p className="c-ink text-lg font-bold">Selecione um caso para abrir a biblioteca.</p><p className="c-copy mt-2 text-sm leading-6">A biblioteca mantém documentos por caso, sem disponibilizar dados de outros contextos.</p></> : activeCase.isLoading ? <p className="c-copy text-sm">Carregando referências documentais…</p> : <><p className="c-ink text-lg font-bold">Biblioteca do caso</p><p className="c-copy mt-2 max-w-2xl text-sm leading-6">Esta etapa registra metadados e a origem dos documentos autorizados. Cada abertura confirma a sessão titular e o vínculo com este caso; arquivos não são enviados ou compartilhados automaticamente.</p>{documentAccessError && <p role="alert" className="c-tint c-accent-strong mt-4 rounded-xl px-4 py-3 text-xs">{documentAccessError}</p>}<div className="mt-6 grid gap-3">{activeCase.data?.documents.length ? activeCase.data.documents.map(document => <article key={document.id} className="c-tint c-border rounded-2xl border p-5"><p className="c-ink text-sm font-bold">{document.title}</p><p className="c-accent-strong mt-2 text-[10px] font-bold uppercase tracking-[0.14em]">{document.documentType}</p><p className="c-soft mt-3 text-[10px] uppercase tracking-[0.12em]">{document.reviewStatus === "verified" ? "verificado" : "em revisão"}</p><p className="c-copy mt-2 text-xs leading-5">Origem: {document.sourceReference}</p>{document.hasStoredFile ? <div className="mt-4"><Button variant="outline" className="c-border c-ink rounded-xl" disabled={Boolean(openingDocumentId)} onClick={() => openPrivateDocument(document.id)}><FileLock2 size={15} />{openingDocumentId === document.id ? "Abrindo anexo…" : "Abrir anexo privado"}</Button><p className="c-soft mt-2 text-[10px] leading-5">O link temporário é liberado somente após validar sua sessão e este caso.</p></div> : <p className="c-soft mt-3 text-xs">Arquivo ainda não armazenado na biblioteca.</p>}</article>) : <div className="c-tint c-border rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Nenhuma referência documental registrada.</p><p className="c-copy mt-2 text-xs leading-5">Documentos serão vinculados somente após armazenamento protegido e revisão.</p></div>}</div></>}</article>}

      {isLibrary && !simulationMode && selectedCaseId && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8">
        <p className="c-ink text-lg font-bold">Anexos protegidos</p>
        <p className="c-copy mt-2 max-w-2xl text-sm leading-6">Os arquivos são enviados ao armazenamento privado do caso. O sistema guarda metadados e hash para conferência; o conteúdo não é publicado automaticamente.</p>
        <section className="c-tint c-border mt-6 grid gap-4 rounded-2xl border p-5" aria-label="Adicionar anexo protegido">
          <Input value={attachmentTitle} onChange={event => setAttachmentTitle(event.target.value)} placeholder="Nome ou descrição do documento" aria-label="Nome do anexo" maxLength={220} />
          <Input type="file" onChange={event => setAttachmentFile(event.target.files?.[0] ?? null)} aria-label="Selecionar arquivo" />
          <p className="c-soft text-xs">Limite atual: 20 MB por arquivo. Para documentos reais, prefira um arquivo já anonimizado ou um pacote criptografado.</p>
          <Button className="c-deep-button w-fit rounded-xl" disabled={!attachmentTitle.trim() || !attachmentFile || uploadAttachment.isPending} onClick={() => void submitAttachment()}>{uploadAttachment.isPending ? "Enviando…" : "Armazenar anexo privado"}</Button>
          {uploadAttachment.error && <p role="alert" className="c-accent-strong text-xs">Não foi possível armazenar o anexo: {uploadAttachment.error.message}</p>}
        </section>
        <section className="mt-7"><p className="c-ink text-sm font-bold">Arquivos armazenados</p>{attachments.isLoading ? <p className="c-copy mt-3 text-sm">Carregando anexos…</p> : attachments.error ? <p role="alert" className="c-copy mt-3 text-sm">Não foi possível consultar os anexos deste caso.</p> : attachments.data?.length ? <div className="mt-4 grid gap-3">{attachments.data.map(attachment => <article key={attachment.id} className="c-tint c-border flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4"><div><p className="c-ink text-sm font-bold">{attachment.title}</p><p className="c-soft mt-1 text-[10px] uppercase tracking-[0.12em]">{attachment.mimeType} · {Math.ceil(attachment.byteSize / 1024)} KB</p><p className="c-copy mt-2 text-xs">Hash: {attachment.contentHash.slice(0, 16)}…</p></div><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" onClick={() => void openPrivateAttachment(attachment.id)}>{openAttachment.isPending ? "Abrindo…" : "Abrir anexo"}</Button></article>)}</div> : <p className="c-copy mt-3 text-sm">Nenhum anexo privado armazenado.</p>}</section>
      </article>}

      {isLibrary && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8">
        <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.16em]">Bibliotecário jurídico</p>
        <h2 className="c-ink mt-2 text-lg font-bold">Consulte o acervo sem carregar o banco inteiro</h2>
        <p className="c-copy mt-2 max-w-2xl text-sm leading-6">Descreva a situação ou o assunto que deseja pesquisar. O Concilium encaminha apenas a consulta ao Knowledge Service e devolve fontes, versões e assuntos relacionados.</p>
        <div className="c-tint c-border mt-6 grid gap-3 rounded-2xl border p-5">
          <Textarea value={knowledgeQuery} onChange={event => setKnowledgeQuery(event.target.value)} placeholder="Ex.: critérios para cláusula de convivência na coabitação pós-separação" aria-label="Pergunta para o bibliotecário jurídico" maxLength={2000} className="min-h-24" />
          <div className="grid gap-3 sm:grid-cols-2 sm:items-end"><label className="grid gap-2 text-xs"><span className="c-ink font-semibold">Modo do Bibliotecário</span><select value={knowledgeResearchMode} onChange={event => setKnowledgeResearchMode(event.target.value as LibrarianResearchMode)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2"><option value="contextual_research">Pesquisa contextual ampla</option><option value="sources">Fontes e precedentes</option><option value="clause_models">Cláusulas e modelos de minuta</option><option value="strategy_handoff">Pergunta para encaminhar ao Estrategista</option></select></label><label className="grid gap-2 text-xs"><span className="c-ink font-semibold">Área do direito</span><select value={knowledgeArea} onChange={event => setKnowledgeArea(event.target.value as KnowledgeArea)} className="c-border c-ink rounded-xl border bg-transparent px-3 py-2"><option value="geral">Todas as áreas</option>{knowledgeAreas.filter(area => area !== "geral").map(area => <option key={area} value={area}>{area}</option>)}</select></label><label className="c-ink flex items-center gap-2 text-xs"><input type="checkbox" checked={knowledgeIncludeRelated} onChange={event => setKnowledgeIncludeRelated(event.target.checked)} /> Trazer relacionados</label><Button className="c-deep-button rounded-xl" disabled={knowledgeQuery.trim().length < 3 || knowledgeSearch.isPending} onClick={submitKnowledgeSearch}>{knowledgeSearch.isPending ? "Pesquisando…" : "Consultar biblioteca"}</Button></div>
          <p className="c-soft text-xs leading-5">Por padrão, nenhum documento ou identificador do caso é enviado. O contexto do caso só entrará mediante autorização específica e já minimizado.</p>
        </div>
        {knowledgeSearch.error && <p role="alert" className="c-accent-strong mt-4 text-xs">{knowledgeSearch.error.message}</p>}
        {knowledgeSearch.data?.notice && <p role="status" className="c-tint c-copy mt-4 rounded-xl px-4 py-3 text-xs">{knowledgeSearch.data.notice}</p>}{knowledgeSearch.data?.routing && <div className="c-border mt-4 rounded-xl border px-4 py-3 text-xs"><p className="c-ink font-semibold">Roteamento: {knowledgeSearch.data.routing.label}</p><p className="c-copy mt-1 leading-5">{knowledgeSearch.data.routing.reason}</p><p className="c-soft mt-2">Agentes ativados: {knowledgeSearch.data.routing.activeRoles.join(" · ")}</p>{knowledgeSearch.data.routing.handoffRecommended && <><p className="c-accent-strong mt-2 font-semibold">A busca pode acompanhar uma nova exploração do Estrategista, mas o Bibliotecário não escolhe a estratégia nem recebe o caso protegido por padrão.</p><Button size="sm" variant="outline" className="c-border c-ink mt-3 rounded-xl" onClick={handoffKnowledgeQuestionToStrategy}>{knowledgeSearch.data.routing.handoffTarget === "alternatives_lab" ? "Levar ao Laboratório de Alternativas" : "Levar pergunta ao Estrategista"}</Button></>}</div>}{knowledgeSearch.data?.packet && <details className="c-tint c-border mt-4 rounded-xl border p-4"><summary className="c-ink cursor-pointer text-xs font-bold">Pacote neutro de triagem ({knowledgeSearch.data.packet.items.length} itens)</summary><p className="c-copy mt-3 text-xs leading-5">{knowledgeSearch.data.packet.neutralSummary}</p>{knowledgeSearch.data.packet.items.slice(0, 12).map(item => <div key={item.resultId} className="c-border mt-3 rounded-lg border p-3"><p className="c-ink text-xs font-semibold">{item.materialType.replaceAll("_", " ")} · {item.treatment.replaceAll("_", " ")}</p><p className="c-copy mt-1 text-xs leading-5">{item.limitation}</p><p className="c-soft mt-2 text-xs leading-5">Pergunta para a próxima etapa: {item.handoffQuestion}</p></div>)}</details>}
        {knowledgeResults.length > 0 && <div className="mt-6 grid gap-3">{knowledgeResults.map(result => <article key={result.id} className="c-tint c-border rounded-2xl border p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="c-ink text-sm font-bold">{result.title}</p><p className="c-soft mt-1 text-[10px] uppercase tracking-[0.12em]">{result.area} · relevância {Math.round(result.relevance * 100)}%</p></div><span className="c-copy text-xs">{result.country} · {result.jurisdiction}</span></div><p className="c-copy mt-3 text-sm leading-6">{result.summary}</p><p className="c-soft mt-3 text-xs">Fonte: {result.sourceTitle} · versão {result.sourceVersion}{result.effectiveDate ? ` · vigência/referência ${result.effectiveDate}` : ""} · autoridade {result.authorityLevel}</p><p className={cn("mt-2 text-xs font-bold", result.validityState === "vigente" ? "c-success-ink" : "c-accent-strong")}>Status: {result.validityState.replaceAll("_", " ")}{result.validityCheckedAt ? ` · verificado em ${result.validityCheckedAt}` : ""}{result.supersededBy ? ` · substituído por ${result.supersededBy}` : ""}</p>{result.citations.length > 0 && <div className="c-border mt-4 border-t pt-3">{result.citations.map(citation => <p key={`${citation.label}-${citation.locator}`} className="c-copy mt-2 text-xs leading-5"><strong className="c-ink">{citation.label}</strong> · {citation.locator}{citation.verified ? " · citação verificada" : " · verificação pendente"}{citation.quote ? ` — “${citation.quote}”` : ""}</p>)}</div>}{result.related.length > 0 && <p className="c-copy mt-4 text-xs leading-5"><strong className="c-ink">Relacionados:</strong> {result.related.map(item => `${item.title} (${item.reason})`).join(" · ")}</p>}{selectedCaseId && <div className="mt-5 flex flex-wrap gap-2"><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={saveKnowledgeReference.isPending} onClick={() => void saveKnowledgeResult(result, "reference")}>Salvar referência no caso</Button><Button size="sm" variant="outline" className="c-border c-ink rounded-xl" disabled={saveKnowledgeClause.isPending} onClick={() => void saveKnowledgeResult(result, "clause")}>Adicionar ao compêndio</Button><Button size="sm" className="c-deep-button rounded-xl" disabled={saveKnowledgeReference.isPending || prepareKnowledgeArena.isPending} onClick={() => void saveKnowledgeResult(result, "arena")}>Refinar na Arena</Button></div>}</article>)}</div>}
      </article>}

      {isLibrary && selectedCaseId && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-ink text-lg font-bold">Referências e compêndio do caso</p><p className="c-copy mt-2 text-sm leading-6">O caso guarda apenas o snapshot da referência e o rascunho necessário para trabalho. O acervo original continua no Knowledge Service.</p>{knowledgeReferences.data?.length ? <div className="mt-5 grid gap-3">{knowledgeReferences.data.map(reference => <article key={reference.id} className="c-tint c-border rounded-2xl border p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="c-ink text-sm font-bold">{reference.title}</p><p className="c-soft mt-1 text-[10px] uppercase tracking-[0.12em]">{reference.actionType === "clause_compendium" ? "compêndio de cláusulas" : "referência"} · {reference.refinementStatus.replaceAll("_", " ")}</p></div><span className="c-copy text-xs">{reference.validityState.replaceAll("_", " ")}</span></div><p className="c-copy mt-2 text-xs leading-5">Fonte: {reference.sourceTitle} · {reference.sourceVersion} · {reference.jurisdiction}</p>{reference.clauseDraft && <p className="c-copy mt-3 whitespace-pre-wrap text-xs leading-5">{reference.clauseDraft}</p>}<Button size="sm" className="c-deep-button mt-4 rounded-xl" onClick={() => { window.open(`/espaco/comite-ia?caseId=${selectedCaseId}&knowledgeReference=${reference.id}`, "_blank", "noopener,noreferrer"); }}>Abrir para refinamento na Arena</Button></article>)}</div> : <p className="c-copy mt-4 text-sm">Nenhuma referência foi vinculada a este caso ainda.</p>}</article>}

      {isLibrary && selectedCaseId && activeCase.data?.documents && <DocumentCatalogReview caseId={selectedCaseId} documents={activeCase.data.documents} />}
      {isLibrary && selectedCaseId && activeCase.data?.documents && <DocumentVersionHistory caseId={selectedCaseId} documents={activeCase.data.documents} />}

      {isLibrary && selectedCaseId && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><p className="c-ink text-lg font-bold">Trabalho derivado da Arena</p><p className="c-copy mt-2 text-sm leading-6">Sínteses homologadas podem deixar tarefas no Bibliotecário e rascunhos no Compêndio. Nenhum desses itens é uma cláusula final ou um parecer.</p><section className="mt-5"><p className="c-ink text-sm font-bold">Solicitações para o Bibliotecário</p>{researchRequests.isLoading ? <p className="c-copy mt-3 text-sm">Carregando solicitações…</p> : researchRequests.data?.length ? <div className="mt-3 grid gap-3">{researchRequests.data.map(request => <article key={request.id} className="c-tint c-border rounded-2xl border p-4"><div className="flex flex-wrap items-center justify-between gap-2"><p className="c-copy whitespace-pre-wrap text-xs leading-5">{request.query}</p><span className="c-soft text-[10px] uppercase tracking-[0.12em]">{request.status === "answered" ? "retornou à estratégia" : "aguardando pesquisa"}</span></div><Button size="sm" variant="outline" className="c-border c-ink mt-3 rounded-xl" onClick={() => { setKnowledgeQuery(request.query); setActiveResearchRequestId(request.id); }}>Usar na busca da Biblioteca</Button></article>)}</div> : <p className="c-copy mt-3 text-sm">Nenhuma solicitação derivada.</p>}</section><section className="mt-7"><p className="c-ink text-sm font-bold">Compêndio de cláusulas</p>{compendiumEntries.isLoading ? <p className="c-copy mt-3 text-sm">Carregando rascunhos…</p> : compendiumEntries.data?.length ? <div className="mt-3 grid gap-3">{compendiumEntries.data.map(entry => <article key={entry.id} className="c-tint c-border rounded-2xl border p-4"><div className="flex flex-wrap items-center justify-between gap-3"><p className="c-ink text-sm font-bold">{entry.title}</p><span className="c-soft text-[10px] uppercase tracking-[0.12em]">{entry.status === "draft" ? "rascunho" : entry.status}</span></div><p className="c-copy mt-3 whitespace-pre-wrap text-xs leading-6">{entry.body}</p><p className="c-soft mt-3 text-[10px]">Origem: síntese da Arena · {new Date(entry.createdAt).toLocaleString("pt-BR")}</p></article>)}</div> : <p className="c-copy mt-3 text-sm">Nenhum rascunho no compêndio.</p>}</section></article>}

      {isGovernance && <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8"><p className="c-ink text-lg font-bold">Administração exclusiva do titular</p><p className="c-copy mt-3 max-w-2xl text-sm leading-7">Os indicadores abaixo refletem sua identidade titular atual. Nenhum convite, participante ou permissão de terceiros foi criado nesta fase.</p><dl className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-5"><div className="c-tint c-border rounded-2xl border p-4"><dt className="c-soft text-[10px] font-bold uppercase tracking-[0.14em]">Conta</dt><dd className="c-ink mt-2 text-sm font-bold">{governance.accountState === "active" ? "Ativa" : governance.accountState}</dd><p className="c-copy mt-2 text-xs">Identidade titular</p></div><div className="c-tint c-border rounded-2xl border p-4"><dt className="c-soft text-[10px] font-bold uppercase tracking-[0.14em]">E-mail</dt><dd className="c-ink mt-2 text-sm font-bold">{governance.emailVerified ? "Confirmado" : "Pendente"}</dd><p className="c-copy mt-2 text-xs">Endereço não exibido</p></div><div className="c-tint c-border rounded-2xl border p-4"><dt className="c-soft text-[10px] font-bold uppercase tracking-[0.14em]">Passkeys</dt><dd className="c-ink mt-2 text-2xl font-bold">{governance.passkeyCount}</dd><p className="c-copy mt-1 text-xs">Acesso rotineiro</p></div><div className="c-tint c-border rounded-2xl border p-4"><dt className="c-soft text-[10px] font-bold uppercase tracking-[0.14em]">Contingência</dt><dd className="c-ink mt-2 text-sm font-bold">{governance.totpContingencyConfigured ? "Configurada" : "Pendente"}</dd><p className="c-copy mt-2 text-xs">TOTP apenas se necessário</p></div><div className="c-tint c-border rounded-2xl border p-4"><dt className="c-soft text-[10px] font-bold uppercase tracking-[0.14em]">Recuperação</dt><dd className="c-ink mt-2 text-2xl font-bold">{governance.remainingRecoveryCodes}</dd><p className="c-copy mt-1 text-xs">Códigos disponíveis</p></div></dl><div className="c-border mt-7 rounded-2xl border p-4"><p className="c-ink text-sm font-bold">Convites ainda não habilitados</p><p className="c-copy mt-2 text-xs leading-5">Quando o módulo de participantes estiver pronto, os acessos serão concedidos por convite e por caso. Nenhuma pessoa receberá privilégios administrativos do titular.</p></div></article>}

      {isAudit && <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8"><p className="c-ink text-lg font-bold">Histórico de decisões do caso</p><p className="c-copy mt-3 max-w-2xl text-sm leading-7">Apenas ações vinculadas aos seus casos aparecem aqui. Eventos de ativação, desenvolvimento, sessão e manutenção ficam fora desta visualização e permanecem restritos à proteção técnica da conta.</p>{simulationMode ? <div className="c-tint c-border mt-7 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">A simulação não gera histórico.</p><p className="c-copy mt-2 text-xs leading-5">O caso demonstrativo não cria eventos nem registra decisões.</p></div> : audit.isLoading && auditEvents.length === 0 ? <p className="c-copy mt-7 text-sm">Carregando histórico…</p> : audit.error ? <div className="c-tint c-border mt-7 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Não foi possível consultar o histórico do caso.</p><Button variant="outline" className="c-border c-ink mt-4" onClick={() => audit.refetch()}>Tentar novamente</Button></div> : auditEvents.length ? <><ol className="mt-7 grid gap-3">{auditEvents.map(event => <li key={event.id} className="c-tint c-border flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4"><p className="c-ink text-sm font-medium">{event.eventType.replace(/^owner\.case_/, "").replaceAll("_", " ")}</p><time className="c-soft text-xs">{new Date(event.createdAt).toLocaleString("pt-BR")}</time></li>)}</ol>{audit.data?.nextCursor && <Button variant="outline" className="c-border c-ink mt-5" disabled={Boolean(audit.isFetching)} onClick={() => setAuditCursor(audit.data!.nextCursor!)}>{audit.isFetching ? "Carregando…" : "Mostrar eventos anteriores"}</Button>}</> : <div className="c-tint c-border mt-7 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Nenhuma decisão de caso disponível.</p><p className="c-copy mt-2 text-xs leading-5">Registros técnicos da aplicação não são exibidos neste histórico.</p></div>}</article>}

      {isStrategies && <ExplorationLineageComparison explorations={strategyExplorations.data ?? []} />}

      {isSettings && <SecretIntakePanel />}

      {isSettings && <div className="mt-8 grid gap-5 lg:grid-cols-[1.15fr_0.85fr]"><article className="concilium-card c-border rounded-3xl border p-6 sm:p-8"><div className="flex items-start gap-3"><span className="c-tint c-accent grid h-10 w-10 place-items-center rounded-xl"><Settings size={19} /></span><div><h2 className="c-ink text-lg font-bold">Aparência</h2><p className="c-copy mt-1 text-sm leading-6">O tema é salvo apenas neste dispositivo. Ele não altera conteúdos, permissões ou registros do caso.</p></div></div><Button variant="outline" className="c-border c-ink mt-5 rounded-xl" onClick={() => setTheme(theme === "ivory" ? "navy" : "ivory")}>{theme === "ivory" ? <Moon size={16} /> : <Sun size={16} />}{theme === "ivory" ? "Usar modo escuro" : "Usar modo claro"}</Button><div className="mt-6 grid gap-3 sm:grid-cols-2">{conciliumThemes.map(option => <button key={option.id} type="button" aria-pressed={theme === option.id} onClick={() => setTheme(option.id)} className={cn("c-border rounded-2xl border p-4 text-left transition-colors hover:[background:var(--concilium-tint)]", theme === option.id && "c-tint ring-1 ring-[var(--concilium-accent)]")}><span className="flex gap-1.5">{option.preview.map(color => <span key={color} className="h-3 w-3 rounded-full border border-black/10" style={{ backgroundColor: color }} />)}</span><strong className="c-ink mt-4 block text-sm">{option.name}</strong><span className="c-copy mt-1 block text-xs leading-5">{option.description}</span></button>)}</div></article><div className="grid gap-5"><article className="concilium-card c-border rounded-3xl border p-6"><div className="flex items-start gap-3"><span className="c-tint c-accent grid h-10 w-10 place-items-center rounded-xl"><FlaskConical size={19} /></span><div><h2 className="c-ink text-base font-bold">Modo de simulação</h2><p className="c-copy mt-1 text-sm leading-6">Cria um único caso demonstrativo somente nesta interface. Nenhuma consulta de casos, alteração ou registro é enviado ao servidor enquanto estiver ativo.</p></div></div><Button variant={simulationMode ? "default" : "outline"} className={cn("mt-5 rounded-xl", !simulationMode && "c-border c-ink")} aria-pressed={simulationMode} onClick={() => onSimulationModeChange(!simulationMode)}><FlaskConical size={16} />{simulationMode ? "Desativar modo de simulação" : "Ativar modo de simulação"}</Button></article><article className="concilium-card c-border rounded-3xl border p-6"><div className="flex items-start gap-3"><span className="c-tint c-accent grid h-10 w-10 place-items-center rounded-xl"><Languages size={19} /></span><div><h2 className="c-ink text-base font-bold">{languagePack.ui.language}</h2><p className="c-copy mt-1 text-sm leading-6">{languagePack.ui.languageDescription}</p></div></div><label className="c-ink mt-5 block text-xs font-bold" htmlFor="language-pack-select">{languagePack.ui.selectLanguage}</label><select id="language-pack-select" value={languagePackId} onChange={event => selectLanguagePack(event.target.value as LanguagePackId)} className="c-border c-ink mt-2 min-h-11 w-full rounded-xl border bg-transparent px-3 text-sm">{installedLanguagePackIds.map(id => <option key={id} value={id}>{languagePacks[id].flag} {languagePacks[id].name}</option>)}</select><p className="c-soft mt-3 text-xs leading-5">{languagePack.ui.packageLocalOnly}</p><div className="c-border mt-5 border-t pt-5"><p className="c-ink text-sm font-bold">{languagePack.ui.availablePacks}</p><div className="mt-3 grid gap-2">{(Object.keys(languagePacks) as LanguagePackId[]).filter(id => !installedLanguagePackIds.includes(id)).map(id => <div key={id} className="c-tint c-border flex items-center justify-between gap-3 rounded-xl border p-3"><span className="text-sm"><span className="mr-2">{languagePacks[id].flag}</span>{languagePacks[id].name}</span><Button size="sm" variant="outline" className="c-border c-ink" disabled={Boolean(installingLanguagePackId)} onClick={() => installLanguagePack(id)}>{installingLanguagePackId === id ? languagePack.ui.installing : languagePack.ui.install}</Button></div>)}</div></div></article><article className="concilium-card c-border rounded-3xl border p-6"><div className="flex items-start gap-3"><span className="c-tint c-accent grid h-10 w-10 place-items-center rounded-xl"><ShieldCheck size={19} /></span><div><h2 className="c-ink text-base font-bold">Painel de segurança do titular</h2><p className="c-copy mt-1 text-sm leading-6">Passkeys, contingência TOTP e códigos de recuperação são centralizados neste painel, aberto a partir das Configurações.</p></div></div><Button variant="outline" className="c-border c-ink mt-5 rounded-xl" onClick={onOpenSecurity}>Abrir painel de segurança</Button></article><article className="c-tint c-border rounded-3xl border p-6"><h2 className="c-ink text-base font-bold">Encerrar sessão</h2><p className="c-copy mt-2 text-sm leading-6">Desconecta este dispositivo da área interna. Será necessária uma nova confirmação por passkey para voltar.</p><Button variant="outline" className="c-border c-ink mt-5 rounded-xl" onClick={onLogout} disabled={isLoggingOut}><LogOut size={16} /> {isLoggingOut ? "Encerrando…" : "Sair deste dispositivo"}</Button></article></div></div>}

      {!isOverview && !isStrategies && !isGovernance && !isAudit && !isSettings && <article className="concilium-card c-border mt-8 rounded-3xl border p-6 sm:p-8"><p className="c-ink text-lg font-bold">Módulo restaurado para navegação segura.</p><p className="c-copy mt-3 max-w-2xl text-sm leading-7">{isAi ? "Nenhum conteúdo foi enviado à IA e nenhuma análise é iniciada nesta tela. A integração analítica será reativada apenas com autorização explícita do titular para cada material." : "A estrutura desta seção foi recuperada sem inventar conteúdo, documentos ou eventos. Os dados operacionais serão vinculados ao módulo de casos do Concilium em uma próxima entrega."}</p><div className="c-tint c-border mt-7 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Nenhum dado a exibir neste momento.</p><p className="c-copy mt-2 text-xs leading-5">A navegação está ativa; registros reais aparecerão somente depois que forem criados e autorizados no módulo correspondente.</p></div></article>}
      {isSettings && <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8"><h2 className="c-ink text-lg font-bold">APIs dos provedores de IA</h2><p className="c-copy mt-2 max-w-2xl text-sm leading-6">As chaves nunca são exibidas. Uma alteração exige sua passkey e é cifrada no servidor. Provedores inativos ficam separados até nova validação.</p><div className="mt-6 grid gap-5 lg:grid-cols-2"><section><p className="c-success text-[10px] font-bold uppercase tracking-[0.14em]">Ativas</p><div className="mt-3 grid gap-2">{aiProviders.data?.filter(provider => provider.state === "active").map(provider => <div key={provider.provider} className="c-tint c-border flex items-center justify-between rounded-xl border p-3"><span className="c-ink text-sm font-semibold">{provider.displayName}</span><span className="c-success-ink text-[10px] font-bold uppercase">validada</span></div>) ?? <p className="c-copy text-xs">Carregando provedores…</p>}</div></section><section><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.14em]">Inativas — editar chave</p><div className="mt-3 grid gap-2">{aiProviders.data?.filter(provider => provider.state !== "active" && provider.true).map(provider => <button key={provider.provider} type="button" onClick={() => { setCredentialProvider(provider.provider); setCredentialDraft(""); setCredentialNotice(null); }} className={cn("c-tint c-border flex items-center justify-between rounded-xl border p-3 text-left", credentialProvider === provider.provider && "ring-1 ring-[var(--concilium-accent)]")}><span className="c-ink text-sm font-semibold">{provider.displayName}</span><span className="c-copy text-[10px] font-bold uppercase">{provider.lastValidationStatus === "rejected" ? "chave recusada" : "aguardando chave"}</span></button>) ?? <p className="c-copy text-xs">Carregando provedores…</p>}</div></section></div>{credentialProvider && <div className="c-tint c-border mt-6 rounded-2xl border p-4"><p className="c-ink text-sm font-bold">Substituir credencial</p><p className="c-copy mt-1 text-xs leading-5">A nova chave não será mostrada novamente. A confirmação por passkey será solicitada antes de salvar.</p><Input className="mt-4" type="password" value={credentialDraft} onChange={event => setCredentialDraft(event.target.value)} placeholder="Cole a nova chave" aria-label="Nova chave de API" autoComplete="off" /><div className="mt-4 flex flex-wrap gap-3"><Button className="c-deep-button rounded-xl" disabled={!credentialDraft.trim() || beginApiCredentialReauthentication.isPending || finishApiCredentialReauthentication.isPending || updateAiProviderCredential.isPending} onClick={() => void saveAiProviderCredential()}>Confirmar com passkey e salvar</Button><Button variant="outline" className="c-border c-ink rounded-xl" onClick={() => { setCredentialProvider(null); setCredentialDraft(""); setCredentialNotice(null); }}>Cancelar</Button></div>{credentialNotice && <p role="status" className="c-copy mt-3 text-xs">{credentialNotice}</p>}</div>}</article>}
    </section>
  );
}

export default function OwnerWorkspace() {
  const [location, setLocation] = useLocation();
  const [navigationOpen, setNavigationOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [simulationMode, setSimulationMode] = useState(false);
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [sectionBeforeSettings, setSectionBeforeSettings] = useState<WorkspaceSection>("visao-geral");
  const dashboard = trpc.ownerActivation.dashboard.useQuery();
  const logout = trpc.ownerActivation.logout.useMutation({ onSuccess: () => setLocation("/ativacao") });
  const redirectPath = getOwnerDashboardRedirectPath({ isLoading: dashboard.isLoading, hasDashboard: Boolean(dashboard.data), errorCode: dashboard.error?.data?.code });
  const activeSection = useMemo(() => workspaceSectionFromPath(location), [location]);

  useEffect(() => { if (redirectPath) setLocation(redirectPath, { replace: true }); }, [redirectPath, setLocation]);

  if (dashboard.isLoading || redirectPath) return <div className="concilium-app-shell grid min-h-screen place-items-center"><p className="c-copy text-sm">{redirectPath ? "Redirecionando para a área reservada…" : "Abrindo espaço de trabalho…"}</p></div>;
  if (!dashboard.data) return <main className="concilium-app-shell grid min-h-screen place-items-center px-5"><section className="concilium-card c-border max-w-md rounded-3xl border p-8 text-center"><FileLock2 className="c-accent mx-auto" size={28} /><h1 className="font-editorial c-ink mt-5 text-3xl">Não foi possível abrir o espaço interno.</h1><p className="c-copy mt-4 text-sm leading-6">A sessão não foi alterada. Verifique sua conexão e tente novamente.</p><Button onClick={() => dashboard.refetch()} className="c-deep-button mt-7 rounded-xl">Tentar novamente</Button></section></main>;

  const { owner, passkeyCount, remainingRecoveryCodes, totpContingencyConfigured } = dashboard.data;
  const navigate = (section: WorkspaceSection) => {
    const destination = section === "configuracoes" ? getSettingsToggleDestination(activeSection, sectionBeforeSettings) : section;
    if (section === "configuracoes" && activeSection !== "configuracoes") setSectionBeforeSettings(activeSection);
    setLocation(destination === "visao-geral" ? "/espaco" : `/espaco/${destination}`);
    setNavigationOpen(false);
  };
  const setSimulation = (enabled: boolean) => { setSimulationMode(enabled); setSelectedCaseId(null); };
  const navigation = <nav aria-label="Navegação da área interna" className="space-y-1">{sectionConfig.filter(item => item.id !== "configuracoes").map(item => { const NavIcon = item.icon; const active = item.id === activeSection; return <button key={item.id} onClick={() => navigate(item.id)} className={cn("flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-left text-sm transition-colors", active ? "c-deep-button shadow-sm" : "c-copy hover:[background:var(--concilium-tint)] hover:[color:var(--concilium-ink)]")}><NavIcon size={16} /><span>{item.label}</span></button>; })}</nav>;
  const sidebar = <aside className="concilium-card c-border flex h-full w-[min(286px,calc(100vw-2.25rem))] flex-col border-r p-4 sm:p-5 lg:w-[286px]"><button aria-label="Recolher navegação" onClick={() => { setSidebarCollapsed(true); setNavigationOpen(false); }} className="flex items-center gap-3 px-2 py-3 text-left"><span className="c-deep-button grid h-9 w-9 place-items-center rounded-full"><BookOpenCheck size={18} /></span><span><strong className="font-editorial c-ink block text-xl tracking-[0.11em]">CONCILIUM</strong><small className="c-soft mt-0.5 block text-[9px] uppercase tracking-[0.18em]">Negociação reservada</small></span></button><div className="c-border my-5 border-t" />{navigation}<div className="mt-auto pt-6"><div className="c-tint c-border rounded-2xl border p-3"><p className="c-accent-strong text-[9px] font-semibold uppercase tracking-[0.17em]">Proteção documental</p><p className="c-copy mt-1.5 text-xs leading-5">Documentos e acessos serão vinculados a cada caso com trilha de auditoria.</p></div><button onClick={() => navigate("configuracoes")} className={cn("c-border mt-4 flex min-h-11 w-full items-center gap-3 rounded-xl border px-3 text-left text-sm transition-colors", activeSection === "configuracoes" ? "c-tint c-ink" : "c-copy hover:[background:var(--concilium-tint)] hover:[color:var(--concilium-ink)]")}><Settings size={16} /><span>Configurações</span></button><div className="mt-4 flex items-center gap-3 px-2"><span className="c-deep-button grid h-9 w-9 place-items-center rounded-full text-xs font-bold">{owner.displayName.slice(0, 1).toUpperCase()}</span><div className="min-w-0 flex-1"><p className="c-ink truncate text-sm font-medium">{owner.displayName}</p><p className="c-soft truncate text-[11px]">Titular autenticado</p></div></div></div></aside>;

  return <div className="concilium-app-shell min-h-screen">{!sidebarCollapsed && <div className="hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-30 lg:block">{sidebar}</div>}{sidebarCollapsed && <button aria-label="Abrir navegação lateral" onClick={() => setSidebarCollapsed(false)} className="concilium-card c-border fixed left-4 top-4 z-30 hidden h-11 w-11 place-items-center rounded-xl border lg:grid"><PanelLeftOpen size={19} /></button>}<div className={cn(!sidebarCollapsed && "lg:pl-[286px]")}><header className="concilium-header sticky top-0 z-20 flex h-16 items-center justify-between border-b px-4 backdrop-blur sm:px-6"><div className="flex min-w-0 items-center gap-2 sm:gap-3"><button aria-label="Abrir navegação" aria-expanded={navigationOpen} onClick={() => setNavigationOpen(true)} className="c-ink inline-flex h-11 w-11 shrink-0 items-center justify-center lg:hidden"><Menu size={20} /></button><p className="c-copy text-[11px] font-bold uppercase tracking-[0.14em]">Espaço interno</p></div><div className="flex items-center gap-2"><span className="c-success-tint c-success-ink hidden items-center gap-2 rounded-full px-3 py-2 text-[10px] font-bold sm:inline-flex"><ShieldCheck size={14} className="c-success" /> Sessão protegida</span><Button variant="outline" onClick={() => navigate("configuracoes")} className="c-border c-ink h-9 rounded-xl bg-transparent text-[11px] hover:[background:var(--concilium-tint)]"><Settings size={14} /> Configurações</Button></div></header><main className="px-4 py-8 sm:px-7 sm:py-10 lg:px-10"><WorkspaceContent section={activeSection} ownerName={owner.displayName} governance={{ passkeyCount, remainingRecoveryCodes, totpContingencyConfigured, accountState: owner.state, emailVerified: owner.emailVerified }} selectedCaseId={selectedCaseId} onSelectCase={setSelectedCaseId} onOpenSecurity={() => setLocation("/app")} onLogout={() => logout.mutate()} isLoggingOut={logout.isPending} simulationMode={simulationMode} onSimulationModeChange={setSimulation} /></main></div>{navigationOpen && <div className="fixed inset-0 z-50 bg-black/55 lg:hidden" onClick={() => setNavigationOpen(false)}><div className="relative h-full w-[min(286px,calc(100vw-2.25rem))]" onClick={event => event.stopPropagation()}>{sidebar}</div></div>}</div>;
}
