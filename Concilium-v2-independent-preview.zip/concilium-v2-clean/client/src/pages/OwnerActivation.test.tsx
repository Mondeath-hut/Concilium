import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { ThemeProvider } from "@/contexts/ThemeContext";

const mocks = vi.hoisted(() => ({
  statusQuery: vi.fn(),
  mutation: vi.fn(),
  beginPasskeyLoginMutation: vi.fn(),
  finishPasskeyLoginMutation: vi.fn(),
  startAuthentication: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    ownerActivation: {
      status: { useQuery: mocks.statusQuery },
      beginSetup: { useMutation: mocks.mutation },
      finishPasskeyRegistration: { useMutation: mocks.mutation },
      resendEmailConfirmation: { useMutation: mocks.mutation },
      beginTotpSetup: { useMutation: mocks.mutation },
      confirmTotpAndActivate: { useMutation: mocks.mutation },
      beginPasskeyLogin: { useMutation: mocks.beginPasskeyLoginMutation },
      finishPasskeyLogin: { useMutation: mocks.finishPasskeyLoginMutation },
      useTotpContingency: { useMutation: mocks.mutation },
      useRecoveryCode: { useMutation: mocks.mutation },
    },
  },
}));

vi.mock("@simplewebauthn/browser", () => ({
  startAuthentication: mocks.startAuthentication,
  startRegistration: vi.fn(),
}));

import OwnerActivation from "./OwnerActivation";

function renderActivation(onAuthenticated = vi.fn()) {
  return { onAuthenticated, ...render(<ThemeProvider defaultTheme="navy" switchable><OwnerActivation onAuthenticated={onAuthenticated} /></ThemeProvider>) };
}

describe("owner activation after setup", () => {
  beforeEach(() => {
    mocks.mutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.beginPasskeyLoginMutation.mockReturnValue({ mutateAsync: vi.fn().mockResolvedValue({ challenge: "passkey-challenge" }), isPending: false });
    mocks.finishPasskeyLoginMutation.mockReturnValue({ mutateAsync: vi.fn().mockResolvedValue({ verified: true }), isPending: false });
    mocks.startAuthentication.mockResolvedValue({ id: "credential-test" });
    mocks.statusQuery.mockReturnValue({ isLoading: false, data: { ownerState: "active", activationConfigured: true, mfaEncryptionConfigured: true } });
  });

  afterEach(() => cleanup());

  it("presents passkey access to an active owner instead of the registration form", () => {
    renderActivation();

    expect(screen.getByRole("heading", { name: /entrar com passkey/i })).toBeDefined();
    expect(screen.getByRole("button", { name: /confirmar com passkey/i })).toBeDefined();
    expect(screen.queryByLabelText(/nome do titular/i)).toBeNull();
    expect(screen.queryByText(/vincule a conta titular/i)).toBeNull();
  });

  it("performs passkey login and routes the active owner to the internal panel", async () => {
    const { onAuthenticated } = renderActivation();
    fireEvent.click(screen.getByRole("button", { name: /confirmar com passkey/i }));

    await waitFor(() => expect(mocks.beginPasskeyLoginMutation().mutateAsync).toHaveBeenCalled());
    expect(mocks.startAuthentication).toHaveBeenCalledWith({ optionsJSON: { challenge: "passkey-challenge" } });
    await waitFor(() => expect(mocks.finishPasskeyLoginMutation().mutateAsync).toHaveBeenCalledWith({ response: { id: "credential-test" } }));
    expect(onAuthenticated).toHaveBeenCalledWith("/espaco");
  });
});
