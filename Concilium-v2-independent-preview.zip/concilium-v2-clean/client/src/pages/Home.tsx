import { Button } from "@/components/ui/button";
import { SettingsDialog } from "@/components/SettingsDialog";
import { OwnerAccessButton } from "@/components/OwnerAccessButton";
import { getSecurityStep, securitySteps, type SecurityStepId } from "@/lib/securityFlow";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleCheck,
  EyeOff,
  FileLock2,
  Fingerprint,
  KeyRound,
  Landmark,
  LockKeyhole,
  Menu,
  MonitorSmartphone,
  ShieldCheck,
  X,
} from "lucide-react";
import React, { useState } from "react";
import { useLocation } from "wouter";

const navItems = [
  { label: "Método", target: "metodo" },
  { label: "Segurança", target: "seguranca" },
  { label: "Mobilidade", target: "mobilidade" },
  { label: "Privacidade", target: "privacidade" },
];

function scrollToSection(target: string) {
  document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedStepId, setSelectedStepId] = useState<SecurityStepId>("passkey");
  const selectedStep = getSecurityStep(selectedStepId);
  const showSettingsPreview = import.meta.env.DEV && new URLSearchParams(window.location.search).get("panel") === "settings";

  const navigateTo = (target: string) => {
    setMenuOpen(false);
    scrollToSection(target);
  };

  return (
    <div className="concilium-app-shell min-h-screen overflow-x-hidden">
      <header className="concilium-header sticky top-0 z-50 border-b backdrop-blur-xl">
        <div className="container flex h-[76px] items-center justify-between gap-6">
          <button
            className="group flex items-center gap-3 text-left"
            onClick={() => scrollToSection("inicio")}
            aria-label="Ir para o início"
          >
            <span className="c-deep c-accent grid h-9 w-9 place-items-center rounded-full transition-transform duration-200 group-hover:rotate-6">
              <Landmark size={17} strokeWidth={2.1} />
            </span>
            <span className="leading-none">
              <strong className="font-editorial c-ink block text-[22px] font-normal tracking-[-0.04em]">concilium</strong>
              <span className="c-soft mt-1 block text-[9px] font-bold uppercase tracking-[0.22em]">acordos sensíveis</span>
            </span>
          </button>

          <nav className="hidden items-center gap-7 lg:flex" aria-label="Navegação principal">
            {navItems.map(item => (
              <button
                key={item.target}
                onClick={() => navigateTo(item.target)}
                className="c-copy text-[12px] font-semibold tracking-[0.01em] transition-colors hover:[color:var(--concilium-accent)]"
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <OwnerAccessButton onNavigate={setLocation} className="c-ink text-[12px] font-bold transition-colors hover:[color:var(--concilium-accent)]">
              Acessar
            </OwnerAccessButton>
            <Button onClick={() => scrollToSection("seguranca")} className="c-deep-button h-10 rounded-full px-5 text-[12px] font-bold shadow-none">
              Ver proteção <ArrowUpRight size={14} />
            </Button>
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            <SettingsDialog />
            <button
              type="button"
              onClick={() => setMenuOpen(open => !open)}
              className="c-icon-button grid h-10 w-10 place-items-center rounded-full border"
              aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={menuOpen}
            >
              {menuOpen ? <X size={19} /> : <Menu size={20} />}
            </button>
          </div>
          <div className="hidden lg:block"><SettingsDialog forceOpen={showSettingsPreview} /></div>
        </div>
        {menuOpen && (
          <div className="concilium-mobile-menu border-t px-5 py-5 lg:hidden">
            <nav className="mx-auto flex max-w-xl flex-col gap-2" aria-label="Navegação móvel">
              {navItems.map(item => (
                <button
                  key={item.target}
                  onClick={() => navigateTo(item.target)}
                  className="c-ink flex items-center justify-between rounded-xl px-3 py-3 text-left text-sm font-semibold hover:[background:var(--concilium-card-alt)]"
                >
                  {item.label} <ChevronRight size={16} className="c-accent" />
                </button>
              ))}
              <OwnerAccessButton onNavigate={setLocation} className="c-deep-button mt-3 h-11 rounded-xl px-4 text-sm font-bold">
                Acessar <KeyRound size={16} />
              </OwnerAccessButton>
            </nav>
          </div>
        )}
      </header>

      <main>
        <section id="inicio" className="concilium-hero relative isolate overflow-hidden pb-20 pt-14 sm:pb-28 sm:pt-20">
          <div className="concilium-grid pointer-events-none absolute inset-0 opacity-60" />
          <div className="c-tint pointer-events-none absolute -right-40 top-20 h-[430px] w-[430px] rounded-full blur-[110px]" />
          <div className="c-accent-border pointer-events-none absolute bottom-[-220px] left-[16%] h-[380px] w-[380px] rounded-full border" />
          <div className="container relative grid items-center gap-14 lg:grid-cols-[1.06fr_0.94fr] lg:gap-20">
            <div className="max-w-3xl">
              <div className="c-accent mb-7 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.22em]">
                <span className="c-accent-bg h-px w-9" />
                Infraestrutura de confiança para acordos sensíveis
              </div>
              <h1 className="font-editorial c-deep-ink max-w-3xl text-[54px] leading-[0.92] tracking-[-0.055em] sm:text-[70px] lg:text-[86px]">
                Conciliação exige discrição. <span className="c-accent">A tecnologia também.</span>
              </h1>
              <p className="c-deep-copy mt-8 max-w-xl text-[16px] leading-7 sm:text-[18px]">
                O Concilium organiza acordos, participantes e documentos sensíveis em um ambiente onde acesso, contexto e responsabilidade caminham juntos.
              </p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Button onClick={() => scrollToSection("seguranca")} className="c-primary-button h-12 rounded-full px-6 text-[13px] font-bold shadow-none">
                  Conhecer a camada de proteção <ArrowRight size={16} />
                </Button>
                <OwnerAccessButton className="c-outline-deep h-12 rounded-full px-6 text-[13px] font-bold">
                  Acessar <KeyRound size={15} />
                </OwnerAccessButton>
              </div>
              <div className="c-deep-border c-deep-copy mt-12 flex items-center gap-3 border-t pt-5 text-[12px] leading-5">
                <CircleCheck size={16} className="c-accent shrink-0" />
                Informação jurídica tratada com contexto, permissão e rastreabilidade.
              </div>
            </div>

            <div className="relative mx-auto w-full max-w-[530px] lg:mx-0">
              <div className="c-accent-border absolute -left-4 top-11 h-full w-full rounded-[32px] border" />
              <div className="concilium-showcase-card relative overflow-hidden rounded-[28px] border p-5 shadow-[0_40px_100px_var(--concilium-shadow)] sm:p-7">
                <div className="c-showcase-border flex items-center justify-between border-b pb-5">
                  <div>
                    <p className="c-showcase-soft text-[9px] font-bold uppercase tracking-[0.2em]">Exemplo de experiência futura · 08:45 BRT</p>
                    <p className="c-showcase-ink mt-2 text-[15px] font-semibold">Acordo em curso · #04</p>
                  </div>
                  <span className="c-success-tint c-success-ink flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-bold">
                    <span className="c-success h-1.5 w-1.5 rounded-full bg-current" /> Verificado
                  </span>
                </div>
                <div className="mt-6 grid grid-cols-[auto_1fr] gap-x-4 gap-y-4">
                  {[
                    [KeyRound, "Credencial", "Passkey — exemplo de interface"],
                    [Fingerprint, "Verificação local", "Confirmação local — exemplo"],
                    [ShieldCheck, "Sessão", "Escopo limitado ao caso convidado"],
                  ].map(([Icon, label, value]) => {
                    const IconComponent = Icon as typeof KeyRound;
                    return (
                      <React.Fragment key={label as string}>
                        <span className="c-tint c-accent grid h-9 w-9 place-items-center rounded-xl"><IconComponent size={17} /></span>
                        <div>
                          <p className="c-showcase-soft text-[10px] font-bold uppercase tracking-[0.16em]">{label as string}</p>
                          <p className="c-showcase-ink mt-1 text-[13px]">{value as string}</p>
                        </div>
                      </React.Fragment>
                    );
                  })}
                </div>
                <div className="concilium-showcase-inner c-showcase-border mt-7 rounded-2xl border p-4">
                  <div className="flex items-start gap-3"><FileLock2 size={16} className="c-accent mt-0.5" /><p className="c-showcase-copy text-[12px] leading-5">Documento confidencial. A arquitetura prevê um novo fator antes de exportar ou compartilhar.</p></div>
                </div>
              </div>
              <div className="c-card c-border absolute -bottom-7 -left-5 hidden items-center gap-3 rounded-2xl border p-3 pr-5 shadow-xl sm:flex">
                <span className="c-success-tint c-success-ink grid h-8 w-8 place-items-center rounded-full"><Check size={16} strokeWidth={3} /></span>
                <span className="c-ink text-[11px] font-bold">Evento demonstrativo</span>
              </div>
            </div>
          </div>
        </section>

        <section id="metodo" className="concilium-surface scroll-mt-20 py-20 sm:py-28">
          <div className="container">
            <div className="grid gap-8 lg:grid-cols-[0.78fr_1.22fr] lg:gap-20">
              <div>
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">O método Concilium</p>
                <h2 className="font-editorial c-ink mt-5 text-[46px] leading-[0.96] tracking-[-0.045em] sm:text-[58px]">Confiança não é um recurso extra.</h2>
              </div>
              <div className="pt-2">
                <p className="c-copy max-w-2xl text-[18px] leading-8">Ela orienta o desenho do produto. O Concilium foi pensado para que cada entrada, decisão, permissão e documento tenha o contexto necessário — sem forçar a equipe jurídica a trabalhar em um fluxo burocrático.</p>
                <div className="mt-10 grid gap-px overflow-hidden rounded-[22px] border border-[var(--concilium-card-border)] bg-[var(--concilium-card-border)] sm:grid-cols-3">
                  {[
                    ["Convite contextual", "A entrada já nasce com caso, papel e limite definidos."],
                    ["Trabalho protegido", "Acesso por necessidade, não por conveniência."],
                    ["Registro contínuo", "Eventos relevantes compõem uma trilha de responsabilidade."],
                  ].map(([title, text], index) => (
                    <article key={title} className="concilium-card p-6 sm:p-7">
                      <span className="c-accent-strong text-[11px] font-bold">0{index + 1}</span>
                      <h3 className="c-ink mt-7 text-[15px] font-bold">{title}</h3>
                      <p className="c-copy mt-3 text-[13px] leading-6">{text}</p>
                    </article>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="seguranca" className="concilium-surface-alt scroll-mt-20 py-20 sm:py-28">
          <div className="container">
            <div className="max-w-2xl">
              <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Segurança em camadas</p>
              <h2 className="font-editorial c-ink mt-5 text-[46px] leading-[0.96] tracking-[-0.045em] sm:text-[58px]">Proteção que acompanha a importância do gesto.</h2>
              <p className="c-copy mt-6 text-[16px] leading-7">O acesso não é tratado como um único momento. O Concilium combina identidade, credenciais fortes e confirmação contextual para manter a informação dentro do limite correto.</p>
              <p className="concilium-settings-card c-copy mt-4 max-w-2xl rounded-xl border px-4 py-3 text-[12px] leading-5"><strong className="c-ink">Demonstração de arquitetura.</strong> As telas abaixo representam o fluxo planejado; a camada efetiva de MFA ainda será implementada no backend.</p>
            </div>

            <div className="concilium-access-shell mt-12 grid overflow-hidden rounded-[28px] border lg:grid-cols-[0.9fr_1.1fr]">
              <div className="concilium-access-list border-b p-4 sm:p-6 lg:border-b-0 lg:border-r">
                <p className="c-soft px-3 pb-4 text-[10px] font-bold uppercase tracking-[0.2em]">Fluxo de acesso</p>
                <div className="space-y-1.5">
                  {securitySteps.map((step, index) => {
                    const active = step.id === selectedStepId;
                    return (
                      <button
                        key={step.id}
                        type="button"
                        aria-pressed={active}
                        onClick={() => setSelectedStepId(step.id)}
                        className={`group flex w-full items-center gap-4 rounded-2xl p-3 text-left transition-all duration-200 ${active ? "concilium-step-active" : "concilium-step-idle"}`}
                      >
                        <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-[11px] font-bold ${active ? "concilium-step-index-active" : "concilium-step-index"}`}>0{index + 1}</span>
                        <span className="min-w-0 flex-1"><span className={`block text-[12px] font-bold ${active ? "c-deep-ink" : "c-ink"}`}>{step.title}</span><span className={`mt-1 block truncate text-[10px] ${active ? "c-deep-copy" : "c-soft"}`}>{step.detail}</span></span>
                        <ChevronRight size={16} className={active ? "c-accent" : "c-soft"} />
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="concilium-showcase relative overflow-hidden p-7 sm:p-10">
                <div className="c-accent-border absolute -right-20 -top-20 h-64 w-64 rounded-full border" />
                <div className="c-tint absolute -bottom-28 right-10 h-60 w-60 rounded-full blur-3xl" />
                <div className="relative">
                  <div className="flex items-center justify-between gap-4">
                    <span className="c-tint c-accent c-accent-border rounded-full border px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.16em]">{selectedStep.eyebrow}</span>
                    <span className="c-success-ink flex items-center gap-2 text-[10px] font-semibold"><span className="c-success h-1.5 w-1.5 rounded-full bg-current" /> Arquitetura proposta</span>
                  </div>
                  <h3 className="font-editorial c-showcase-ink mt-10 max-w-lg text-[38px] leading-[1] tracking-[-0.04em] sm:text-[48px]">{selectedStep.title}</h3>
                  <p className="c-showcase-copy mt-5 max-w-xl text-[15px] leading-7">{selectedStep.description}</p>
                  <div className="mt-10 grid gap-4 sm:grid-cols-2">
                    <div className="concilium-showcase-soft-card rounded-2xl border p-4"><p className="c-showcase-soft text-[9px] font-bold uppercase tracking-[0.16em]">Objetivo</p><p className="c-showcase-ink mt-2 text-[13px] font-semibold">{selectedStep.signal}</p></div>
                    <div className="concilium-showcase-soft-card rounded-2xl border p-4"><p className="c-showcase-soft text-[9px] font-bold uppercase tracking-[0.16em]">Previsão de controle</p><p className="c-showcase-ink mt-2 text-[13px] font-semibold">Eventos auditáveis e revogáveis</p></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-7 grid gap-4 md:grid-cols-3">
              <div className="concilium-note-card flex items-start gap-3 rounded-2xl border p-5"><Fingerprint className="c-accent mt-0.5" size={18} /><p className="text-[13px] leading-6"><strong>Biometria local.</strong> A digital ou o rosto, quando disponíveis, ficam no aparelho.</p></div>
              <div className="concilium-note-card flex items-start gap-3 rounded-2xl border p-5"><EyeOff className="c-accent mt-0.5" size={18} /><p className="text-[13px] leading-6"><strong>Sem atalho por selfie.</strong> Verificação de identidade é uma decisão separada de MFA.</p></div>
              <div className="concilium-note-card flex items-start gap-3 rounded-2xl border p-5"><LockKeyhole className="c-accent mt-0.5" size={18} /><p className="text-[13px] leading-6"><strong>Recuperação auditável.</strong> A perda de dispositivo não abre uma porta lateral para o caso.</p></div>
            </div>
          </div>
        </section>

        <section id="mobilidade" className="concilium-surface scroll-mt-20 py-20 sm:py-28">
          <div className="container grid items-center gap-14 lg:grid-cols-[0.95fr_1.05fr] lg:gap-24">
            <div className="order-2 lg:order-1">
              <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">O mesmo cuidado, no aparelho</p>
              <h2 className="font-editorial c-ink mt-5 max-w-xl text-[46px] leading-[0.96] tracking-[-0.045em] sm:text-[58px]">O app não será outro sistema.</h2>
              <p className="c-copy mt-6 max-w-xl text-[16px] leading-7">A versão móvel nasce conectada ao mesmo backend, às mesmas permissões por caso e à mesma trilha de auditoria. O dispositivo recebe uma sessão própria, curta e revogável.</p>
              <div className="mt-9 space-y-4">
                {[
                  [MonitorSmartphone, "Acesso nativo", "Login com fluxo protegido e retorno seguro ao aplicativo."],
                  [KeyRound, "Chave protegida", "Armazenamento no cofre do aparelho, nunca em armazenamento simples."],
                  [ShieldCheck, "Notificação discreta", "Alertas sem expor dados jurídicos no texto da notificação."],
                ].map(([Icon, title, text]) => {
                  const IconComponent = Icon as typeof KeyRound;
                  return (
                    <div key={title as string} className="flex items-start gap-4"><span className="c-tint c-accent-strong grid h-10 w-10 shrink-0 place-items-center rounded-xl"><IconComponent size={18} /></span><div><p className="c-ink text-[14px] font-bold">{title as string}</p><p className="c-copy mt-1 text-[13px] leading-6">{text as string}</p></div></div>
                  );
                })}
              </div>
            </div>

            <div className="order-1 mx-auto w-full max-w-[430px] lg:order-2">
              <div className="concilium-device-shell relative mx-auto w-[290px] rounded-[43px] border-[8px] p-2 shadow-[0_30px_70px_var(--concilium-shadow)]">
                <div className="concilium-device-notch absolute left-1/2 top-2 h-5 w-24 -translate-x-1/2 rounded-b-2xl" />
                <div className="c-card min-h-[530px] overflow-hidden rounded-[33px] px-5 pb-6 pt-12">
                  <div className="c-copy flex items-center justify-between text-[9px] font-bold"><span>9:41</span><span className="c-success-ink flex items-center gap-1"><span className="c-success h-1.5 w-1.5 rounded-full bg-current" /> Protegido</span></div>
                  <p className="c-accent-strong mt-9 text-[10px] font-bold uppercase tracking-[0.2em]">Bem-vinda, Helena</p>
                  <h3 className="font-editorial c-ink mt-3 text-[31px] leading-[0.98] tracking-[-0.045em]">Seu caso pede atenção.</h3>
                  <div className="concilium-showcase mt-7 rounded-2xl p-4"><div className="c-accent flex items-center gap-2 text-[10px] font-bold"><FileLock2 size={13} /> ACORDO EM CURSO</div><p className="c-showcase-ink mt-3 text-[13px] font-semibold">Mediação · documentos privados</p><p className="c-showcase-soft mt-1 text-[10px] leading-4">3 atualizações desde o último acesso</p></div>
                  <div className="concilium-settings-card mt-5 rounded-2xl border p-4"><div className="flex items-center justify-between"><span className="c-ink text-[10px] font-bold">Confirmação solicitada</span><Fingerprint size={15} className="c-accent-strong" /></div><p className="c-copy mt-2 text-[10px] leading-4">Use a passkey deste aparelho para abrir o documento.</p><button type="button" className="c-tint c-ink mt-3 w-full rounded-xl py-2 text-[10px] font-bold">Confirmar no aparelho</button></div>
                </div>
              </div>
              <div className="c-card c-border mx-auto -mt-7 w-[238px] rounded-2xl border p-4 text-center shadow-xl"><p className="c-ink text-[10px] font-bold">Aplicativo Concilium</p><p className="c-soft mt-1 text-[9px] leading-4">A mesma conta. O mesmo limite de acesso.</p></div>
            </div>
          </div>
        </section>

        <section id="privacidade" className="concilium-surface-privacy scroll-mt-20 py-20 sm:py-28">
          <div className="container grid gap-12 lg:grid-cols-[0.82fr_1.18fr] lg:gap-20">
            <div><p className="c-success-ink text-[10px] font-bold uppercase tracking-[0.2em]">Privacidade que se prova</p><h2 className="font-editorial c-ink mt-5 text-[46px] leading-[0.96] tracking-[-0.045em] sm:text-[58px]">Menos exposição. Mais responsabilidade.</h2></div>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                ["Permissões por caso", "Cada participante atua no escopo que lhe foi atribuído, sem visão global por padrão."],
                ["Documentos com contexto", "O acesso a conteúdo reservado pode ser limitado, confirmado novamente e registrado."],
                ["Auditoria útil", "Eventos de segurança contam uma história verificável, sem guardar senha, OTP ou conteúdo indevido."],
                ["Evolução responsável", "Qualquer uso de biometria, IA ou transferência de dados exige finalidade e revisão específicas."],
              ].map(([title, text]) => (
                <article key={title} className="concilium-card rounded-2xl border p-6"><p className="c-ink text-[14px] font-bold">{title}</p><p className="c-copy mt-3 text-[13px] leading-6">{text}</p></article>
              ))}
            </div>
          </div>
        </section>

        <section className="concilium-callout py-20 sm:py-24">
          <div className="container flex flex-col items-start justify-between gap-10 lg:flex-row lg:items-end">
            <div className="max-w-3xl"><p className="c-accent text-[10px] font-bold uppercase tracking-[0.2em]">Concilium</p><h2 className="font-editorial c-showcase-ink mt-5 text-[47px] leading-[0.96] tracking-[-0.05em] sm:text-[64px]">Pronto para conciliar com outra camada de segurança?</h2></div>
            <Button onClick={() => window.location.assign("/ativacao")} className="c-primary-button h-12 shrink-0 rounded-full px-6 text-[13px] font-bold shadow-none">Área reservada <KeyRound size={16} /></Button>
          </div>
        </section>
      </main>

      <footer className="concilium-callout pb-8">
        <div className="container c-callout-border c-callout-soft flex flex-col justify-between gap-6 border-t pt-7 text-[10px] font-semibold sm:flex-row"><span>© 2026 Concilium. Acordos sensíveis, tratados com contexto.</span><span>Segurança · Privacidade · Responsabilidade</span></div>
      </footer>
    </div>
  );
}
