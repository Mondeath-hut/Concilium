import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Home } from "lucide-react";
import { useLocation } from "wouter";

export default function NotFound() {
  const [, setLocation] = useLocation();

  return (
    <div className="concilium-app-shell concilium-surface-alt flex min-h-screen w-full items-center justify-center">
      <Card className="concilium-card mx-4 w-full max-w-lg border shadow-lg">
        <CardContent className="pt-8 pb-8 text-center">
          <div className="flex justify-center pb-6">
            <div className="c-tint c-accent grid h-16 w-16 place-items-center rounded-full">
              <AlertCircle className="h-8 w-8" />
            </div>
          </div>
          <h1 className="c-ink text-4xl font-bold">404</h1>
          <h2 className="c-ink mt-2 text-xl font-semibold">Página não encontrada</h2>
          <p className="c-copy mt-4 leading-relaxed">O endereço informado não corresponde a uma página disponível no Concilium.</p>
          <div id="not-found-button-group" className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button onClick={() => setLocation("/")} className="c-deep-button rounded-lg px-6 py-2.5 shadow-md">
              <Home className="mr-2 h-4 w-4" />
              Ir para o início
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
