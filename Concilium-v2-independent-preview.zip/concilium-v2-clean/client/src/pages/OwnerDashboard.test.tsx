import { act, cleanup, render, screen, waitFor, within } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent } from "@testing-library/react";
import { ThemeProvider } from "@/contexts/ThemeContext";

const mocks = vi.hoisted(() => ({
  dashboardQuery: vi.fn(),
  logoutMutation: vi.fn(),
  beginRecoveryRenewalMutation: vi.fn(),
  finishRecoveryRenewalMutation: vi.fn(),
  beginApiCredentialReauthenticationMutation: vi.fn(),
  finishApiCredentialReauthenticationMutation: vi.fn(),
  casesQuery: vi.fn(),
  operationalCasesListQuery: vi.fn(),
  operationalCasesCreateMutation: vi.fn(),
  operationalCasesOverviewQuery: vi.fn(),
  operationalCasesCreateStrategyMutation: vi.fn(),
  createCaseMutation: vi.fn(),
  caseOverviewQuery: vi.fn(),
  createStrategyMutation: vi.fn(),
  documentAccessMutation: vi.fn(),
  auditQuery: vi.fn(),
  aiModelsQuery: vi.fn(),
  aiProvidersQuery: vi.fn(),
  aiRunsQuery: vi.fn(),
  updateAiProviderCredentialMutation: vi.fn(),
  runAiMutation: vi.fn(),
  decideAiMutation: vi.fn(),
  fallbackQuery: vi.fn(),
  fallbackMutation: vi.fn(),
  setLocation: vi.fn(),
  location: "/app",
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    knowledge: new Proxy({}, { get: () => ({ useQuery: mocks.fallbackQuery, useMutation: mocks.fallbackMutation }) }),
    operationalAttachments: new Proxy({}, { get: () => ({ useQuery: mocks.fallbackQuery, useMutation: mocks.fallbackMutation }) }),
    operationalDocuments: new Proxy({}, { get: () => ({ useQuery: mocks.fallbackQuery, useMutation: mocks.fallbackMutation }) }),
    ownerActivation: {
      dashboard: { useQuery: mocks.dashboardQuery },
      logout: { useMutation: mocks.logoutMutation },
      beginRecoveryCodeRegeneration: { useMutation: mocks.beginRecoveryRenewalMutation },
      finishRecoveryCodeRegeneration: { useMutation: mocks.finishRecoveryRenewalMutation },
      beginApiCredentialReauthentication: { useMutation: mocks.beginApiCredentialReauthenticationMutation },
      finishApiCredentialReauthentication: { useMutation: mocks.finishApiCredentialReauthenticationMutation },
    },
    operationalCases: new Proxy({
      list: { useQuery: mocks.operationalCasesListQuery },
      create: { useMutation: mocks.operationalCasesCreateMutation },
      overview: { useQuery: mocks.operationalCasesOverviewQuery },
      createStrategy: { useMutation: mocks.operationalCasesCreateStrategyMutation },
    }, { get: (target, property) => (target as Record<string, unknown>)[String(property)] ?? { useQuery: mocks.fallbackQuery, useMutation: mocks.fallbackMutation } }),
    ownerWorkspace: new Proxy({
      listCases: { useQuery: mocks.casesQuery },
      createCase: { useMutation: mocks.createCaseMutation },
      caseOverview: { useQuery: mocks.caseOverviewQuery },
      createStrategy: { useMutation: mocks.createStrategyMutation },
      requestDocumentAccess: { useMutation: mocks.documentAccessMutation },
      audit: { useQuery: mocks.auditQuery },
      listAiModels: { useQuery: mocks.aiModelsQuery },
      listAiProviders: { useQuery: mocks.aiProvidersQuery },
      listAiRuns: { useQuery: mocks.aiRunsQuery },
      updateAiProviderCredential: { useMutation: mocks.updateAiProviderCredentialMutation },
      runAiCommittee: { useMutation: mocks.runAiMutation },
      decideAiRun: { useMutation: mocks.decideAiMutation },
    }, { get: (target, property) => (target as Record<string, unknown>)[String(property)] ?? { useQuery: mocks.fallbackQuery, useMutation: mocks.fallbackMutation } }),
  },
}));

vi.mock("wouter", () => ({
  useLocation: () => [mocks.location, mocks.setLocation],
}));

import OwnerDashboard, { getOwnerDashboardRedirectPath } from "./OwnerDashboard";
import OwnerWorkspace, { getSettingsToggleDestination } from "./OwnerWorkspace";

function renderDashboard() {
  return render(<ThemeProvider defaultTheme="navy" switchable><OwnerDashboard /></ThemeProvider>);
}

function renderWorkspace() {
  return render(<ThemeProvider defaultTheme="navy" switchable><OwnerWorkspace /></ThemeProvider>);
}

describe("getOwnerDashboardRedirectPath", () => {
  beforeEach(() => {
    mocks.setLocation.mockReset();
    mocks.location = "/app";
    localStorage.removeItem("concilium-theme");
    localStorage.removeItem("concilium-installed-language-packs");
    localStorage.removeItem("concilium-language-pack");
    mocks.logoutMutation.mockReturnValue({ mutate: vi.fn(), isPending: false });
    mocks.beginRecoveryRenewalMutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.finishRecoveryRenewalMutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.beginApiCredentialReauthenticationMutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.finishApiCredentialReauthenticationMutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.casesQuery.mockReturnValue({ isLoading: false, data: [], refetch: vi.fn() });
    mocks.operationalCasesListQuery.mockImplementation((...args) => mocks.casesQuery(...args));
    mocks.operationalCasesCreateMutation.mockImplementation((...args) => mocks.createCaseMutation(...args));
    mocks.operationalCasesOverviewQuery.mockImplementation((...args) => mocks.caseOverviewQuery(...args));
    mocks.operationalCasesCreateStrategyMutation.mockImplementation((...args) => mocks.createStrategyMutation(...args));
    mocks.createCaseMutation.mockReturnValue({ mutate: vi.fn(), isPending: false });
    mocks.caseOverviewQuery.mockReturnValue({ isLoading: false, data: undefined, refetch: vi.fn() });
    mocks.createStrategyMutation.mockReturnValue({ mutate: vi.fn(), isPending: false });
    mocks.documentAccessMutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.auditQuery.mockReturnValue({ isLoading: false, isFetching: false, data: { events: [], nextCursor: null }, error: undefined, refetch: vi.fn() });
    mocks.aiModelsQuery.mockReturnValue({ isLoading: false, data: [], error: undefined, refetch: vi.fn() });
    mocks.aiProvidersQuery.mockReturnValue({ isLoading: false, data: [], error: undefined, refetch: vi.fn() });
    mocks.aiRunsQuery.mockReturnValue({ isLoading: false, data: [], error: undefined, refetch: vi.fn() });
    mocks.updateAiProviderCredentialMutation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });
    mocks.runAiMutation.mockReturnValue({ mutate: vi.fn(), isPending: false, error: undefined });
    mocks.decideAiMutation.mockReturnValue({ mutate: vi.fn(), isPending: false });
    mocks.fallbackQuery.mockReturnValue({ isLoading: false, data: undefined, error: undefined, refetch: vi.fn() });
    mocks.fallbackMutation.mockReturnValue({ mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false, error: undefined });
  });

  afterEach(() => cleanup());

  it("mantém o carregamento enquanto a sessão própria é verificada", () => {
    expect(getOwnerDashboardRedirectPath({ isLoading: true, hasDashboard: false, errorCode: "UNAUTHORIZED" })).toBeNull();
  });

  it("navega de fato para a ativação quando o servidor informa ausência de sessão", async () => {
    mocks.dashboardQuery.mockReturnValue({ isLoading: false, data: undefined, error: { data: { code: "UNAUTHORIZED" } }, refetch: vi.fn() });
    renderDashboard();

    await waitFor(() => expect(mocks.setLocation).toHaveBeenCalledWith("/ativacao", { replace: true }));
  });

  it("não redireciona em falha operacional e oferece uma nova tentativa", () => {
    const refetch = vi.fn();
    mocks.dashboardQuery.mockReturnValue({ isLoading: false, data: undefined, error: { data: { code: "INTERNAL_SERVER_ERROR" } }, refetch });
    renderDashboard();

    expect(mocks.setLocation).not.toHaveBeenCalled();
    expect(screen.getByRole("heading", { name: /não foi possível abrir/i })).toBeDefined();
    expect(screen.getByRole("button", { name: /tentar novamente/i })).toBeDefined();
  });

  it("mantém o titular no painel apenas quando o servidor retorna dados autenticados", () => {
    expect(getOwnerDashboardRedirectPath({ isLoading: false, hasDashboard: true, errorCode: "UNAUTHORIZED" })).toBeNull();
  });

  it("mostra somente a quantidade de códigos de recuperação ainda disponíveis", () => {
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active" }, remainingRecoveryCodes: 10 },
      error: undefined,
      refetch: vi.fn(),
    });
    renderDashboard();

    expect(screen.getByText(/10 disponíveis/i)).toBeDefined();
    expect(screen.queryByText(/hash-a/i)).toBeNull();
  });

  it("retorna às Configurações a partir do painel de segurança do titular", () => {
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active" }, remainingRecoveryCodes: 10 },
      error: undefined,
      refetch: vi.fn(),
    });
    renderDashboard();
    fireEvent.click(screen.getByRole("button", { name: /voltar às configurações/i }));
    expect(mocks.setLocation).toHaveBeenCalledWith("/espaco/configuracoes");
  });

  it("bloqueia o espaço interno sem sessão titular e informa a separação de futuros convites", async () => {
    mocks.dashboardQuery.mockReturnValue({ isLoading: false, data: undefined, error: { data: { code: "UNAUTHORIZED" } }, refetch: vi.fn() });
    renderWorkspace();
    await waitFor(() => expect(mocks.setLocation).toHaveBeenCalledWith("/ativacao", { replace: true }));
  });

  it("restaura a navegação interna clicável, incluindo Biblioteca e Governança", () => {
    mocks.location = "/espaco/biblioteca";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active" }, remainingRecoveryCodes: 10 },
      error: undefined,
      refetch: vi.fn(),
    });
    renderWorkspace();

    expect(screen.getByRole("heading", { name: /biblioteca protegida/i })).toBeDefined();
    expect(screen.getByRole("button", { name: "Estratégias" })).toBeDefined();
    expect(screen.getByRole("button", { name: "Comitê de IA" })).toBeDefined();
    fireEvent.click(screen.getByRole("button", { name: "Governança" }));
    expect(mocks.setLocation).toHaveBeenCalledWith("/espaco/governanca");
  });

  it("alterna Configurações de volta para a última seção interna visitada", () => {
    expect(getSettingsToggleDestination("visao-geral", "visao-geral")).toBe("configuracoes");
    expect(getSettingsToggleDestination("estrategias", "estrategias")).toBe("configuracoes");
    expect(getSettingsToggleDestination("configuracoes", "visao-geral")).toBe("visao-geral");
    expect(getSettingsToggleDestination("configuracoes", "negociacao")).toBe("negociacao");
  });

  it("mostra o Comitê de IA integrado e exige consentimento antes de iniciar uma rodada", () => {
    const run = vi.fn();
    mocks.location = "/espaco/comite-ia";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    mocks.casesQuery.mockReturnValue({ isLoading: false, data: [{ id: "case-real", title: "Caso real", summary: "Contexto protegido", status: "active" }], refetch: vi.fn() });
    mocks.caseOverviewQuery.mockReturnValue({ isLoading: false, data: { ownerCase: { id: "case-real", title: "Caso real" }, strategies: [], memorialEntries: [], assets: [], documents: [], scenarios: [] }, refetch: vi.fn() });
    mocks.aiModelsQuery.mockReturnValue({ isLoading: false, data: [{ id: "modelo-integrado", provider: "openrouter" }], error: undefined, refetch: vi.fn() });
    mocks.runAiMutation.mockReturnValue({ mutate: run, isPending: false, error: undefined });
    renderWorkspace();

    expect(screen.getByRole("heading", { name: /comitê de ia/i })).toBeDefined();
    fireEvent.change(screen.getByLabelText("Título da rodada de IA"), { target: { value: "Revisão técnica" } });
    fireEvent.change(screen.getByLabelText("Objetivo técnico da rodada de IA"), { target: { value: "Identificar pendências documentais e pontos de revisão." } });
    fireEvent.change(screen.getByLabelText("Conteúdo autorizado para análise de IA"), { target: { value: "Conteúdo privado autorizado para revisão técnica com perguntas objetivas." } });
    fireEvent.click(screen.getByRole("checkbox", { name: /modelo-integrado/i }));
    const submit = screen.getByRole("button", { name: /autorizar e iniciar rodada/i });
    expect((submit as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByRole("checkbox", { name: /confirmo que posso autorizar/i }));
    expect((submit as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(submit);
    expect(run).toHaveBeenCalledWith(expect.objectContaining({ caseId: "case-real", consentConfirmed: true, modelIds: ["modelo-integrado"] }));
  });

  it("exibe os indicadores reais de identidade na Governança sem divulgar o e-mail", () => {
    mocks.location = "/espaco/governanca";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 2, remainingRecoveryCodes: 8, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    renderWorkspace();

    expect(screen.getByText("Ativa")).toBeDefined();
    expect(screen.getByText("Confirmado")).toBeDefined();
    expect(screen.getByText("2")).toBeDefined();
    expect(screen.getByText("8")).toBeDefined();
    expect(screen.queryByText("titular@exemplo.test")).toBeNull();
  });

  it("carrega eventos de auditoria em páginas sem revelar metadados", async () => {
    const firstEvent = { id: "audit-current", eventType: "owner.case_created", createdAt: new Date("2026-08-21T08:00:00.000Z") };
    const secondEvent = { id: "audit-older", eventType: "owner.case_strategy_created", createdAt: new Date("2026-08-20T08:00:00.000Z") };
    mocks.location = "/espaco/auditoria";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    mocks.auditQuery.mockImplementation((input: { cursor?: { id: string } }) => input.cursor
      ? { isLoading: false, isFetching: false, data: { events: [secondEvent], nextCursor: null }, error: undefined, refetch: vi.fn() }
      : { isLoading: false, isFetching: false, data: { events: [firstEvent], nextCursor: { id: firstEvent.id, createdAt: firstEvent.createdAt } }, error: undefined, refetch: vi.fn() });
    renderWorkspace();

    await waitFor(() => expect(screen.getByText(/^created$/i)).toBeDefined());
    fireEvent.click(screen.getByRole("button", { name: /mostrar eventos anteriores/i }));
    await waitFor(() => expect(screen.getByText(/strategy created/i)).toBeDefined());
    expect(screen.queryByText(/passkey authenticated/i)).toBeNull();
    expect(screen.queryByText(/never-returned/i)).toBeNull();
  });

  it("reúne as preferências do titular em Configurações sem expor controles de identidade", () => {
    const logout = vi.fn();
    mocks.location = "/espaco/configuracoes";
    mocks.logoutMutation.mockReturnValue({ mutate: logout, isPending: false });
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    renderWorkspace();

    expect(screen.getByRole("heading", { name: "Configurações" })).toBeDefined();
    expect((document.getElementById("language-pack-select") as HTMLSelectElement).value).toBe("pt-BR");
    fireEvent.click(screen.getByRole("button", { name: /Âmbar original/i }));
    expect(document.documentElement.dataset.conciliumTheme).toBe("amber");
    expect(localStorage.getItem("concilium-theme")).toBe("amber");
    fireEvent.click(screen.getByRole("button", { name: /abrir painel de segurança/i }));
    expect(mocks.setLocation).toHaveBeenCalledWith("/app");
    fireEvent.click(screen.getByRole("button", { name: /sair deste dispositivo/i }));
    expect(logout).toHaveBeenCalledTimes(1);
    expect(screen.queryByText("titular@exemplo.test")).toBeNull();
  });

  it("instala e seleciona um pacote de idioma somente neste navegador", async () => {
    vi.useFakeTimers();
    mocks.location = "/espaco/configuracoes";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    renderWorkspace();

    fireEvent.click(screen.getAllByRole("button", { name: /instalar pacote/i })[0]);
    expect(screen.getByRole("button", { name: /instalando pacote/i })).toBeDefined();
    await act(async () => { vi.advanceTimersByTime(650); });

    expect((document.getElementById("language-pack-select") as HTMLSelectElement).value).toBe("en-US");
    expect(localStorage.getItem("concilium-language-pack")).toBe("en-US");
    expect(localStorage.getItem("concilium-installed-language-packs")).toContain("en-US");
    vi.useRealTimers();
  });

  it("ativa a simulação somente no navegador e desabilita consultas e criação persistente", () => {
    mocks.location = "/espaco/configuracoes";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    renderWorkspace();

    fireEvent.click(screen.getByRole("button", { name: /ativar modo de simulação/i }));
    expect(screen.getByRole("status").textContent).toMatch(/somente neste navegador/i);
    expect(mocks.casesQuery.mock.calls.at(-1)?.[1]).toMatchObject({ enabled: false });
    expect(mocks.caseOverviewQuery.mock.calls.at(-1)?.[1]).toMatchObject({ enabled: false });
  });

  it("seleciona automaticamente o caso real e apresenta registros rastreáveis sem expor arquivos da biblioteca", async () => {
    mocks.location = "/espaco";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    mocks.casesQuery.mockReturnValue({ isLoading: false, data: [{ id: "case-real", title: "Caso autorizado", summary: "Registros rastreáveis", status: "active" }], error: undefined, refetch: vi.fn() });
    mocks.caseOverviewQuery.mockReturnValue({
      isLoading: false,
      data: {
        ownerCase: { id: "case-real", title: "Caso autorizado" },
        strategies: [],
        memorialEntries: [
          { id: "memorial-1", title: "Marco temporal", narrative: "Registro factual em revisão.", entryType: "cronologia", referenceDate: null, chronologyStatus: "pending_confirmation", chronologyConfidence: "unknown", reviewStatus: "pending_review", sourceReference: "Fonte conversacional autorizada" },
          { id: "memorial-2", title: "Data documental", narrative: "Registro com data confirmada na fonte.", entryType: "documento", referenceDate: "2026-08-10T12:00:00.000Z", chronologyStatus: "verified", chronologyConfidence: "high", reviewStatus: "verified", sourceReference: "Documento autorizado" },
        ],
        assets: [{ id: "asset-1", title: "Referência patrimonial", details: "Indício documental em revisão.", assetType: "patrimonio", reviewStatus: "pending_review", sourceReference: "Anexo autorizado" }],
        documents: [{ id: "document-1", title: "Comprovante registrado", documentType: "comprovante", reviewStatus: "pending_review", sourceReference: "Anexo autorizado" }],
        scenarios: [{ id: "scenario-1", title: "Cenário técnico", narrative: "Hipótese para revisão humana.", reviewStatus: "draft", sourceReference: "Minuta autorizada" }],
      },
      error: undefined,
      refetch: vi.fn(),
    });
    const { rerender } = renderWorkspace();

    await waitFor(() => expect(screen.getByText("Marco temporal")).toBeDefined());
    expect(screen.getByText("Data documental")).toBeDefined();
    expect(screen.getByText("Referência patrimonial")).toBeDefined();
    expect(screen.getByText(/cronologia pendente de confirmação/i)).toBeDefined();
    expect(screen.getByText(/data de referência verificada: 10\/08\/2026/i)).toBeDefined();
    expect(screen.getByText(/fonte conversacional autorizada/i)).toBeDefined();
    fireEvent.click(screen.getByRole("button", { name: "Negociação" }));
    mocks.location = "/espaco/negociacao";
    rerender(<ThemeProvider defaultTheme="navy" switchable><OwnerWorkspace /></ThemeProvider>);
    expect(screen.getAllByText("Mesa de negociação").length).toBeGreaterThan(0);
    expect(screen.getByRole("combobox", { name: "Cenário da proposta" })).toBeDefined();
    fireEvent.click(screen.getByRole("button", { name: "Biblioteca" }));
    mocks.location = "/espaco/biblioteca";
    rerender(<ThemeProvider defaultTheme="navy" switchable><OwnerWorkspace /></ThemeProvider>);
    const libraryCard = screen.getByText("Biblioteca do caso").closest("article");
    expect(libraryCard).not.toBeNull();
    expect(within(libraryCard!).getByText("Comprovante registrado")).toBeDefined();
    expect(screen.getByText(/arquivo ainda não armazenado/i)).toBeDefined();
  });

  it("recolhe a barra pelo logotipo e oferece um controle para reabri-la", () => {
    mocks.location = "/espaco";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active", emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true },
      error: undefined,
      refetch: vi.fn(),
    });
    renderWorkspace();

    fireEvent.click(screen.getByRole("button", { name: /recolher navegação/i }));
    expect(screen.getByRole("button", { name: /abrir navegação lateral/i })).toBeDefined();
  });

  it("mostra uma visão geral vazia e atualiza a lista após a criação real de um caso", () => {
    const refetch = vi.fn();
    let visibleCases: Array<{ id: string; title: string; summary?: string; status: string }> = [];
    mocks.location = "/espaco";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active" }, remainingRecoveryCodes: 10 },
      error: undefined,
      refetch: vi.fn(),
    });
    mocks.casesQuery.mockImplementation(() => ({ isLoading: false, data: visibleCases, error: undefined, refetch }));
    mocks.createCaseMutation.mockImplementation((options) => {
      return {
      isPending: false,
      mutate: (input: { title: string; summary?: string }) => {
        const ownerCase = { id: "case-real", title: input.title, summary: input.summary, status: "draft" };
        visibleCases = [ownerCase];
        options.onSuccess?.(ownerCase);
      },
    };
    });
    renderWorkspace();

    expect(screen.getByText(/nenhum caso criado ainda/i)).toBeDefined();
    expect(screen.getByText(/não foram inseridos casos/i)).toBeDefined();
    fireEvent.click(screen.getByRole("button", { name: /^criar caso$/i }));
    fireEvent.change(screen.getByLabelText("Título do caso"), { target: { value: "Acordo patrimonial" } });
    fireEvent.click(screen.getByRole("button", { name: /confirmar criação/i }));

    expect(refetch).toHaveBeenCalled();
    expect(screen.getByText("Acordo patrimonial")).toBeDefined();
  });

  it("mantém o carregamento e oferece nova tentativa quando a consulta de casos falha", () => {
    const refetch = vi.fn();
    mocks.location = "/espaco";
    mocks.dashboardQuery.mockReturnValue({
      isLoading: false,
      data: { owner: { displayName: "Titular", email: "titular@exemplo.test", state: "active" }, remainingRecoveryCodes: 10 },
      error: undefined,
      refetch: vi.fn(),
    });
    mocks.casesQuery.mockReturnValue({ isLoading: true, data: undefined, error: undefined, refetch });
    renderWorkspace();
    expect(screen.getByText(/carregando seus casos/i)).toBeDefined();

    cleanup();
    mocks.casesQuery.mockReturnValue({ isLoading: false, data: undefined, error: new Error("network"), refetch });
    renderWorkspace();
    fireEvent.click(screen.getByRole("button", { name: /tentar novamente/i }));
    expect(refetch).toHaveBeenCalled();
  });
});
