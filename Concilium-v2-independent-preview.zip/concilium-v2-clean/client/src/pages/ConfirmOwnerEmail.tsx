import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, MailWarning, ShieldCheck } from "lucide-react";
import React, { useEffect, useState } from "react";

function messageFrom(error: unknown) {
  return error instanceof Error ? error.message : "Não foi possível confirmar este link.";
}

export default function ConfirmOwnerEmail() {
  const [status, setStatus] = useState<"processing" | "confirmed" | "failed">("processing");
  const [message, setMessage] = useState("Validando o link seguro…");
  const confirmEmail = trpc.ownerActivation.confirmEmailVerification.useMutation();

  useEffect(() => {
    const url = new URL(window.location.href);
    const token = url.searchParams.get("token");
    // Evita que o token permaneça no histórico depois da leitura inicial.
    window.history.replaceState({}, document.title, "/confirmar-email");
    if (!token) {
      setStatus("failed");
      setMessage("O link de confirmação está incompleto.");
      return;
    }
    void confirmEmail.mutateAsync({ token })
      .then(result => {
        setStatus("confirmed");
        setMessage(`O e-mail ${result.email} foi confirmado. Volte à ativação para configurar a contingência.`);
      })
      .catch(error => {
        setStatus("failed");
        setMessage(messageFrom(error));
      });
    // A mutação é usada uma única vez na abertura intencional deste link.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const succeeded = status === "confirmed";
  return (
    <main className="concilium-app-shell grid min-h-screen place-items-center px-4 py-8">
      <section className="concilium-card w-full max-w-lg rounded-[28px] border border-[var(--concilium-card-border)] p-7 text-center sm:p-10">
        <span className="c-tint c-accent mx-auto grid h-12 w-12 place-items-center rounded-2xl">
          {status === "processing" ? <ShieldCheck size={22} /> : succeeded ? <CheckCircle2 size={22} /> : <MailWarning size={22} />}
        </span>
        <p className="c-accent mt-7 text-[10px] font-bold uppercase tracking-[0.2em]">Concilium · confirmação institucional</p>
        <h1 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">{status === "processing" ? "Validando o link." : succeeded ? "E-mail confirmado." : "Não foi possível confirmar."}</h1>
        <p className="c-copy mt-5 text-[14px] leading-7">{message}</p>
        {status !== "processing" && <Button onClick={() => window.location.assign("/ativacao")} className="c-primary-button mt-8 h-12 rounded-xl px-5 text-[13px] font-bold">Voltar à ativação</Button>}
      </section>
    </main>
  );
}
