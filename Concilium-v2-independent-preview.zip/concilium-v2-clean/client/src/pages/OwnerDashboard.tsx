import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { startAuthentication } from "@simplewebauthn/browser";
import { ArrowLeft, Copy, FileLock2, KeyRound, RefreshCw, ShieldCheck, SquareArrowOutUpRight } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";

export function getOwnerDashboardRedirectPath(input: { isLoading: boolean; hasDashboard: boolean; errorCode?: string }) {
  return !input.isLoading && !input.hasDashboard && input.errorCode === "UNAUTHORIZED" ? "/ativacao" : null;
}

export default function OwnerDashboard() {
  const [, setLocation] = useLocation();
  const dashboard = trpc.ownerActivation.dashboard.useQuery();
  const logout = trpc.ownerActivation.logout.useMutation({ onSuccess: () => setLocation("/ativacao") });
  const beginRecoveryRenewal = trpc.ownerActivation.beginRecoveryCodeRegeneration.useMutation();
  const finishRecoveryRenewal = trpc.ownerActivation.finishRecoveryCodeRegeneration.useMutation({ onSuccess: () => dashboard.refetch() });
  const [newRecoveryCodes, setNewRecoveryCodes] = useState<string[] | null>(null);
  const [recoveryError, setRecoveryError] = useState<string | null>(null);
  const redirectPath = getOwnerDashboardRedirectPath({
    isLoading: dashboard.isLoading,
    hasDashboard: Boolean(dashboard.data),
    errorCode: dashboard.error?.data?.code,
  });

  useEffect(() => {
    if (redirectPath) setLocation(redirectPath, { replace: true });
  }, [redirectPath, setLocation]);

  if (dashboard.isLoading || redirectPath) return <div className="concilium-app-shell grid min-h-screen place-items-center"><p className="c-copy text-sm">{redirectPath ? "Redirecionando para a área reservada…" : "Abrindo área do titular…"}</p></div>;
  if (!dashboard.data) return <main className="concilium-app-shell grid min-h-screen place-items-center px-5"><section className="concilium-card c-border max-w-md rounded-3xl border p-8 text-center"><FileLock2 className="c-accent mx-auto" size={28} /><h1 className="font-editorial c-ink mt-5 text-3xl">Não foi possível abrir a área do titular.</h1><p className="c-copy mt-4 text-sm leading-6">A sessão não foi alterada. Verifique sua conexão e tente novamente; se o problema continuar, aguarde alguns instantes antes de repetir a operação.</p><Button onClick={() => dashboard.refetch()} className="c-deep-button mt-7 rounded-xl">Tentar novamente</Button></section></main>;
  const { owner } = dashboard.data!;
  const renewRecoveryCodes = async () => {
    setRecoveryError(null);
    try {
      const options = await beginRecoveryRenewal.mutateAsync();
      const response = await startAuthentication({ optionsJSON: options });
      const result = await finishRecoveryRenewal.mutateAsync({ response });
      setNewRecoveryCodes(result.recoveryCodes);
    } catch (error) { setRecoveryError(error instanceof Error ? error.message : "Não foi possível renovar os códigos agora."); }
  };
  const copyNewCodes = async () => {
    if (newRecoveryCodes) await navigator.clipboard.writeText(newRecoveryCodes.join("\n"));
  };
  return <main className="concilium-app-shell min-h-screen px-4 py-8 sm:px-6 sm:py-12"><div className="mx-auto max-w-6xl"><a href="/espaco/configuracoes" className="c-copy inline-flex items-center gap-2 text-[12px] font-bold hover:[color:var(--concilium-accent)]"><ArrowLeft size={15} /> Voltar às configurações</a><header className="mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Painel de segurança do titular</p><h1 className="font-editorial c-ink mt-3 text-5xl tracking-[-0.05em]">Olá, {owner.displayName}.</h1><p className="c-copy mt-3 text-sm">{owner.email} · identidade ativada e protegida por passkey.</p></div><div className="flex items-center gap-3"><span className="c-success-tint c-success-ink inline-flex w-fit items-center gap-2 rounded-full px-4 py-2 text-[11px] font-bold"><ShieldCheck size={15} className="c-success" /> Sessão protegida</span><Button variant="outline" onClick={() => logout.mutate()} disabled={logout.isPending} className="c-border c-ink h-9 rounded-xl bg-transparent text-[11px] hover:[background:var(--concilium-tint)]">Sair</Button></div></header><section className="concilium-card c-border mt-8 flex flex-col justify-between gap-5 rounded-3xl border p-6 sm:flex-row sm:items-center"><div><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Próximo ambiente</p><h2 className="font-editorial c-ink mt-2 text-3xl">Volte ao espaço interno.</h2><p className="c-copy mt-2 text-sm leading-6">Os controles de identidade foram abertos pelas Configurações e continuam separados dos registros do caso.</p></div><Button onClick={() => setLocation("/espaco/configuracoes")} className="c-deep-button h-11 rounded-xl"><SquareArrowOutUpRight size={16} /> Voltar às configurações</Button></section><section className="mt-10 grid gap-4 md:grid-cols-3"><article className="concilium-card c-border rounded-2xl border p-6"><KeyRound className="c-accent" size={19} /><h2 className="c-ink mt-6 text-sm font-bold">Passkey ativa</h2><p className="c-copy mt-2 text-[12px] leading-5">A confirmação do aparelho é o acesso rotineiro. Nenhuma senha diária foi criada.</p></article><article className="concilium-card c-border rounded-2xl border p-6"><ShieldCheck className="c-success" size={19} /><h2 className="c-ink mt-6 text-sm font-bold">Códigos de recuperação</h2><p className="c-copy mt-2 text-[12px] leading-5"><strong className="c-ink">{dashboard.data.remainingRecoveryCodes} disponíveis.</strong> Cada código é de uso único; use-os apenas se a passkey não estiver disponível.</p><Button onClick={renewRecoveryCodes} disabled={beginRecoveryRenewal.isPending || finishRecoveryRenewal.isPending} variant="outline" className="c-border c-ink mt-5 h-9 rounded-xl bg-transparent text-[11px]"><RefreshCw size={13} /> Renovar com passkey</Button></article><article className="concilium-card c-border rounded-2xl border p-6"><FileLock2 className="c-accent" size={19} /><h2 className="c-ink mt-6 text-sm font-bold">Convites bloqueados</h2><p className="c-copy mt-2 text-[12px] leading-5">Os convites serão liberados somente quando o módulo de casos estiver implementado.</p></article></section>{recoveryError && <p role="alert" className="c-error mt-6 text-sm">{recoveryError}</p>}{newRecoveryCodes && <section className="concilium-card c-border mt-8 max-w-2xl rounded-2xl border p-6"><p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Nova lista emitida</p><h2 className="font-editorial c-ink mt-3 text-3xl">Guarde estes códigos agora.</h2><p className="c-copy mt-3 text-sm leading-6">A lista anterior foi invalidada. Estes códigos só são mostrados uma vez; armazene-os fora do dispositivo em local seguro.</p><pre className="c-tint c-ink mt-5 whitespace-pre-wrap rounded-xl p-4 text-sm leading-7">{newRecoveryCodes.join("\n")}</pre><Button onClick={copyNewCodes} variant="outline" className="c-border c-ink mt-4 rounded-xl bg-transparent text-[11px]"><Copy size={13} /> Copiar nova lista</Button></section>}</div></main>;
}
