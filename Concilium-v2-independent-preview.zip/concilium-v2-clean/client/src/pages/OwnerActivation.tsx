import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { startAuthentication, startRegistration } from "@simplewebauthn/browser";
import { QRCodeSVG } from "qrcode.react";
import { ArrowLeft, Check, Copy, KeyRound, LockKeyhole, MailCheck, ShieldCheck, Smartphone, TriangleAlert } from "lucide-react";
import React, { useMemo, useState } from "react";

type Screen = "identity" | "passkey" | "email" | "totp" | "recovery" | "login" | "contingency";
type OwnerActivationProps = { onAuthenticated?: (path: string) => void };

function toErrorMessage(error: unknown) {
  if (error instanceof Error) return error.message;
  return "Não foi possível concluir esta etapa. Tente novamente.";
}

function Step({ active, number, title }: { active: boolean; number: number; title: string }) {
  return <div className={`flex items-center gap-2 text-[11px] font-bold ${active ? "c-accent" : "c-soft"}`}><span className={`grid h-6 w-6 place-items-center rounded-full ${active ? "c-accent-bg c-on-accent" : "c-card-alt"}`}>{number}</span>{title}</div>;
}

export default function OwnerActivation({ onAuthenticated = path => window.location.assign(path) }: OwnerActivationProps) {
  const [screen, setScreen] = useState<Screen>("identity");
  const [bootstrapCode, setBootstrapCode] = useState("");
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [totpUri, setTotpUri] = useState("");
  const [manualKey, setManualKey] = useState("");
  const [totpCode, setTotpCode] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [recoveryCodes, setRecoveryCodes] = useState<string[]>([]);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const status = trpc.ownerActivation.status.useQuery();
  const beginSetup = trpc.ownerActivation.beginSetup.useMutation();
  const finishPasskeyRegistration = trpc.ownerActivation.finishPasskeyRegistration.useMutation();
  const activateWithPasskey = trpc.ownerActivation.activateWithPasskey.useMutation();
  const resendEmailConfirmation = trpc.ownerActivation.resendEmailConfirmation.useMutation();
  const beginTotpSetup = trpc.ownerActivation.beginTotpSetup.useMutation();
  const confirmTotpAndActivate = trpc.ownerActivation.confirmTotpAndActivate.useMutation();
  const beginPasskeyLogin = trpc.ownerActivation.beginPasskeyLogin.useMutation();
  const finishPasskeyLogin = trpc.ownerActivation.finishPasskeyLogin.useMutation();
  const useTotpContingency = trpc.ownerActivation.useTotpContingency.useMutation();
  const useRecoveryCode = trpc.ownerActivation.useRecoveryCode.useMutation();

  const loading = beginSetup.isPending || finishPasskeyRegistration.isPending || activateWithPasskey.isPending || resendEmailConfirmation.isPending || beginTotpSetup.isPending || confirmTotpAndActivate.isPending || beginPasskeyLogin.isPending || finishPasskeyLogin.isPending || useTotpContingency.isPending || useRecoveryCode.isPending;
  const ownerActive = status.data?.ownerState === "active";
  const currentStep = useMemo(() => screen === "identity" ? 1 : screen === "passkey" ? 2 : screen === "email" ? 3 : screen === "totp" ? 4 : 5, [screen]);

  const clearFeedback = () => { setError(""); setNotice(""); };

  const registerPasskey = async () => {
    clearFeedback();
    try {
      const options = await beginSetup.mutateAsync({ code: bootstrapCode.trim(), email: email.trim(), displayName: displayName.trim() });
      setScreen("passkey");
      const response = await startRegistration({ optionsJSON: options });
      await finishPasskeyRegistration.mutateAsync({ response });
      const result = await activateWithPasskey.mutateAsync();
      setRecoveryCodes(result.recoveryCodes);
      setNotice("Acesso titular ativado com passkey. Guarde os códigos de recuperação em local protegido.");
      setScreen("recovery");
    } catch (reason) {
      setError(toErrorMessage(reason));
      setScreen("identity");
    }
  };

  const continueAfterEmailVerification = async () => {
    clearFeedback();
    try {
      const totp = await beginTotpSetup.mutateAsync();
      setTotpUri(totp.provisioningUri);
      setManualKey(totp.manualKey);
      setScreen("totp");
    } catch (reason) {
      setError(toErrorMessage(reason));
    }
  };

  const resendConfirmation = async () => {
    clearFeedback();
    try {
      const result = await resendEmailConfirmation.mutateAsync();
      setNotice(result.alreadyVerified ? "O e-mail institucional já está confirmado. Você pode continuar." : "Novo link enviado. O anterior foi invalidado por segurança.");
    } catch (reason) { setError(toErrorMessage(reason)); }
  };

  const confirmTotp = async () => {
    clearFeedback();
    try {
      const result = await confirmTotpAndActivate.mutateAsync({ code: totpCode.replace(/\s/g, "") });
      setRecoveryCodes(result.recoveryCodes);
      setScreen("recovery");
    } catch (reason) { setError(toErrorMessage(reason)); }
  };

  const loginWithPasskey = async () => {
    clearFeedback();
    try {
      const options = await beginPasskeyLogin.mutateAsync();
      const response = await startAuthentication({ optionsJSON: options });
      await finishPasskeyLogin.mutateAsync({ response });
      onAuthenticated("/espaco");
    } catch (reason) { setError(toErrorMessage(reason)); }
  };

  const loginWithTotpContingency = async () => {
    clearFeedback();
    try {
      await useTotpContingency.mutateAsync({ code: totpCode.replace(/\s/g, "") });
      onAuthenticated("/espaco");
    } catch (reason) { setError(toErrorMessage(reason)); }
  };

  const loginWithRecoveryCode = async () => {
    clearFeedback();
    try {
      const result = await useRecoveryCode.mutateAsync({ code: recoveryCode });
      setNotice(`Código de recuperação aceito. Restam ${result.remainingRecoveryCodes} código(s); gere novos códigos após entrar.`);
      onAuthenticated("/espaco");
    } catch (reason) { setError(toErrorMessage(reason)); }
  };

  const copyRecoveryCodes = async () => {
    await navigator.clipboard.writeText(recoveryCodes.join("\n"));
    setNotice("Códigos copiados. Guarde-os fora do dispositivo, em local protegido.");
  };

  const copyManualKey = async () => {
    await navigator.clipboard.writeText(manualKey);
    setNotice("Chave copiada para configuração manual no aplicativo autenticador.");
  };

  if (status.isLoading) return <div className="concilium-app-shell grid min-h-screen place-items-center"><p className="c-copy text-sm">Verificando a ativação segura…</p></div>;

  return (
    <main className="concilium-app-shell min-h-screen px-4 py-8 sm:px-6 sm:py-12">
      <div className="mx-auto max-w-5xl">
        <a href="/" className="c-copy inline-flex items-center gap-2 text-[12px] font-bold transition-colors hover:[color:var(--concilium-accent)]"><ArrowLeft size={15} /> Voltar ao site institucional</a>
        <div className="mt-6 grid overflow-hidden rounded-[30px] border border-[var(--concilium-card-border)] lg:grid-cols-[0.82fr_1.18fr]">
          <aside className="concilium-showcase p-7 sm:p-10">
            <span className="c-tint c-accent grid h-11 w-11 place-items-center rounded-2xl"><ShieldCheck size={21} /></span>
            <p className="c-accent mt-7 text-[10px] font-bold uppercase tracking-[0.2em]">{ownerActive ? "Acesso titular" : "Ativação exclusiva"}</p>
            <h1 className="font-editorial c-showcase-ink mt-4 text-[43px] leading-[0.95] tracking-[-0.05em]">{ownerActive ? "Seu acesso está protegido." : "A conta titular começa aqui."}</h1>
            <p className="c-showcase-copy mt-6 text-[14px] leading-7">{ownerActive ? "A conta já está configurada. Confirme a passkey do seu dispositivo para entrar com biometria, reconhecimento facial ou PIN local." : "Este fluxo cria a identidade própria do Concilium. Ele não usa contas Google, Facebook, Microsoft nem sessões de outro projeto."}</p>
            {ownerActive ? (
              <div className="concilium-showcase-soft-card c-showcase-border mt-9 rounded-2xl border p-5">
                <p className="c-showcase-ink text-[12px] font-bold">Acesso rotineiro</p>
                <p className="c-showcase-soft mt-2 text-[11px] leading-5">A passkey é o caminho normal. Os códigos de recuperação são apenas uma contingência e não serão solicitados enquanto a passkey estiver disponível.</p>
              </div>
            ) : (
              <div className="c-showcase-border mt-9 space-y-4 border-t pt-7">
                <Step active={currentStep >= 1} number={1} title="Vincular a conta titular" />
                <Step active={currentStep >= 2} number={2} title="Registrar a passkey" />
                <Step active={currentStep >= 3} number={3} title="Confirmar o e-mail" />
                <Step active={currentStep >= 4} number={4} title="Configurar contingência" />
                <Step active={currentStep >= 5} number={5} title="Guardar recuperação" />
              </div>
            )}
            <div className="concilium-showcase-soft-card mt-9 rounded-2xl border p-4"><p className="c-showcase-ink text-[12px] font-bold">Como será o uso normal</p><p className="c-showcase-soft mt-2 text-[11px] leading-5">Depois da ativação, a passkey será o acesso rotineiro. O código do autenticador só entra em contingência, recuperação ou reautenticação sensível.</p></div>
          </aside>

          <section className="concilium-card p-6 sm:p-10">
            {error && <div role="alert" className="mb-6 flex items-start gap-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-4 text-[12px] leading-5 text-red-700 dark:text-red-200"><TriangleAlert size={17} className="shrink-0" />{error}</div>}
            {notice && <div className="concilium-security-note c-success-ink mb-6 flex items-start gap-3 rounded-2xl border p-4 text-[12px] leading-5"><Check size={17} className="c-success shrink-0" />{notice}</div>}

            {ownerActive && screen !== "recovery" && screen !== "contingency" ? (
              <div className="max-w-lg">
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Área titular</p>
                <h2 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">Entrar com passkey.</h2>
                <p className="c-copy mt-5 text-[14px] leading-7">A conta titular já foi ativada. Confirme no seu aparelho para abrir o painel interno. Não há senha de uso diário.</p>
                <Button onClick={loginWithPasskey} disabled={loading} className="c-deep-button mt-8 h-12 rounded-xl px-5 text-[13px] font-bold"><KeyRound size={16} />{loading ? "Verificando…" : "Confirmar com passkey"}</Button>
                <p className="c-soft mt-5 text-[11px] leading-5">O TOTP configurado no aplicativo autenticador fica reservado para indisponibilidade da passkey, recuperação ou ação sensível.</p>
                <button type="button" onClick={() => { clearFeedback(); setScreen("contingency"); }} className="c-accent-strong mt-4 text-[11px] font-bold underline underline-offset-4">A passkey não está disponível</button>
              </div>
            ) : screen === "identity" ? (
              <div className="max-w-lg">
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Primeira configuração</p>
                <h2 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">Vincule a conta titular.</h2>
                <p className="c-copy mt-5 text-[14px] leading-7">Use o código único definido por você, como administrador do projeto. Ele não é um código do Google Authenticator e não deve ser compartilhado.</p>
                {!status.data?.activationConfigured && <p className="mt-5 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-[12px] leading-5 text-amber-800 dark:text-amber-100">O código de ativação ainda não foi definido nas configurações seguras do projeto. Configure-o antes de iniciar.</p>}
                <div className="mt-8 grid gap-5">
                  <div><Label htmlFor="owner-name" className="c-ink text-[12px] font-bold">Nome do titular</Label><Input id="owner-name" value={displayName} onChange={event => setDisplayName(event.target.value)} placeholder="Nome completo" className="c-border c-ink mt-2 h-11 bg-transparent" autoComplete="name" /></div>
                  <div><Label htmlFor="owner-email" className="c-ink text-[12px] font-bold">E-mail institucional</Label><Input id="owner-email" value={email} onChange={event => setEmail(event.target.value)} placeholder="titular@dominio.com" className="c-border c-ink mt-2 h-11 bg-transparent" type="email" autoComplete="email" /></div>
                  <div><Label htmlFor="activation-code" className="c-ink text-[12px] font-bold">Código único de ativação</Label><Input id="activation-code" value={bootstrapCode} onChange={event => setBootstrapCode(event.target.value)} placeholder="Cole o código definido nas configurações seguras" className="c-border c-ink mt-2 h-11 bg-transparent" type="password" autoComplete="one-time-code" /></div>
                </div>
                <Button onClick={registerPasskey} disabled={loading || !status.data?.activationConfigured || displayName.trim().length < 2 || !email.includes("@") || bootstrapCode.trim().length < 20} className="c-primary-button mt-8 h-12 rounded-xl px-5 text-[13px] font-bold"><KeyRound size={16} />{loading ? "Preparando…" : "Criar passkey e continuar"}</Button>
              </div>
            ) : screen === "passkey" ? <div className="grid min-h-[360px] place-items-center text-center"><KeyRound className="c-accent h-10 w-10" /><p className="c-ink mt-5 text-sm font-bold">Confirme a passkey no seu aparelho.</p><p className="c-copy mt-2 max-w-sm text-[12px] leading-5">O navegador abriu a confirmação segura. Em seguida, confirme o e-mail institucional antes de configurar a contingência.</p></div> : screen === "email" ? (
              <div className="max-w-lg">
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Confirmação verificável</p>
                <MailCheck className="c-accent mt-5" size={32} />
                <h2 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">Confirme o e-mail institucional.</h2>
                <p className="c-copy mt-5 text-[14px] leading-7">Enviamos um link de uso único para <strong className="c-ink">{email}</strong>. Abra-o na caixa de entrada e, depois, volte a esta tela para continuar. O link expira em 30 minutos.</p>
                <Button onClick={continueAfterEmailVerification} disabled={loading} className="c-primary-button mt-8 h-12 rounded-xl px-5 text-[13px] font-bold"><Check size={16} />{loading ? "Verificando…" : "Já confirmei o e-mail"}</Button>
                <button type="button" onClick={resendConfirmation} disabled={loading} className="c-accent-strong mt-5 block text-[11px] font-bold underline underline-offset-4 disabled:opacity-50">{loading ? "Aguarde…" : "Reenviar link e invalidar o anterior"}</button>
              </div>
            ) : screen === "totp" ? (
              <div className="max-w-lg">
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Contingência, não rotina</p>
                <h2 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">Configure o autenticador.</h2>
                <p className="c-copy mt-5 text-[14px] leading-7">Abra Google Authenticator, Microsoft Authenticator ou aplicativo compatível; escaneie o QR Code e informe apenas o primeiro código. Depois, a passkey será seu acesso normal.</p>
                <div className="c-card-alt c-border mt-7 flex flex-col items-center gap-5 rounded-2xl border p-6 sm:flex-row sm:items-start"><div className="rounded-xl bg-white p-3"><QRCodeSVG value={totpUri} size={148} includeMargin={false} /></div><div className="min-w-0"><p className="c-ink text-[12px] font-bold">Não consegue escanear?</p><p className="c-copy mt-2 break-all text-[11px] leading-5">{manualKey}</p><Button variant="outline" onClick={copyManualKey} className="c-border c-ink mt-3 h-9 rounded-lg bg-transparent text-[11px] hover:[background:var(--concilium-tint)]"><Copy size={13} /> Copiar chave</Button></div></div>
                <div className="mt-7"><Label htmlFor="totp-code" className="c-ink text-[12px] font-bold">Código de 6 dígitos</Label><Input id="totp-code" value={totpCode} onChange={event => setTotpCode(event.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" placeholder="000000" className="c-border c-ink mt-2 h-12 max-w-xs bg-transparent text-center text-lg tracking-[0.35em]" /></div>
                <Button onClick={confirmTotp} disabled={loading || totpCode.length !== 6} className="c-primary-button mt-6 h-12 rounded-xl px-5 text-[13px] font-bold"><Smartphone size={16} />{loading ? "Confirmando…" : "Confirmar contingência"}</Button>
              </div>
            ) : screen === "contingency" ? (
              <div className="max-w-lg">
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Uso excepcional</p>
                <h2 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">Recupere o acesso.</h2>
                <p className="c-copy mt-5 text-[14px] leading-7">Use o código atual do autenticador somente se a passkey estiver indisponível. Caso também não tenha o autenticador, use um dos códigos de recuperação guardados na ativação.</p>
                <div className="c-card-alt c-border mt-7 rounded-2xl border p-5">
                  <Label htmlFor="contingency-totp" className="c-ink text-[12px] font-bold">Código do autenticador</Label>
                  <Input id="contingency-totp" value={totpCode} onChange={event => setTotpCode(event.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" placeholder="000000" className="c-border c-ink mt-2 h-12 max-w-xs bg-transparent text-center text-lg tracking-[0.35em]" />
                  <Button onClick={loginWithTotpContingency} disabled={loading || totpCode.length !== 6} className="c-primary-button mt-4 h-11 rounded-xl px-5 text-[12px] font-bold"><Smartphone size={15} />{loading ? "Verificando…" : "Usar contingência"}</Button>
                </div>
                <div className="c-border mt-5 border-t pt-5"><Label htmlFor="recovery-code" className="c-ink text-[12px] font-bold">Código de recuperação</Label><Input id="recovery-code" value={recoveryCode} onChange={event => setRecoveryCode(event.target.value.toUpperCase())} placeholder="Cole um código guardado" className="c-border c-ink mt-2 h-11 bg-transparent font-mono" autoComplete="one-time-code" /><Button variant="outline" onClick={loginWithRecoveryCode} disabled={loading || recoveryCode.trim().length < 8} className="c-border c-ink mt-4 h-10 rounded-xl bg-transparent text-[12px] hover:[background:var(--concilium-tint)]"><LockKeyhole size={14} /> Usar código de recuperação</Button></div>
                <button type="button" onClick={() => { clearFeedback(); setScreen("login"); }} className="c-copy mt-6 text-[11px] font-bold underline underline-offset-4">Voltar para passkey</button>
              </div>
            ) : (
              <div className="max-w-lg">
                <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.2em]">Ativação concluída</p>
                <h2 className="font-editorial c-ink mt-4 text-[39px] leading-[0.96] tracking-[-0.04em]">Guarde os códigos de recuperação.</h2>
                <p className="c-copy mt-5 text-[14px] leading-7">Use cada código somente se perder a passkey e o autenticador. Eles não serão exibidos outra vez.</p>
                <div className="c-card-alt c-border mt-7 grid grid-cols-2 gap-2 rounded-2xl border p-5 font-mono text-[12px] sm:grid-cols-3">{recoveryCodes.map(code => <span key={code} className="c-ink rounded-lg bg-[var(--concilium-card)] px-2 py-2 text-center">{code}</span>)}</div>
                <Button variant="outline" onClick={copyRecoveryCodes} className="c-border c-ink mt-5 h-10 rounded-xl bg-transparent text-[12px] hover:[background:var(--concilium-tint)]"><Copy size={14} /> Copiar códigos</Button>
                <Button onClick={() => window.location.assign("/app")} className="c-primary-button mt-3 h-12 w-full rounded-xl text-[13px] font-bold"><LockKeyhole size={16} /> Abrir área do titular</Button>
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
