import React, { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export const conciliumThemes = [
  { id: "navy", name: "Azul-noturno", description: "Profundo, reservado e institucional.", preview: ["#17263a", "#21364e", "#e9b578"] },
  { id: "ivory", name: "Claro editorial", description: "A versão luminosa e original da interface.", preview: ["#f5f2ed", "#fbfaf7", "#17263a"] },
  { id: "forest", name: "Verde-pinho", description: "Sóbrio, calmo e orientado à privacidade.", preview: ["#102e2b", "#1b4840", "#e1b56c"] },
  { id: "slate", name: "Grafite", description: "Neutro, técnico e de baixo contraste visual.", preview: ["#20242b", "#303640", "#c6ccd5"] },
  { id: "amber", name: "Âmbar original", description: "Marfim, âmbar e verde-musgo da primeira identidade.", preview: ["#fbfaf5", "#f5efdf", "#b4985a"] },
] as const;

export type Theme = (typeof conciliumThemes)[number]["id"];

const themeStorageKey = "concilium-theme";

function isTheme(value: string | null): value is Theme {
  return conciliumThemes.some(theme => theme.id === value);
}

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme?: () => void;
  switchable: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: Theme;
  switchable?: boolean;
}

export function ThemeProvider({
  children,
  defaultTheme = "navy",
  switchable = true,
}: ThemeProviderProps) {
  const [theme, updateTheme] = useState<Theme>(() => {
    if (switchable && typeof window !== "undefined") {
      const stored = localStorage.getItem(themeStorageKey);
      return isTheme(stored) ? stored : defaultTheme;
    }
    return defaultTheme;
  });

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.conciliumTheme = theme;
    root.classList.toggle("dark", theme !== "ivory" && theme !== "amber");

    if (switchable) {
      localStorage.setItem(themeStorageKey, theme);
    }
  }, [theme, switchable]);

  const setTheme = (nextTheme: Theme) => {
    if (switchable) updateTheme(nextTheme);
  };

  const toggleTheme = switchable
    ? () => setTheme(theme === "ivory" ? "navy" : "ivory")
    : undefined;

  const value = useMemo(
    () => ({ theme, setTheme, toggleTheme, switchable }),
    [theme, switchable]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within ThemeProvider");
  }
  return context;
}
