export type WorkspaceSectionKey =
  | "visao-geral"
  | "estrategias"
  | "negociacao"
  | "biblioteca"
  | "governanca"
  | "auditoria"
  | "comite-ia"
  | "configuracoes";

export type LanguagePackId = "pt-BR" | "en-US" | "es-ES" | "fr-FR";

type SectionCopy = {
  label: string;
  eyebrow: string;
  title: string;
  description: string;
};

export type LanguagePack = {
  id: LanguagePackId;
  locale: string;
  flag: string;
  name: string;
  nativeName: string;
  sections: Record<WorkspaceSectionKey, SectionCopy>;
  ui: {
    workspace: string;
    settings: string;
    language: string;
    languageDescription: string;
    installedPacks: string;
    loadPacks: string;
    availablePacks: string;
    install: string;
    installing: string;
    installed: string;
    selectLanguage: string;
    packageLocalOnly: string;
  };
};

const portugueseSections: Record<WorkspaceSectionKey, SectionCopy> = {
  "visao-geral": { label: "Visão geral", eyebrow: "Painel de controle", title: "Casos e acordos", description: "Acompanhe a condução reservada de cada caso, seus documentos e decisões verificáveis." },
  estrategias: { label: "Estratégias", eyebrow: "Painel de estratégias", title: "Cenários e próximos passos", description: "Organize cenários antes de formalizar qualquer proposta, mantendo a decisão humana como referência." },
  negociacao: { label: "Negociação", eyebrow: "Mesa de negociação", title: "Cenários e rascunhos técnicos", description: "Consulte cenários do caso em contexto protegido. Nenhum item é proposta enviada, aceite ou comunicação a terceiros." },
  biblioteca: { label: "Biblioteca", eyebrow: "Acervo documental", title: "Biblioteca protegida", description: "Documentos e anexos do caso são acessíveis com registro de visibilidade e validação da sessão titular." },
  governanca: { label: "Governança", eyebrow: "Governança de acesso", title: "Proteção e permissões", description: "Acompanhe os controles ativos da conta e do caso. Convites continuam desativados até uma abertura segura e expressamente autorizada." },
  auditoria: { label: "Auditoria", eyebrow: "Histórico do caso", title: "Decisões do caso", description: "Ações do caso serão preservadas com contexto, data e autoria para acompanhamento objetivo." },
  "comite-ia": { label: "Comitê de IA", eyebrow: "Ambiente reservado", title: "Comitê de IA", description: "O laboratório de análise assistida permanecerá exclusivo ao titular e só receberá conteúdo quando você autorizar uma análise." },
  configuracoes: { label: "Configurações", eyebrow: "Preferências do titular", title: "Configurações", description: "Ajuste a experiência do Concilium sem alterar a sua identidade, passkeys ou controles de segurança." },
};

export const languagePacks: Record<LanguagePackId, LanguagePack> = {
  "pt-BR": {
    id: "pt-BR", locale: "pt-BR", flag: "🇧🇷", name: "Português do Brasil", nativeName: "Português do Brasil", sections: portugueseSections,
    ui: { workspace: "Espaço interno", settings: "Configurações", language: "Idioma", languageDescription: "Escolha entre os pacotes instalados neste dispositivo. A alteração não envia dados, documentos ou decisões do caso.", installedPacks: "Pacotes instalados", loadPacks: "Carregar pacotes", availablePacks: "Pacotes disponíveis", install: "Instalar pacote", installing: "Instalando pacote…", installed: "Instalado", selectLanguage: "Selecionar idioma", packageLocalOnly: "Os pacotes são locais e alteram somente os rótulos da interface já cobertos por tradução." },
  },
  "en-US": {
    id: "en-US", locale: "en-US", flag: "🇺🇸", name: "English (United States)", nativeName: "English", sections: {
      "visao-geral": { label: "Overview", eyebrow: "Control panel", title: "Cases and agreements", description: "Follow the reserved handling of each case, its documents, and verifiable decisions." },
      estrategias: { label: "Strategies", eyebrow: "Strategy panel", title: "Scenarios and next steps", description: "Organize scenarios before formalizing a proposal, keeping human judgment as the reference." },
      negociacao: { label: "Negotiation", eyebrow: "Negotiation desk", title: "Offers and counteroffers", description: "The negotiation area will bring together rounds and formal records of each agreement in a protected context." },
      biblioteca: { label: "Library", eyebrow: "Document archive", title: "Protected library", description: "Documents and attachments will be available per case, with visibility and access records." },
      governanca: { label: "Governance", eyebrow: "Access governance", title: "People and permissions", description: "As the owner, you will manage permissions by case. Invitations remain disabled until a case is safely opened." },
      auditoria: { label: "Audit", eyebrow: "Case history", title: "Case decisions", description: "Case actions will be retained with context, date, and authorship for objective follow-up." },
      "comite-ia": { label: "AI Committee", eyebrow: "Reserved environment", title: "AI Committee", description: "The assisted-analysis workspace stays exclusive to the owner and only receives content when you authorize an analysis." },
      configuracoes: { label: "Settings", eyebrow: "Owner preferences", title: "Settings", description: "Adjust the Concilium experience without changing your identity, passkeys, or security controls." },
    },
    ui: { workspace: "Internal workspace", settings: "Settings", language: "Language", languageDescription: "Choose among packages installed on this device. The change does not send case data, documents, or decisions.", installedPacks: "Installed packages", loadPacks: "Load packages", availablePacks: "Available packages", install: "Install package", installing: "Installing package…", installed: "Installed", selectLanguage: "Select language", packageLocalOnly: "Packages are local and change only interface labels already covered by translation." },
  },
  "es-ES": {
    id: "es-ES", locale: "es-ES", flag: "🇪🇸", name: "Español (España)", nativeName: "Español", sections: {
      "visao-geral": { label: "Resumen", eyebrow: "Panel de control", title: "Casos y acuerdos", description: "Siga la gestión reservada de cada caso, sus documentos y decisiones verificables." },
      estrategias: { label: "Estrategias", eyebrow: "Panel de estrategias", title: "Escenarios y próximos pasos", description: "Organice escenarios antes de formalizar una propuesta, manteniendo la decisión humana como referencia." },
      negociacao: { label: "Negociación", eyebrow: "Mesa de negociación", title: "Propuestas y contrapropuestas", description: "El área de negociación reunirá rondas y registros formales de cada acuerdo en un contexto protegido." },
      biblioteca: { label: "Biblioteca", eyebrow: "Archivo documental", title: "Biblioteca protegida", description: "Los documentos y anexos estarán disponibles por caso, con registro de visibilidad y acceso." },
      governanca: { label: "Gobernanza", eyebrow: "Gobernanza de acceso", title: "Personas y permisos", description: "Como titular, administrará permisos por caso. Las invitaciones permanecen deshabilitadas hasta abrir un caso de forma segura." },
      auditoria: { label: "Auditoría", eyebrow: "Historial del caso", title: "Decisiones del caso", description: "Las acciones del caso se conservarán con contexto, fecha y autoría para un seguimiento objetivo." },
      "comite-ia": { label: "Comité de IA", eyebrow: "Entorno reservado", title: "Comité de IA", description: "El espacio de análisis asistido permanece exclusivo del titular y solo recibe contenido cuando usted autorice un análisis." },
      configuracoes: { label: "Configuración", eyebrow: "Preferencias del titular", title: "Configuración", description: "Ajuste la experiencia de Concilium sin cambiar su identidad, passkeys ni controles de seguridad." },
    },
    ui: { workspace: "Espacio interno", settings: "Configuración", language: "Idioma", languageDescription: "Elija entre los paquetes instalados en este dispositivo. El cambio no envía datos, documentos ni decisiones del caso.", installedPacks: "Paquetes instalados", loadPacks: "Cargar paquetes", availablePacks: "Paquetes disponibles", install: "Instalar paquete", installing: "Instalando paquete…", installed: "Instalado", selectLanguage: "Seleccionar idioma", packageLocalOnly: "Los paquetes son locales y cambian solo etiquetas de la interfaz ya cubiertas por traducción." },
  },
  "fr-FR": {
    id: "fr-FR", locale: "fr-FR", flag: "🇫🇷", name: "Français (France)", nativeName: "Français", sections: {
      "visao-geral": { label: "Vue d’ensemble", eyebrow: "Tableau de bord", title: "Dossiers et accords", description: "Suivez le traitement réservé de chaque dossier, de ses documents et de ses décisions vérifiables." },
      estrategias: { label: "Stratégies", eyebrow: "Panneau de stratégie", title: "Scénarios et prochaines étapes", description: "Organisez les scénarios avant de formaliser une proposition, en gardant la décision humaine comme référence." },
      negociacao: { label: "Négociation", eyebrow: "Table de négociation", title: "Offres et contre-offres", description: "L’espace de négociation réunira les étapes et les registres formels de chaque accord dans un contexte protégé." },
      biblioteca: { label: "Bibliothèque", eyebrow: "Archives documentaires", title: "Bibliothèque protégée", description: "Les documents et pièces jointes seront disponibles par dossier, avec une trace de visibilité et d’accès." },
      governanca: { label: "Gouvernance", eyebrow: "Gouvernance des accès", title: "Personnes et autorisations", description: "En tant que titulaire, vous administrerez les autorisations par dossier. Les invitations restent désactivées jusqu’à l’ouverture sécurisée d’un dossier." },
      auditoria: { label: "Audit", eyebrow: "Historique du dossier", title: "Décisions du dossier", description: "Les actions du dossier seront conservées avec leur contexte, leur date et leur auteur pour un suivi objectif." },
      "comite-ia": { label: "Comité IA", eyebrow: "Environnement réservé", title: "Comité IA", description: "L’espace d’analyse assistée reste exclusif au titulaire et ne reçoit du contenu que lorsque vous autorisez une analyse." },
      configuracoes: { label: "Paramètres", eyebrow: "Préférences du titulaire", title: "Paramètres", description: "Ajustez l’expérience Concilium sans modifier votre identité, vos passkeys ni vos contrôles de sécurité." },
    },
    ui: { workspace: "Espace interne", settings: "Paramètres", language: "Langue", languageDescription: "Choisissez parmi les packages installés sur cet appareil. Le changement n’envoie ni données, ni documents, ni décisions du dossier.", installedPacks: "Packages installés", loadPacks: "Charger des packages", availablePacks: "Packages disponibles", install: "Installer le package", installing: "Installation du package…", installed: "Installé", selectLanguage: "Sélectionner la langue", packageLocalOnly: "Les packages sont locaux et ne modifient que les libellés déjà couverts par traduction." },
  },
};

export const defaultLanguagePackId: LanguagePackId = "pt-BR";
