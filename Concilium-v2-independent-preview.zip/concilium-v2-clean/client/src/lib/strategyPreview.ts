// [NOVO v2 / Fase 4] "agreementChance" -> "strategicPostureScore" e "consensualityImpact" ->
// "cooperationTradeoff": os nomes antigos soavam perto demais de "chance de vitória"/
// previsão de resultado, que o Manual funcional (seção 12) proíbe explicitamente. Isto
// aqui é só um placar interno de postura para ordenar os 6 cartões de estratégia padrão —
// não é o índice comparativo de atendimento dos interesses (esse é multi-dimensão, com
// pesos visíveis, e vive em shared/interestAlignmentIndex.ts).
export type StrategyPreview = {
  code: string;
  name: "Aurora" | "Horizonte" | "Equilíbrio" | "Independência" | "Dissolução" | "Judicial";
  description: string;
  primaryBenefit: string;
  counterpartyBenefit: string;
  strategicPostureScore: number;
  cooperationTradeoff: number;
};

export const STRATEGY_PREVIEW: StrategyPreview[] = [
  { code: "aurora", name: "Aurora", description: "Abre o diálogo por pontos de convergência e metas graduais.", primaryBenefit: "Avanço gradual com menor atrito.", counterpartyBenefit: "Previsibilidade sem decisão definitiva imediata.", strategicPostureScore: 82, cooperationTradeoff: 0 },
  { code: "horizonte", name: "Horizonte", description: "Estrutura transição por marcos, prazos e revisões objetivas.", primaryBenefit: "Tempo para organizar recursos e prioridades.", counterpartyBenefit: "Cronograma claro e pontos de conferência.", strategicPostureScore: 74, cooperationTradeoff: -4 },
  { code: "equilibrio", name: "Equilíbrio", description: "Busca equivalência material em direitos, deveres e compensações.", primaryBenefit: "Critérios patrimoniais transparentes.", counterpartyBenefit: "Contrapartidas objetivas e tratamento paritário.", strategicPostureScore: 67, cooperationTradeoff: -8 },
  { code: "independencia", name: "Independência", description: "Constrói autonomia com divisão progressiva de responsabilidades.", primaryBenefit: "Organização individual de longo prazo.", counterpartyBenefit: "Limites claros e menos dependências futuras.", strategicPostureScore: 55, cooperationTradeoff: -13 },
  { code: "dissolucao", name: "Dissolução", description: "Planeja a extinção ordenada de vínculos patrimoniais.", primaryBenefit: "Encerramento estruturado e rastreável.", counterpartyBenefit: "Menos incerteza sobre obrigações remanescentes.", strategicPostureScore: 35, cooperationTradeoff: -22 },
  { code: "judicial", name: "Judicial", description: "Registra a alternativa formal após as vias consensuais disponíveis.", primaryBenefit: "Histórico objetivo das tentativas.", counterpartyBenefit: "Acesso organizado a uma via formal.", strategicPostureScore: 12, cooperationTradeoff: -35 },
];
