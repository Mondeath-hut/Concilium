import { describe, expect, it } from "vitest";
import { getSecurityStep, securitySteps } from "./securityFlow";

describe("security flow content", () => {
  it("keeps the four stages of the Concilium access model available", () => {
    expect(securitySteps.map(step => step.id)).toEqual([
      "convite",
      "identidade",
      "passkey",
      "step-up",
    ]);
  });

  it("returns the selected passkey stage with its privacy principle", () => {
    const step = getSecurityStep("passkey");

    expect(step.signal).toBe("Resistente a phishing");
    expect(step.description).toContain("biometria do aparelho");
  });
});
