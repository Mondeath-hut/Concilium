export const securitySteps = [
  {
    id: "convite",
    eyebrow: "01 · Convite contextual",
    title: "O acesso começa pelo caso.",
    description:
      "O participante recebe um convite exclusivo, com prazo, papel e escopo definidos. Um link encaminhado não deve se transformar em uma nova permissão.",
    detail: "Identidade vinculada ao convite",
    signal: "Escopo mínimo",
  },
  {
    id: "identidade",
    eyebrow: "02 · Identidade confirmada",
    title: "A conta é confirmada antes da sessão.",
    description:
      "A identidade de acesso é validada no provedor autorizado, preservando uma única conta de trabalho e uma trilha auditável de entrada.",
    detail: "Provedor de identidade",
    signal: "Sessão rastreável",
  },
  {
    id: "passkey",
    eyebrow: "03 · Passkey no dispositivo",
    title: "A chave está com a pessoa, não no servidor.",
    description:
      "A passkey usa uma prova criptográfica ligada ao domínio. A biometria do aparelho somente desbloqueia essa chave local; rosto e digital não são enviados ao Concilium.",
    detail: "Credencial criptográfica",
    signal: "Resistente a phishing",
  },
  {
    id: "step-up",
    eyebrow: "04 · Confirmação por risco",
    title: "Ações críticas pedem uma prova recente.",
    description:
      "Baixar, liberar, exportar ou alterar permissões exige uma nova confirmação. A experiência continua fluida para o trabalho cotidiano, mas se eleva quando o impacto aumenta.",
    detail: "Reautenticação contextual",
    signal: "Controle de alto impacto",
  },
] as const;

export type SecurityStepId = (typeof securitySteps)[number]["id"];

export function getSecurityStep(id: SecurityStepId) {
  return securitySteps.find(step => step.id === id) ?? securitySteps[0]!;
}
