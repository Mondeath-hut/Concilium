import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import ConfirmOwnerEmail from "@/pages/ConfirmOwnerEmail";
import OwnerActivation from "@/pages/OwnerActivation";
import OwnerDashboard from "@/pages/OwnerDashboard";
import OwnerWorkspace from "@/pages/OwnerWorkspace";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { conciliumThemes, ThemeProvider, type Theme } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/ativacao"} component={() => <OwnerActivation />} />
      <Route path={"/confirmar-email"} component={ConfirmOwnerEmail} />
      <Route path={"/app"} component={OwnerDashboard} />
      <Route path={"/espaco"} component={OwnerWorkspace} />
      <Route path={"/espaco/:section"} component={OwnerWorkspace} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  const requestedTheme = new URLSearchParams(window.location.search).get("theme");
  const previewTheme = conciliumThemes.some(theme => theme.id === requestedTheme)
    ? (requestedTheme as Theme)
    : undefined;

  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme={previewTheme ?? "navy"}
        switchable={!previewTheme}
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
