import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { analyzeDocumentVersions } from "@shared/documentVersionAnalysis";

type DocumentItem = { id: string; title: string };

export function DocumentVersionHistory({ caseId, documents }: { caseId: string; documents: DocumentItem[] }) {
  const [selectedDocumentId, setSelectedDocumentId] = useState("");
  const versions = trpc.ownerWorkspace.listDocumentVersions.useQuery({ caseId, documentId: selectedDocumentId }, { enabled: Boolean(selectedDocumentId) });
  const selected = documents.find(document => document.id === selectedDocumentId);
  const analysis = versions.data ? analyzeDocumentVersions(versions.data) : null;
  return <section className="c-tint c-border mt-5 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Histórico de versões</p><p className="c-copy mt-1 text-xs leading-5">Versões anteriores permanecem preservadas. Hash e semelhança técnica não confirmam autenticidade nem equivalência jurídica.</p><select value={selectedDocumentId} onChange={event => setSelectedDocumentId(event.target.value)} className="c-border c-ink mt-4 min-h-10 w-full rounded-xl border bg-transparent px-3 text-xs"><option value="">Escolher documento</option>{documents.map(document => <option key={document.id} value={document.id}>{document.title}</option>)}</select>{selected && <div className="mt-4">{analysis && <p className="c-soft mb-3 text-[10px]">{analysis.note} · {analysis.versionCount} versão(ões)</p>}{versions.isLoading ? <p className="c-copy text-sm">Carregando versões…</p> : versions.data?.length ? <div className="grid gap-3">{versions.data.map(version => <article key={version.id} className="c-border rounded-xl border p-3"><div className="flex flex-wrap items-center justify-between gap-2"><p className="c-ink text-xs font-bold">{version.versionLabel}</p><span className="c-soft text-[10px]">{new Date(version.createdAt).toLocaleString("pt-BR")}</span></div><p className="c-copy mt-2 text-xs leading-5">{version.changeNote}</p><p className="c-soft mt-2 break-all text-[10px]">Hash: {version.contentHash}</p><p className="c-soft mt-1 text-[10px]">Origem: {version.sourceReference}</p><p className="c-soft mt-3 text-[10px]">Abertura privada será liberada pelo conector de armazenamento autorizado.</p></article>)}</div> : <p className="c-copy text-sm">Nenhuma versão registrada para este documento.</p>}</div>}</section>;
}
