import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EyeOff, FileText } from "lucide-react";

const visibilityLabels = {
  privado_titular: "Somente eu",
  partes: "Pessoas autorizadas",
  contexto_protegido: "Contexto protegido",
} as const;

function formatDate(value?: Date | string | null) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

export function ProtectedDocumentArchive({ documents, isOwner, onOpen, onSetVisibility, onProtectedPreview }: {
  documents: any[];
  isOwner: boolean;
  onOpen: (document: any) => void;
  onSetVisibility: (documentId: string, visibility: "privado_titular" | "partes" | "contexto_protegido") => void;
  onProtectedPreview: (document: any) => void;
}) {
  return <section className="mt-8 border border-[#ded8ca] bg-[#fbfaf5]"><div className="flex flex-col justify-between gap-4 border-b border-[#e5dfd3] p-6 sm:flex-row sm:items-end"><div><p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#9a8450]">Arquivo do caso</p><h2 className="mt-1 font-serif text-3xl text-[#29322c]">Propostas e contrapropostas</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#72756d]">Rascunhos podem permanecer só com você, ser liberados às pessoas autorizadas ou exibir apenas o contexto protegido. Uma peça enviada mantém a visibilidade estabelecida pela rodada.</p></div><Badge className="w-fit rounded-full border-0 bg-[#e7dfcb] text-[#5e5338]">{documents.length} documento(s)</Badge></div>{documents.length ? <div className="divide-y divide-[#ebe6dc]">{documents.map((entry: any) => { const document = entry.document; const editableVisibility = document.currentStatus === "rascunho" && isOwner; return <div key={document.id} className="flex flex-col gap-4 p-6 lg:flex-row lg:items-start lg:justify-between"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><FileText size={16} className="text-[#8e7338]"/><p className="font-medium text-[#343d36]">{document.title}</p><Badge className="rounded-full border-0 bg-[#e8e7e1] text-[#61635d]">{document.currentStatus}</Badge></div><p className="mt-2 text-xs text-[#777a70]">{document.documentType} · {entry.authorName || "Parte Principal"} · {formatDate(document.submittedAt || document.createdAt)}</p><p className="mt-1 text-xs text-[#777a70]">SHA-256: {document.contentHash.slice(0, 18)}…</p></div><div className="grid min-w-[248px] gap-2"><div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => onOpen(document)}>Abrir</Button><Button size="sm" variant="outline" onClick={() => onProtectedPreview(document)}><EyeOff size={14}/> Prévia protegida</Button></div>{editableVisibility ? <select value={document.visibility} onChange={event => onSetVisibility(document.id, event.target.value as "privado_titular" | "partes" | "contexto_protegido")} className="h-10 rounded-none border border-[#d8d1c3] bg-white px-3 text-sm text-[#3d453f]"><option value="privado_titular">Somente eu</option><option value="partes">Pessoas autorizadas</option><option value="contexto_protegido">Contexto protegido</option></select> : <p className="text-xs leading-5 text-[#777a70]">Visibilidade: {visibilityLabels[document.visibility as keyof typeof visibilityLabels] || "Homologado"}</p>}</div></div>; })}</div> : <div className="p-8 text-sm text-[#74786e]">O arquivo documental está vazio.</div>}</section>;
}
