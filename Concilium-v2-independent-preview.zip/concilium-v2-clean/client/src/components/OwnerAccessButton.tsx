import { trpc } from "@/lib/trpc";
import { startAuthentication } from "@simplewebauthn/browser";
import React, { useState } from "react";

type OwnerAccessButtonProps = {
  children: React.ReactNode;
  className?: string;
  onNavigate?: (path: string) => void;
};

function messageFrom(error: unknown) {
  return error instanceof Error ? error.message : "Não foi possível confirmar a passkey. Tente novamente.";
}

/**
 * Public entry point for the sole owner. Once activation is completed, the
 * WebAuthn ceremony begins from the user's original click instead of requiring
 * a second intermediate page. New or pending accounts continue to /ativacao.
 */
export function OwnerAccessButton({ children, className = "", onNavigate = path => window.location.assign(path) }: OwnerAccessButtonProps) {
  const [error, setError] = useState("");
  const status = trpc.ownerActivation.status.useQuery();
  const beginPasskeyLogin = trpc.ownerActivation.beginPasskeyLogin.useMutation();
  const finishPasskeyLogin = trpc.ownerActivation.finishPasskeyLogin.useMutation();
  const pending = beginPasskeyLogin.isPending || finishPasskeyLogin.isPending;

  const access = async () => {
    setError("");
    if (status.isLoading) {
      setError("Verificando a disponibilidade do acesso seguro. Tente novamente em instantes.");
      return;
    }
    if (status.data?.ownerState !== "active") {
      onNavigate("/ativacao");
      return;
    }
    try {
      const options = await beginPasskeyLogin.mutateAsync();
      const response = await startAuthentication({ optionsJSON: options });
      await finishPasskeyLogin.mutateAsync({ response });
      onNavigate("/espaco");
    } catch (reason) {
      setError(messageFrom(reason));
    }
  };

  return (
    <span className="inline-flex flex-col items-start gap-2">
      <button type="button" onClick={access} disabled={pending} className={`inline-flex items-center justify-center gap-2 disabled:cursor-not-allowed disabled:opacity-60 ${className}`}>
        {pending ? "Confirmando biometria…" : children}
      </button>
      {error && <span role="alert" className="c-copy max-w-xs text-left text-[11px] leading-4">{error}</span>}
    </span>
  );
}
