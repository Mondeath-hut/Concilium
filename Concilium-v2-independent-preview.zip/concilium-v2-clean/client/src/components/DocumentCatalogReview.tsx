import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { documentVaults } from "@shared/documentCatalog";

type DocumentVault = (typeof documentVaults)[number];
type CatalogDocument = { id: string; title: string; catalogStatus?: string; suggestedVault?: DocumentVault | null; catalogSensitivity?: string; catalogConfidence?: string; catalogNotes?: string | null };

function readEnsembleNotes(raw?: string | null) {
  if (!raw) return null;
  try { const parsed = JSON.parse(raw) as { roleSuggestions?: Array<{ role: string; status: string; suggestion?: { suggestedVault: string; sensitivity: string; confidence: string } | null }> }; return parsed.roleSuggestions ?? null; } catch { return null; }
}

export function DocumentCatalogReview({ caseId, documents }: { caseId: string; documents: CatalogDocument[] }) {
  const pending = documents.filter(document => document.catalogStatus === "needs_owner_review");
  const [selectedVaults, setSelectedVaults] = useState<Record<string, DocumentVault>>({});
  const confirm = trpc.ownerWorkspace.confirmDocumentCatalog.useMutation();
  if (!pending.length) return null;
  return <section className="c-tint c-border mt-5 rounded-2xl border p-5"><p className="c-ink text-sm font-bold">Revisão de catalogação</p><p className="c-copy mt-1 text-xs leading-5">As sugestões abaixo vieram da análise documental e ainda não são confirmação de autenticidade ou relevância jurídica. Escolha o cofre somente depois da sua revisão.</p><div className="mt-4 grid gap-3">{pending.map(document => { const vault = selectedVaults[document.id] ?? document.suggestedVault ?? "quarantine"; const roleSuggestions = readEnsembleNotes(document.catalogNotes); return <div key={document.id} className="c-border rounded-xl border p-4"><p className="c-ink text-xs font-semibold">{document.title}</p><p className="c-soft mt-1 text-[10px]">Sugestão: {document.suggestedVault ?? "quarantine"} · sensibilidade: {document.catalogSensitivity ?? "não catalogado"} · confiança: {document.catalogConfidence ?? "não verificada"}</p>{roleSuggestions?.length ? <details className="mt-3"><summary className="c-ink cursor-pointer text-[10px] font-semibold">Ver leituras dos papéis</summary><div className="mt-2 grid gap-2">{roleSuggestions.map(item => <p key={item.role} className="c-copy text-[10px] leading-4"><strong className="c-ink">{item.role}:</strong> {item.status === "failed" ? "falhou nesta análise" : `${item.suggestion?.suggestedVault ?? "sem cofre"} · ${item.suggestion?.sensitivity ?? "sensibilidade desconhecida"} · confiança ${item.suggestion?.confidence ?? "desconhecida"}`}</p>)}</div></details> : null}<select value={vault} onChange={event => setSelectedVaults(current => ({ ...current, [document.id]: event.target.value as DocumentVault }))} className="c-border c-ink mt-3 min-h-10 w-full rounded-xl border bg-transparent px-3 text-xs">{documentVaults.map(option => <option key={option} value={option}>{option}</option>)}</select><Button size="sm" className="c-deep-button mt-3 rounded-xl" disabled={confirm.isPending} onClick={() => confirm.mutate({ caseId, documentId: document.id, confirmedVault: vault })}>Confirmar cofre</Button></div>; })}</div></section>;
}
