// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const fixtures = vi.hoisted(() => ({
  owner: { id: "owner-integration", email: "titular@exemplo.test", displayName: "Titular", state: "active" },
  setup: { ownerId: "owner-integration", challenge: "challenge-integration", purpose: "passkey_authentication", origin: "https://concilium.test", rpId: "concilium.test" },
  sessionCreated: false,
}));

const db = vi.hoisted(() => ({
  clearOwnerAuthThrottle: vi.fn(),
  createOwnerSession: vi.fn(),
  getOwnerAccount: vi.fn(),
  getOwnerAccountById: vi.fn(),
  getOwnerAuthThrottle: vi.fn(),
  getOwnerPasskey: vi.fn(),
  getOwnerPasskeys: vi.fn(),
  listOwnerCases: vi.fn(),
  recordOwnerAudit: vi.fn(),
  updateOwnerAccount: vi.fn(),
  updateOwnerPasskeyUsage: vi.fn(),
}));

const ownerAuth = vi.hoisted(() => ({
  clearSetupCookie: vi.fn(),
  getOwnerSession: vi.fn(),
  makeSessionId: vi.fn(() => "session-integration"),
  readSetupCookie: vi.fn(),
  requestOrigin: vi.fn(() => "https://concilium.test"),
  requestRpId: vi.fn(() => "concilium.test"),
  setOwnerSession: vi.fn(async () => ({ tokenHash: "token-hash" })),
  setSetupCookie: vi.fn(),
}));

const webauthn = vi.hoisted(() => ({
  generateAuthenticationOptions: vi.fn(),
  verifyAuthenticationResponse: vi.fn(),
}));

const browser = vi.hoisted(() => ({ startAuthentication: vi.fn() }));
const client = vi.hoisted(() => ({
  status: vi.fn(),
  begin: vi.fn(),
  finish: vi.fn(),
  dashboard: vi.fn(),
  logout: vi.fn(),
  beginApiCredentialReauthentication: vi.fn(),
  finishApiCredentialReauthentication: vi.fn(),
  listCases: vi.fn(),
  operationalCasesList: vi.fn(),
  operationalCasesCreate: vi.fn(),
  operationalCasesOverview: vi.fn(),
  operationalCasesCreateStrategy: vi.fn(),
  createCase: vi.fn(),
  caseOverview: vi.fn(),
  createStrategy: vi.fn(),
  requestDocumentAccess: vi.fn(),
  audit: vi.fn(),
  listAiModels: vi.fn(),
  listAiProviders: vi.fn(),
  listAiRuns: vi.fn(),
  updateAiProviderCredential: vi.fn(),
  runAiCommittee: vi.fn(),
  decideAiRun: vi.fn(),
  fallbackQuery: vi.fn(),
  fallbackMutation: vi.fn(),
  location: "/",
  setLocation: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    knowledge: new Proxy({}, { get: () => ({ useQuery: client.fallbackQuery, useMutation: client.fallbackMutation }) }),
    operationalAttachments: new Proxy({}, { get: () => ({ useQuery: client.fallbackQuery, useMutation: client.fallbackMutation }) }),
    operationalDocuments: new Proxy({}, { get: () => ({ useQuery: client.fallbackQuery, useMutation: client.fallbackMutation }) }),
    ownerActivation: {
      status: { useQuery: client.status },
      beginPasskeyLogin: { useMutation: () => ({ mutateAsync: client.begin, isPending: false }) },
      finishPasskeyLogin: { useMutation: () => ({ mutateAsync: client.finish, isPending: false }) },
      dashboard: { useQuery: client.dashboard },
      logout: { useMutation: () => ({ mutate: client.logout, isPending: false }) },
      beginApiCredentialReauthentication: { useMutation: () => ({ mutateAsync: client.beginApiCredentialReauthentication, isPending: false }) },
      finishApiCredentialReauthentication: { useMutation: () => ({ mutateAsync: client.finishApiCredentialReauthentication, isPending: false }) },
    },
    operationalCases: new Proxy({
      list: { useQuery: client.operationalCasesList },
      create: { useMutation: () => ({ mutate: client.operationalCasesCreate, isPending: false }) },
      overview: { useQuery: client.operationalCasesOverview },
      createStrategy: { useMutation: () => ({ mutate: client.operationalCasesCreateStrategy, isPending: false }) },
    }, { get: (target, property) => (target as Record<string, unknown>)[String(property)] ?? { useQuery: client.fallbackQuery, useMutation: client.fallbackMutation } }),
    ownerWorkspace: new Proxy({
      listCases: { useQuery: client.listCases },
      createCase: { useMutation: () => ({ mutate: client.createCase, isPending: false }) },
      caseOverview: { useQuery: client.caseOverview },
      createStrategy: { useMutation: () => ({ mutate: client.createStrategy, isPending: false }) },
      requestDocumentAccess: { useMutation: () => ({ mutateAsync: client.requestDocumentAccess, isPending: false }) },
      audit: { useQuery: client.audit },
      listAiModels: { useQuery: client.listAiModels },
      listAiProviders: { useQuery: client.listAiProviders },
      listAiRuns: { useQuery: client.listAiRuns },
      updateAiProviderCredential: { useMutation: () => ({ mutateAsync: client.updateAiProviderCredential, isPending: false }) },
      runAiCommittee: { useMutation: () => ({ mutate: client.runAiCommittee, isPending: false, error: undefined }) },
      decideAiRun: { useMutation: () => ({ mutate: client.decideAiRun, isPending: false }) },
    }, { get: (target, property) => (target as Record<string, unknown>)[String(property)] ?? { useQuery: client.fallbackQuery, useMutation: client.fallbackMutation } }),
  },
}));
vi.mock("@simplewebauthn/browser", () => ({ startAuthentication: browser.startAuthentication }));
vi.mock("@simplewebauthn/server", () => webauthn);
vi.mock("@/../../server/db", () => db);
vi.mock("@/../../server/ownerAuth", () => ownerAuth);
vi.mock("wouter", () => ({ useLocation: () => [client.location, client.setLocation] }));

import { OwnerAccessButton } from "./OwnerAccessButton";
import { ThemeProvider } from "@/contexts/ThemeContext";
import Home from "@/pages/Home";
import OwnerWorkspace from "@/pages/OwnerWorkspace";
import { ownerActivationRouter } from "@/../../server/routers/ownerActivation";
import { ownerWorkspaceRouter } from "@/../../server/routers/ownerWorkspace";

const activationCaller = () => ownerActivationRouter.createCaller({ req: {}, res: {} } as never);
const workspaceCaller = () => ownerWorkspaceRouter.createCaller({ req: {}, res: {} } as never);

describe("OwnerAccessButton — integração de passkey e espaço interno", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fixtures.sessionCreated = false;
    client.location = "/";
    client.setLocation.mockImplementation((path: string) => { client.location = path; });
    client.status.mockReturnValue({ data: { ownerState: "active" }, isLoading: false });
    client.dashboard.mockReturnValue({ data: { owner: { ...fixtures.owner, emailVerified: true }, passkeyCount: 1, remainingRecoveryCodes: 10, totpContingencyConfigured: true }, isLoading: false, error: null, refetch: vi.fn() });
    client.listCases.mockReturnValue({ data: [], isLoading: false, error: null, refetch: vi.fn() });
    client.operationalCasesList.mockImplementation((...args) => client.listCases(...args));
    client.operationalCasesCreate.mockImplementation((...args) => client.createCase(...args));
    client.operationalCasesOverview.mockImplementation((...args) => client.caseOverview(...args));
    client.operationalCasesCreateStrategy.mockImplementation((...args) => client.createStrategy(...args));
    client.fallbackQuery.mockReturnValue({ data: undefined, isLoading: false, error: null, refetch: vi.fn() });
    client.fallbackMutation.mockReturnValue({ mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false, error: undefined });
    client.caseOverview.mockReturnValue({ data: undefined, isLoading: false, error: null, refetch: vi.fn() });
    client.requestDocumentAccess.mockResolvedValue({ url: "https://storage.example.test/temporary-download" });
    client.audit.mockReturnValue({ data: { events: [], nextCursor: undefined }, isLoading: false, isFetching: false, error: null, refetch: vi.fn() });
    client.listAiModels.mockReturnValue({ data: [], isLoading: false, error: null, refetch: vi.fn() });
    client.listAiProviders.mockReturnValue({ data: [], isLoading: false, error: null, refetch: vi.fn() });
    client.listAiRuns.mockReturnValue({ data: [], isLoading: false, error: null, refetch: vi.fn() });
    db.getOwnerAccount.mockResolvedValue(fixtures.owner);
    db.getOwnerAccountById.mockResolvedValue(fixtures.owner);
    db.getOwnerAuthThrottle.mockResolvedValue(undefined);
    db.getOwnerPasskeys.mockResolvedValue([{ credentialId: "credential-integration", ownerId: fixtures.owner.id, publicKey: "", counter: 0, transports: "internal" }]);
    db.getOwnerPasskey.mockResolvedValue({ credentialId: "credential-integration", ownerId: fixtures.owner.id, publicKey: "", counter: 0, transports: "internal" });
    db.listOwnerCases.mockResolvedValue([]);
    ownerAuth.readSetupCookie.mockResolvedValue(fixtures.setup);
    ownerAuth.setSetupCookie.mockResolvedValue(undefined);
    ownerAuth.getOwnerSession.mockImplementation(async () => fixtures.sessionCreated ? { owner: fixtures.owner } : undefined);
    db.createOwnerSession.mockImplementation(async () => { fixtures.sessionCreated = true; });
    webauthn.generateAuthenticationOptions.mockResolvedValue({ challenge: fixtures.setup.challenge, rpId: fixtures.setup.rpId });
    webauthn.verifyAuthenticationResponse.mockResolvedValue({ verified: true, authenticationInfo: { newCounter: 1 } });
    client.begin.mockImplementation(() => activationCaller().beginPasskeyLogin());
    client.finish.mockImplementation((input: { response: unknown }) => activationCaller().finishPasskeyLogin(input));
    browser.startAuthentication.mockResolvedValue({ id: "credential-integration" });
  });

  afterEach(() => cleanup());

  it("emite sessão por passkey após o clique público e autoriza /espaco", async () => {
    const navigate = vi.fn();
    render(<OwnerAccessButton onNavigate={navigate}>Acessar</OwnerAccessButton>);

    fireEvent.click(screen.getByRole("button", { name: "Acessar" }));
    await waitFor(() => expect(navigate).toHaveBeenCalledWith("/espaco"));

    expect(browser.startAuthentication).toHaveBeenCalledWith({ optionsJSON: expect.objectContaining({ challenge: fixtures.setup.challenge }) });
    expect(db.createOwnerSession).toHaveBeenCalledWith(expect.objectContaining({ ownerId: fixtures.owner.id }));
    await expect(workspaceCaller().listCases()).resolves.toEqual([]);
    expect(db.listOwnerCases).toHaveBeenCalledWith(fixtures.owner.id);
  });

  it("renderiza o espaço interno protegido depois da navegação pública por passkey", async () => {
    const { rerender } = render(<ThemeProvider><Home /></ThemeProvider>);

    fireEvent.click(screen.getAllByRole("button", { name: "Acessar" })[0]);
    await waitFor(() => expect(client.setLocation).toHaveBeenCalledWith("/espaco"));
    expect(fixtures.sessionCreated).toBe(true);
    expect(client.location).toBe("/espaco");

    rerender(<ThemeProvider><OwnerWorkspace /></ThemeProvider>);
    expect(await screen.findByRole("heading", { name: "Casos e acordos" })).toBeTruthy();
    expect(client.dashboard).toHaveBeenCalled();
    expect(client.listCases).toHaveBeenCalled();
  });
});
