import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AIChatBox, type Message } from "./AIChatBox";
import { trpc } from "@/lib/trpc";
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react";

/**
 * Atores interativos anônimos (Manual funcional v2, seção 8-A): um retrato clicável por
 * papel — sem nome próprio, só a função — que abre um chat dedicado. Entrada e saída por
 * voz são opcionais e não mudam o comportamento do ator, só o canal de conversa.
 */
const ACTOR_ROLES = ["estrategista", "supervisor", "bibliotecario", "defesa", "advogado_do_diabo", "mediador"] as const;
type ActorRole = (typeof ACTOR_ROLES)[number];

const ACTOR_LABELS: Record<ActorRole, string> = {
  estrategista: "Estrategista",
  supervisor: "Supervisor",
  bibliotecario: "Bibliotecário",
  defesa: "Defesa",
  advogado_do_diabo: "Advogado do Diabo",
  mediador: "Mediador",
};

// Iniciais em vez de foto — nenhum retrato real é usado, só a função (Manual, seção 8-A: "sem nome próprio").
const ACTOR_INITIALS: Record<ActorRole, string> = {
  estrategista: "ES",
  supervisor: "SU",
  bibliotecario: "BI",
  defesa: "DE",
  advogado_do_diabo: "AD",
  mediador: "ME",
};

export type ActorRosterProps = {
  caseId: string;
  title: string;
  objective: string;
  /** Conteúdo bruto do caso — a redação por nível de acesso do papel acontece no servidor, nunca aqui. */
  rawCaseContent: string;
};

export function ActorRoster({ title, objective, rawCaseContent }: ActorRosterProps) {
  const [openRole, setOpenRole] = useState<ActorRole | null>(null);

  return (
    <>
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        {ACTOR_ROLES.map(role => (
          <button
            key={role}
            type="button"
            onClick={() => setOpenRole(role)}
            className="flex flex-col items-center gap-2 rounded-lg border border-border bg-card p-3 text-center transition-colors hover:bg-accent"
            aria-label={`Conversar com o ${ACTOR_LABELS[role]}`}
          >
            <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
              {ACTOR_INITIALS[role]}
            </div>
            <span className="text-xs text-muted-foreground">{ACTOR_LABELS[role]}</span>
          </button>
        ))}
      </div>

      <Dialog open={openRole !== null} onOpenChange={open => !open && setOpenRole(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{openRole ? ACTOR_LABELS[openRole] : ""}</DialogTitle>
          </DialogHeader>
          {openRole && (
            <ActorChatPanel role={openRole} caseId={title} title={title} objective={objective} rawCaseContent={rawCaseContent} />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function ActorChatPanel({ role, title, objective, rawCaseContent }: { role: ActorRole; caseId: string; title: string; objective: string; rawCaseContent: string }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [voiceOutputEnabled, setVoiceOutputEnabled] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const sendMessage = trpc.actorChat.sendMessage.useMutation({
    onSuccess: result => {
      setMessages(prev => [...prev, { role: "assistant", content: result.reply }]);
      if (voiceOutputEnabled) speak(result.reply);
    },
  });

  // Limpa qualquer fala em andamento ao trocar de ator ou fechar o painel.
  useEffect(() => () => window.speechSynthesis?.cancel(), [role]);

  function speak(text: string) {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "pt-BR";
    window.speechSynthesis.speak(utterance);
  }

  function handleSend(content: string) {
    const history = messages;
    setMessages(prev => [...prev, { role: "user", content }]);
    sendMessage.mutate({
      role,
      title,
      objective,
      rawCaseContent,
      history: history.filter(message => message.role !== "system") as { role: "user" | "assistant"; content: string }[],
      message: content,
    });
  }

  function toggleVoiceInput() {
    const SpeechRecognitionCtor = (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition
      ?? (window as unknown as { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition;

    if (!SpeechRecognitionCtor) {
      alert("Captação de voz indisponível neste navegador.");
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      return;
    }

    const recognition = new SpeechRecognitionCtor();
    recognition.lang = "pt-BR";
    recognition.continuous = false;
    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onresult = event => {
      const transcript = event.results[0][0].transcript;
      if (transcript.trim()) handleSend(transcript.trim());
    };
    recognitionRef.current = recognition;
    recognition.start();
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-end gap-2">
        <Button type="button" size="icon" variant={isRecording ? "default" : "outline"} onClick={toggleVoiceInput} aria-label="Falar com o ator">
          {isRecording ? <Mic className="size-4 animate-pulse" /> : <MicOff className="size-4" />}
        </Button>
        <Button
          type="button"
          size="icon"
          variant={voiceOutputEnabled ? "default" : "outline"}
          onClick={() => setVoiceOutputEnabled(value => !value)}
          aria-label="Ouvir as respostas em voz alta"
        >
          {voiceOutputEnabled ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
        </Button>
      </div>
      <AIChatBox
        messages={messages}
        onSendMessage={handleSend}
        isLoading={sendMessage.isPending}
        height="480px"
        emptyStateMessage={`Converse com o ${ACTOR_LABELS[role]} por texto ou pelo microfone.`}
      />
    </div>
  );
}
