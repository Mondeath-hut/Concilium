import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { conciliumThemes, useTheme } from "@/contexts/ThemeContext";
import { Check, KeyRound, Palette, Settings2, ShieldCheck } from "lucide-react";
import React from "react";

function ThemePreview({ colors }: { colors: readonly string[] }) {
  return (
    <span className="c-border flex h-10 overflow-hidden rounded-xl border" aria-hidden="true">
      {colors.map(color => <span key={color} className="flex-1" style={{ backgroundColor: color }} />)}
    </span>
  );
}

export function SettingsDialog({ forceOpen = false }: { forceOpen?: boolean }) {
  const { theme, setTheme } = useTheme();
  const [open, setOpen] = React.useState(forceOpen);

  React.useEffect(() => {
    if (forceOpen) setOpen(true);
  }, [forceOpen]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button type="button" className="c-icon-button grid h-10 w-10 place-items-center rounded-full border" aria-label="Abrir configurações">
          <Settings2 size={18} />
        </button>
      </DialogTrigger>
      <DialogContent className="concilium-settings-dialog max-h-[calc(100dvh-2rem)] max-w-[calc(100%-1.5rem)] overflow-y-auto p-0 sm:max-w-2xl">
        <DialogHeader className="c-border border-b px-6 pb-5 pt-6 text-left">
          <div className="flex items-center gap-3">
            <span className="c-tint c-accent grid h-10 w-10 place-items-center rounded-xl"><Settings2 size={19} /></span>
            <div>
              <DialogTitle className="font-editorial c-ink text-[25px] font-normal tracking-[-0.03em]">Configurações</DialogTitle>
              <DialogDescription className="c-copy mt-1 text-[12px]">Aparência e preferências deste navegador.</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-7 px-6 py-6">
          <section aria-labelledby="acesso-configuracoes" className="concilium-settings-card rounded-2xl border p-4">
            <div className="flex items-start gap-3">
              <span className="c-deep-card c-deep-ink grid h-10 w-10 shrink-0 place-items-center rounded-full"><KeyRound size={17} /></span>
              <div className="min-w-0 flex-1">
                <h3 id="acesso-configuracoes" className="c-ink text-[14px] font-bold">Acesso institucional</h3>
                <p className="c-copy mt-1 text-[12px] leading-5">A área privada do Concilium ainda está em preparação. Nenhuma conta externa é exibida ou vinculada por esta página.</p>
              </div>
            </div>
          </section>

          <section aria-labelledby="aparencia-configuracoes">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 id="aparencia-configuracoes" className="c-ink flex items-center gap-2 text-[14px] font-bold"><Palette size={16} className="c-accent" /> Aparência</h3>
                <p className="c-copy mt-1 text-[12px] leading-5">A escolha é salva neste navegador e pode ser alterada a qualquer momento.</p>
              </div>
              <span className="c-tint c-accent c-accent-border hidden rounded-full border px-3 py-1 text-[9px] font-bold uppercase tracking-[0.14em] sm:block">Preferência local</span>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {conciliumThemes.map(option => {
                const selected = theme === option.id;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setTheme(option.id)}
                    aria-pressed={selected}
                    className={`rounded-2xl border p-3 text-left transition-all duration-200 ${selected ? "concilium-settings-choice-active" : "concilium-settings-choice"}`}
                  >
                    <div className="flex items-center justify-between gap-3"><ThemePreview colors={option.preview} />{selected && <span className="c-accent-bg c-on-accent grid h-6 w-6 place-items-center rounded-full"><Check size={14} strokeWidth={3} /></span>}</div>
                    <p className="c-ink mt-3 text-[13px] font-bold">{option.name}</p>
                    <p className="c-copy mt-1 text-[11px] leading-4">{option.description}</p>
                  </button>
                );
              })}
            </div>
          </section>

          <section className="concilium-security-note rounded-2xl border p-4">
            <p className="c-success-ink flex items-center gap-2 text-[13px] font-bold"><ShieldCheck size={16} className="c-success" /> Preferências sem expor o caso</p>
            <p className="c-copy mt-1 text-[12px] leading-5">A aparência é uma configuração local. Informações de processo, documentos e permissões permanecem sob os controles da plataforma.</p>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
