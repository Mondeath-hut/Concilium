import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { OwnerAccessButton } from "./OwnerAccessButton";

const mocks = {
  status: { data: { ownerState: "active" }, isLoading: false },
  begin: vi.fn(),
  finish: vi.fn(),
  authenticate: vi.fn(),
};

vi.mock("@/lib/trpc", () => ({
  trpc: {
    ownerActivation: {
      status: { useQuery: () => mocks.status },
      beginPasskeyLogin: { useMutation: () => ({ mutateAsync: mocks.begin, isPending: false }) },
      finishPasskeyLogin: { useMutation: () => ({ mutateAsync: mocks.finish, isPending: false }) },
    },
  },
}));

vi.mock("@simplewebauthn/browser", () => ({ startAuthentication: (input: unknown) => mocks.authenticate(input) }));

describe("OwnerAccessButton", () => {
  beforeEach(() => {
    mocks.begin.mockReset();
    mocks.finish.mockReset();
    mocks.authenticate.mockReset();
    mocks.status = { data: { ownerState: "active" }, isLoading: false };
    mocks.begin.mockResolvedValue({ challenge: "challenge", rpId: "example.test", allowCredentials: [] });
    mocks.authenticate.mockResolvedValue({ id: "credential" });
    mocks.finish.mockResolvedValue({});
  });

  afterEach(() => cleanup());

  it("starts passkey from the public button and opens the private workspace after success", async () => {
    const navigate = vi.fn();
    render(<OwnerAccessButton onNavigate={navigate}>Acessar</OwnerAccessButton>);
    fireEvent.click(screen.getByRole("button", { name: "Acessar" }));
    await waitFor(() => expect(mocks.begin).toHaveBeenCalledTimes(1));
    expect(mocks.authenticate).toHaveBeenCalledWith({ optionsJSON: expect.objectContaining({ challenge: "challenge" }) });
    await waitFor(() => expect(mocks.finish).toHaveBeenCalledWith({ response: { id: "credential" } }));
    expect(navigate).toHaveBeenCalledWith("/espaco");
  });

  it("keeps first use on the activation route", () => {
    mocks.status = { data: { ownerState: "pending" }, isLoading: false };
    const navigate = vi.fn();
    render(<OwnerAccessButton onNavigate={navigate}>Acessar</OwnerAccessButton>);
    fireEvent.click(screen.getByRole("button", { name: "Acessar" }));
    expect(navigate).toHaveBeenCalledWith("/ativacao");
    expect(mocks.begin).not.toHaveBeenCalled();
  });
});
