import React, { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { secretManifest, SECRET_INTAKE_RULES } from "@shared/secretManifest";
import { isSevenZipHeader, sanitizeArchiveDisplayName, SECRET_INTAKE_SECURITY_NOTICE, SEVEN_ZIP_MAGIC } from "@shared/secretIntake";

/** Preparação visual do wizard. A senha permanece apenas no estado da tela e não é transmitida nesta versão. */
export function SecretIntakePanel() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [formatStatus, setFormatStatus] = useState<"pending" | "valid" | "invalid">("pending");
  const [password, setPassword] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const expectedNames = useMemo(() => secretManifest.map(entry => entry.name), []);

  const inspectSelectedFile = async (file: File | null) => {
    setSelectedFile(file);
    setNotice(null);
    if (!file) {
      setFormatStatus("pending");
      return;
    }
    try {
      const header = new Uint8Array(await file.slice(0, SEVEN_ZIP_MAGIC.length).arrayBuffer());
      setFormatStatus(isSevenZipHeader(header) ? "valid" : "invalid");
    } catch {
      setFormatStatus("invalid");
      setNotice("Não foi possível ler o cabeçalho local do arquivo. Nenhum conteúdo foi enviado.");
    }
  };

  const preparePackage = () => {
    if (!selectedFile || !password || !confirmed) return;
    setNotice("Pré-validação concluída somente nesta tela. A descriptografia e a gravação no cofre ainda não foram executadas.");
    setPassword("");
  };

  return <article className="concilium-card c-border mt-5 rounded-3xl border p-6 sm:p-8">
    <p className="c-accent-strong text-[10px] font-bold uppercase tracking-[0.16em]">Cofre seguro de credenciais</p>
    <h2 className="c-ink mt-2 text-lg font-bold">Preparar ingestão do pacote criptografado</h2>
    <p className="c-copy mt-2 max-w-3xl text-sm leading-6">Esta tela prepara o futuro wizard. A senha fica somente no estado temporário da tela, não é salva nem enviada ao chat. A validação do cabeçalho confirma apenas o formato; não abre nem extrai o pacote.</p><p className="c-soft mt-2 text-xs">{SECRET_INTAKE_SECURITY_NOTICE}</p>
    <div className="c-tint c-border mt-5 grid gap-4 rounded-2xl border p-5">
      <label className="grid gap-2 text-xs"><span className="c-ink font-semibold">Pacote criptografado</span><input type="file" accept=".7z,.001,.bin,.html,.txt" onChange={event => void inspectSelectedFile(event.target.files?.[0] ?? null)} className="c-copy text-xs" /></label>
      {selectedFile && <p className="c-soft text-xs">Arquivo selecionado: {sanitizeArchiveDisplayName(selectedFile.name)} · {(selectedFile.size / 1024 / 1024).toFixed(2)} MB · formato: {formatStatus === "valid" ? "7z reconhecido" : formatStatus === "invalid" ? "cabeçalho não reconhecido" : "verificando…"}</p>}
      <label className="grid gap-2 text-xs"><span className="c-ink font-semibold">Senha do pacote</span><input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete="new-password" placeholder="Digite somente nesta tela protegida" className="c-border c-ink rounded-xl border bg-transparent px-3 py-2" /></label>
      <label className="c-border c-copy flex items-start gap-2 rounded-xl border p-3 text-xs leading-5"><input className="mt-0.5" type="checkbox" checked={confirmed} onChange={event => setConfirmed(event.target.checked)} /><span>Confirmo que este pacote contém meus próprios segredos e autorizo somente a preparação do fluxo. Não autorizo a exibição dos valores nem o envio ao chat.</span></label>
      <Button className="c-deep-button w-fit rounded-xl" disabled={!selectedFile || formatStatus !== "valid" || !password || !confirmed} onClick={preparePackage}>Pré-validar pacote</Button>
      {notice && <p role="status" className="c-copy text-xs leading-5">{notice}</p>}
    </div>
    <details className="c-border mt-5 rounded-xl border p-4"><summary className="c-ink cursor-pointer text-xs font-semibold">Entradas que o manifesto reconhecerá</summary><div className="mt-3 grid gap-2 sm:grid-cols-2">{expectedNames.map(name => <span key={name} className="c-soft text-xs">{name}</span>)}</div></details>
    <ul className="c-copy mt-5 grid gap-2 text-xs leading-5">{SECRET_INTAKE_RULES.map(rule => <li key={rule}>• {rule}</li>)}</ul>
  </article>;
}
