import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { KeyRound, ShieldCheck } from "lucide-react";
import React from "react";

type AccessNoticeDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function AccessNoticeDialog({ open, onOpenChange }: AccessNoticeDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="concilium-settings-dialog max-w-[calc(100%-1.5rem)] p-0 sm:max-w-md">
        <DialogHeader className="c-border border-b px-6 pb-5 pt-6 text-left">
          <div className="flex items-start gap-3">
            <span className="c-tint c-accent grid h-10 w-10 shrink-0 place-items-center rounded-xl"><KeyRound size={19} /></span>
            <div>
              <DialogTitle className="font-editorial c-ink text-[25px] font-normal tracking-[-0.03em]">Área reservada em preparação</DialogTitle>
              <DialogDescription className="c-copy mt-1 text-[12px] leading-5">Esta versão é institucional e ainda não possui uma conta própria do Concilium para acesso de participantes.</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <div className="space-y-4 px-6 py-6">
          <p className="c-copy text-[13px] leading-6">Para proteger suas escolhas de conta, o site não abre mais o portal de autenticação compartilhado. Assim, nenhuma sessão de outro projeto é usada como se fosse uma conta do Concilium.</p>
          <div className="concilium-security-note rounded-2xl border p-4">
            <p className="c-success-ink flex items-center gap-2 text-[13px] font-bold"><ShieldCheck size={16} className="c-success" /> Próxima etapa de segurança</p>
            <p className="c-copy mt-1 text-[12px] leading-5">O acesso será ativado quando a área autenticada de casos existir, com identidade própria, MFA por passkey/TOTP e permissões por caso.</p>
          </div>
          <Button type="button" onClick={() => onOpenChange(false)} className="c-deep-button h-11 w-full rounded-xl text-[12px] font-bold">Entendi</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
