# Concilium — checkpoint da fase 40

## Estrategista como figura central
O Estrategista não é apenas mais uma IA do Laboratório. Ele coordena a exploração.

### Acesso

- recebe a pergunta e o contexto integral autorizado pelo titular;
- preserva detalhes que podem alterar a análise;
- faz triagem e coordenação antes de distribuir o material;
- não confunde acesso integral com poder de decidir pelo titular.

### Distribuição

As IAs que desenvolvem as linhas recebem:

- pauta do Estrategista;
- contexto projetado;
- evidências comuns;
- somente a pergunta e o histórico pertinentes à sua linha.

O conteúdo é mascarado antes da transmissão, mantendo a semântica necessária.

### Continuidade

Cada resposta do titular retorna primeiro ao Estrategista. Ele atualiza a pauta, pode indicar encerramento, continuidade, nova lacuna ou redistribuição e então repassa somente o necessário às linhas.

## Bibliotecário → Estrategista
O encaminhamento não transporta apenas a palavra-chave. Ele leva:

- pergunta original;
- pacote neutro já triado;
- resultados recuperados;
- fontes e metadados disponíveis;
- limitações e perguntas de continuidade.

Assim, o Estrategista compreende o âmago da solicitação sem exigir que o Bibliotecário receba o caso integral.

## Implementação
- `strategistBrief` e `strategistModelId` persistidos;
- coordenação inicial e de continuação;
- resposta do Bibliotecário transportada com pacote e resultados;
- interface do Laboratório atualizada para mostrar a centralidade do Estrategista;
- `PHASE_39_CHECKPOINT.md` e este checkpoint.

## Limite
A redistribuição é atualmente registrada na pauta atualizada e aplicada à continuação das linhas envolvidas. A abertura automática de uma nova linha física ainda aguarda validação do ciclo básico.
