# Concilium — checkpoint da fase 49

## Validação do manifesto interno
Foi preparada a etapa que vem depois da descriptografia em memória.

### Formato esperado

O pacote poderá conter:

```text
concilium-secrets.manifest.json
```

O manifesto declara nomes e metadados não secretos. Ele não deve ser usado para transportar valores como parte do relatório.

### Validação

A função de validação:

- extrai somente nomes;
- suporta JSON estruturado e linhas `NOME=`/`NOME:`;
- compara com o catálogo conhecido;
- detecta entradas ausentes;
- detecta entradas desconhecidas;
- detecta duplicidades;
- não retorna valores secretos.

### Segurança

A validação do manifesto não confirma se um segredo é correto, válido ou atual. Ela apenas impede encaminhamento automático para o módulo errado. Valores continuam dentro do fluxo cifrado e não aparecem em respostas, logs ou auditoria.

## Arquivos

- `shared/secretManifest.ts`;
- `shared/secretManifest.test.ts`;
- `SECURE_SECRET_INTAKE.md`.

## Estado
Validador de nomes preparado e testado com valores fictícios. A integração com o conteúdo interno do 7z depende do descriptografador em memória.
