# Concilium — checkpoint da fase 17

## Homologação individual
Cada rodada da Arena passa a permitir que sua síntese seja:

- homologada para uso;
- marcada para revisão;
- marcada como não utilizada.

A homologação é individual: a síntese da rodada 1 pode ser utilizada mesmo que a rodada 3 ainda esteja em análise, e uma síntese posterior pode ser recusada sem apagar as anteriores.

## Sessões e equipes alternativas
A Arena agora prevê sessões independentes:

- equipe/sessão original preservada;
- nova equipe a partir de qualquer rodada recolhida;
- vínculo com a rodada de origem;
- nova sessão sem apagar ou reiniciar a anterior;
- nova autorização do conteúdo para o primeiro round da sessão derivada.

## Comparador
Foi criado o comparador assistido de sínteses, com:

- pontos em comum;
- divergências;
- o que uma sessão considerou e a outra não;
- perguntas para chamar novamente o supervisor;
- auxílio à decisão humana, sem escolha automática.

A comparação pode ser feita entre rodadas diferentes e entre sessões/equipes diferentes.

## Limites
A comparação não transforma divergência em erro e não cria vencedor automático. O resultado serve para orientar nova pergunta ao supervisor, nova busca no Bibliotecário ou decisão humana sobre qual linha merece refinamento.

## Estado
A estrutura de banco, endpoints e controles iniciais de interface foram adicionados. A validação em build/banco real permanece pendente junto com as migrações.
