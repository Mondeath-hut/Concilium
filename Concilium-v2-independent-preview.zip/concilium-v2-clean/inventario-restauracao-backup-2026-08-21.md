# Inventário de restauração do backup — 2026-08-21

## Origem e finalidade

Fonte recebida do titular: `/home/ubuntu/upload/concilium.zip`. A inspeção foi limitada à listagem do arquivo compactado; nenhum código foi executado e nenhum segredo foi extraído ou reaproveitado.

## Achado relevante

O backup contém uma implementação anterior do Comitê de IA, incluindo os arquivos `client/src/components/AiAnalysisLab.tsx`, `server/aiForum.ts`, `shared/aiForumPolicy.ts`, `server/aiForumPolicy.test.ts`, `server/workspacePolicy.test.ts`, `scripts/manage-ai-lab-validation-fixture.mjs`, `ai-lab-validation.md` e `ai-provider-sources.md`.

Esse achado demonstra que a ausência atual do Comitê de IA decorre de **não incorporação da implementação anterior nesta cópia do projeto**, e não comprova que credenciais de provedores tenham sido migradas. A restauração deverá reutilizar apenas lógica compatível, revisar políticas e solicitar novamente qualquer segredo indispensável que não esteja configurado nesta conta.
