# Concilium — checkpoint da fase 12

## Catálogo inicial do Knowledge Service
Foi criado um manifesto de seed para iniciar um acervo amplo, sem limitar a biblioteca ao caso de divórcio.

O primeiro catálogo contempla famílias de fontes para:

- legislação federal;
- jurisprudência constitucional;
- jurisprudência infraconstitucional;
- atos e orientações de política judiciária;
- legislação estadual, municipal e regras locais configuráveis.

As áreas previstas incluem Família, Criminal, Contratos, Contábil, Trabalhista, Empresarial, Processual, Constitucional, Tributário e Geral.

## Curadoria antes da ingestão
O manifesto exige, para cada lote:

- fonte oficial ou material com licença adequada;
- país e jurisdição;
- órgão emissor ou tribunal;
- versão e publicação;
- vigência;
- revogação, alteração ou superação;
- localização da citação;
- escopo de autoridade;
- não tratamento de pendências como fundamento atual.

## Estratégia de expansão
A recomendação é começar por Direito de Família e fundamentos transversais, depois ampliar para Contratos, Processo Civil, Empresarial/Contábil, Trabalhista, Tributário, Criminal e legislação local conforme a jurisdição do caso.

O catálogo é preparado em lotes revisáveis. Não será feita cópia indiscriminada de material protegido ou de procedência incerta.

## Próximo marco
Implementar a fila de ingestão e o painel editorial do Knowledge Service, permitindo cadastrar, revisar, suspender e revalidar fontes sem afetar a operação do Concilium.
