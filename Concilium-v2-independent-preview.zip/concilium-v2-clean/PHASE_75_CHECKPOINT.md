# Concilium — checkpoint da fase 75

## Interface de histórico documental

Foi criada a interface para consultar versões registradas por documento.

### Exibe

- seleção do documento;
- rótulo da versão;
- data de recebimento;
- nota de alteração;
- hash técnico;
- referência da origem;
- aviso sobre abertura privada.

### Regras

- versões anteriores continuam preservadas;
- hash não é tratado como autenticidade;
- semelhança técnica não é equivalência jurídica;
- abertura de arquivo depende do conector privado autorizado;
- nenhum arquivo é exposto automaticamente.

## Arquivos

- `client/src/components/DocumentVersionHistory.tsx`;
- integração em `client/src/pages/OwnerWorkspace.tsx`;
- `PHASE_75_CHECKPOINT.md`.
