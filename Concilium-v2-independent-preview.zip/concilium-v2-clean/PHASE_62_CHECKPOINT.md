# Concilium — checkpoint da fase 62

## Nova pulverização da exploração derivada

Foi implementado o endpoint que coordena uma exploração derivada depois de sua criação e de um pacote de ramificações submetido.

### Fluxo

- confirma titular, caso, exploração e pacote;
- exige `derivationType: branch`;
- exige pacote em `submitted`;
- recupera o contexto original cifrado somente para o Estrategista autorizado;
- envia projeção protegida às linhas do Laboratório;
- cria novas ideias e threads com novo `runId`;
- preserva possíveis ramificações da nova exploração;
- registra auditoria sem conteúdo sensível.

### Nova rota

```text
coordinateDerivedStrategyExploration
```

### Garantias

- a exploração original não é reaberta;
- a nova exploração tem novas linhas independentes;
- o contexto integral não é enviado às IAs derivadas;
- modelos não recebem respostas de outras linhas;
- a nova pergunta não é tratada como conclusão;
- falhas de um modelo não apagam as demais linhas.

## Estado

O ciclo completo de criação e coordenação da exploração derivada está preparado no backend. Ainda falta expor na interface a seleção de modelos e o botão de iniciar a nova pulverização após a criação da unidade.
