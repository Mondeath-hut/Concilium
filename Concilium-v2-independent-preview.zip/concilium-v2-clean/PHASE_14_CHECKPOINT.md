# Concilium — checkpoint da fase 14

## Laboratório interativo por linhas
A exploração deixou de ser somente uma resposta por IA. Cada alternativa agora pode manter uma linha própria:

- linha ativa;
- aguardando resposta do titular;
- encerrada;
- selecionada para a Arena.

A IA pode declarar que concluiu ou fazer uma pergunta objetiva. Quando pergunta, a pergunta fica vinculada ao seu thread e não ao histórico das outras IAs.

## Perguntas e respostas
Foram adicionados:

- threads por alternativa/modelo;
- mensagens separadas por thread;
- perguntas pendentes;
- respostas do titular;
- estado da linha após a resposta;
- continuação do modelo usando somente o histórico daquela linha;
- encerramento automático quando não há nova lacuna;
- nova pergunta quando ainda há informação indispensável.

## Agrupamento semântico
Perguntas semanticamente próximas podem receber o mesmo grupo. A resposta do titular é materializada em cada thread correspondente, mas o histórico de outra linha nunca é anexado. Perguntas de patrimônio, filhos, convivência ou processo permanecem separadas quando exigem respostas diferentes.

## Exemplo de funcionamento
Uma IA pode encerrar após sugerir copropriedade temporária. Outra pode perguntar sobre valor do imóvel, renda e prazo. Uma terceira pode perguntar sobre filhos e efeitos familiares. Cada pergunta segue sua linha; uma resposta patrimonial não aparece na linha dos filhos, salvo quando o agrupamento identificar equivalência real.

## Limitações atuais
O agrupamento semântico inicial é conservador e baseado em similaridade textual; a evolução prevista é usar um classificador dedicado, sempre como auxílio de organização e nunca para fundir contextos automaticamente.
