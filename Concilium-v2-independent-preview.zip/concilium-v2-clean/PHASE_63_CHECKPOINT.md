# Concilium — checkpoint da fase 63

## Interface da nova pulverização

A caixa de ramificações agora permite escolher os modelos e iniciar o novo ciclo da exploração derivada.

### Fluxo visual completo

- revisar pergunta composta;
- submeter pacote;
- criar exploração derivada;
- escolher de 2 a 5 modelos;
- iniciar nova pulverização;
- criar novas linhas independentes;
- preservar novas ramificações para o próximo ciclo.

### Proteções

- modelos são selecionados para o novo `runId`;
- a exploração original não é reaberta;
- a submissão é separada da pulverização;
- a pulverização não começa sem escolha de modelos;
- o contexto integral permanece restrito ao Estrategista;
- o Laboratório recebe projeção protegida.

## Estado

O ciclo visual de ramificação → nova exploração → nova pulverização está conectado. A validação executável ainda depende de dependências, servidor, modelos e banco disponíveis.
