# Concilium — checkpoint da fase 35

## Pergunta normal → mapa contextual → Estrategista/Laboratório
O comportamento padrão do Bibliotecário foi ampliado. Uma pergunta normal não será reduzida a uma busca estreita. O sistema poderá expandi-la em um perímetro de pesquisa contendo:

- conceitos jurídicos relacionados;
- fontes primárias;
- jurisprudência;
- cláusulas e padrões de minuta;
- requisitos e exceções;
- limites e fontes contrárias;
- lacunas de fatos e documentos.

## Roteamento

- pergunta de aplicação ou escolha: `strategy_handoff` → Estrategista;
- pergunta normal com possibilidades: `contextual_research` → Laboratório de Alternativas;
- pedido neutro de fonte: `sources`;
- pedido de cláusulas/modelos: `clause_models`.

O Laboratório não recebe uma conclusão pronta. Recebe o mapa e as fontes triadas para gerar linhas independentes, contextualizar e refinar.

## Implementação

- novo modo `contextual_research`;
- novo campo `handoffTarget`;
- cinco agentes funcionais ativados na pesquisa contextual;
- modo contextual como padrão da Biblioteca;
- encaminhamento visual para Estrategista ou Laboratório;
- transporte transitório da pergunta via `sessionStorage`, sem colocá-la em URL pública;
- testes de classificação e pacote neutro atualizados.

## Estado
Roteamento e contrato preparados. A expansão semântica real da pergunta e a execução dos agentes dependem do Knowledge Service conectado.
