import { secretManifest, type SecretManifestEntry } from "./secretManifest";

export type SecretRoutingDecision = "proposed" | "approved" | "blocked";

export type SecretRoutingPlanItem = {
  name: string;
  consumer: SecretManifestEntry["consumer"] | "unknown";
  decision: SecretRoutingDecision;
  reason: string;
};

/** Cria um plano sem receber valores. Nenhuma entrada é aprovada por inferência nominal. */
export function buildSecretRoutingPlan(names: string[]): SecretRoutingPlanItem[] {
  const uniqueNames = [...new Set(names)];
  const expected = new Map(secretManifest.map(entry => [entry.name, entry]));
  return uniqueNames.map(name => {
    const entry = expected.get(name);
    if (!entry) return { name, consumer: "unknown", decision: "blocked", reason: "Nome ausente no manifesto conhecido." };
    const reason = entry.consumer === "pending_contract"
      ? "Finalidade e escopo ainda precisam de confirmação explícita."
      : "Mapeamento sugerido; aguarda confirmação do titular antes do armazenamento.";
    return { name, consumer: entry.consumer, decision: "proposed", reason };
  });
}

export function approveSecretRouting(plan: SecretRoutingPlanItem[], approvedNames: string[]) {
  const approved = new Set(approvedNames);
  return plan.map(item => {
    if (item.decision === "blocked") return item;
    if (!approved.has(item.name)) return { ...item, decision: "blocked" as const, reason: "Não confirmado pelo titular." };
    if (item.consumer === "pending_contract") return { ...item, decision: "blocked" as const, reason: "Não pode ser aprovado antes da definição de finalidade e escopo." };
    return { ...item, decision: "approved" as const, reason: "Mapeamento confirmado pelo titular." };
  });
}

export function getApprovedSecretNames(plan: SecretRoutingPlanItem[]) {
  return plan.filter(item => item.decision === "approved").map(item => item.name);
}
