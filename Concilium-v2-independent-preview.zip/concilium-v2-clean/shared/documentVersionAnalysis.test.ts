import { describe, expect, it } from "vitest";
import { analyzeDocumentVersions } from "./documentVersionAnalysis";

describe("análise técnica de versões", () => {
  it("identifica hash repetido sem concluir equivalência", () => {
    const result = analyzeDocumentVersions([
      { id: "v2", versionLabel: "2", contentHash: "hash-a", sourceReference: "origem 2", createdAt: "2026-01-02", changeNote: "segunda" },
      { id: "v1", versionLabel: "1", contentHash: "hash-a", sourceReference: "origem 1", createdAt: "2026-01-01", changeNote: "primeira" },
    ]);
    expect(result.duplicateGroups).toEqual([["v2", "v1"]]);
    expect(result.chronologicalOrder).toEqual(["v1", "v2"]);
    expect(result.requiresOwnerReview).toBe(true);
    expect(result.note).toContain("conferir");
  });
});
