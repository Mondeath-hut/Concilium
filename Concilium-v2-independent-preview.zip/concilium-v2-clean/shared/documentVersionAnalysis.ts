export type DocumentVersionLike = { id: string; versionLabel: string; contentHash: string; sourceReference: string; createdAt: Date | string; changeNote: string };

export function analyzeDocumentVersions(versions: DocumentVersionLike[]) {
  const byHash = new Map<string, DocumentVersionLike[]>();
  for (const version of versions) byHash.set(version.contentHash, [...(byHash.get(version.contentHash) ?? []), version]);
  const duplicateGroups = [...byHash.values()].filter(group => group.length > 1).map(group => group.map(version => version.id));
  const ordered = [...versions].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  return {
    versionCount: versions.length,
    duplicateGroups,
    chronologicalOrder: ordered.map(version => version.id),
    requiresOwnerReview: duplicateGroups.length > 0,
    note: duplicateGroups.length ? "Há versões com o mesmo hash; conferir se são cópias ou registros repetidos." : "A análise técnica não identificou hash repetido.",
  };
}
