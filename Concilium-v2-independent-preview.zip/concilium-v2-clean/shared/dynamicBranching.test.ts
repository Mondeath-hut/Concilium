import { describe, expect, it } from "vitest";
import { composeStrategistBranchBundle, markBranchBundleSubmitted } from "./dynamicBranching";

describe("ramificações dinâmicas", () => {
  it("retira ramificações da linha de origem e preserva a proveniência", () => {
    const bundle = composeStrategistBranchBundle({
      id: "bundle-1",
      proposals: [
        { id: "p1", parentRunId: "run-1", parentThreadId: "thread-a", originQuestionId: "q1", question: "O uso exclusivo do imóvel muda a estratégia?", whyItMatters: "Pode alterar a análise patrimonial.", state: "parked" },
        { id: "p2", parentRunId: "run-1", parentThreadId: "thread-b", originQuestionId: "q2", question: "Como comprovar a ocupação e as despesas?", whyItMatters: "Pode alterar a estratégia probatória.", state: "parked" },
      ],
    });
    expect(bundle.state).toBe("ready_for_strategist");
    expect(bundle.sourceThreadIds).toEqual(["thread-a", "thread-b"]);
    expect(bundle.draftQuestion).toContain("uso exclusivo do imóvel");
    expect(bundle.draftQuestion).toContain("Não trate nenhuma delas como fato provado");
  });

  it("não submete automaticamente ao Estrategista", () => {
    const bundle = composeStrategistBranchBundle({ id: "bundle-2", proposals: [{ id: "p1", parentRunId: "run-1", parentThreadId: "thread-a", question: "Existe um eixo novo?", whyItMatters: "Pode mudar a estratégia.", state: "parked" }] });
    expect(bundle.state).toBe("ready_for_strategist");
    expect(markBranchBundleSubmitted(bundle).state).toBe("submitted");
  });
});
