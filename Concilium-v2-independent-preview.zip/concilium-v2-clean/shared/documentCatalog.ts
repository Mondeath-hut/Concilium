import { z } from "zod";

export const documentVaults = ["identity", "family", "property", "income_expenses", "legal_procedural", "agreements_strategies", "evidence", "communications", "research", "quarantine", "archive"] as const;
export type DocumentVault = (typeof documentVaults)[number];
export const documentCatalogStatuses = ["unclassified", "suggested", "needs_owner_review", "confirmed", "quarantined", "archived"] as const;
export type DocumentCatalogStatus = (typeof documentCatalogStatuses)[number];
export const documentSensitivityLevels = ["ordinary", "personal", "sensitive", "highly_sensitive"] as const;
export type DocumentSensitivityLevel = (typeof documentSensitivityLevels)[number];
export const catalogAgentRoles = ["document_classifier", "fact_chronology_extractor", "legal_relevance_reader", "privacy_guardian", "duplicate_version_checker"] as const;
export type CatalogAgentRole = (typeof catalogAgentRoles)[number];

export const documentCatalogSuggestionSchema = z.object({
  suggestedVault: z.enum(documentVaults),
  sensitivity: z.enum(documentSensitivityLevels),
  confidence: z.enum(["high", "medium", "low", "unknown"]),
  reasons: z.array(z.string()).max(12),
  extractedFacts: z.array(z.string()).max(30),
  datesAndChronology: z.array(z.string()).max(20),
  legalRelevance: z.array(z.string()).max(20),
  missingOrUnclear: z.array(z.string()).max(20),
  duplicateOrVersionNote: z.string().nullable(),
});
export type DocumentCatalogSuggestion = z.infer<typeof documentCatalogSuggestionSchema>;

export const DOCUMENT_CATALOG_POLICY = {
  quarantine: "Todo documento novo entra primeiro em quarentena; a IA sugere classificação, mas não move, arquiva, elimina ou compartilha sem confirmação do titular.",
  provenance: "O catálogo preserva nome, hash, origem, data de recebimento, versão e relação com documentos semelhantes.",
  truth: "A IA separa texto encontrado, fato narrado, fato documental, hipótese, data explícita e interpretação. Classificação não comprova autenticidade.",
  privacy: "Identidade, endereços, valores, dados de saúde, dados de terceiros e documentos pessoais permanecem protegidos; o catálogo não os repassa a outras IAs por padrão.",
  legal: "Relevância jurídica é uma sugestão para triagem. Não equivale a validade, decisão, parecer ou prova suficiente.",
} as const;

export function buildDocumentCatalogPrompt(input: { title: string; documentType: string; sourceReference: string; extractedText: string; existingVaults?: string }) {
  return [
    "Você é um agente catalogador de documentos de um workspace jurídico privado.",
    "Classifique e organize sem decidir o caso. O documento novo está em quarentena e nenhuma movimentação, eliminação ou compartilhamento deve ser presumida.",
    "Separe texto encontrado, fato documental, fato narrado, hipótese, data explícita, interpretação e lacuna. Não invente nomes, datas, valores ou vínculos.",
    "Sugira um único cofre principal, mas indique incerteza e cofres relacionados quando necessário. Preserve identidade e dados de terceiros como informação protegida.",
    "Não trate a classificação como prova de autenticidade, validade jurídica, acordo, decisão ou parecer.",
    `Título: ${input.title}.`,
    `Tipo informado: ${input.documentType}.`,
    `Origem informada: ${input.sourceReference}.`,
    input.existingVaults ? `Cofres já existentes no caso: ${input.existingVaults}` : "Nenhum cofre adicional foi informado.",
    "Retorne somente JSON conforme o schema: suggestedVault, sensitivity, confidence, reasons, extractedFacts, datesAndChronology, legalRelevance, missingOrUnclear, duplicateOrVersionNote.",
    `TEXTO EXTRAÍDO DO DOCUMENTO:\n---\n${input.extractedText}\n---`,
  ].join("\n\n");
}
