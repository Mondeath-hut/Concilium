import { describe, expect, it } from "vitest";
import { assertValidScenarioMigration, evaluateParameterValue, isForwardMigration } from "./scenarioParameters";

describe("migração de estágio de cenário", () => {
  it("identifica avanço vs. retrocesso na progressão padrão", () => {
    expect(isForwardMigration({ from: "cooperativo", to: "equilibrado" })).toBe(true);
    expect(isForwardMigration({ from: "defensivo", to: "cooperativo_protegido" })).toBe(false);
  });

  it("exige motivo com no mínimo 8 caracteres", () => {
    expect(() => assertValidScenarioMigration({ from: "cooperativo", to: "defensivo", reason: "" })).toThrow(/motivo/);
    expect(() => assertValidScenarioMigration({ from: "cooperativo", to: "defensivo", reason: "curto" })).toThrow(/motivo/);
  });

  it("não permite migrar para o mesmo estágio", () => {
    expect(() => assertValidScenarioMigration({ from: "equilibrado", to: "equilibrado", reason: "sem mudança real" })).toThrow(/mudar de estágio/);
  });

  it("aceita retrocesso explícito com motivo (negociação evoluiu melhor que o previsto)", () => {
    expect(() => assertValidScenarioMigration({ from: "defensivo", to: "equilibrado", reason: "outra parte aceitou proposta cooperativa" })).not.toThrow();
  });
});

describe("avaliação de parâmetro do cenário", () => {
  const pensao = {
    parameterKey: "pensao_valor_mensal",
    label: "Valor mensal da pensão",
    valueType: "numeric" as const,
    minValue: 900,
    idealValue: 1200,
    maxValue: 1800,
    hardFloor: 700,
  };

  it("marca vermelho quando abaixo da reserva mínima protegida", () => {
    expect(evaluateParameterValue(pensao, 600).level).toBe("red");
  });

  it("marca vermelho quando acima do máximo aceitável", () => {
    expect(evaluateParameterValue(pensao, 2100).level).toBe("red");
  });

  it("marca amarelo quando dentro do intervalo mas fora do ideal", () => {
    expect(evaluateParameterValue(pensao, 1000).level).toBe("amber");
  });

  it("marca verde apenas no valor ideal exato", () => {
    expect(evaluateParameterValue(pensao, 1200).level).toBe("green");
  });
});
