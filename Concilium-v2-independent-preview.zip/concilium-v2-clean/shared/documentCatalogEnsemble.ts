import type { DocumentCatalogSuggestion, CatalogAgentRole } from "./documentCatalog";

export type DocumentCatalogAgent = { role: CatalogAgentRole; analyze: () => Promise<DocumentCatalogSuggestion> };

export async function runDocumentCatalogEnsemble(agents: DocumentCatalogAgent[]) {
  const results = await Promise.all(agents.map(async agent => {
    try { return { role: agent.role, status: "completed" as const, suggestion: await agent.analyze() }; }
    catch { return { role: agent.role, status: "failed" as const, suggestion: null }; }
  }));
  const completed = results.filter(item => item.suggestion);
  const keys = completed.map(item => `${item.suggestion!.suggestedVault}:${item.suggestion!.sensitivity}`);
  const unanimous = keys.length > 0 && new Set(keys).size === 1;
  return {
    results,
    roleResults: results.map(item => ({ role: item.role, status: item.status, suggestion: item.suggestion })),
    summary: {
      completedRoles: completed.map(item => item.role),
      failedRoles: results.filter(item => item.status === "failed").map(item => item.role),
      unanimousClassification: unanimous,
      suggestedVault: unanimous ? completed[0].suggestion!.suggestedVault : null,
      sensitivity: unanimous ? completed[0].suggestion!.sensitivity : null,
      requiresOwnerReview: true,
    },
  };
}
