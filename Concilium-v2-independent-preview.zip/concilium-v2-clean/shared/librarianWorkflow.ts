import { z } from "zod";

/** O Bibliotecário continua neutro: recupera e qualifica material, sem conhecer o caso protegido. */
export const librarianResearchModes = ["contextual_research", "sources", "clause_models", "strategy_handoff"] as const;
export type LibrarianResearchMode = (typeof librarianResearchModes)[number];

export const librarianAgentRoles = [
  "primary_source_finder",
  "jurisprudence_finder",
  "validity_auditor",
  "clause_pattern_curator",
  "counter_source_auditor",
] as const;
export type LibrarianAgentRole = (typeof librarianAgentRoles)[number];

export const librarianRoutingSchema = z.object({
  mode: z.enum(librarianResearchModes),
  label: z.string(),
  handoffRecommended: z.boolean(),
  handoffTarget: z.enum(["strategist", "alternatives_lab", "none"]),
  reason: z.string(),
  activeRoles: z.array(z.enum(librarianAgentRoles)),
});
export type LibrarianRouting = z.infer<typeof librarianRoutingSchema>;

export const librarianPacketItemSchema = z.object({
  resultId: z.string(),
  materialType: z.enum(["primary_source", "jurisprudence", "clause_model", "secondary_material"]),
  treatment: z.enum(["candidate_foundation", "non_normative_model", "needs_verification", "not_current"]),
  limitation: z.string(),
  handoffQuestion: z.string(),
});
export const librarianResponsePacketSchema = z.object({
  mode: z.enum(librarianResearchModes),
  neutralSummary: z.string(),
  items: z.array(librarianPacketItemSchema),
});
export type LibrarianResponsePacket = z.infer<typeof librarianResponsePacketSchema>;

type LibrarianResultLike = {
  id: string;
  authorityLevel: "primaria" | "jurisprudencia_relevante" | "secundaria" | "modelo_nao_normativo";
  validityState: "vigente" | "revogada" | "superada" | "expirada" | "pendente_verificacao";
  citations: Array<{ verified: boolean }>;
};

export function buildLibrarianResponsePacket(input: { mode: LibrarianResearchMode; results: LibrarianResultLike[] }): LibrarianResponsePacket {
  return {
    mode: input.mode,
    neutralSummary: input.results.length
      ? "Pacote neutro: os itens abaixo são material recuperado para conferência. A classificação não substitui a leitura da fonte, a análise profissional ou a decisão do titular."
      : "Nenhum item foi recuperado para compor o pacote neutro. A ausência de resultado não prova ausência de fundamento.",
    items: input.results.map(result => {
      const materialType = result.authorityLevel === "primaria" ? "primary_source" : result.authorityLevel === "jurisprudencia_relevante" ? "jurisprudence" : result.authorityLevel === "modelo_nao_normativo" ? "clause_model" : "secondary_material";
      const verified = result.validityState === "vigente" && result.citations.length > 0 && result.citations.every(citation => citation.verified);
      const treatment = result.authorityLevel === "modelo_nao_normativo" ? "non_normative_model" : ["revogada", "superada", "expirada"].includes(result.validityState) ? "not_current" : verified ? "candidate_foundation" : "needs_verification";
      const limitation = treatment === "non_normative_model" ? "Modelo de trabalho; não é norma nem redação automaticamente adequada ao caso." : treatment === "not_current" ? "Não deve ser usado como fundamento atual sem confirmar a relação com a fonte vigente." : treatment === "needs_verification" ? "Vigência, citação ou adequação jurisdicional exige conferência adicional." : "Ainda exige leitura da fonte, confronto com fontes contrárias e validação profissional.";
      const handoffQuestion = input.mode === "strategy_handoff" ? "Quais fatos, documentos e restrições precisam ser confirmados pelo Estrategista antes de considerar este material?" : materialType === "clause_model" ? "Quais campos, requisitos e riscos precisam ser adaptados antes de qualquer uso?" : "Qual é o alcance exato desta fonte e quais limites ou exceções devem ser verificados?";
      return { resultId: result.id, materialType, treatment, limitation, handoffQuestion };
    }),
  };
}

const strategySignals = /\b(no meu caso|meu caso|qual estratégia|o que devo fazer|como negociar|negociar|qual caminho|qual a melhor opção|aplicar ao caso|posso usar|posso utilizar|posso substituir|em vez de|no lugar de|eximir|dispensar|evitar o pagamento)\b/i;
const clauseSignals = /\b(cláusula|clausula|minuta|minutas|modelo|modelos|redação|redacao|pacto|acordo|termo)\b/i;

export function classifyLibrarianRequest(query: string, requestedMode?: LibrarianResearchMode): LibrarianRouting {
  const mode = requestedMode ?? (strategySignals.test(query) ? "strategy_handoff" : clauseSignals.test(query) ? "clause_models" : "contextual_research");
  if (mode === "strategy_handoff") return {
    mode,
    label: "Pergunta com possível encaminhamento ao Estrategista",
    handoffRecommended: true,
    handoffTarget: "strategist",
    reason: "A pergunta parece pedir escolha, adaptação ao caso ou orientação de negociação. O Bibliotecário pode fornecer fontes neutras e localizar padrões de cláusula, mas a formulação estratégica deve ser feita em linhas independentes no Estrategista.",
    activeRoles: ["primary_source_finder", "jurisprudence_finder", "validity_auditor", "clause_pattern_curator", "counter_source_auditor"],
  };
  if (mode === "clause_models") return {
    mode,
    label: "Pesquisa de cláusulas e modelos não normativos",
    handoffRecommended: false,
    handoffTarget: "none",
    reason: "O Bibliotecário pode localizar padrões de cláusulas, minutas e requisitos formais, sempre identificando que são modelos de trabalho e não texto automaticamente válido para o caso.",
    activeRoles: ["primary_source_finder", "validity_auditor", "clause_pattern_curator", "counter_source_auditor"],
  };
  if (mode === "sources") return {
    mode,
    label: "Pesquisa neutra de fontes",
    handoffRecommended: false,
    handoffTarget: "none",
    reason: "A consulta será tratada como pesquisa de fontes, vigência, jurisdição, autoridade e relações, sem enviar contexto sensível do caso.",
    activeRoles: ["primary_source_finder", "jurisprudence_finder", "validity_auditor", "counter_source_auditor"],
  };
  return {
    mode: "contextual_research",
    label: "Mapa contextual amplo para encaminhamento",
    handoffRecommended: true,
    handoffTarget: "alternatives_lab",
    reason: "A pergunta será expandida em conceitos, fontes, cláusulas, limites e contrapontos relacionados. O resultado segue para o Laboratório de Alternativas, que poderá contextualizar e refinar sem receber uma conclusão pronta.",
    activeRoles: ["primary_source_finder", "jurisprudence_finder", "validity_auditor", "clause_pattern_curator", "counter_source_auditor"],
  };
}

export const LIBRARIAN_ENSEMBLE_CONTRACT = {
  architecture: "O Knowledge Service pode distribuir a consulta a agentes independentes por função e consolidar apenas metadados, fontes e divergências verificáveis.",
  neutrality: "Agentes não recebem o caso protegido por padrão e não escolhem estratégia pelo titular.",
  clauseModels: "Modelos e minutas são apresentados como material não normativo, com origem, jurisdição, data, vigência, limitações e pontos que exigem adaptação profissional.",
  handoff: "Pedidos de escolha, negociação ou aplicação ao caso são sinalizados para o Estrategista; fontes recuperadas podem acompanhar o encaminhamento sem contaminar as linhas independentes.",
} as const;
