export const SEVEN_ZIP_MAGIC = [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c] as const;

export function isSevenZipHeader(bytes: ArrayLike<number>) {
  return SEVEN_ZIP_MAGIC.every((value, index) => bytes[index] === value);
}

export function sanitizeArchiveDisplayName(name: string) {
  const lastSegment = name.replaceAll("\\", "/").split("/").pop() ?? "pacote.7z";
  return lastSegment.replace(/[^A-Za-z0-9À-ÿ._ -]/g, "_").slice(0, 180) || "pacote.7z";
}

export const SECRET_INTAKE_STATES = ["file_selected", "format_validated", "password_ready", "manifest_pending", "awaiting_owner_confirmation", "stored", "rejected"] as const;
export type SecretIntakeState = (typeof SECRET_INTAKE_STATES)[number];

export const SECRET_INTAKE_SECURITY_NOTICE = "A validação do cabeçalho identifica o formato sem abrir, extrair ou revelar qualquer segredo.";
