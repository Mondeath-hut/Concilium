import { describe, expect, it } from "vitest";
import { assertValidProposalTransition, hearingChecklistAlert, isValidProposalTransition, proposalStatusAllowsFormalAcceptance, proposalStatusIsFormal, validHearingTransition } from "./hearingChecklist";

describe("hearing checklist rules", () => {
  it("requires a pause for an unresolved non-negotiable item", () => {
    expect(hearingChecklistAlert({ itemType: "inegociavel_exige_pausa", priority: "critica", state: "pendente" })).toEqual({ level: "red", requiresOwnerPause: true, label: "Pausa exigida" });
  });

  it("marks uncertain evidence as amber", () => {
    expect(hearingChecklistAlert({ itemType: "pendente_de_prova", priority: "normal", state: "pendente" }).level).toBe("amber");
  });

  it("does not allow a closed hearing to restart", () => {
    expect(validHearingTransition("encerrada", "em_andamento")).toBe(false);
    expect(validHearingTransition("pausada", "em_andamento")).toBe(true);
  });

  it("keeps internal drafts out of the formal negotiation history", () => {
    expect(proposalStatusIsFormal("rascunho_interno")).toBe(false);
    expect(proposalStatusIsFormal("apresentada")).toBe(true);
    expect(proposalStatusAllowsFormalAcceptance("rascunho_interno")).toBe(false);
    expect(proposalStatusAllowsFormalAcceptance("contraproposta_recebida")).toBe(true);
  });
});

// [NOVO v2 / Fase 0] antes desta migração, a tabela do banco só aceitava 5 dos 9 estados
// aqui definidos ("aceita parcialmente", "contraproposta recebida" e "substituída" eram
// impossíveis de registrar). Estes testes cobrem o grafo de transição real da Mesa Formal.
describe("mesa formal — transição dos 9 estados", () => {
  it("uma proposta apresentada nunca pula direto para encerrada sem passar por uma resposta", () => {
    expect(isValidProposalTransition("apresentada", "encerrada")).toBe(false);
    expect(isValidProposalTransition("apresentada", "recebida")).toBe(true);
  });

  it("permite os três desfechos que antes não existiam no banco", () => {
    expect(isValidProposalTransition("recebida", "aceita_parcialmente")).toBe(true);
    expect(isValidProposalTransition("recebida", "contraproposta_recebida")).toBe(true);
    expect(isValidProposalTransition("apresentada", "substituida")).toBe(true);
  });

  it("estados terminais (aceita, recusada, substituída, encerrada) não voltam atrás", () => {
    expect(isValidProposalTransition("substituida", "apresentada")).toBe(false);
    expect(isValidProposalTransition("encerrada", "apresentada")).toBe(false);
  });

  it("lança erro descritivo para transição inválida", () => {
    expect(() => assertValidProposalTransition("rascunho_interno", "aceita")).toThrow(/Transição de proposta inválida/);
  });
});
