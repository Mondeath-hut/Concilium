import { describe, expect, it } from "vitest";
import { runDocumentCatalogEnsemble } from "./documentCatalogEnsemble";

const suggestion = { suggestedVault: "legal_procedural" as const, sensitivity: "highly_sensitive" as const, confidence: "medium" as const, reasons: [], extractedFacts: [], datesAndChronology: [], legalRelevance: [], missingOrUnclear: [], duplicateOrVersionNote: null };

describe("ensemble de catalogação documental", () => {
  it("preserva divergência e nunca confirma movimentação automaticamente", async () => {
    const result = await runDocumentCatalogEnsemble([
      { role: "document_classifier", analyze: async () => suggestion },
      { role: "privacy_guardian", analyze: async () => ({ ...suggestion, suggestedVault: "evidence" }) },
      { role: "duplicate_version_checker", analyze: async () => { throw new Error("falha fictícia"); } },
    ]);
    expect(result.summary.unanimousClassification).toBe(false);
    expect(result.summary.requiresOwnerReview).toBe(true);
    expect(result.summary.failedRoles).toContain("duplicate_version_checker");
  });
});
