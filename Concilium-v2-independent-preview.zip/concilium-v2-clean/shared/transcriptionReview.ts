export type TranscriptSegment = {
  id: string;
  startMs: number;
  endMs: number;
  textOriginal: string;
  speaker?: string;
  confidence?: number;
};

export type TranscriptReviewKind = "possivel_proposta" | "possivel_aceite" | "possivel_recusa" | "valor_ou_prazo" | "fala_ambigua";

export type TranscriptReview = {
  segmentId: string;
  kind: TranscriptReviewKind;
  requiresHumanConfirmation: true;
  reason: string;
};

const fillerPattern = /\b(?:é|eh|né|ne|hum|hã|ah|tipo|assim)\b[,.]?/gi;

/** Keeps the original transcript untouched and creates only a reading aid. */
export function normalizeTranscriptForReview(text: string): string {
  return text.replace(fillerPattern, " ").replace(/\s{2,}/g, " ").trim();
}

export function transcriptReviews(segment: TranscriptSegment): TranscriptReview[] {
  const normalized = normalizeTranscriptForReview(segment.textOriginal);
  const lower = normalized.toLocaleLowerCase("pt-BR");
  const reviews: TranscriptReview[] = [];
  const lowConfidence = segment.confidence !== undefined && segment.confidence < 0.86;
  const containsMoneyOrTime = /(?:r\$|reais|prazo|meses?|anos?|dias?|%|por cento|\b\d+[.,]?\d*)/i.test(normalized);
  const possibleAcceptance = /\b(?:aceito|aceita|concordo|de acordo|fechado)\b/i.test(lower);
  const possibleRefusal = /\b(?:recuso|recusado|não aceito|nao aceito|discordo)\b/i.test(lower);
  const possibleProposal = /\b(?:proponho|proposta|ofereço|ofereco|podemos|poderia)\b/i.test(lower);

  if (possibleAcceptance) reviews.push({ segmentId: segment.id, kind: "possivel_aceite", requiresHumanConfirmation: true, reason: "A fala contém linguagem que pode indicar aceite." });
  if (possibleRefusal) reviews.push({ segmentId: segment.id, kind: "possivel_recusa", requiresHumanConfirmation: true, reason: "A fala contém linguagem que pode indicar recusa." });
  if (possibleProposal) reviews.push({ segmentId: segment.id, kind: "possivel_proposta", requiresHumanConfirmation: true, reason: "A fala contém linguagem que pode indicar proposta." });
  if (containsMoneyOrTime) reviews.push({ segmentId: segment.id, kind: "valor_ou_prazo", requiresHumanConfirmation: true, reason: "Valores e prazos exigem conferência humana." });
  if (lowConfidence || !normalized) reviews.push({ segmentId: segment.id, kind: "fala_ambigua", requiresHumanConfirmation: true, reason: "Trecho com baixa confiança ou conteúdo insuficiente para interpretação segura." });

  return reviews;
}
