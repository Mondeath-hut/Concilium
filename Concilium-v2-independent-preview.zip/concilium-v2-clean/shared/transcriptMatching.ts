/**
 * Camada de comparação entre um trecho de fala (áudio ao vivo ou ditado manual — ver
 * TRANSCRICAO_AUDIENCIA_INTEGRACAO.md) e os itens do checklist dinâmico do cenário ativo
 * (Manual funcional v2, seção 9-A).
 *
 * Roda em cascata, cada camada é um substituto da anterior quando ela não está disponível:
 *   A) online     — modelo de linguagem já conectado ao Concilium (melhor qualidade).
 *   B) local       — modelo pequeno de embeddings rodando no próprio processo, sem internet.
 *   C) léxica      — sinônimos cadastrados por item + extração de número, sempre disponível.
 *
 * Nenhuma camada decide sozinha: o resultado é sempre um TranscriptReview com
 * requiresHumanConfirmation, igual ao que shared/transcriptionReview.ts já faz para as
 * categorias genéricas (possível aceite/recusa/proposta/valor).
 */
import { transcriptReviews, type TranscriptReview, type TranscriptSegment } from "./transcriptionReview";

export type ChecklistItemForMatching = {
  id: string;
  description: string;
  canonicalKeywords: string[];
};

export type MatchMethod = "online" | "local_offline" | "lexico";

export type ChecklistMatch = {
  checklistItemId: string;
  method: MatchMethod;
  /** 0 a 1. A camada léxica nunca deve reportar mais que 0.7 — é aproximação, não semântica de verdade. */
  confidence: number;
};

/** Injetada pelo servidor; ausente ou lançando erro faz a cascata cair para a próxima camada. */
export type OnlineSemanticMatcher = (text: string, items: ChecklistItemForMatching[]) => Promise<ChecklistMatch[]>;

/** Injetada pelo servidor quando um modelo local de embeddings estiver disponível. */
export type LocalSemanticMatcher = (text: string, items: ChecklistItemForMatching[]) => Promise<ChecklistMatch[]>;

export type MatchCascadeProviders = {
  online?: OnlineSemanticMatcher;
  localOffline?: LocalSemanticMatcher;
};

/**
 * Converte números por extenso (português) e valores em R$ para um valor numérico.
 * Cobre o vocabulário financeiro típico do caso ("dois mil reais", "vinte e quatro meses").
 * Não tenta ser um parser completo de linguagem natural — só o necessário para comparar
 * com os parâmetros do cenário (shared/scenarioParameters.ts).
 */
const UNIT_WORDS: Record<string, number> = {
  zero: 0, um: 1, uma: 1, dois: 2, duas: 2, três: 3, tres: 3, quatro: 4, cinco: 5,
  seis: 6, sete: 7, oito: 8, nove: 9, dez: 10, onze: 11, doze: 12, treze: 13,
  catorze: 14, quatorze: 14, quinze: 15, dezesseis: 16, dezessete: 17, dezoito: 18, dezenove: 19,
  vinte: 20, trinta: 30, quarenta: 40, cinquenta: 50, sessenta: 60, setenta: 70, oitenta: 80, noventa: 90,
  cem: 100, cento: 100, duzentos: 200, trezentos: 300, quatrocentos: 400, quinhentos: 500,
  seiscentos: 600, setecentos: 700, oitocentos: 800, novecentos: 900,
  mil: 1000,
};

export function extractSpokenNumbers(text: string): number[] {
  const normalized = text.toLocaleLowerCase("pt-BR");
  const found: number[] = [];

  // Formatos numéricos diretos: "R$ 2.000", "2000", "2.100,50"
  const numericPattern = /r?\$?\s*(\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?|\d+(?:,\d{1,2})?)/g;
  for (const match of normalized.matchAll(numericPattern)) {
    const raw = match[1].replace(/\./g, "").replace(",", ".");
    const value = Number(raw);
    if (!Number.isNaN(value) && value > 0) found.push(value);
  }

  // Números por extenso: soma sequências de palavras numéricas contíguas.
  const words = normalized.replace(/[^\p{L}\s]/gu, " ").split(/\s+/).filter(Boolean);
  let acc = 0;
  let hasValue = false;
  const flush = () => {
    if (hasValue && acc > 0) found.push(acc);
    acc = 0;
    hasValue = false;
  };
  for (const word of words) {
    if (word === "e") continue; // "vinte e quatro" -> ignora o conectivo
    if (word in UNIT_WORDS) {
      const value = UNIT_WORDS[word];
      if (value === 1000) {
        acc = (acc || 1) * 1000;
      } else if (value === 100 && acc > 0 && acc < 100) {
        acc *= value;
      } else {
        acc += value;
      }
      hasValue = true;
    } else {
      flush();
    }
  }
  flush();

  return found;
}

/** Camada C: dicionário de sinônimos cadastrado por item + correspondência textual simples. */
export function lexicalMatch(text: string, items: ChecklistItemForMatching[]): ChecklistMatch[] {
  const normalized = text.toLocaleLowerCase("pt-BR");
  const matches: ChecklistMatch[] = [];
  for (const item of items) {
    const hit = item.canonicalKeywords.some(keyword => normalized.includes(keyword.toLocaleLowerCase("pt-BR")));
    if (hit) matches.push({ checklistItemId: item.id, method: "lexico", confidence: 0.6 });
  }
  return matches;
}

export type TranscriptMatchResult = {
  reviews: TranscriptReview[];
  checklistMatches: ChecklistMatch[];
  spokenNumbers: number[];
};

/**
 * Ponto de entrada único usado tanto pelo modo ao vivo quanto pelo modo manual (ditado).
 * A origem do texto (áudio transcrito ou digitado) não muda o comportamento — só quem
 * chama essa função é diferente.
 */
export async function analyzeTranscriptSegment(
  segment: TranscriptSegment,
  checklistItems: ChecklistItemForMatching[],
  providers: MatchCascadeProviders = {},
): Promise<TranscriptMatchResult> {
  const reviews = transcriptReviews(segment);
  const spokenNumbers = extractSpokenNumbers(segment.textOriginal);

  if (providers.online) {
    try {
      const matches = await providers.online(segment.textOriginal, checklistItems);
      if (matches.length > 0) return { reviews, checklistMatches: matches, spokenNumbers };
    } catch {
      // cai para a próxima camada — nunca interrompe a análise por falha de conectividade
    }
  }

  if (providers.localOffline) {
    try {
      const matches = await providers.localOffline(segment.textOriginal, checklistItems);
      if (matches.length > 0) return { reviews, checklistMatches: matches, spokenNumbers };
    } catch {
      // cai para a camada léxica
    }
  }

  return { reviews, checklistMatches: lexicalMatch(segment.textOriginal, checklistItems), spokenNumbers };
}
