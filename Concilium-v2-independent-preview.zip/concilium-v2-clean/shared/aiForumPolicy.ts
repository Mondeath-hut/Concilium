import { redactIdentifiersKeepContext, redactPersonalNamesKeepContext, redactSensitiveText } from "./workspacePolicy";

export const aiVisibilityLevels = ["integral_autorizado", "contexto_protegido", "redigido"] as const;
export type AiVisibilityLevel = (typeof aiVisibilityLevels)[number];

export const aiRoles = ["auditor_critico", "defensor_da_minuta", "mediador"] as const;
export type AiRole = (typeof aiRoles)[number];

/** A possibilidade jurídica deve ser separada de reprovação moral e de risco operacional. */
export const aiArgumentTriageStatuses = [
  "apoiado_por_fonte_vigente",
  "possivel_aplicacao",
  "controvertido",
  "nao_verificado",
  "contradito_ou_rejeitado",
  "fora_da_jurisdicao",
  "inexecutavel_ou_ilicito_operacional",
] as const;
export type AiArgumentTriageStatus = (typeof aiArgumentTriageStatuses)[number];

export const aiRoundStates = ["active", "collapsed", "closed"] as const;
export type AiRoundState = (typeof aiRoundStates)[number];

/** Regra invariável: supervisor e Estrategista recebem a solicitação integral quando o titular autoriza; as IAs derivadas recebem somente a projeção permitida. */
export const SUPERVISOR_ACCESS_LEVEL = "integral_autorizado" as const;
export const STRATEGIST_ACCESS_LEVEL = "integral_autorizado" as const;
export const LAB_DEFAULT_ACCESS_LEVEL = "contexto_protegido" as const;

export function automaticVisibilityForRole(input: { role: AiRole; allowIntegral: boolean; containsSensitiveContext: boolean }): AiVisibilityLevel {
  if (input.allowIntegral) return "integral_autorizado";
  if (input.role === "auditor_critico" && input.containsSensitiveContext) return "redigido";
  return "contexto_protegido";
}

export const AI_VISIBILITY_COPY: Record<AiVisibilityLevel, { label: string; description: string }> = {
  integral_autorizado: { label: "Conteúdo integral autorizado", description: "A IA recebe o texto completo por sua autorização expressa nesta rodada." },
  contexto_protegido: { label: "Contexto protegido", description: "A IA recebe a estrutura e as cláusulas com dados sensíveis esmaecidos." },
  redigido: { label: "Conteúdo redigido", description: "A IA recebe somente formulações jurídicas e marcadores de dados protegidos." },
};

export function isAiLabOwner(input: { caseCreatedBy: number; userId: number }) {
  return input.caseCreatedBy === input.userId;
}

export function projectContentForAi(content: string, visibilityLevel: AiVisibilityLevel) {
  if (visibilityLevel === "integral_autorizado") return content;
  const protectedContent = redactPersonalNamesKeepContext(redactIdentifiersKeepContext(content));
  if (visibilityLevel === "contexto_protegido") return protectedContent;
  return protectedContent
    .replace(/[A-Za-zÀ-ÿ]{2,}/g, word => [
      "cláusula", "considerando", "acordo", "parte", "documento", "proposta", "divórcio", "patrimonial", "resposta",
      "casamento", "comunhão", "parcial", "ex-cônjuge", "cônjuge", "convivência", "coabitação", "residência", "propriedade",
      "filhos", "maiores", "companheiro", "companheira", "família", "familiar", "imagem", "constrangimento", "privacidade",
      "comum", "comuns", "área", "áreas", "rotina", "despesas", "limites", "visitas", "relacionamento", "separação",
      "interesses", "fatos", "hipótese", "pendência", "consentimento", "moradia", "social", "doméstico", "doméstica",
    ].includes(word.toLowerCase()) ? word : "[trecho redigido]")
    .replace(/(?:\[trecho redigido\]\s*){2,}/g, "[trecho redigido] ");
}

export function buildArgumentTriageInstruction() {
  return [
    "Faça triagem em três eixos separados: (1) possibilidade jurídica; (2) força da fonte, prova e incerteza; (3) moral, ética e risco profissional.",
    "Não descarte uma tese apenas porque o fato ou o resultado parecem moralmente repulsivos. Em defesa, examine todos os meios juridicamente lícitos e plausíveis, inclusive teses impopulares, com fontes contrárias, limites e riscos.",
    "Não confunda ausência de fonte localizada com ilegalidade. Diferencie tese apoiada por fonte vigente, possível aplicação, controvertida, não verificada, contradita/rejeitada e fora da jurisdição.",
    "Bloqueie somente instruções operacionais que exigiriam fraude, violência, ameaça, destruição/fabricação de prova, obstrução ou outro ato ilícito. Essa barreira não bloqueia a análise jurídica lícita da defesa de pessoa acusada de ato grave.",
    "Não use ‘causa perdida’ ou ‘impossível’ sem incompatibilidade objetiva, fonte aplicável clara e explicação. Uma tese improvável pode continuar sendo possível/controvertida quando depender de prova, interpretação ou convencimento judicial.",
  ].join(" ");
}

export function buildSupervisorCoordinationPrompt(input: { title: string; content: string; objective: string; strategistContext?: string | null; previousSynthesis?: string | null }) {
  return [
    "Você é o supervisor coordenador de uma Arena privada de análise jurídica. Você tem acesso integral autorizado ao conteúdo desta rodada.",
    "Sua função é manter o raciocínio avançando: extraia fatos relevantes, regime/contexto, lacunas que realmente impedem a análise e perguntas objetivas. Não interrompa a análise por detalhes já suficientes e não decida pelo titular.",
    buildArgumentTriageInstruction(),
    "Preserve a fidelidade do contexto concreto. Não reduza uma situação íntima, doméstica, familiar ou patrimonial a um rótulo jurídico genérico quando o titular descreveu motivos, constrangimentos, relações, limites, rotina, pessoas afetadas ou condições materiais específicas.",
    "Diferencie: (1) fatos narrados; (2) contexto e motivo da preocupação; (3) pedido real do titular; (4) hipóteses a investigar; (5) questões jurídicas a aprofundar. Se o pedido envolver convivência após separação, examine expressamente coabitação, áreas comuns, despesas, visitas, novos relacionamentos, privacidade, filhos, imagem familiar e limites de duração e execução — somente quando esses elementos estiverem no conteúdo.",
    "Prepare uma pauta de coordenação para as demais IAs. Ao repassar a pauta, os identificadores deverão ser minimizados, mas o contexto necessário para raciocinar não pode ser apagado.",
    "Para cada questão jurídica, indique a fonte necessária e classifique país, jurisdição, autoridade, versão e vigência. Nunca trate uma decisão como atual sem verificar se foi revogada, superada ou substituída; marque confirmação pendente quando não houver fonte validada.",
    `Objeto: ${input.title}.`,
    `Objetivo: ${input.objective}.`,
    input.previousSynthesis ? `Síntese aprovada da rodada anterior:\n${input.previousSynthesis}` : "Esta é a primeira rodada.",
    input.strategistContext ? `CONTEXTO ESTRATÉGICO ENCAMINHADO PELO ESTRATEGISTA:\n${input.strategistContext}` : "Nenhum contexto estratégico separado foi encaminhado.",
    "Entregue: Contexto operacional; fatos e premissas; lacunas prioritárias; perguntas que destravam o debate; ordem sugerida das análises.",
    "CONTEÚDO INTEGRAL AUTORIZADO:\n---\n" + input.content + "\n---",
  ].join("\n\n");
}

export function buildNextRoundPrompt(input: { previousSynthesis: string; ownerInstruction?: string }) {
  return [
    "Esta é uma nova rodada independente da Arena.",
    "Use a síntese aprovada anterior como ponto de partida, sem reabrir automaticamente questões já encerradas.",
    input.ownerInstruction ? `Intervenção do titular: ${input.ownerInstruction}` : "Sem instrução adicional do titular.",
    "A síntese é orientação de continuidade, não decisão jurídica definitiva.",
    "SÍNTESE DA RODADA ANTERIOR:\n---\n" + input.previousSynthesis + "\n---",
  ].join("\n\n");
}

export function buildAiAnalysisPrompt(input: { title: string; content: string; objective: string; role: AiRole; visibilityLevel: AiVisibilityLevel; supervisorBrief?: string | null; previousSynthesis?: string | null }) {
  const roleInstruction: Record<AiRole, string> = {
    auditor_critico: "Atue como acusação técnica/advogado do diabo. Procure ambiguidades, omissões, riscos de execução, conflitos internos e fragilidades capazes de derrubar a alternativa, sem oferecer aconselhamento jurídico definitivo.",
    defensor_da_minuta: "Atue como defensor técnico da minuta. Identifique qualidades, coerências, cláusulas preserváveis e pequenos ajustes de clareza, sem oferecer aconselhamento jurídico definitivo.",
    mediador: "Atue como mediador técnico. Organize pontos de convergência, divergências e perguntas objetivas que uma revisão humana deve decidir, sem oferecer aconselhamento jurídico definitivo.",
  };
  return [
    "Você participa de um laboratório privado de revisão documental. A análise é informativa e exige revisão humana qualificada antes de qualquer decisão.",
    roleInstruction[input.role],
    buildArgumentTriageInstruction(),
    `Nível de conteúdo autorizado: ${AI_VISIBILITY_COPY[input.visibilityLevel].label}.`,
    `Objeto: ${input.title}.`,
    `Objetivo informado pelo titular: ${input.objective}.`,
    input.previousSynthesis ? `Ponto de partida aprovado da rodada anterior:\n${input.previousSynthesis}` : "",
    input.supervisorBrief ? `Pauta do supervisor, projetada para este nível de acesso:\n${input.supervisorBrief}` : "",
    "Não trate o rótulo jurídico como substituto do cenário concreto. Use a pauta e o contexto preservado para discutir critérios, limites, consequências práticas e alternativas. Para cada afirmação jurídica específica, traga fonte/citação ou marque verificação pendente; confirme país, jurisdição, vigência e eventual revogação/superação. Responda em português do Brasil, usando as seções: Contexto considerado; Achados; Triagem de possibilidade jurídica; Fontes e validade; Contrapontos e fontes contrárias; Riscos morais/éticos/profissionais separados da legalidade; Pontos a preservar; Questões para decisão humana; Sugestão de redação (se cabível).",
    "CONTEÚDO PARA ANÁLISE:\n---\n" + input.content + "\n---",
  ].join("\n\n");
}
