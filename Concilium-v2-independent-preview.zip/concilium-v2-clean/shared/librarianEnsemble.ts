import { buildLibrarianResponsePacket, type LibrarianAgentRole, type LibrarianResponsePacket, type LibrarianResearchMode } from "./librarianWorkflow";
import type { KnowledgeResult } from "./knowledgeService";

type Result = KnowledgeResult;

export type LibrarianAgent = {
  role: LibrarianAgentRole;
  search: (query: string) => Promise<Result[]>;
};

export async function runLibrarianEnsemble(input: { query: string; mode: LibrarianResearchMode; agents: LibrarianAgent[] }): Promise<{ results: Result[]; packet: LibrarianResponsePacket; roleResults: Array<{ role: LibrarianAgentRole; status: "completed" | "failed"; resultIds: string[] }> }> {
  const settled = await Promise.all(input.agents.map(async agent => {
    try {
      const results = await agent.search(input.query);
      return { role: agent.role, status: "completed" as const, results };
    } catch {
      return { role: agent.role, status: "failed" as const, results: [] as Result[] };
    }
  }));
  const deduped = [...new Map(settled.flatMap(item => item.results).map(result => [result.id, result])).values()];
  return {
    results: deduped,
    packet: buildLibrarianResponsePacket({ mode: input.mode, results: deduped }),
    roleResults: settled.map(item => ({ role: item.role, status: item.status, resultIds: item.results.map(result => result.id) })),
  };
}
