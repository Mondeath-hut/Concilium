import { describe, expect, it } from "vitest";
import { computeInterestAlignmentIndex, type DimensionScore } from "./interestAlignmentIndex";

describe("índice comparativo de atendimento dos interesses", () => {
  it("calcula a média ponderada quando todas as dimensões têm nota", () => {
    const scores: DimensionScore[] = [
      { dimension: "seguranca_habitacional", score: 80, weight: 0.5 },
      { dimension: "liquidez", score: 40, weight: 0.5 },
    ];
    expect(computeInterestAlignmentIndex(scores).value).toBe(60);
  });

  it("nunca inventa nota: dimensão sem score entra em missingDimensions", () => {
    const scores: DimensionScore[] = [
      { dimension: "seguranca_habitacional", score: 80, weight: 0.5 },
      { dimension: "liquidez", weight: 0.5 },
    ];
    const result = computeInterestAlignmentIndex(scores);
    expect(result.missingDimensions).toEqual(["liquidez"]);
  });

  it("retorna não calculado (null) quando menos de metade do peso tem dado", () => {
    const scores: DimensionScore[] = [
      { dimension: "seguranca_habitacional", score: 80, weight: 0.2 },
      { dimension: "liquidez", weight: 0.8 },
    ];
    expect(computeInterestAlignmentIndex(scores).value).toBeNull();
  });

  it("continua calculável quando exatamente metade do peso tem dado", () => {
    const scores: DimensionScore[] = [
      { dimension: "seguranca_habitacional", score: 80, weight: 0.5 },
      { dimension: "liquidez", weight: 0.5 },
    ];
    expect(computeInterestAlignmentIndex(scores).value).not.toBeNull();
  });

  it("sempre mostra os pesos usados, mesmo quando não calculado", () => {
    const scores: DimensionScore[] = [{ dimension: "prazo", weight: 1 }];
    const result = computeInterestAlignmentIndex(scores);
    expect(result.value).toBeNull();
    expect(result.weightsUsed).toEqual([{ dimension: "prazo", weight: 1 }]);
  });

  it("nunca se chama 'chance de acordo' ou rótulo de probabilidade de vitória", () => {
    const result = computeInterestAlignmentIndex([{ dimension: "prazo", score: 50, weight: 1 }]);
    expect(result.label).toBe("índice comparativo de atendimento dos interesses");
  });
});
