import { describe, expect, it } from "vitest";
import { approveSecretRouting, buildSecretRoutingPlan, getApprovedSecretNames } from "./secretRouting";

describe("plano de roteamento de segredos", () => {
  it("não aprova por inferência e bloqueia nome desconhecido", () => {
    const plan = buildSecretRoutingPlan(["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY", "CHAVE_MESTRE", "NAO_CONHECIDA"]);
    expect(plan.find(item => item.name === "NAO_CONHECIDA")?.decision).toBe("blocked");
    expect(plan.find(item => item.name === "CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY")?.decision).toBe("proposed");
    expect(plan.find(item => item.name === "CHAVE_MESTRE")?.decision).toBe("proposed");
  });

  it("aprova apenas entradas confirmadas e com contrato definido", () => {
    const plan = buildSecretRoutingPlan(["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY", "CHAVE_MESTRE"]);
    const reviewed = approveSecretRouting(plan, ["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY", "CHAVE_MESTRE"]);
    expect(getApprovedSecretNames(reviewed)).toEqual(["CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY"]);
    expect(reviewed.find(item => item.name === "CHAVE_MESTRE")?.decision).toBe("blocked");
  });
});
