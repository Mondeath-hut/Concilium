import { z } from "zod";

export const secretConsumers = ["bootstrap", "mfa", "ai_credentials", "ai_context", "authenticator", "account_recovery", "email_delivery", "pending_contract"] as const;
export type SecretConsumer = (typeof secretConsumers)[number];
export const secretSensitivities = ["critical", "very_high", "high"] as const;
export type SecretSensitivity = (typeof secretSensitivities)[number];

export const secretManifestEntrySchema = z.object({
  name: z.string().min(1),
  label: z.string().min(1),
  consumer: z.enum(secretConsumers),
  sensitivity: z.enum(secretSensitivities),
  valueExpected: z.boolean(),
  configuredBy: z.enum(["environment", "encrypted_vault", "one_time_setup", "owner_device"]),
  notes: z.string(),
});
export type SecretManifestEntry = z.infer<typeof secretManifestEntrySchema>;

/** Catálogo público de nomes e finalidades. Nunca contém valores, senhas ou tokens. */
export const secretManifest: SecretManifestEntry[] = [
  { name: "CONCILIUM_BOOTSTRAP_CODE", label: "Código de bootstrap", consumer: "bootstrap", sensitivity: "critical", valueExpected: true, configuredBy: "one_time_setup", notes: "Uso controlado na ativação inicial; rotacionar ou desativar após o bootstrap." },
  { name: "CONCILIUM_MFA_ENCRYPTION_KEY", label: "Cifra de autenticação/MFA", consumer: "mfa", sensitivity: "critical", valueExpected: true, configuredBy: "environment", notes: "Protege segredos de autenticação; não é o segredo do autenticador." },
  { name: "CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY", label: "Cifra do cofre de IA", consumer: "ai_credentials", sensitivity: "critical", valueExpected: true, configuredBy: "environment", notes: "Protege credenciais de provedores; não deve ser entregue ao provedor como conteúdo." },
  { name: "CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY", label: "Cifra do contexto de IA", consumer: "ai_context", sensitivity: "critical", valueExpected: true, configuredBy: "environment", notes: "Protege contexto original para handoffs autorizados; não deve aparecer em logs." },
  { name: "RESEND_API_KEY", label: "Chave de API do Resend", consumer: "email_delivery", sensitivity: "critical", valueExpected: true, configuredBy: "environment", notes: "Usada apenas no servidor para validação de entrega de e-mail; nunca enviar ao cliente ou registrar em logs." },
  { name: "RESEND_FROM_EMAIL", label: "Remetente de teste do Resend", consumer: "email_delivery", sensitivity: "high", valueExpected: true, configuredBy: "environment", notes: "Endereço autorizado para testes de entrega; validar formato sem expor o valor." },
  { name: "SEGREDO_AUTENTICADOR_2FA", label: "Segredo do autenticador 2FA", consumer: "authenticator", sensitivity: "very_high", valueExpected: true, configuredBy: "owner_device", notes: "Usado pelo autenticador; não confundir com a chave que cifra o segredo." },
  { name: "CODIGOS_RECUPERACAO_2FA", label: "Códigos de recuperação", consumer: "account_recovery", sensitivity: "critical", valueExpected: true, configuredBy: "owner_device", notes: "Uso único; preferir armazenamento como hashes e não enviar a modelos." },
  { name: "CHAVE_MESTRE", label: "Chave mestre", consumer: "pending_contract", sensitivity: "critical", valueExpected: true, configuredBy: "encrypted_vault", notes: "Finalidade ainda precisa ser confirmada; não distribuir por semelhança de nome." },
  { name: "CHAVE_DE_CIFRAGEM", label: "Chave de cifragem", consumer: "pending_contract", sensitivity: "critical", valueExpected: true, configuredBy: "encrypted_vault", notes: "Escopo, algoritmo, rotação e consumidor ainda precisam ser confirmados." },
];

export const SECRET_MANIFEST_FILENAME = "concilium-secrets.manifest.json";

export function extractSecretNamesFromManifestDocument(content: string) {
  const names: string[] = [];
  try {
    const parsed = JSON.parse(content) as { secrets?: Array<{ name?: unknown }> };
    if (Array.isArray(parsed.secrets)) {
      for (const entry of parsed.secrets) if (typeof entry?.name === "string") names.push(entry.name.trim());
    }
  } catch {
    for (const line of content.split(/\r?\n/)) {
      const name = line.match(/^\s*([A-Z][A-Z0-9_]{2,})\s*(?:=|:)/)?.[1];
      if (name) names.push(name);
    }
  }
  return [...new Set(names.filter(Boolean))];
}

export function validateSecretNames(input: { names: string[]; allowUnknown?: boolean }) {
  const expected = new Set(secretManifest.map(entry => entry.name));
  const uniqueNames = [...new Set(input.names)];
  return {
    missing: secretManifest.filter(entry => !uniqueNames.includes(entry.name)).map(entry => entry.name),
    unknown: input.allowUnknown ? [] : uniqueNames.filter(name => !expected.has(name)),
    duplicates: input.names.filter((name, index) => input.names.indexOf(name) !== index),
    accepted: uniqueNames.filter(name => expected.has(name)),
  };
}

export function buildSecretIntakeChecklist() {
  return secretManifest.map(entry => ({ name: entry.name, label: entry.label, consumer: entry.consumer, sensitivity: entry.sensitivity, configuredBy: entry.configuredBy }));
}

export const SECRET_INTAKE_RULES = [
  "A senha do arquivo nunca é persistida.",
  "O valor de cada segredo nunca é devolvido pela API, mostrado na interface ou escrito em log.",
  "O manifesto valida nomes e finalidades, não valida o valor secreto.",
  "Chaves desconhecidas ficam pendentes para revisão; não são distribuídas automaticamente.",
  "Cada módulo recebe apenas o segredo necessário para sua função.",
] as const;
