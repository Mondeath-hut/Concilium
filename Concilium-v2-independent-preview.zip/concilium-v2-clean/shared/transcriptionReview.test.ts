import { describe, expect, it } from "vitest";
import { normalizeTranscriptForReview, transcriptReviews } from "./transcriptionReview";

describe("transcription review", () => {
  it("does not modify the original and normalizes only the review copy", () => {
    expect(normalizeTranscriptForReview("É, né, eu proponho um prazo de 4 anos.")).toBe("eu proponho um prazo de 4 anos.");
  });

  it("requires confirmation for possible acceptance and time terms", () => {
    const reviews = transcriptReviews({ id: "s1", startMs: 0, endMs: 1000, textOriginal: "Eu concordo com o prazo de 4 anos.", confidence: 0.97 });
    expect(reviews.map(item => item.kind)).toEqual(expect.arrayContaining(["possivel_aceite", "valor_ou_prazo"]));
    expect(reviews.every(item => item.requiresHumanConfirmation)).toBe(true);
  });

  it("flags low confidence", () => {
    expect(transcriptReviews({ id: "s2", startMs: 0, endMs: 1000, textOriginal: "Talvez...", confidence: 0.4 }).some(item => item.kind === "fala_ambigua")).toBe(true);
  });
});
