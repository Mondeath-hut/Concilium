/**
 * Atores interativos anônimos (Manual funcional v2, seção 8-A).
 * Cada papel tem um retrato clicável na interface — sem nome próprio, só a função —
 * e reaproveita, sempre que possível, os prompts que já existem para a Arena e o
 * Laboratório, para não duplicar regras de comportamento em dois lugares.
 */
import { AI_VISIBILITY_COPY, buildAiAnalysisPrompt, buildSupervisorCoordinationPrompt, type AiVisibilityLevel } from "./aiForumPolicy";
import { buildStrategistContinuationPrompt } from "./strategyExploration";

export const ACTOR_ROLES = [
  "estrategista",
  "supervisor",
  "bibliotecario",
  "defesa",
  "advogado_do_diabo",
  "mediador",
] as const;

export type ActorRole = (typeof ACTOR_ROLES)[number];

export const ACTOR_ROLE_LABELS: Record<ActorRole, string> = {
  estrategista: "Estrategista",
  supervisor: "Supervisor",
  bibliotecario: "Bibliotecário",
  defesa: "Defesa",
  advogado_do_diabo: "Advogado do Diabo",
  mediador: "Mediador",
};

/**
 * Nível de contexto padrão de cada papel (Manual, seção 4.3): Supervisor e Estrategista
 * recebem integral autorizado por padrão; o Bibliotecário nunca recebe o dossiê completo,
 * só o necessário para a busca jurídica.
 */
export const ACTOR_DEFAULT_ACCESS: Record<ActorRole, AiVisibilityLevel> = {
  estrategista: "integral_autorizado",
  supervisor: "integral_autorizado",
  bibliotecario: "redigido",
  defesa: "contexto_protegido",
  advogado_do_diabo: "contexto_protegido",
  mediador: "contexto_protegido",
};

export type ActorChatContext = {
  role: ActorRole;
  title: string;
  objective: string;
  /** Conteúdo já projetado para o nível de acesso do papel (ver shared/aiForumPolicy.ts, projectContentForAi). */
  projectedContent: string;
  visibilityLevel: AiVisibilityLevel;
};

/**
 * Uma única função de entrada que escolhe o prompt certo por papel, reaproveitando os
 * construtores que já existem no restante do sistema em vez de duplicar a instrução de
 * comportamento em um terceiro lugar.
 */
export function buildActorSystemPrompt(ctx: ActorChatContext): string {
  if (ctx.role === "estrategista") {
    return buildStrategistContinuationPrompt({
      objective: ctx.objective,
      currentBrief: ctx.projectedContent,
      question: "Conversa livre com o titular pelo retrato do Estrategista.",
      ownerAnswer: "",
      lineStates: "Conversa direta — não é uma linha formal do Laboratório.",
    });
  }

  if (ctx.role === "supervisor") {
    return buildSupervisorCoordinationPrompt({
      title: ctx.title,
      content: ctx.projectedContent,
      objective: ctx.objective,
    });
  }

  if (ctx.role === "bibliotecario") {
    return [
      "Você é o Bibliotecário do Concilium. Sua função é busca jurídica e documental — você NUNCA recebe o dossiê completo do caso, só o necessário para pesquisar.",
      `Nível de conteúdo autorizado: ${AI_VISIBILITY_COPY[ctx.visibilityLevel].label}.`,
      "Para cada afirmação jurídica, traga fonte, versão, data de consulta, jurisdição, autoridade e situação de vigência — ou marque 'confirmação pendente' quando não houver fonte validada.",
      "Não converta hipótese em fato e não avalie a Arena nem o Laboratório — isso é papel de outros atores.",
      `Objeto: ${ctx.title}. Objetivo: ${ctx.objective}.`,
      "CONTEXTO DISPONÍVEL PARA A BUSCA:\n---\n" + ctx.projectedContent + "\n---",
    ].join("\n\n");
  }

  // defesa | advogado_do_diabo | mediador -> reaproveita buildAiAnalysisPrompt (Arena)
  const roleMap: Record<"defesa" | "advogado_do_diabo" | "mediador", "defensor_da_minuta" | "auditor_critico" | "mediador"> = {
    defesa: "defensor_da_minuta",
    advogado_do_diabo: "auditor_critico",
    mediador: "mediador",
  };
  return buildAiAnalysisPrompt({
    title: ctx.title,
    content: ctx.projectedContent,
    objective: ctx.objective,
    role: roleMap[ctx.role as "defesa" | "advogado_do_diabo" | "mediador"],
    visibilityLevel: ctx.visibilityLevel,
  });
}
