export const explorationThreadStates = ["active", "awaiting_owner", "ceased", "selected_for_arena"] as const;
export type ExplorationThreadState = (typeof explorationThreadStates)[number];

/** O agrupamento reduz repetição na tela, mas não mistura históricos entre modelos. */
export type ExplorationQuestionGroup = {
  id: string;
  questionIds: string[];
  representativeQuestion: string;
  threadIds: string[];
};

const STOP_WORDS = new Set(["para", "como", "qual", "quais", "que", "uma", "um", "dos", "das", "por", "com", "sobre", "pode", "ser", "será", "ter", "de", "da", "do", "e", "ou"]);
export function areQuestionsSemanticallySimilar(first: string, second: string) {
  const tokens = (value: string) => new Set(value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[^a-z0-9]+/).filter(token => token.length > 3 && !STOP_WORDS.has(token)));
  const a = tokens(first);
  const b = tokens(second);
  if (!a.size || !b.size) return false;
  const intersection = [...a].filter(token => b.has(token)).length;
  const union = new Set([...a, ...b]).size;
  return intersection / union >= 0.45;
}

export type BranchProposal = { question: string; whyItMatters: string };

export function extractBranchProposals(body: string): BranchProposal[] {
  const proposals: BranchProposal[] = [];
  const lines = body.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const question = lines[index].match(/^\s*RAMIFICACAO_PROPOSTA\s*:\s*(.+?)\s*$/i)?.[1]?.trim();
    if (!question || question.length < 8 || question.length > 500) continue;
    const whyItMatters = lines[index + 1]?.match(/^\s*MOTIVO_RAMIFICACAO\s*:\s*(.+?)\s*$/i)?.[1]?.trim() ?? "Relevância a avaliar pelo Estrategista.";
    proposals.push({ question, whyItMatters: whyItMatters.slice(0, 500) });
  }
  return proposals;
}

export function extractStrategistLineProposals(brief: string) {
  const proposals: string[] = [];
  for (const line of brief.split(/\r?\n/)) {
    const match = line.match(/^\s*(?:LINHA_EXPLORATORIA|LINHA|PERSPECTIVA_PROPOSTA)\s*:\s*(.+?)\s*$/i);
    if (match?.[1]) {
      const value = match[1].replace(/\s+/g, " ").trim();
      if (value.length >= 4 && value.length <= 160) proposals.push(value);
    }
  }
  return [...new Set(proposals)];
}

export function buildInitialExplorationPerspectives(brief: string, defaults: string[]) {
  return [...new Set([...defaults, ...extractStrategistLineProposals(brief)])].slice(0, 12);
}

export type ExplorationResponseDisposition = {
  state: "awaiting_owner" | "ceased";
  blockingQuestion?: string;
  optionalOffer?: string;
};

/**
 * Uma oferta de próximo passo não reabre a linha. Só uma lacuna que muda a
 * alternativa ou impede a próxima etapa gera pergunta pendente.
 */
export function classifyExplorationResponse(body: string): ExplorationResponseDisposition {
  const blocking = body.match(/PERGUNTA_BLOQUEANTE:\s*(.+?)(?:\n|$)/i)?.[1]?.trim();
  if (blocking && !/^(voce gostaria|você gostaria|voce deseja|você deseja|gostaria que eu|quer que eu|deseja que eu)/i.test(blocking)) {
    return { state: "awaiting_owner", blockingQuestion: blocking };
  }
  const optionalOffer = body.match(/OFERTA_PROXIMA_ACAO:\s*(.+?)(?:\n|$)/i)?.[1]?.trim()
    ?? body.match(/(?:voce gostaria|você gostaria|voce deseja|você deseja|gostaria que eu|quer que eu|deseja que eu)\s+(.+?)(?:\?|\n|$)/i)?.[0]?.trim();
  return { state: "ceased", optionalOffer };
}

export function buildStrategistCoordinatorPrompt(input: { title: string; objective: string; sourceContent: string; evidencePacket?: string }) {
  return [
    "Você é o Estrategista central de uma exploração jurídica privada.",
    "O titular autorizou o recebimento integral desta solicitação. Preserve o contexto completo, inclusive detalhes pessoais, relacionais, patrimoniais e domésticos que possam alterar a análise.",
    "Sua função é coordenar, não escolher pelo titular: decomponha a solicitação em eixos de investigação, indique quais aspectos cada linha independente deve explorar e preserve perguntas que poderão ser redivididas quando o diálogo avançar. Procure também linhas que o titular ainda não mencionou, mas que possam mudar a estratégia — por exemplo, necessidade atual, autonomia econômica, trabalho, idade, vulnerabilidade, prova e exigibilidade.",
    "As IAs do Laboratório receberão apenas uma projeção protegida do contexto e esta pauta. Não repasse identificadores, nomes, endereços, valores ou números sensíveis; preserve o significado necessário.",
    "Não produza parecer definitivo, acordo, garantia de resultado ou instrução vinculante. Diferencie fatos narrados, hipóteses, questões jurídicas, fontes a pesquisar, riscos e lacunas.",
    `Título: ${input.title}.`,
    `Objetivo: ${input.objective}.`,
    input.evidencePacket ? `EVIDÊNCIAS JÁ TRIADAS:\n${input.evidencePacket}` : "Não há pacote de evidências anterior.",
    "Entregue uma pauta para as linhas independentes com: âmago da solicitação; fatos/contextos que não podem ser perdidos; eixos de investigação; distribuição sugerida por perspectivas; perguntas potencialmente bloqueantes; fontes e cláusulas a pesquisar; critérios para encerrar ou continuar cada linha. Quando identificar uma linha que não esteja na distribuição padrão, inclua uma linha isolada no formato LINHA_EXPLORATORIA: descrição curta.",
    `SOLICITAÇÃO INTEGRAL AUTORIZADA:\n---\n${input.sourceContent}\n---`,
  ].join("\n\n");
}

export function buildStrategistContinuationPrompt(input: { objective: string; currentBrief: string; question: string; ownerAnswer: string; lineStates: string }) {
  return [
    "Você continua como Estrategista central. Receba integralmente a nova resposta do titular e reorganize a pauta sem apagar o contexto anterior.",
    "Decida apenas a coordenação do raciocínio: quais linhas devem continuar, quais podem encerrar, quais lacunas são realmente bloqueantes e se uma questão precisa ser redistribuída. Não responda pelo titular nem produza decisão jurídica final.",
    `Objetivo da exploração: ${input.objective}.`,
    `Pauta anterior do Estrategista:\n${input.currentBrief}`,
    `Pergunta feita por uma linha:\n${input.question}`,
    `Nova resposta integral do titular:\n${input.ownerAnswer}`,
    `Estado das linhas (metadados):\n${input.lineStates}`,
    "Entregue: pauta atualizada; linhas que continuam ou encerram; eventual pergunta que deve ser feita somente a uma linha; fontes/lacunas que precisam acompanhar o debate. Preserve a separação entre as linhas e não revele dados pessoais às IAs derivadas.",
  ].join("\n\n");
}

export function buildExplorationFollowUpPrompt(input: {
  objective: string;
  perspective: string;
  branchHistory: string;
  question: string;
  ownerAnswer: string;
  strategistBrief?: string;
}) {
  return [
    "Continue somente esta linha de raciocínio estratégico. Não use, compare ou incorpore respostas de outras IAs.",
    `Perspectiva desta linha: ${input.perspective}.`,
    `Objetivo do titular: ${input.objective}.`,
    "A resposta do titular abaixo responde à pergunta desta linha. Extraia somente o que for pertinente a este raciocínio e mantenha as demais hipóteses separadas.",
    `Pergunta feita: ${input.question}.`,
    `Resposta do titular: ${input.ownerAnswer}.`,
    input.strategistBrief ? `Pauta atualizada do Estrategista central:\n${input.strategistBrief}` : "O Estrategista central não forneceu pauta adicional nesta continuação.",
    `Histórico exclusivo desta linha:\n${input.branchHistory}`,
    "Entregue: atualização da alternativa; impacto da nova informação; próximos riscos. Se ainda houver uma lacuna indispensável que possa mudar materialmente a alternativa, escreva ESTADO: AGUARDANDO_RESPOSTA e PERGUNTA_BLOQUEANTE: com uma única pergunta objetiva. Caso contrário, escreva ESTADO: ENCERRADA. Uma sugestão opcional deve usar OFERTA_PROXIMA_ACAO: e não pode ser tratada como pergunta pendente. Se surgir um assunto correlato, mas não pertencente a esta linha, registre RAMIFICACAO_PROPOSTA: com a nova pergunta e, na linha seguinte, MOTIVO_RAMIFICACAO:. Isso apenas estaciona uma proposta; não reabra nem contamine esta linha.",
  ].join("\n\n");
}

export function buildExplorationSynthesisPrompt(input: { objective: string; stage: "incremental" | "final"; closedLine: string; consolidatedLines: string[] }) {
  return [
    input.stage === "final" ? "Produza a síntese final de uma exploração estratégica com todas as linhas encerradas." : "Atualize a síntese incremental apenas com a linha que acabou de ser encerrada.",
    "Não crie uma nova alternativa e não reabra uma linha encerrada. Preserve divergências, premissas e incertezas.",
    "A síntese organiza; não escolhe automaticamente uma vencedora. Não transforme convergência entre IAs em prova jurídica, consenso do titular ou decisão.",
    "Para cada linha, diferencie fatos/premissas, proposta estratégica, suporte jurídico encontrado, ausência de fonte, tese controvertida, riscos éticos/profissionais e impedimentos operacionais ilícitos.",
    "Mantenha teses moralmente desconfortáveis quando forem juridicamente arguíveis e operacionalmente lícitas, apresentando contrapontos e o grau de incerteza.",
    `Objetivo do titular: ${input.objective}.`,
    `Linha recém-encerrada:\n${input.closedLine}`,
    input.consolidatedLines.length ? `Sínteses anteriores:\n${input.consolidatedLines.join("\n\n---\n\n")}` : "Ainda não há sínteses anteriores.",
    input.stage === "final" ? "Entregue exatamente com as seções: Panorama das alternativas; Convergências sem consenso automático; Divergências preservadas; Premissas e fatos dependentes de confirmação; Triagem de possibilidade jurídica por linha; Fontes confirmadas e fontes a verificar; Riscos jurídicos, éticos e práticos; Pontos cegos; Perguntas ainda abertas; Opções de encaminhamento (Estratégia, Bibliotecário, Arena ou Arquivo)." : "Entregue exatamente com as seções: Contribuição desta linha; Classificação provisória da possibilidade jurídica; O que fica definido provisoriamente; Riscos e informações pendentes; relação com as sínteses anteriores sem apagar divergências.",
  ].join("\n\n");
}

export function buildQuestionGroupingPrompt(questions: Array<{ id: string; body: string }>) {
  return [
    "Agrupe somente perguntas semanticamente equivalentes ou que possam receber a mesma resposta factual.",
    "Não agrupe perguntas apenas porque pertencem ao mesmo caso. Não misture patrimônio, filhos, convivência ou processo se a resposta exigida for diferente.",
    "Retorne grupos com um identificador, perguntas incluídas e uma formulação representativa. Perguntas sem equivalência devem ficar em grupos individuais.",
    JSON.stringify(questions),
  ].join("\n\n");
}
