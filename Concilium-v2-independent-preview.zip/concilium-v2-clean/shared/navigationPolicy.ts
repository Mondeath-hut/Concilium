export const DESKTOP_NAVIGATION_BREAKPOINT = 1024;

export function shouldUseCollapsedNavigation({ pointerCoarse, viewportWidth }: { pointerCoarse: boolean; viewportWidth: number }) {
  return pointerCoarse || viewportWidth < DESKTOP_NAVIGATION_BREAKPOINT;
}
