/**
 * Exportações completas (Manual funcional v2, seção 17): síntese de uma página, checklist
 * atual, histórico formal da negociação, tabela de propostas, perguntas de audiência e
 * pontos inegociáveis — cada uma separadamente, mais um JSON estruturado com tudo.
 *
 * Sem dependência nova de geração de PDF: a exportação "PDF" é uma página HTML autônoma
 * (sem chamadas externas, funciona offline) que o navegador imprime/salva como PDF — o
 * mesmo princípio de "sem firula" que já guiou o resto do projeto.
 */
import { hearingChecklistAlert, type ChecklistItemState, type ChecklistItemType, type ChecklistPriority } from "./hearingChecklist";
import type { NegotiationProposalStatus } from "./hearingChecklist";

export type ChecklistExportItem = {
  id: string;
  groupLabel: string;
  description: string;
  itemType: ChecklistItemType;
  priority: ChecklistPriority;
  state: ChecklistItemState;
  justification?: string | null;
};

export type ProposalExportRow = {
  id: string;
  documentType: "proposta" | "contraproposta";
  title: string;
  currentStatus: NegotiationProposalStatus;
  parentDocumentId?: string | null;
  createdAtIso: string;
};

export type CaseExportBundle = {
  caseTitle: string;
  generatedAtIso: string;
  onePageSynthesis: {
    title: string;
    currentStage: string;
    keyFacts: string[];
    topRisks: string[];
    nextSteps: string[];
  };
  checklist: Array<ChecklistExportItem & { alertLevel: "green" | "amber" | "red" }>;
  inegotiableItems: ChecklistExportItem[];
  hearingQuestions: ChecklistExportItem[];
  formalHistory: ProposalExportRow[];
};

export function buildChecklistExport(items: ChecklistExportItem[]) {
  return items.map(item => ({
    ...item,
    alertLevel: hearingChecklistAlert({ itemType: item.itemType, priority: item.priority, state: item.state }).level,
  }));
}

/** Pontos inegociáveis — sempre os itens que exigem pausa do titular (Manual, seção 9). */
export function buildInegotiableItemsExport(items: ChecklistExportItem[]) {
  return items.filter(item => item.itemType === "inegociavel_exige_pausa");
}

/** Perguntas de audiência — itens que ainda dependem de prova ou confirmação. */
export function buildHearingQuestionsExport(items: ChecklistExportItem[]) {
  return items.filter(item => item.itemType === "pendente_de_prova" || item.state === "dependente_confirmacao");
}

export function buildCaseExportBundle(input: {
  caseTitle: string;
  currentStage: string;
  keyFacts: string[];
  topRisks: string[];
  nextSteps: string[];
  checklistItems: ChecklistExportItem[];
  formalHistory: ProposalExportRow[];
}): CaseExportBundle {
  return {
    caseTitle: input.caseTitle,
    generatedAtIso: new Date().toISOString(),
    onePageSynthesis: {
      title: input.caseTitle,
      currentStage: input.currentStage,
      keyFacts: input.keyFacts,
      topRisks: input.topRisks,
      nextSteps: input.nextSteps,
    },
    checklist: buildChecklistExport(input.checklistItems),
    inegotiableItems: buildInegotiableItemsExport(input.checklistItems),
    hearingQuestions: buildHearingQuestionsExport(input.checklistItems),
    formalHistory: input.formalHistory,
  };
}

export function exportBundleToJson(bundle: CaseExportBundle): string {
  return JSON.stringify(bundle, null, 2);
}

const ALERT_COLOR: Record<"green" | "amber" | "red", string> = {
  green: "#10b981",
  amber: "#f59e0b",
  red: "#ef4444",
};

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] as string);
}

/**
 * Página HTML autônoma, sem chamadas externas — o titular abre no navegador e usa
 * "imprimir → salvar como PDF". Não substitui o histórico formal em si, é só a
 * apresentação para impressão/exportação (Manual, seção 17).
 */
export function exportBundleToPrintableHtml(bundle: CaseExportBundle): string {
  const checklistRows = bundle.checklist.map(item => `
    <tr>
      <td>${escapeHtml(item.groupLabel)}</td>
      <td>${escapeHtml(item.description)}</td>
      <td>${escapeHtml(item.itemType)}</td>
      <td>${escapeHtml(item.state)}</td>
      <td><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${ALERT_COLOR[item.alertLevel]}"></span></td>
    </tr>`).join("");

  const historyRows = bundle.formalHistory.map(row => `
    <tr>
      <td>${escapeHtml(row.title)}</td>
      <td>${escapeHtml(row.documentType)}</td>
      <td>${escapeHtml(row.currentStatus)}</td>
      <td>${escapeHtml(new Date(row.createdAtIso).toLocaleString("pt-BR"))}</td>
    </tr>`).join("");

  const inegotiableList = bundle.inegotiableItems.map(item => `<li>${escapeHtml(item.description)}</li>`).join("");
  const questionsList = bundle.hearingQuestions.map(item => `<li>${escapeHtml(item.description)}</li>`).join("");

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>${escapeHtml(bundle.caseTitle)} — Exportação Concilium</title>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #1e293b; padding: 24px; max-width: 900px; margin: 0 auto; }
  h1 { font-size: 1.4rem; } h2 { font-size: 1.1rem; margin-top: 28px; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 0.85rem; }
  th, td { text-align: left; padding: 6px 8px; border-bottom: 1px solid #e2e8f0; }
  ul { margin: 8px 0; padding-left: 20px; }
  .meta { color: #64748b; font-size: 0.8rem; }
  @media print { body { padding: 0; } }
</style>
</head>
<body>
  <h1>${escapeHtml(bundle.caseTitle)}</h1>
  <p class="meta">Gerado em ${escapeHtml(new Date(bundle.generatedAtIso).toLocaleString("pt-BR"))} — documento informativo, não substitui o histórico formal do sistema nem constitui decisão jurídica.</p>

  <h2>Síntese de uma página</h2>
  <p><strong>Estágio atual:</strong> ${escapeHtml(bundle.onePageSynthesis.currentStage)}</p>
  <p><strong>Fatos-chave:</strong></p>
  <ul>${bundle.onePageSynthesis.keyFacts.map(fact => `<li>${escapeHtml(fact)}</li>`).join("")}</ul>
  <p><strong>Principais riscos:</strong></p>
  <ul>${bundle.onePageSynthesis.topRisks.map(risk => `<li>${escapeHtml(risk)}</li>`).join("")}</ul>
  <p><strong>Próximos passos:</strong></p>
  <ul>${bundle.onePageSynthesis.nextSteps.map(step => `<li>${escapeHtml(step)}</li>`).join("")}</ul>

  <h2>Pontos inegociáveis</h2>
  <ul>${inegotiableList || "<li>Nenhum registrado.</li>"}</ul>

  <h2>Perguntas de audiência</h2>
  <ul>${questionsList || "<li>Nenhuma pendente.</li>"}</ul>

  <h2>Checklist atual</h2>
  <table>
    <thead><tr><th>Grupo</th><th>Descrição</th><th>Tipo</th><th>Estado</th><th>Alerta</th></tr></thead>
    <tbody>${checklistRows || "<tr><td colspan=\"5\">Nenhum item registrado.</td></tr>"}</tbody>
  </table>

  <h2>Histórico formal da negociação (Mesa Formal)</h2>
  <table>
    <thead><tr><th>Título</th><th>Tipo</th><th>Status</th><th>Criado em</th></tr></thead>
    <tbody>${historyRows || "<tr><td colspan=\"4\">Nenhum documento registrado.</td></tr>"}</tbody>
  </table>
</body>
</html>`;
}
