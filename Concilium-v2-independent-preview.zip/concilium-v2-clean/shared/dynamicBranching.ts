export const branchProposalStates = ["parked", "grouped", "ready_for_strategist", "submitted", "resolved", "dismissed"] as const;
export type BranchProposalState = (typeof branchProposalStates)[number];

export type DynamicBranchProposal = {
  id: string;
  parentRunId: string;
  parentThreadId: string;
  originQuestionId?: string;
  originMessageId?: string;
  question: string;
  whyItMatters: string;
  state: BranchProposalState;
};

export type StrategistBranchBundle = {
  id: string;
  parentRunId: string;
  sourceProposalIds: string[];
  sourceThreadIds: string[];
  sourceQuestionIds: string[];
  draftQuestion: string;
  state: "ready_for_strategist" | "submitted";
};

function compact(value: string, max = 420) {
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

/** Agrupa ramificações sem incorporá-las à linha original. A decisão continua humana/Estrategista. */
export function composeStrategistBranchBundle(input: { id: string; proposals: DynamicBranchProposal[] }) {
  if (!input.proposals.length) throw new Error("Não há ramificações para compor.");
  const first = input.proposals[0];
  const questions = input.proposals.map(item => compact(item.question, 240));
  const reasons = input.proposals.map(item => compact(item.whyItMatters, 260));
  const draftQuestion = [
    "Novas questões surgiram a partir de ramificações independentes da exploração.",
    "Sem alterar a linha de origem, avalie se elas formam um novo eixo estratégico:",
    ...questions.map((question, index) => `${index + 1}. ${question} — relevância apontada: ${reasons[index]}`),
    "Reorganize, descarte ou reformule as questões antes de propor nova pulverização. Não trate nenhuma delas como fato provado.",
  ].join("\n");
  return {
    id: input.id,
    parentRunId: first.parentRunId,
    sourceProposalIds: input.proposals.map(item => item.id),
    sourceThreadIds: [...new Set(input.proposals.map(item => item.parentThreadId))],
    sourceQuestionIds: [...new Set(input.proposals.flatMap(item => item.originQuestionId ? [item.originQuestionId] : []))],
    draftQuestion,
    state: "ready_for_strategist" as const,
  } satisfies StrategistBranchBundle;
}

export function markBranchBundleSubmitted(bundle: StrategistBranchBundle): StrategistBranchBundle {
  if (bundle.state !== "ready_for_strategist") throw new Error("Somente um pacote pronto pode ser submetido.");
  return { ...bundle, state: "submitted" };
}
