import { describe, expect, it } from "vitest";
import { areQuestionsSemanticallySimilar, buildExplorationFollowUpPrompt, buildExplorationSynthesisPrompt, buildInitialExplorationPerspectives, buildStrategistContinuationPrompt, buildStrategistCoordinatorPrompt, classifyExplorationResponse, extractBranchProposals, extractStrategistLineProposals } from "./strategyExploration";

describe("linhas isoladas do Laboratório de Alternativas", () => {
  it("agrupa perguntas semanticamente próximas sem misturar áreas diferentes", () => {
    expect(areQuestionsSemanticallySimilar("Qual o valor do imóvel para recomprar a parte?", "Quanto vale o imóvel para calcular o valor da parte?")).toBe(true);
    expect(areQuestionsSemanticallySimilar("Quantos filhos adultos existem?", "Qual o valor do imóvel para recomprar a parte?")).toBe(false);
  });

  it("separa uma ramificação correlata da linha original", () => {
    const branches = extractBranchProposals("ESTADO: ENCERRADA\nRAMIFICACAO_PROPOSTA: O uso exclusivo do imóvel cria outro eixo?\nMOTIVO_RAMIFICACAO: Pode alterar a análise patrimonial.");
    expect(branches).toEqual([{ question: "O uso exclusivo do imóvel cria outro eixo?", whyItMatters: "Pode alterar a análise patrimonial." }]);
    expect(classifyExplorationResponse("ESTADO: ENCERRADA\nRAMIFICACAO_PROPOSTA: Outra questão?").state).toBe("ceased");
  });

  it("abre linhas adicionais somente quando o Estrategista as propõe", () => {
    const proposals = extractStrategistLineProposals("LINHA_EXPLORATORIA: impacto tributário\nLINHA: impacto tributário\ntexto comum sem comando");
    expect(proposals).toEqual(["impacto tributário"]);
    expect(buildInitialExplorationPerspectives("LINHA_EXPLORATORIA: impacto tributário", ["familiar"])).toEqual(["familiar", "impacto tributário"]);
  });

  it("distingue oferta opcional de pergunta que bloqueia a linha", () => {
    expect(classifyExplorationResponse("A resposta está completa.\nOFERTA_PROXIMA_ACAO: posso ajudar a montar um cronograma?").state).toBe("ceased");
    expect(classifyExplorationResponse("Ainda falta um dado essencial.\nPERGUNTA_BLOQUEANTE: Qual é a renda disponível para o cronograma?").state).toBe("awaiting_owner");
    expect(classifyExplorationResponse("Você gostaria que eu montasse uma estratégia?").state).toBe("ceased");
  });

  it("consolida linhas encerradas progressivamente e preserva divergências", () => {
    const prompt = buildExplorationSynthesisPrompt({ stage: "final", objective: "reorganizar o patrimônio", closedLine: "Linha patrimonial: aquisição gradual.", consolidatedLines: ["Linha familiar: proteger a convivência."] });
    expect(prompt).toContain("síntese final");
    expect(prompt).toContain("aquisição gradual");
    expect(prompt).toContain("proteger a convivência");
    expect(prompt).toContain("Preserve divergências");
  });

  it("faz o Estrategista central coordenar a distribuição sem substituir as linhas", () => {
    const prompt = buildStrategistCoordinatorPrompt({ title: "Responsabilidades pós-divórcio", objective: "explorar alternativas", sourceContent: "Contexto integral autorizado", evidencePacket: "[]" });
    expect(prompt).toContain("solicitação integral");
    expect(prompt).toContain("distribuição sugerida");
    expect(prompt).toContain("IAs do Laboratório");
  });

  it("permite ao Estrategista reorganizar a pauta após resposta do titular", () => {
    const prompt = buildStrategistContinuationPrompt({ objective: "explorar alternativas", currentBrief: "Pauta anterior", question: "Qual despesa deve ser comprovada?", ownerAnswer: "Resposta integral do titular", lineStates: "patrimonial: active" });
    expect(prompt).toContain("Estrategista central");
    expect(prompt).toContain("redistribuída");
    expect(prompt).toContain("Resposta integral do titular");
  });

  it("inclui somente o histórico da linha e a resposta correspondente", () => {
    const prompt = buildExplorationFollowUpPrompt({
      objective: "ganhar tempo para reorganizar o patrimônio",
      perspective: "patrimonial",
      branchHistory: "model: avaliar aquisição gradual",
      question: "Qual a renda disponível para um cronograma?",
      ownerAnswer: "A informação será fornecida nesta linha.",
    });
    expect(prompt).toContain("avaliar aquisição gradual");
    expect(prompt).toContain("A informação será fornecida nesta linha.");
    expect(prompt).toContain("Não use, compare ou incorpore respostas de outras IAs");
  });
});
