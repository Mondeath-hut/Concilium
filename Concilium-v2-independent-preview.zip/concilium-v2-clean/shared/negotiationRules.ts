// [NOVO v2 / Fase 0] DocumentStatus deixou de ter sua própria lista de 5 estados e passou a
// ser um alias do NegotiationProposalStatus (shared/hearingChecklist.ts) — fonte única de
// verdade para o status da Mesa Formal, evitando que os dois arquivos fiquem dessincronizados
// como aconteceu antes (a tabela no banco só aceitava 5 dos 9 estados já projetados aqui).
import {
  assertValidProposalTransition,
  isValidProposalTransition,
  NEGOTIATION_PROPOSAL_STATUSES,
  type NegotiationProposalStatus,
} from "./hearingChecklist";

export const DOCUMENT_STATUSES = NEGOTIATION_PROPOSAL_STATUSES;
export type DocumentStatus = NegotiationProposalStatus;

export const CASE_ROLES = ["parte_principal", "assessor_juridico", "convidado"] as const;
export type CaseRole = (typeof CASE_ROLES)[number];

export function isCaseRole(value: string): value is CaseRole {
  return (CASE_ROLES as readonly string[]).includes(value);
}

export function isInvitationEmailMatch(invitedEmail?: string | null, authenticatedEmail?: string | null) {
  if (!invitedEmail || !authenticatedEmail) return false;
  return invitedEmail.trim().toLocaleLowerCase() === authenticatedEmail.trim().toLocaleLowerCase();
}

export function isValidDocumentTransition(from: DocumentStatus, to: DocumentStatus) {
  return isValidProposalTransition(from, to);
}

export function assertValidDocumentTransition(from: DocumentStatus, to: DocumentStatus) {
  assertValidProposalTransition(from, to);
}
