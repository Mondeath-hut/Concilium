/**
 * Índice comparativo de atendimento dos interesses (Manual funcional v2, seção 12).
 *
 * Substitui o antigo `agreementChance` ("chance de acordo"), que soava perto demais da
 * "probabilidade de vitória" que o manual proíbe explicitamente de usar como rótulo.
 * Este índice nunca prevê resultado judicial nem chance de aceitação — só mostra, com
 * pesos visíveis, o quanto uma alternativa atende a cada interesse considerado.
 */

export const INTEREST_DIMENSIONS = [
  "seguranca_habitacional",
  "preservacao_patrimonial",
  "liquidez",
  "previsibilidade",
  "prazo",
  "risco_de_inadimplemento",
  "impacto_financeiro",
  "preservacao_interesses_filhos",
] as const;

export type InterestDimension = (typeof INTEREST_DIMENSIONS)[number];

export const INTEREST_DIMENSION_LABELS: Record<InterestDimension, string> = {
  seguranca_habitacional: "Segurança habitacional",
  preservacao_patrimonial: "Preservação patrimonial",
  liquidez: "Liquidez",
  previsibilidade: "Previsibilidade",
  prazo: "Prazo",
  risco_de_inadimplemento: "Risco de inadimplemento",
  impacto_financeiro: "Impacto financeiro",
  preservacao_interesses_filhos: "Preservação dos interesses dos filhos",
};

/** Nota de 0 a 100 numa dimensão, mais o peso que ela tem no índice final (soma dos pesos = 1). */
export type DimensionScore = {
  dimension: InterestDimension;
  /** undefined = não calculado (falta dado) — nunca inventar um número para preencher a lacuna. */
  score?: number;
  weight: number;
};

export type InterestAlignmentResult = {
  /** null quando falta dado suficiente — nunca preenchido com um valor arbitrário. */
  value: number | null;
  weightsUsed: Array<{ dimension: InterestDimension; weight: number }>;
  missingDimensions: InterestDimension[];
  label: "índice comparativo de atendimento dos interesses";
};

/**
 * Calcula o índice a partir de notas e pesos explícitos. Se faltar nota em uma dimensão
 * com peso definido, ela entra em `missingDimensions` e não participa do cálculo — o
 * índice só fica "não calculado" (value: null) se sobrar peso insuficiente para uma
 * leitura confiável (menos de 50% do peso total coberto).
 */
export function computeInterestAlignmentIndex(scores: DimensionScore[]): InterestAlignmentResult {
  const totalWeight = scores.reduce((sum, item) => sum + item.weight, 0);
  const missingDimensions = scores.filter(item => item.score === undefined).map(item => item.dimension);
  const usable = scores.filter((item): item is DimensionScore & { score: number } => item.score !== undefined);
  const usableWeight = usable.reduce((sum, item) => sum + item.weight, 0);

  const weightsUsed = scores.map(item => ({ dimension: item.dimension, weight: item.weight }));

  if (totalWeight <= 0 || usableWeight / totalWeight < 0.5) {
    return { value: null, weightsUsed, missingDimensions, label: "índice comparativo de atendimento dos interesses" };
  }

  const weightedSum = usable.reduce((sum, item) => sum + item.score * item.weight, 0);
  const value = Math.round((weightedSum / usableWeight) * 100) / 100;

  return { value, weightsUsed, missingDimensions, label: "índice comparativo de atendimento dos interesses" };
}
