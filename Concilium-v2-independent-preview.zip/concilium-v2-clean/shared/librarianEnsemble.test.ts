import { describe, expect, it } from "vitest";
import { runLibrarianEnsemble } from "./librarianEnsemble";

describe("ensemble neutro do Bibliotecário", () => {
  it("executa papéis independentemente, deduplica fontes e preserva falha de papel", async () => {
    const result = await runLibrarianEnsemble({
      query: "formas de cumprimento",
      mode: "contextual_research",
      agents: [
        { role: "primary_source_finder", search: async () => [{ id: "f1", authorityLevel: "primaria", validityState: "vigente", citations: [{ verified: true }] }] },
        { role: "jurisprudence_finder", search: async () => [{ id: "f1", authorityLevel: "primaria", validityState: "vigente", citations: [{ verified: true }] }] },
        { role: "validity_auditor", search: async () => { throw new Error("falha fictícia"); } },
      ],
    });
    expect(result.packet.items).toHaveLength(1);
    expect(result.roleResults.find(item => item.role === "validity_auditor")?.status).toBe("failed");
    expect(result.packet.items[0].resultId).toBe("f1");
  });
});
