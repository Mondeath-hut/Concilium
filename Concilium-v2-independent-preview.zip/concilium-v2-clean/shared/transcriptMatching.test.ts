import { describe, expect, it } from "vitest";
import { analyzeTranscriptSegment, extractSpokenNumbers, lexicalMatch, type ChecklistItemForMatching } from "./transcriptMatching";
import type { TranscriptSegment } from "./transcriptionReview";

const pensionItem: ChecklistItemForMatching = {
  id: "item-pensao",
  description: "Valor da pensão alimentícia mensal",
  canonicalKeywords: ["pensão", "alimentos", "mesada", "valor mensal"],
};

function segment(text: string): TranscriptSegment {
  return { id: "seg-1", startMs: 0, endMs: 1000, textOriginal: text };
}

describe("extractSpokenNumbers", () => {
  it("extrai valores em R$ com separador de milhar", () => {
    expect(extractSpokenNumbers("ela pediu R$ 2.100,00 de pensão")).toContain(2100);
  });

  it("extrai números por extenso simples", () => {
    expect(extractSpokenNumbers("pensão de dois mil reais")).toContain(2000);
  });

  it("soma dezena e unidade em números compostos", () => {
    expect(extractSpokenNumbers("prazo de vinte e quatro meses")).toContain(24);
  });

  it("retorna lista vazia quando não há número", () => {
    expect(extractSpokenNumbers("vamos conversar sobre isso depois")).toEqual([]);
  });
});

describe("lexicalMatch (Camada C)", () => {
  it("encontra o item pelo dicionário de sinônimos, mesmo sem a palavra exata do item", () => {
    const matches = lexicalMatch("minha ex-esposa está pedindo uma mesada de dois mil reais", [pensionItem]);
    expect(matches).toEqual([{ checklistItemId: "item-pensao", method: "lexico", confidence: 0.6 }]);
  });

  it("não gera correspondência quando nenhum sinônimo aparece", () => {
    expect(lexicalMatch("vamos falar sobre o terreno de Salinas", [pensionItem])).toEqual([]);
  });
});

describe("analyzeTranscriptSegment (cascata online -> local -> léxica)", () => {
  it("usa a Camada A quando o provedor online responde com sucesso", async () => {
    const result = await analyzeTranscriptSegment(segment("ela pediu dois mil reais de pensão"), [pensionItem], {
      online: async () => [{ checklistItemId: "item-pensao", method: "online", confidence: 0.95 }],
    });
    expect(result.checklistMatches[0].method).toBe("online");
  });

  it("cai para a Camada B quando a Camada A falha", async () => {
    const result = await analyzeTranscriptSegment(segment("ela pediu dois mil reais de pensão"), [pensionItem], {
      online: async () => { throw new Error("sem conexão"); },
      localOffline: async () => [{ checklistItemId: "item-pensao", method: "local_offline", confidence: 0.8 }],
    });
    expect(result.checklistMatches[0].method).toBe("local_offline");
  });

  it("cai para a Camada C quando A e B estão indisponíveis", async () => {
    const result = await analyzeTranscriptSegment(segment("ela está pedindo uma mesada de dois mil reais"), [pensionItem], {});
    expect(result.checklistMatches[0].method).toBe("lexico");
    expect(result.spokenNumbers).toContain(2000);
  });

  it("modo manual (ditado) usa exatamente o mesmo motor que o modo ao vivo", async () => {
    const ditado = await analyzeTranscriptSegment(segment("pensão de dois mil reais"), [pensionItem], {});
    const aoVivo = await analyzeTranscriptSegment(segment("pensão de dois mil reais"), [pensionItem], {});
    expect(ditado.checklistMatches).toEqual(aoVivo.checklistMatches);
  });

  it("sempre inclui a categorização genérica de transcriptionReview junto do match", async () => {
    const result = await analyzeTranscriptSegment(segment("eu aceito a proposta de dois mil reais"), [pensionItem], {});
    expect(result.reviews.some(review => review.kind === "possivel_aceite")).toBe(true);
  });
});
