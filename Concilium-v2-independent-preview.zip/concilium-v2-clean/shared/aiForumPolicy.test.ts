import { describe, expect, it } from "vitest";
import { automaticVisibilityForRole, buildNextRoundPrompt, buildSupervisorCoordinationPrompt, LAB_DEFAULT_ACCESS_LEVEL, SUPERVISOR_ACCESS_LEVEL, STRATEGIST_ACCESS_LEVEL, projectContentForAi } from "./aiForumPolicy";
import { canUseAsCurrentFoundation } from "./knowledgeService";

describe("política de acesso da Arena", () => {
  it("mantém o supervisor no nível integral autorizado", () => {
    expect(SUPERVISOR_ACCESS_LEVEL).toBe("integral_autorizado");
  });

  it("diferencia acesso integral do Estrategista da projeção do Laboratório", () => {
    expect(STRATEGIST_ACCESS_LEVEL).toBe("integral_autorizado");
    expect(LAB_DEFAULT_ACCESS_LEVEL).toBe("contexto_protegido");
  });

  it("minimiza automaticamente o conteúdo para o auditor quando há contexto sensível", () => {
    expect(automaticVisibilityForRole({ role: "auditor_critico", allowIntegral: false, containsSensitiveContext: true })).toBe("redigido");
    expect(automaticVisibilityForRole({ role: "mediador", allowIntegral: false, containsSensitiveContext: true })).toBe("contexto_protegido");
  });

  it("mascara nome declarado e preserva o contexto no Laboratório", () => {
    const projected = projectContentForAi("Meu nome é Augusto Lima e continuarei na mesma casa após a separação.", "contexto_protegido");
    expect(projected).not.toContain("Augusto Lima");
    expect(projected).toContain("mesma casa");
  });

  it("preserva o contexto de convivência sem expor identificadores", () => {
    const source = "Após a separação, os ex-cônjuges continuarão na mesma casa por falta de condições financeiras. Há filhos maiores, áreas comuns, despesas e constrangimento com novos companheiros.";
    const projected = projectContentForAi(source, "contexto_protegido");
    expect(projected).toContain("mesma casa");
    expect(projected).toContain("filhos maiores");
    expect(projected).toContain("novos companheiros");
  });

  it("obriga o supervisor a preservar o pedido concreto, não apenas o rótulo jurídico", () => {
    const prompt = buildSupervisorCoordinationPrompt({ title: "Convivência pós-separação", content: "Precisamos regular áreas comuns e visitas para preservar a convivência e evitar constrangimentos aos filhos.", objective: "Avaliar critérios e limites da cláusula." });
    expect(prompt).toContain("Não reduza uma situação íntima");
    expect(prompt).toContain("áreas comuns");
  });

  it("não aceita como fundamento atual uma fonte superada ou de outro país", () => {
    expect(canUseAsCurrentFoundation({ validityState: "superada", country: "Brasil", requestedCountry: "Brasil" })).toBe(false);
    expect(canUseAsCurrentFoundation({ validityState: "vigente", country: "Portugal", requestedCountry: "Brasil" })).toBe(false);
    expect(canUseAsCurrentFoundation({ validityState: "vigente", country: "Brasil", requestedCountry: "Brasil", jurisdiction: "São Paulo", requestedJurisdiction: "São Paulo" })).toBe(true);
  });

  it("faz a nova rodada partir de uma síntese, e não de uma conversa contínua", () => {
    const prompt = buildNextRoundPrompt({ previousSynthesis: "Separar fatos confirmados de hipóteses." });
    expect(prompt).toContain("nova rodada independente");
    expect(prompt).toContain("Separar fatos confirmados");
  });
});
