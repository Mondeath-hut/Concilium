import { describe, expect, it } from "vitest";
import { ACTOR_DEFAULT_ACCESS, ACTOR_ROLE_LABELS, ACTOR_ROLES, buildActorSystemPrompt } from "./actorRoles";

describe("papéis de ator (Manual v2, seção 8-A)", () => {
  it("define os 6 papéis do manual, sem nome próprio, só a função", () => {
    expect(ACTOR_ROLES).toEqual(["estrategista", "supervisor", "bibliotecario", "defesa", "advogado_do_diabo", "mediador"]);
    for (const role of ACTOR_ROLES) {
      expect(ACTOR_ROLE_LABELS[role]).toBeTruthy();
    }
  });

  it("o Bibliotecário nunca tem acesso integral autorizado por padrão", () => {
    expect(ACTOR_DEFAULT_ACCESS.bibliotecario).not.toBe("integral_autorizado");
  });

  it("Supervisor e Estrategista têm acesso integral autorizado por padrão", () => {
    expect(ACTOR_DEFAULT_ACCESS.supervisor).toBe("integral_autorizado");
    expect(ACTOR_DEFAULT_ACCESS.estrategista).toBe("integral_autorizado");
  });
});

describe("buildActorSystemPrompt", () => {
  const baseCtx = { title: "Caso de teste", objective: "Organizar a negociação", projectedContent: "conteúdo de teste" };

  it("gera um prompt diferente para cada papel", () => {
    const prompts = ACTOR_ROLES.map(role => buildActorSystemPrompt({ role, visibilityLevel: ACTOR_DEFAULT_ACCESS[role], ...baseCtx }));
    const unique = new Set(prompts);
    expect(unique.size).toBe(ACTOR_ROLES.length);
  });

  it("o prompt do Bibliotecário nunca menciona 'dossiê completo' como algo recebido", () => {
    const prompt = buildActorSystemPrompt({ role: "bibliotecario", visibilityLevel: ACTOR_DEFAULT_ACCESS.bibliotecario, ...baseCtx });
    expect(prompt).toMatch(/NUNCA recebe o dossiê completo/);
  });
});
