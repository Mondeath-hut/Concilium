/**
 * Progressão nomeada de cenário e parâmetros dinâmicos (Manual funcional v2, seções 7 e 10).
 * A migração entre estágios sempre exige motivo — nunca é automática (Manual, seção 7:
 * "A passagem entre cenários exige autorização do titular, com registro de motivo").
 */
export const SCENARIO_STAGES = [
  "cooperativo",
  "cooperativo_protegido",
  "equilibrado",
  "defensivo",
  "impasse",
] as const;

export type ScenarioStage = (typeof SCENARIO_STAGES)[number];

// A progressão padrão é linear (Manual, seção 7), mas retroceder é permitido — o titular
// pode reabrir uma via mais cooperativa se a negociação evoluir bem — sempre com motivo.
const stageOrder: Record<ScenarioStage, number> = {
  cooperativo: 0,
  cooperativo_protegido: 1,
  equilibrado: 2,
  defensivo: 3,
  impasse: 4,
};

export type ScenarioMigration = {
  from: ScenarioStage;
  to: ScenarioStage;
  reason: string;
};

export function isForwardMigration(migration: Pick<ScenarioMigration, "from" | "to">): boolean {
  return stageOrder[migration.to] > stageOrder[migration.from];
}

/** Toda migração — de avanço ou de retrocesso — exige um motivo não vazio. */
export function assertValidScenarioMigration(migration: ScenarioMigration): void {
  if (migration.from === migration.to) {
    throw new Error("Migração de cenário precisa mudar de estágio.");
  }
  if (!migration.reason || migration.reason.trim().length < 8) {
    throw new Error("Migração de cenário exige motivo registrado (mínimo 8 caracteres).");
  }
}

export type ScenarioParameterDefinition = {
  parameterKey: string;
  label: string;
  valueType: "numeric" | "date" | "text" | "boolean";
  minValue?: number;
  idealValue?: number;
  maxValue?: number;
  /** Reserva mínima intocável — abaixo dela, o alerta é sempre vermelho, mesmo dentro do min/max. */
  hardFloor?: number;
};

export type ParameterEvaluation = {
  parameterKey: string;
  observedValue: number;
  level: "green" | "amber" | "red";
  reason: string;
};

/**
 * Compara um valor observado na fala (ver shared/transcriptMatching.ts,
 * extractSpokenNumbers) com os limites definidos para o parâmetro do cenário.
 * Nunca resolve sozinho — é entrada para o alerta do checklist (shared/hearingChecklist.ts).
 */
export function evaluateParameterValue(
  definition: ScenarioParameterDefinition,
  observedValue: number,
): ParameterEvaluation {
  if (definition.hardFloor !== undefined && observedValue < definition.hardFloor) {
    return {
      parameterKey: definition.parameterKey,
      observedValue,
      level: "red",
      reason: `Abaixo da reserva mínima protegida (${definition.hardFloor}).`,
    };
  }
  if (definition.maxValue !== undefined && observedValue > definition.maxValue) {
    return {
      parameterKey: definition.parameterKey,
      observedValue,
      level: "red",
      reason: `Acima do limite máximo aceitável (${definition.maxValue}).`,
    };
  }
  if (
    (definition.minValue !== undefined && observedValue < definition.minValue) ||
    (definition.idealValue !== undefined && observedValue !== definition.idealValue)
  ) {
    return {
      parameterKey: definition.parameterKey,
      observedValue,
      level: "amber",
      reason: "Dentro do intervalo aceitável, mas fora do valor ideal — confirmar com o titular.",
    };
  }
  return {
    parameterKey: definition.parameterKey,
    observedValue,
    level: "green",
    reason: "Compatível com o parâmetro definido para o cenário.",
  };
}
