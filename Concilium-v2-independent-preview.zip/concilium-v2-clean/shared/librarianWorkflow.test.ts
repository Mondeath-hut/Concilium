import { describe, expect, it } from "vitest";
import { buildLibrarianResponsePacket, classifyLibrarianRequest } from "./librarianWorkflow";

describe("librarian workflow", () => {
  it("classifica pedidos de cláusulas como modelos não normativos", () => {
    const result = classifyLibrarianRequest("modelos de cláusulas para divórcio com partilha de imóvel");
    expect(result.mode).toBe("clause_models");
    expect(result.handoffRecommended).toBe(false);
    expect(result.activeRoles).toContain("clause_pattern_curator");
  });

  it("sinaliza perguntas de escolha ou aplicação ao Estrategista", () => {
    const result = classifyLibrarianRequest("qual estratégia devo usar no meu caso para negociar o imóvel?");
    expect(result.mode).toBe("strategy_handoff");
    expect(result.handoffRecommended).toBe(true);
  });

  it("reconhece a pergunta concreta sobre compensar alimentos com despesas da casa", () => {
    const result = classifyLibrarianRequest("Estou morando na mesma casa que minha ex-cônjuge e pagando as compras de supermercado do mês. Posso utilizar uma cláusula compensatória para substituir ou evitar o envio de dinheiro diretamente a ela?");
    expect(result.mode).toBe("strategy_handoff");
    expect(result.handoffRecommended).toBe(true);
    expect(result.activeRoles).toContain("validity_auditor");
  });

  it("expande uma pergunta normal para pesquisa contextual ampla", () => {
    const result = classifyLibrarianRequest("Quais possibilidades jurídicas existem para organizar as responsabilidades depois do divórcio?");
    expect(result.mode).toBe("contextual_research");
    expect(result.handoffTarget).toBe("alternatives_lab");
    expect(result.activeRoles).toHaveLength(5);
  });

  it("monta pacote neutro sem transformar modelo em fundamento", () => {
    const packet = buildLibrarianResponsePacket({ mode: "strategy_handoff", results: [{ id: "clause-1", authorityLevel: "modelo_nao_normativo", validityState: "vigente", citations: [{ verified: true }] }] });
    expect(packet.items[0]?.treatment).toBe("non_normative_model");
    expect(packet.items[0]?.materialType).toBe("clause_model");
  });

  it("permite forçar um modo sem enviar o caso protegido", () => {
    const result = classifyLibrarianRequest("pesquisar cláusula", "sources");
    expect(result.mode).toBe("sources");
  });
});
