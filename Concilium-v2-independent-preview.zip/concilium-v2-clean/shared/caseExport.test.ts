import { describe, expect, it } from "vitest";
import { buildCaseExportBundle, buildInegotiableItemsExport, exportBundleToJson, exportBundleToPrintableHtml, type ChecklistExportItem } from "./caseExport";

const checklistItems: ChecklistExportItem[] = [
  { id: "1", groupLabel: "Casa", description: "Uso exclusivo provisório", itemType: "negociavel", priority: "alta", state: "pendente" },
  { id: "2", groupLabel: "Pensão", description: "Valor mínimo intocável", itemType: "inegociavel_exige_pausa", priority: "critica", state: "pendente" },
  { id: "3", groupLabel: "Bradesco", description: "Confirmar se a dívida ainda está ativa", itemType: "pendente_de_prova", priority: "normal", state: "pendente" },
];

describe("filtros de exportação", () => {
  it("pontos inegociáveis só traz itens que exigem pausa", () => {
    const result = buildInegotiableItemsExport(checklistItems);
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe("2");
  });
});

describe("montagem do pacote de exportação", () => {
  const bundle = buildCaseExportBundle({
    caseTitle: "Caso de teste",
    currentStage: "equilibrado",
    keyFacts: ["fato 1"],
    topRisks: ["risco 1"],
    nextSteps: ["passo 1"],
    checklistItems,
    formalHistory: [{ id: "doc-1", documentType: "proposta", title: "Proposta inicial", currentStatus: "apresentada", createdAtIso: new Date().toISOString() }],
  });

  it("inclui checklist com nível de alerta calculado", () => {
    expect(bundle.checklist.find(item => item.id === "2")?.alertLevel).toBe("red");
  });

  it("separa perguntas de audiência dos itens pendentes de prova", () => {
    expect(bundle.hearingQuestions.map(item => item.id)).toContain("3");
  });

  it("exporta em JSON válido e reversível", () => {
    const json = exportBundleToJson(bundle);
    const parsed = JSON.parse(json);
    expect(parsed.caseTitle).toBe("Caso de teste");
    expect(parsed.checklist).toHaveLength(3);
  });

  it("exporta um HTML autônomo, sem referências externas, pronto para impressão", () => {
    const html = exportBundleToPrintableHtml(bundle);
    expect(html).toContain("<html");
    expect(html).not.toMatch(/https?:\/\//); // sem chamada externa nenhuma
    expect(html).toContain("Valor mínimo intocável");
  });

  it("escapa HTML no conteúdo do usuário (evita injeção na exportação)", () => {
    const withScript = buildCaseExportBundle({
      caseTitle: "<script>alert(1)</script>",
      currentStage: "cooperativo",
      keyFacts: [], topRisks: [], nextSteps: [],
      checklistItems: [],
      formalHistory: [],
    });
    const html = exportBundleToPrintableHtml(withScript);
    expect(html).not.toContain("<script>alert(1)</script>");
    expect(html).toContain("&lt;script&gt;");
  });
});
