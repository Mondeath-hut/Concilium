import { describe, expect, it } from "vitest";
import { isSevenZipHeader, sanitizeArchiveDisplayName, SEVEN_ZIP_MAGIC } from "./secretIntake";

describe("pré-validação segura de pacote", () => {
  it("reconhece o cabeçalho 7z sem extrair o arquivo", () => {
    expect(isSevenZipHeader(SEVEN_ZIP_MAGIC)).toBe(true);
    expect(isSevenZipHeader([0x50, 0x4b, 0x03, 0x04, 0, 0])).toBe(false);
  });

  it("não permite caminho no nome exibido", () => {
    expect(sanitizeArchiveDisplayName("../cofre/chaves.7z")).toBe("chaves.7z");
  });
});
