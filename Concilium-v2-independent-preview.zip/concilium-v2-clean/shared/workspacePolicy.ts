import type { CaseRole } from "./negotiationRules";
import type { NegotiationProposalStatus } from "./hearingChecklist";

export function getWorkspaceVisibility(role: CaseRole) {
  return {
    includeDraftDocuments: role !== "convidado",
    exposeParticipantContacts: role === "parte_principal",
  } as const;
}

export function getUtcTimestampMs(now = Date.now) {
  return now();
}

export function isUtcEpochMilliseconds(value: number) {
  return Number.isSafeInteger(value) && value >= 0;
}

export type DocumentVisibility = "privado_titular" | "partes" | "contexto_protegido" | "homologado";

export function canViewCaseDocument(input: { role: CaseRole; isOwner: boolean; isAuthor: boolean; visibility: DocumentVisibility; isShared: boolean }) {
  if (input.isOwner || input.isAuthor) return true;
  if (input.role === "parte_principal") return input.visibility !== "privado_titular";
  if (input.visibility === "contexto_protegido") return true;
  return input.visibility === "homologado" || input.isShared;
}

export function canReleaseInSequence(states: Array<"reservada" | "liberada">, targetIndex: number) {
  return targetIndex >= 0 && states.slice(0, targetIndex).every(state => state === "liberada");
}

// [NOVO v2 / Fase 0] aceita qualquer status pós-rascunho do enum canônico de 9 estados;
// estados não tratados explicitamente mantêm a visibilidade atual.
export function nextDocumentVisibility(current: DocumentVisibility, status: Exclude<NegotiationProposalStatus, "rascunho_interno">) {
  if (status === "apresentada") return "partes" as const;
  if (status === "aceita") return "homologado" as const;
  return current;
}

export function shouldRedactContext(input: { role: CaseRole; isOwner: boolean; isAuthor: boolean; isShared: boolean; visibility: DocumentVisibility }) {
  return input.visibility === "contexto_protegido" && !input.isOwner && !input.isAuthor && input.role !== "parte_principal" && !input.isShared;
}

export function projectDocumentForViewer<T extends { authoredBy: number; visibility: DocumentVisibility; title: string; body: string }>(document: T, input: { userId: number; role: CaseRole; isOwner: boolean; isShared: boolean }) {
  const redacted = shouldRedactContext({ role: input.role, isOwner: input.isOwner, isAuthor: document.authoredBy === input.userId, isShared: input.isShared, visibility: document.visibility });
  return redacted ? { document: { ...document, title: "Documento com dados protegidos", body: redactSensitiveText(document.body) }, redacted: true } : { document, redacted: false };
}

export function canViewCaseAttachment(input: { role: CaseRole; isOwner: boolean; isAuthor: boolean; visibility: DocumentVisibility; isShared: boolean }) {
  if (input.isOwner || input.isAuthor || input.isShared) return true;
  if (input.visibility === "contexto_protegido" || input.visibility === "homologado") return true;
  return input.role === "parte_principal" && input.visibility === "partes";
}

export function projectAttachmentForViewer<T extends { createdBy: number; visibility: DocumentVisibility; title: string; storageUrl: string | null }>(attachment: T, input: { userId: number; role: CaseRole; isOwner: boolean; isShared: boolean }) {
  const redacted = attachment.visibility === "contexto_protegido" && !input.isOwner && attachment.createdBy !== input.userId && input.role !== "parte_principal" && !input.isShared;
  return redacted ? { ...attachment, title: "Anexo com dados protegidos", storageUrl: "", redacted: true } : { ...attachment, redacted: false };
}

/**
 * Remove identificadores e valores pessoais sem apagar o contexto relacional,
 * doméstico ou patrimonial necessário para uma análise. "Casa", "filhos",
 * "coabitação" e o motivo de uma cláusula não são, por si, identificadores.
 */
export function redactIdentifiersKeepContext(content: string) {
  return content
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[e-mail protegido]")
    .replace(/(?:\+?55\s*)?(?:\(?\d{2}\)?\s*)?9?\d{4}[-\s]?\d{4}/g, "[telefone protegido]")
    .replace(/\b\d{3}[.]?\d{3}[.]?\d{3}[-.]?\d{2}\b/g, "[identificador protegido]")
    .replace(/(?:Rua|Avenida|Travessa|Alameda|Quadra|Condomínio|Residencial)\s+[^,;\n.]+/gi, "[referência de endereço protegida]")
    .replace(/R\$\s?[\d.]+(?:,[\d]{2})?(?:\s*(?:mil|milhões))?/gi, "[valor protegido]")
    .replace(/\b\d{1,3}(?:\.\d{3})+(?:,\d{2})?\b/g, "[número protegido]");
}

/** Mascara nomes declarados como pessoais sem remover o restante do contexto semântico. */
export function redactPersonalNamesKeepContext(content: string) {
  return content
    .replace(/((?:meu nome é|me chamo|nome completo(?: é|:)?)\s+)([A-ZÀ-Ý][a-zà-ÿ]+(?:\s+[A-ZÀ-Ý][a-zà-ÿ]+){0,3})/gi, "$1[nome protegido]")
    .replace(/((?:Sr\.?|Sra\.?|Dr\.?|Dra\.?)\s+)([A-ZÀ-Ý][a-zà-ÿ]+(?:\s+[A-ZÀ-Ý][a-zà-ÿ]+){0,3})/g, "$1[nome protegido]");
}

export function redactSensitiveText(content: string) {
  return content
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[e-mail protegido]")
    .replace(/(?:\+?55\s*)?(?:\(?\d{2}\)?\s*)?9?\d{4}[-\s]?\d{4}/g, "[telefone protegido]")
    .replace(/\b\d{3}[.]?\d{3}[.]?\d{3}[-.]?\d{2}\b/g, "[identificador protegido]")
    .replace(/[A-ZÀ-Ý][a-zà-ÿ]+(?:\s+[A-ZÀ-Ý][a-zà-ÿ]+){1,4}/g, match => `${match.split(/\s+/)[0]} ···`)
    .replace(/R\$\s?[\d.]+(?:,\d{2})?(?:\s*(?:mil|milhões))?/gi, "R$ ···")
    .replace(/\b\d+(?:[.,]\d+)?\s?%/g, "···%")
    .replace(/\b\d{1,3}(?:\.\d{3})+(?:,\d{2})?\b/g, "···")
    .replace(/\b\d{1,4}\s?(?:m²|ha|anos|meses)\b/gi, "···")
    .replace(/(?:Rua|Avenida|Travessa|Alameda|Quadra|Condomínio|Residencial)\s+[^,;\n.]+/gi, "[referência patrimonial protegida]")
    .replace(/\b(?:salário|renda|remuneração|FGTS|IPTU|dívida|imóvel|casa|terreno|lote|apartamento|cartão|financiamento|veículo|quotas?)\b[^\n.;:]*/gi, "[dado financeiro ou patrimonial protegido]");
}
