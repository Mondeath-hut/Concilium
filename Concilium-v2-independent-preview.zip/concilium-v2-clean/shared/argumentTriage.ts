import { z } from "zod";

export const argumentLegalStatuses = [
  "apoiado_por_fonte_vigente",
  "possivel_aplicacao",
  "controvertido",
  "nao_verificado",
  "contradito_ou_rejeitado",
  "fora_da_jurisdicao",
] as const;
export type ArgumentLegalStatus = (typeof argumentLegalStatuses)[number];

export const argumentOperationalStatuses = ["licito_para_analise", "requer_revisao_profissional", "bloqueado_instrucao_ilicita"] as const;
export type ArgumentOperationalStatus = (typeof argumentOperationalStatuses)[number];

export const argumentReviewStatuses = ["pending", "triaged", "needs_research", "arena_ready", "approved_for_use", "archived"] as const;
export type ArgumentReviewStatus = (typeof argumentReviewStatuses)[number];

export const argumentAssessmentSchema = z.object({
  formulation: z.string().trim().min(3).max(12_000),
  legalStatus: z.enum(argumentLegalStatuses),
  confidence: z.enum(["high", "medium", "low", "unknown"]),
  evidenceStrength: z.enum(["primary", "official_structured", "licensed_secondary", "secondary", "none"]),
  moralEthicalNotes: z.string().trim().max(4_000).optional(),
  factualDependencies: z.array(z.string().trim().min(1).max(500)).max(30).default([]),
  counterpoints: z.array(z.string().trim().min(1).max(1_000)).max(30).default([]),
  limitations: z.array(z.string().trim().min(1).max(1_000)).max(30).default([]),
  operationalStatus: z.enum(argumentOperationalStatuses),
  reviewStatus: z.enum(argumentReviewStatuses).default("pending"),
  sourceSnapshot: z.array(z.object({
    title: z.string().trim().min(1).max(320),
    url: z.string().url().nullable(),
    jurisdiction: z.string().trim().max(160),
    version: z.string().trim().max(120),
    validity: z.string().trim().max(80),
    locator: z.string().trim().max(500),
    verified: z.boolean(),
  })).max(30).default([]),
});
export type ArgumentAssessment = z.infer<typeof argumentAssessmentSchema>;

export function canEnterActiveStrategy(input: Pick<ArgumentAssessment, "legalStatus" | "operationalStatus">) {
  return input.operationalStatus !== "bloqueado_instrucao_ilicita"
    && input.legalStatus !== "contradito_ou_rejeitado"
    && input.legalStatus !== "fora_da_jurisdicao";
}

export function requiresVisibleWarning(input: Pick<ArgumentAssessment, "legalStatus" | "confidence" | "operationalStatus">) {
  return input.operationalStatus !== "licito_para_analise"
    || input.confidence !== "high"
    || input.legalStatus !== "apoiado_por_fonte_vigente";
}
