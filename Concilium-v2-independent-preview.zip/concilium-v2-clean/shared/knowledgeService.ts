import { z } from "zod";
import { librarianAgentRoles, librarianResearchModes, librarianResponsePacketSchema, librarianRoutingSchema } from "./librarianWorkflow";

export const knowledgeAreas = ["familia", "criminal", "contratos", "contabil", "trabalhista", "empresarial", "processual", "constitucional", "tributario", "geral"] as const;
export type KnowledgeArea = (typeof knowledgeAreas)[number];
export const knowledgeValidityStates = ["vigente", "revogada", "superada", "expirada", "pendente_verificacao"] as const;
export type KnowledgeValidityState = (typeof knowledgeValidityStates)[number];
export const knowledgeAuthorityLevels = ["primaria", "jurisprudencia_relevante", "secundaria", "modelo_nao_normativo"] as const;
export type KnowledgeAuthorityLevel = (typeof knowledgeAuthorityLevels)[number];

export const knowledgeSearchInput = z.object({
  query: z.string().trim().min(3).max(2_000),
  areas: z.array(z.enum(knowledgeAreas)).max(4).default([]),
  country: z.string().trim().max(80).default("Brasil"),
  jurisdiction: z.string().trim().max(120).optional(),
  asOf: z.string().date().optional(),
  requireCurrent: z.boolean().default(true),
  includeRelated: z.boolean().default(true),
  researchMode: z.enum(librarianResearchModes).optional(),
  agentRoles: z.array(z.enum(librarianAgentRoles)).max(5).optional(),
  /** Contexto deve ser uma síntese já minimizada, nunca o documento ou identificadores brutos. */
  contextSummary: z.string().trim().max(4_000).optional(),
});
export type KnowledgeSearchInput = z.infer<typeof knowledgeSearchInput>;

export const knowledgeResultSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  summary: z.string(),
  area: z.enum(knowledgeAreas),
  relevance: z.number().min(0).max(1),
  country: z.string(),
  sourceTitle: z.string(),
  sourceUrl: z.string().url().nullable(),
  sourceVersion: z.string(),
  jurisdiction: z.string(),
  authorityLevel: z.enum(knowledgeAuthorityLevels),
  validityState: z.enum(knowledgeValidityStates),
  validityCheckedAt: z.string().nullable(),
  supersededBy: z.string().nullable(),
  effectiveDate: z.string().nullable(),
  citations: z.array(z.object({ label: z.string(), locator: z.string(), quote: z.string().optional(), verified: z.boolean() })),
  related: z.array(z.object({ id: z.string(), title: z.string(), reason: z.string() })).default([]),
});
export type KnowledgeResult = z.infer<typeof knowledgeResultSchema>;

export const knowledgeSearchResponseSchema = z.object({
  configured: z.boolean(),
  requestId: z.string().optional(),
  results: z.array(knowledgeResultSchema),
  notice: z.string().optional(),
  routing: librarianRoutingSchema.optional(),
  packet: librarianResponsePacketSchema.optional(),
});
export type KnowledgeSearchResponse = z.infer<typeof knowledgeSearchResponseSchema>;

export function canUseAsCurrentFoundation(input: { validityState: KnowledgeValidityState; country: string; requestedCountry: string; jurisdiction?: string; requestedJurisdiction?: string }) {
  if (input.validityState !== "vigente") return false;
  if (input.country.toLowerCase() !== input.requestedCountry.toLowerCase()) return false;
  if (input.requestedJurisdiction && input.jurisdiction && !input.jurisdiction.toLowerCase().includes(input.requestedJurisdiction.toLowerCase())) return false;
  return true;
}

export const KNOWLEDGE_SERVICE_CONTRACT = {
  endpoint: "POST /v1/search",
  purpose: "Busca lexical e semântica em acervo jurídico versionado, com fontes, validade, jurisdição e relações.",
  triage: "Toda resposta precisa informar país, jurisdição, autoridade, versão, vigência, data de verificação e eventual revogação/superação.",
  privacy: "O contexto do caso só é enviado quando o titular autoriza e já foi minimizado; identificadores não fazem parte do contrato padrão.",
  boundary: "O bibliotecário recupera material e relações. Não produz decisão, parecer definitivo ou instrução vinculante.",
  ensemble: "A busca pode ser distribuída por funções independentes — fonte primária, jurisprudência, vigência, modelos de cláusula e fonte contrária — com consolidação posterior e rastreável.",
  routing: "Consultas de cláusulas e minutas permanecem no Bibliotecário como modelos não normativos; consultas de escolha, negociação ou aplicação ao caso são sinalizadas para o Estrategista.",
} as const;
