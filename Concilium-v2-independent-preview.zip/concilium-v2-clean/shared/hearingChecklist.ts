export type HearingState = "preparacao" | "em_andamento" | "pausada" | "encerrada";
export type ChecklistItemType = "negociavel" | "inegociavel_exige_pausa" | "pendente_de_prova";
export type ChecklistItemState = "pendente" | "aceito" | "recusado" | "parcialmente_aceito" | "substituido" | "dependente_confirmacao";
export type ChecklistPriority = "critica" | "alta" | "normal" | "baixa";

export type HearingChecklistInput = {
  itemType: ChecklistItemType;
  priority: ChecklistPriority;
  state: ChecklistItemState;
};

export function validHearingTransition(current: HearingState, next: HearingState): boolean {
  const transitions: Record<HearingState, HearingState[]> = {
    preparacao: ["em_andamento", "encerrada"],
    em_andamento: ["pausada", "encerrada"],
    pausada: ["em_andamento", "encerrada"],
    encerrada: [],
  };
  return transitions[current].includes(next);
}

export function hearingChecklistAlert(item: HearingChecklistInput) {
  if (item.itemType === "inegociavel_exige_pausa" && item.state !== "substituido") {
    return { level: "red" as const, requiresOwnerPause: true, label: "Pausa exigida" };
  }
  if (
    item.itemType === "pendente_de_prova" ||
    item.state === "dependente_confirmacao" ||
    (item.priority === "critica" && item.state === "pendente")
  ) {
    return { level: "amber" as const, requiresOwnerPause: false, label: "Confirmação pendente" };
  }
  return { level: "green" as const, requiresOwnerPause: false, label: "Acompanhado" };
}

export const NEGOTIATION_PROPOSAL_STATUSES = [
  "rascunho_interno",
  "apresentada",
  "recebida",
  "aceita",
  "recusada",
  "aceita_parcialmente",
  "contraproposta_recebida",
  "substituida",
  "encerrada",
] as const;

export type NegotiationProposalStatus = (typeof NEGOTIATION_PROPOSAL_STATUSES)[number];

export function proposalStatusIsFormal(status: NegotiationProposalStatus): boolean {
  return status !== "rascunho_interno";
}

export function proposalStatusAllowsFormalAcceptance(status: NegotiationProposalStatus): boolean {
  return status === "apresentada" || status === "recebida" || status === "contraproposta_recebida";
}

/**
 * [NOVO v2] Grafo de transição da Mesa Formal (Manual funcional, seção 13).
 * Uma proposta apresentada nunca é alterada silenciosamente: uma correção sempre passa
 * por "substituida" e nasce uma nova versão (ligada via parentDocumentId), nunca uma
 * edição in-place do texto já apresentado.
 */
const negotiationProposalTransitions: Record<NegotiationProposalStatus, readonly NegotiationProposalStatus[]> = {
  rascunho_interno: ["apresentada"],
  apresentada: ["recebida", "substituida"],
  recebida: ["aceita", "recusada", "aceita_parcialmente", "contraproposta_recebida", "substituida"],
  aceita_parcialmente: ["contraproposta_recebida", "encerrada", "substituida"],
  contraproposta_recebida: ["substituida", "encerrada"],
  aceita: ["encerrada"],
  recusada: ["encerrada"],
  substituida: [],
  encerrada: [],
};

export function isValidProposalTransition(from: NegotiationProposalStatus, to: NegotiationProposalStatus): boolean {
  return negotiationProposalTransitions[from].includes(to);
}

export function assertValidProposalTransition(from: NegotiationProposalStatus, to: NegotiationProposalStatus): void {
  if (!isValidProposalTransition(from, to)) {
    throw new Error(`Transição de proposta inválida na Mesa Formal: ${from} → ${to}.`);
  }
}
