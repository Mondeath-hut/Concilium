import { describe, expect, it } from "vitest";
import { extractSecretNamesFromManifestDocument, secretManifest, validateSecretNames } from "./secretManifest";

describe("manifesto público de credenciais", () => {
  it("expõe apenas nomes e finalidade, nunca valores", () => {
    expect(secretManifest.every(entry => entry.valueExpected)).toBe(true);
    expect(secretManifest.map(entry => entry.name)).toEqual(expect.arrayContaining(["RESEND_API_KEY", "RESEND_FROM_EMAIL"]));
    expect(secretManifest.every(entry => !Object.prototype.hasOwnProperty.call(entry, "value"))).toBe(true);
  });

  it("extrai somente nomes do manifesto sem retornar os valores", () => {
    const names = extractSecretNamesFromManifestDocument(JSON.stringify({ secrets: [{ name: "CONCILIUM_BOOTSTRAP_CODE", value: "valor-falso" }, { name: "CONCILIUM_MFA_ENCRYPTION_KEY", value: "outro-valor-falso" }] }));
    expect(names).toEqual(["CONCILIUM_BOOTSTRAP_CODE", "CONCILIUM_MFA_ENCRYPTION_KEY"]);
    expect(names.join(" ")).not.toContain("valor-falso");
  });

  it("detecta nomes desconhecidos e duplicidades sem ler segredos", () => {
    const result = validateSecretNames({ names: ["CONCILIUM_BOOTSTRAP_CODE", "CONCILIUM_BOOTSTRAP_CODE", "SEGREDO_DESCONHECIDO"] });
    expect(result.accepted).toEqual(["CONCILIUM_BOOTSTRAP_CODE"]);
    expect(result.duplicates).toEqual(["CONCILIUM_BOOTSTRAP_CODE"]);
    expect(result.unknown).toEqual(["SEGREDO_DESCONHECIDO"]);
  });
});
