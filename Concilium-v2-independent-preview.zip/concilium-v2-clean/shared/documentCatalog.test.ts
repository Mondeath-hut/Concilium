import { describe, expect, it } from "vitest";
import { buildDocumentCatalogPrompt, DOCUMENT_CATALOG_POLICY } from "./documentCatalog";

describe("catalogação segura de documentos", () => {
  it("mantém documento novo em quarentena e exige confirmação humana", () => {
    expect(DOCUMENT_CATALOG_POLICY.quarantine).toContain("quarentena");
    expect(DOCUMENT_CATALOG_POLICY.quarantine).toContain("confirmação do titular");
  });

  it("instrui a IA a separar fato documental de interpretação", () => {
    const prompt = buildDocumentCatalogPrompt({ title: "Comprovantes", documentType: "texto", sourceReference: "upload do titular", extractedText: "Pagamento realizado em data não confirmada." });
    expect(prompt).toContain("fato documental");
    expect(prompt).toContain("Não invente nomes");
    expect(prompt).toContain("Retorne somente JSON");
  });
});
