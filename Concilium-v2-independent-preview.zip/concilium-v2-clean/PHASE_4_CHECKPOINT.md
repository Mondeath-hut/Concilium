# Concilium — checkpoint da fase 4

## Avanço realizado
A visão geral do espaço protegido começou a usar o núcleo operacional da V1:

- `OwnerWorkspace` consulta `operationalCases.list`;
- criação de caso usa `operationalCases.create`;
- a criação é vinculada à identidade operacional do titular;
- o overview usa `operationalCases.overview`;
- as seis estratégias da V1 são preparadas no caso;
- o primeiro cenário é liberado conforme a regra operacional;
- os casos são apresentados dentro do espaço autenticado da V2.

## Segurança preservada
- a consulta exige `ownerOperationalProcedure`;
- a sessão titular V2 é obrigatória;
- o vínculo operacional é individual;
- não há fallback para consulta administrativa global.

## Limitação deliberada desta fatia
Estratégias avançadas, negociação, documentos e Comitê de IA ainda possuem pontos da V2 que consultam o modelo `owner*`. Eles serão migrados gradualmente para o mesmo núcleo V1, evitando misturar fontes de dados ou criar registros duplicados.

## Próximo marco
Migrar o primeiro módulo de documentos/propostas e criar teste de isolamento entre titulares antes de conectar as demais ações.
