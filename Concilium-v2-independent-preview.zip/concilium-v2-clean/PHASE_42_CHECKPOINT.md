# Concilium — checkpoint da fase 42

## Distinção formal entre Estrategista, Laboratório e Arena

Foi consolidado que “Laboratório” não significa a Arena de IA.

### Estrategista
Figura central que recebe o contexto integral autorizado, coordena a exploração, mantém a continuidade e pode abrir linhas não mencionadas inicialmente.

### Laboratório de Alternativas
Área de desenvolvimento divergente do Estrategista. As IAs ampliam possibilidades e formulam linhas independentes. Não atuam como advogado do diabo nem tentam anular alternativas prematuramente.

### Arena de IA
Etapa posterior de estresse adversarial. Recebe o contexto estratégico amplo e o contexto original necessário ao supervisor. Defesa, acusação/advogado do diabo e mediador testam fragilidades, fontes, riscos e condições até uma síntese robusta.

## Novas perspectivas iniciais
As linhas da exploração foram ampliadas para incluir:

- familiar e necessidade;
- autonomia econômica e vulnerabilidade;
- patrimonial e despesas;
- probatória e formalização;
- negocial e processual.

Isso permite que questões como trabalho, idade, tempo fora do mercado e situação de vulnerabilidade apareçam mesmo quando não foram levantadas na pergunta inicial.

## Arena
O papel `critical_auditor` passou a ser apresentado como `Acusação / advogado do diabo`, preservando o schema existente e a função de procurar fragilidades sem bloquear teses lícitas por reprovação moral.

## Arquivo

- `STRATEGIST_LAB_VS_ARENA.md`.

## Estado
Distinção conceitual, prompts, perspectivas e interface atualizados. Execução real continua pendente de build, banco e provedores.
