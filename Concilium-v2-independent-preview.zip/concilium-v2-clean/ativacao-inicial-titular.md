# Ativação inicial da conta titular

**Status:** fundação técnica implementada; controles de produção pendentes de validação complementar.  
**Escopo:** cria uma conta titular própria do Concilium sem reutilizar Google, Facebook, Microsoft, sessão de outro projeto ou o atual portal de autenticação compartilhado.

## Situação da implementação em 20 de agosto de 2026

A primeira versão operacional já usa passkey como acesso rotineiro, TOTP apenas como contingência e recuperação, códigos de recuperação de uso único, cookie de sessão próprio e auditoria. O código de bootstrap fica aposentado logicamente ao concluir a ativação; em seguida, o administrador também deve substituir ou remover `CONCILIUM_BOOTSTRAP_CODE` das configurações seguras do projeto. Nenhum segredo deve ser enviado por mensagens, incluído em URL, salvo em documento ou registrado em analytics.

As tentativas de código inicial, TOTP de contingência e códigos de recuperação recebem limitação persistente. Depois de cinco falhas no mesmo escopo técnico, o fluxo correspondente fica bloqueado por quinze minutos. Para reduzir a coleta de dados, esse controle armazena apenas um identificador derivado por hash — nunca o endereço IP bruto, e-mail, TOTP ou código de recuperação.

## Decisão recomendada

O primeiro titular deve entrar por uma **cerimônia única de ativação**, e não por um botão de login convencional. A ativação estabelece a raiz de confiança do ambiente: cria a conta titular, registra o primeiro conjunto de credenciais fortes, define recuperação e bloqueia qualquer convite até a conclusão desse processo.

O código de ativação deve ser gerado uma única vez pelo proprietário no painel administrativo do projeto e exibido apenas naquele momento. O titular o digita em uma página exclusiva, como `/ativar-titular`; o servidor armazena somente seu hash, impõe validade curta — por exemplo, 15 minutos — e o invalida após a primeira utilização. O código não deve aparecer em URL, e-mail de rastreamento, log ou analytics.

> A primeira ativação não é um convite de participante. Ela é o ato administrativo controlado que cria a conta proprietária do ambiente.

| Etapa | Ação do titular | Validação do servidor | Resultado |
|---|---|---|---|
| 1. Iniciar ativação | Informa o código de ativação único. | Confere hash, validade, uso único, limite de tentativas e origem. | Abre uma sessão restrita de configuração. |
| 2. Vincular identidade | Informa nome e e-mail institucional; confirma o e-mail por código ou link de uso único. | Verifica o desafio de e-mail e reserva o identificador para a conta titular. | Cria a conta em estado `setup_pending`. |
| 3. Registrar passkey | Autoriza a criação da passkey no aparelho. | Valida desafio WebAuthn, origem e chave pública vinculada ao domínio do Concilium. | Cria o autenticador principal. |
| 4. Preparar contingência | Cadastra TOTP e recebe códigos de recuperação de uso único. | Guarda segredo TOTP cifrado e hashes dos códigos; confirma a geração. | Define fatores de recuperação. |
| 5. Confirmar proteção | Reautentica com a passkey recém-criada e confirma a guarda dos códigos. | Registra o evento e exige todos os controles mínimos. | Conta muda para `active`; área interna é liberada. |

## Como evitar que o primeiro acesso fique limitado à página institucional

Após completar a cerimônia, o titular passa a acessar uma rota interna própria, por exemplo, `/app`. A rota pública permanece em `/`; a rota interna só aceita uma sessão emitida pelo backend do Concilium após uma autenticação bem-sucedida pela passkey ou, quando necessário, pelo fluxo de TOTP. Dessa forma, o titular não depende de uma conta Google previamente escolhida no navegador, nem de qualquer login mantido por outro projeto.

A primeira tela interna pode ser um **Painel do titular**, inicialmente enxuto: status de segurança, passkeys cadastradas, TOTP de contingência, códigos de recuperação, trilha de auditoria e o botão para criar o primeiro caso. A emissão de convites deve permanecer bloqueada enquanto a conta estiver em `setup_pending` ou enquanto não houver passkey e recuperação configuradas.

| Estado da conta | Pode entrar em `/app` | Pode criar caso | Pode convidar participantes |
|---|---:|---:|---:|
| `not_initialized` | Não | Não | Não |
| `setup_pending` | Apenas no assistente de ativação | Não | Não |
| `active` | Sim, com autenticação forte | Sim | Sim, após reautenticação recente |
| `recovery_hold` | Somente em recuperação controlada | Não | Não |
| `suspended` | Não | Não | Não |

## Autenticação e recuperação

A **passkey** deve ser o método padrão. O WebAuthn cria uma credencial de chave pública por consentimento do usuário e a restringe ao domínio da aplicação, evitando que uma credencial do Concilium seja reutilizada por outro site. [1] O TOTP é o fator de contingência, não o substituto diário da passkey. O titular também recebe códigos de recuperação de uso único, exibidos uma única vez, para guardar fora do aparelho.

Uma recuperação não deve liberar diretamente a área de casos. Ela deve colocar a conta em `recovery_hold`, notificar o e-mail confirmado, registrar auditoria e exigir reautenticação reforçada antes de adicionar ou trocar fatores. OWASP recomenda tratar a troca de fatores como ação de alto risco, exigir reautenticação com fator existente quando possível e notificar mudanças por canal externo. [2] Para a conta titular, a recuperação sem fatores disponíveis deve exigir validação administrativa documentada e um período de espera antes da reativação; SMS pode permanecer apenas como último recurso, nunca como login comum.

O desenho adota autenticação equivalente a **AAL2** como mínimo operacional para a área com dados jurídicos sensíveis: dois fatores distintos quando a política exigir, com opção resistente a phishing. O NIST define AAL2 como exigindo prova de posse e controle de dois fatores distintos e requer uma opção resistente a phishing. [3] A passkey atende especialmente bem a essa direção por seu uso de criptografia de chave pública; o produto ainda deve realizar sua própria análise de risco e de LGPD antes da ativação em produção.

## Controles técnicos mínimos

| Controle | Regra de implementação |
|---|---|
| Segredo de ativação | Gerar com fonte criptograficamente segura; guardar hash com `expires_at`, `used_at`, contador de falhas e escopo exclusivo `initial_owner`. |
| Conta titular | Só pode haver uma enquanto o ambiente estiver em modo inicial; o papel `owner` não é concedido por convite comum. |
| Sessão de configuração | Curta, sem acesso a casos, cookies `HttpOnly`, `Secure` e `SameSite`; invalidada após inatividade ou conclusão. |
| Passkey | Usar desafio de uso único, validar `rpId` e origem do domínio publicado, pedir verificação de usuário e guardar apenas a chave pública/metadados necessários. |
| TOTP | Cifrar o segredo em repouso, nunca registrar códigos nos logs e limitar tentativas. |
| Recuperação | Códigos de uso único com hash; recuperação de alto risco suspende convites e alterações críticas até validação final. |
| Auditoria | Registrar criação do código, tentativas, confirmação de e-mail, registro/remoção de fatores, recuperação e ativação; nunca registrar segredos, TOTP, OTP ou códigos de recuperação. |
| Convites | Exigir conta `active`, passkey e reautenticação recente do titular antes de criar ou revogar convites. |

## O que será necessário para implementar

A implementação precisa acrescentar um módulo próprio de identidade ao backend — tabelas de contas, credenciais WebAuthn, TOTP, códigos de recuperação, sessões e auditoria — além de um serviço de envio de e-mail transacional para a confirmação do titular. A conta atual do administrador do projeto pode gerar o código de ativação, mas não deve ser usada como identidade da conta titular do Concilium. Essa separação é justamente o que evita o conflito de conta visto na versão anterior.

O projeto agora inclui a fundação do assistente `/activate`, a rota interna `/app`, sessões próprias, registro de passkey, configuração de TOTP de contingência e códigos de recuperação. A ativação real continua dependente do código secreto definido pelo administrador e da conclusão das cerimônias no navegador. Antes de uso com dados reais, permanecem obrigatórios: confirmação verificável da posse do e-mail por provedor transacional, expiração e uso único persistentes para o código inicial, limitação persistente de tentativas, auditoria integral e revisão de privacidade.

## Validação de implementação — 20 de agosto de 2026

O endpoint interno reconheceu o código de bootstrap e a chave de cifragem de MFA sem revelar seus valores; o teste dedicado passou. As rotas móveis `/activate` e `/app` foram renderizadas: a primeira apresenta uma identidade própria do Concilium e a segunda recusa sessões ausentes, exigindo a confirmação da passkey. Nenhuma das duas inicia OAuth externo.

## Referências

[1]: https://www.w3.org/TR/webauthn-3/ "W3C — Web Authentication: An API for accessing Public Key Credentials"
[2]: https://cheatsheetseries.owasp.org/cheatsheets/Multifactor_Authentication_Cheat_Sheet.html "OWASP — Multifactor Authentication Cheat Sheet"
[3]: https://pages.nist.gov/800-63-4/sp800-63b.html "NIST SP 800-63B — Digital Authentication Guidelines"
