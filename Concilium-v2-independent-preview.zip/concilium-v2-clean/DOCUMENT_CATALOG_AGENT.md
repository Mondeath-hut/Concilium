# Agente de catalogação documental

## Proposta
Documentos novos não devem cair diretamente em um cofre definitivo. O fluxo recomendado é:

```text
Recebimento
   ↓
Quarentena
   ↓
Extração de texto/OCR e hash
   ↓
Agente catalogador
   ↓
Sugestão de cofre, sensibilidade e relações
   ↓
Confirmação do titular
   ↓
Cofre definitivo
```

## Cofres iniciais

- **Identidade:** documentos pessoais e dados de identificação;
- **Família:** casamento, filhos, convivência e relações familiares;
- **Patrimônio:** imóveis, terrenos, veículos e titularidade;
- **Renda e despesas:** holerites, contas, dívidas e comprovantes;
- **Jurídico/processual:** decisões, processos, petições e notificações;
- **Acordos e estratégias:** propostas, minutas, cenários e sínteses;
- **Evidências:** comprovantes, mensagens, fotos e registros;
- **Comunicações:** correspondências e diálogos;
- **Pesquisa:** fontes e referências do Bibliotecário;
- **Quarentena:** entrada ainda não classificada;
- **Arquivo:** material fora do fluxo ativo, sem eliminação automática.

## O que o agente sugere

- cofre principal;
- sensibilidade;
- confiança;
- razões da classificação;
- fatos documentais extraídos;
- datas e cronologia;
- relevância jurídica possível;
- lacunas e pontos ilegíveis;
- duplicidade ou relação entre versões.

## O que ele não faz sozinho

- não confirma autenticidade;
- não transforma narrativa em fato provado;
- não decide relevância jurídica final;
- não move documento para cofre definitivo;
- não arquiva nem elimina;
- não compartilha identidade ou dados de terceiros;
- não envia o documento a outras IAs sem autorização de escopo.

## Identidade dela

A identidade pode ser cadastrada diretamente na aplicação, em documento ou registro protegido do cofre de Identidade. O catalogador pode reconhecer que um documento contém identificação e sugerir esse cofre, mas a confirmação e qualquer vinculação nominal continuam sob controle do titular.

## Ensemble possível

A catalogação pode usar funções independentes:

1. classificador documental;
2. extrator de fatos e cronologia;
3. leitor de relevância jurídica;
4. guardião de privacidade;
5. verificador de duplicidade e versões.

A consolidação usa sugestões e trechos localizáveis, preservando divergências. Uma IA não pode transformar a concordância das outras em autenticação do documento.

## Implementação inicial

- contrato em `shared/documentCatalog.ts`;
- política de quarentena;
- prompt estruturado do catalogador;
- campos de catálogo na tabela de documentos;
- migração `0027_document_catalog_quarantine.sql`;
- testes unitários de proteção e separação entre fato e interpretação.

A execução real do agente depende de extração de texto/OCR, armazenamento e provedor de IA conectados. O agente deve ser ativado por documento e por escopo, não como uma IA com acesso indiscriminado ao caso inteiro.
