# Concilium — checkpoint da fase 50

## Plano de roteamento e confirmação
Foi implementado o plano que intermedeia o manifesto e o armazenamento seguro.

### Estados

- `proposed`: mapeamento sugerido, aguardando confirmação;
- `approved`: mapeamento confirmado e elegível para armazenamento;
- `blocked`: nome desconhecido, não confirmado ou sem contrato suficiente.

### Regras

- nenhum segredo é recebido pela função;
- nenhum mapeamento é aprovado pelo nome sozinho;
- nomes desconhecidos são bloqueados;
- entradas não confirmadas são bloqueadas;
- Chave Mestre e Chave de Cifragem continuam bloqueadas até definição de finalidade, escopo, algoritmo e rotação;
- somente nomes aprovados podem seguir para a próxima etapa.

## Arquivos

- `shared/secretRouting.ts`;
- `shared/secretRouting.test.ts`;
- `SECURE_SECRET_INTAKE.md`.

## Estado
Manifesto, validação de nomes e plano de roteamento estão preparados. A gravação no cofre ainda não foi ativada; depende do descriptografador em memória e do backend de armazenamento cifrado.
