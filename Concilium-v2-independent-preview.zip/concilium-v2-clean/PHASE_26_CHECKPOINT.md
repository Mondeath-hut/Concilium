# Concilium — checkpoint da fase 26

## Retorno Bibliotecário → Estratégia
O ciclo bidirecional foi fechado no modelo de dados e no fluxo da interface.

### Preparado
- solicitações de pesquisa derivadas da Arena podem conservar a avaliação de origem;
- estratégia manual associada permanece vinculada;
- o resultado da pesquisa é salvo como snapshot da solicitação;
- a solicitação muda para `answered` somente após retorno registrado;
- a interface identifica quando o resultado retornou à estratégia;
- o titular pode usar a solicitação na Biblioteca sem perder o vínculo de origem;
- a estratégia triada pode voltar ao Laboratório ou seguir para a Arena.

### Fluxo

```text
Estratégia / Arena
       ↓
Solicitação ao Bibliotecário
       ↓
Busca atual com fontes e validade
       ↓
Snapshot dos resultados
       ↓
Retorno à mesma estratégia/avaliação
       ↓
Nova formulação ou Arena
```

## Persistência
- `sourceAssessmentId` e `strategyId` em solicitações;
- `resultSnapshotJson` e `answeredAt`;
- `drizzle/0021_research_strategy_return.sql`;
- rota protegida `answerResearchRequest`.

## Estado de validação
Código e migração foram preparados, mas ainda não foram executados com dependências, banco, Knowledge Service ou fontes reais. Build, testes e migrações continuam pendentes.
