# Concilium — checkpoint da fase 9

## Biblioteca expansível separada
Foi definida e iniciada a separação entre o aplicativo de casos e o acervo jurídico geral.

### Concilium
Continua responsável por identidade, casos, documentos, negociação, auditoria, consentimentos e Arena.

### Knowledge Service
Fica responsável por acervo jurídico versionado, taxonomia por área, fontes, vigência, busca lexical/semântica e relações entre assuntos.

Foram criados:

- contrato compartilhado de busca e resultado;
- cliente HTTP com timeout e validação de resposta;
- router protegido `knowledge.search` dentro do Concilium;
- auditoria de consulta;
- sanitização de identificadores antes do envio ao serviço;
- interface inicial do Bibliotecário Jurídico na Biblioteca;
- schema PostgreSQL inicial para fontes, entradas, trechos e relações;
- documento de arquitetura e limites do serviço.

## Privacidade
A busca padrão envia somente a pergunta e os filtros. Se o titular escrever nomes, contatos, valores ou endereços, a camada do Concilium minimiza esses identificadores, preservando o contexto jurídico necessário.

O acervo não recebe automaticamente documentos do caso, minutas ou anexos.

## Estado atual
A interface já está preparada para consultar o serviço, mas ele ainda não está conectado por ambiente. Enquanto `CONCILIUM_KNOWLEDGE_URL` não existir, a aplicação informa que a biblioteca externa ainda não foi conectada e não tenta enviar dados.

## Próximo marco
Criar o bibliotecário interpretativo, que transforme a situação narrada em intenção de busca, áreas e assuntos relacionados, e permitir salvar uma referência aprovada no caso sem copiar o acervo inteiro.
