# Concilium — checkpoint da fase 61

## Interface de criação da exploração derivada

A caixa de ramificações agora permite continuar o fluxo depois da submissão.

### Fluxo visual

1. selecionar ramificações;
2. compor pergunta;
3. revisar;
4. submeter ao Estrategista;
5. informar título da nova exploração;
6. informar objetivo da nova pulverização;
7. criar unidade derivada.

### Garantias

- formulário só aparece depois de `submitted`;
- a nova unidade recebe linhagem da exploração anterior;
- exploração original permanece inalterada;
- a nova pulverização ainda não começa automaticamente;
- o titular mantém controle sobre título e objetivo;
- erro ou abandono não modifica a exploração original.

## Arquivos

- `client/src/components/StrategyBranchInbox.tsx`;
- `PHASE_61_CHECKPOINT.md`.

## Estado
A criação visual da exploração derivada está pronta. A etapa seguinte é executar a nova coordenação do Estrategista e gerar suas linhas independentes usando a pergunta aprovada como novo ponto de partida.
