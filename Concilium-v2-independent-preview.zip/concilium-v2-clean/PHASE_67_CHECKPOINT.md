# Concilium — checkpoint da fase 67

## Ensemble executável do Bibliotecário

Foi preparada a execução independente dos papéis do Bibliotecário, sem depender diretamente do Knowledge Service.

### Funcionamento

- cada papel recebe a mesma consulta neutra;
- papéis executam em paralelo;
- falha de um papel não apaga os resultados dos demais;
- fontes repetidas são deduplicadas por identificador;
- o pacote final preserva o modo de pesquisa e as limitações;
- o relatório de papéis mostra apenas estado e IDs de resultados.

### Garantias

- não recebe o caso protegido por padrão;
- não escolhe estratégia;
- não transforma ausência de resultado em ausência de fundamento;
- mantém material não normativo separado;
- exige verificação de vigência, autoridade, citação e jurisdição.

## Arquivos

- `shared/librarianEnsemble.ts`;
- `shared/librarianEnsemble.test.ts`;
- `PHASE_67_CHECKPOINT.md`.

## Estado

O contrato executável está preparado. A conexão com o Knowledge Service real continua sendo adaptação futura de infraestrutura.
