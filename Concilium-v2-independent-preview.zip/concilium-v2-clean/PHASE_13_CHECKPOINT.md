# Concilium — checkpoint da fase 13

## Laboratório de Alternativas
Foi criado um terceiro modo, separado do Bibliotecário e da Arena:

- fica dentro de Estratégias;
- recebe uma pergunta/objetivo estratégico e contexto autorizado;
- consulta de 2 a 5 modelos;
- atribui perspectivas diferentes;
- executa respostas independentes, sem mostrar uma resposta para outra;
- registra ideias, premissas, riscos e fontes que precisam ser verificadas;
- aceita soluções semelhantes, complementares ou divergentes;
- não testa, aprova ou trata nenhuma ideia como decisão.

## Divisão de responsabilidades

| Área | Função |
|---|---|
| Bibliotecário | recuperar fontes atuais, citações e assuntos relacionados |
| Estratégias / Laboratório de Alternativas | ampliar o espaço de soluções |
| Arena | confrontar, testar, estressar e refinar alternativas |

## Caminho efetivo
Uma ideia pode ser selecionada no Laboratório e levada à Arena. A Arena abre em página própria e preenche o material inicial, mas exige nova autorização antes de consultar os modelos.

## Persistência
Foram criadas tabelas separadas para:

- explorações;
- ideias por modelo e perspectiva;
- premissas;
- riscos;
- necessidades de fonte;
- estado da ideia (`generated`, `selected_for_arena`, `discarded`).

## Exemplo de uso
A pergunta “como encerrar o relacionamento sem vender imediatamente a casa, ganhando tempo para recomprar a parte da outra pessoa?” pode gerar alternativas patrimoniais, temporais, negociais, processuais e criativas. Essas alternativas não são aceitas automaticamente: primeiro ampliam o campo de análise, depois passam pelo Bibliotecário e pela Arena.
