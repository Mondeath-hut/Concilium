# Concilium — checkpoint da fase 47

## Tela de preparação do cofre
Foi criada a primeira tela visual do wizard de ingestão segura, integrada às Configurações.

### A tela permite

- selecionar o arquivo criptografado;
- informar a senha em campo protegido;
- visualizar apenas nome e tamanho do arquivo;
- confirmar que o pacote contém segredos próprios;
- consultar o manifesto sem valores.

### Limite deliberado

O botão desta fase apenas prepara o fluxo e limpa a senha da tela. A descriptografia do 7z, validação do conteúdo e gravação no cofre ainda não foram ativadas. Isso evita receber uma senha sem um pipeline completo de limpeza, validação, logs seguros e armazenamento cifrado.

## Arquivos

- `client/src/components/SecretIntakePanel.tsx`;
- integração em `client/src/pages/OwnerWorkspace.tsx`;
- `PHASE_47_CHECKPOINT.md`.

## Estado
Tela de preparação disponível. Pipeline operacional do 7z permanece bloqueado até validar a biblioteca de descriptografia e o cofre de segredos.
