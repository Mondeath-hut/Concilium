# Concilium — descrição funcional para integração

## Visão geral

O Concilium é uma aplicação de organização protegida de casos, documentos, estratégias, pesquisa e deliberação humana. A IA apoia triagem, expansão, crítica e síntese, mas não substitui o titular, não autentica documentos e não decide juridicamente.

## Fluxo principal

1. O titular registra o caso e separa fatos narrados, hipóteses, propostas, fontes, respostas de IA e decisões humanas.
2. Documentos entram em Quarentena e recebem catalogação sugerida.
3. A área de Estratégias organiza objetivos, restrições, riscos e alternativas.
4. O Estrategista faz triagem, identifica eixos e distribui pautas.
5. O Laboratório de Alternativas expande possibilidades em linhas independentes.
6. A Arena confronta fragilidades com defesa, acusação/advogado do diabo e mediação.
7. O supervisor intervém, compara rodadas e homologa sínteses.
8. A decisão humana escolhe o que será utilizado.

## Documentos sensíveis

A aplicação não deve bloquear um documento apenas por ser sensível. O tratamento correto é quarentena, minimização, cifragem, projeção de acesso e confirmação humana. A classificação é sugestão operacional, não prova de autenticidade ou relevância definitiva.

## Separação de acesso

O supervisor e o Estrategista podem ter acesso integral autorizado. As IAs derivadas recebem projeções protegidas de acordo com a função e a rodada. O Bibliotecário pesquisa fontes com pacote neutro e não recebe o caso integral por padrão.

## Pesquisa jurídica

Toda fonte precisa carregar jurisdição, autoridade, vigência, data de verificação, identificador/URL, localizador, limitações e contrapontos. Material obsoleto, fora da jurisdição ou não verificável deve ser marcado como tal.

## Segurança

Segredos devem ficar no secret manager/cofre. Senhas, tokens e chaves não devem aparecer no chat, logs, relatórios, prompts ou documentos de integração. O contexto original é cifrado em repouso.

## Publicação

Antes de publicar, validar banco, migrações, autenticação, armazenamento, provedores, limites de upload, OCR, filas, auditoria, backup, rollback e política de privacidade. A publicação não deve ser considerada pronta enquanto build, testes e banco real não tiverem sido comprovados.
