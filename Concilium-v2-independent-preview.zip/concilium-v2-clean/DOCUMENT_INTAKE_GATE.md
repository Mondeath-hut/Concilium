# Gate de entrada de documentos reais

Antes de qualquer importação, upload ou processamento de documentos reais do caso, o fluxo deve parar e avisar Augusto.

## Procedimento reservado

1. Confirmar que a aplicação está pronta para armazenamento protegido.
2. Avisar Augusto que a etapa de documentos foi alcançada.
3. Augusto prepara o pacote criptografado no 7-Zip/7z, conforme o procedimento combinado.
4. A senha do pacote criptografado permanece exclusivamente com Augusto.
5. Nenhuma senha, chave, token ou dado real deve ser enviado no chat.
6. A importação só ocorre após autorização específica e confirmação do destino seguro.
7. Registrar apenas metadados mínimos, hash e status de revisão, sem expor o conteúdo no ZIP público.

Até esse gate, usar exclusivamente dados simulados, arquitetura, contratos, testes e documentos fictícios.
