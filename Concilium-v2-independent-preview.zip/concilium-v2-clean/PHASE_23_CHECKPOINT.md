# Concilium — checkpoint da fase 23

## Ligação persistente entre Estratégia e Arena
A triagem de argumentos agora tem contrato e armazenamento preparados para conservar a origem da linha:

- estratégia manual;
- exploração do Laboratório;
- alternativa individual;
- thread da alternativa;
- rodada da Arena;
- execução específica de modelo;
- versão anterior da avaliação.

## Fluxos preparados

```text
Estratégia manual → triagem de argumento → fontes/alertas → Arena
Linha do Laboratório → triagem de argumento → Arena
Rodada da Arena → avaliação de argumento → decisão humana
```

A interface de Estratégias permite registrar uma estratégia na triagem inicial. A seleção de uma alternativa do Laboratório para a Arena também cria uma avaliação vinculada à linha de origem. A interface do Comitê exibe as avaliações ligadas ao caso e à rodada.

## Persistência
- `shared/argumentTriage.ts`: estados, contrato e regras de entrada na estratégia ativa;
- `drizzle/schema.ts`: tabela `ownerCaseArgumentAssessments`;
- `drizzle/0019_argument_triage.sql`: migração correspondente;
- `server/db.ts`: criação, listagem e decisão humana;
- `server/routers/ownerWorkspace.ts`: rotas protegidas de triagem e decisão;
- `client/src/pages/OwnerWorkspace.tsx`: pontos de entrada e visualização.

## Estado de validação
A ligação foi implementada no código, mas ainda não foi executada com dependências, banco ou migração real. O build, os testes e a aplicação de `0019_argument_triage.sql` continuam pendentes.
