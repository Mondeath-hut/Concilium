# Concilium — checkpoint da fase 11

## A consulta agora gera ação
A pesquisa do Bibliotecário deixou de ser um ponto final. Cada resultado pode seguir um fluxo explícito:

- salvar snapshot como referência no caso;
- adicionar uma base não aprovada ao compêndio de cláusulas;
- preparar a referência para refinamento na Arena.

A referência salva mantém fonte, versão, país, jurisdição, autoridade, validade, data de verificação, substituição e citações. O Knowledge Service continua sendo a fonte do acervo; o caso guarda apenas o snapshot auditável necessário.

## Compêndio
O compêndio de cláusulas é tratado como área de trabalho:

- recebe rascunhos derivados de referências;
- começa com status `saved`;
- não é confundido com cláusula aprovada;
- não gera proposta ou acordo automaticamente;
- pode ser levado à Arena para estresse, crítica e refinamento.

## Integração com a Arena
Foi criado o caminho `Refinar na Arena`:

1. salva a referência no caso;
2. marca o item como preparado para a Arena;
3. abre uma nova página da Arena;
4. carrega o snapshot e o rascunho como material inicial;
5. exige nova autorização do titular antes do envio às IAs.

## Limites preservados
- nenhuma pesquisa envia o acervo inteiro ao Concilium;
- nenhuma referência obsoleta é tratada como fundamento atual;
- nenhuma cláusula vira decisão ou acordo sem revisão humana;
- dados sensíveis do caso não são enviados ao Knowledge Service por padrão.
