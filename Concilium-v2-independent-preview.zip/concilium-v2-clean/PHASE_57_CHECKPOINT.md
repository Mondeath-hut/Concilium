# Concilium — checkpoint da fase 57

## Ramificações dinâmicas estacionadas

Foi implementado o modelo para questões laterais descobertas por várias IAs sem contaminar a linha estrutural original.

### Funcionamento

- cada IA pode propor uma nova questão lateral;
- a proposta permanece vinculada à linha, pergunta e mensagem de origem;
- propostas de linhas diferentes podem compor um pacote;
- o pacote gera uma pergunta preliminar para o Estrategista;
- o pacote fica `ready_for_strategist` e não é enviado automaticamente;
- depois da revisão, pode ser marcado como `submitted`;
- o Estrategista pode reformular, separar, descartar ou iniciar nova pulverização.

### Garantias

- a linha de origem permanece intacta;
- históricos não são fundidos;
- a síntese anterior não é alterada;
- nenhuma ramificação vira fato provado;
- a nova exploração será comparável e derivada, não uma continuação contaminada.

## Arquivos

- `shared/dynamicBranching.ts`;
- `shared/dynamicBranching.test.ts`;
- `DYNAMIC_BRANCHING_PROTOCOL.md`.

## Estado
Modelo e composição de perguntas implementados. Persistência em banco e interface de revisão/submissão ficam preparadas para a próxima integração do fluxo de exploração.
