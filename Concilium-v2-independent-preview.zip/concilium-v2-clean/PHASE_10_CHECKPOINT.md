# Concilium — checkpoint da fase 10

## Triagem de validade e autoridade
A biblioteca e a Arena passaram a tratar a referência jurídica como dado estruturado, não como texto solto.

Cada resultado deve carregar:

- país;
- jurisdição/competência;
- área do Direito;
- nível de autoridade;
- fonte e URL, quando houver;
- versão;
- data de vigência ou referência;
- estado de validade;
- data da última verificação;
- relação de substituição/superação;
- citações e localizadores;
- indicação de citação verificada ou pendente.

## Regra de uso atual
Com `requireCurrent` ativo — padrão do contrato — o cliente não apresenta como fundamento principal material:

- revogado;
- superado;
- expirado;
- pendente de verificação;
- pertencente a outro país;
- fora da jurisdição solicitada.

O material histórico pode continuar armazenado no Knowledge Service, mas fica separado da resposta atual.

## Arena
As instruções do supervisor e das IAs agora exigem:

- fonte/citação para afirmações jurídicas específicas;
- país e jurisdição;
- verificação de vigência;
- identificação de revogação, superação ou substituição;
- marcação explícita de confirmação pendente.

## Interface
Os resultados do Bibliotecário exibem fonte, versão, jurisdição, autoridade, status de validade, data de verificação e estado de cada citação.

## Limite atual
A checagem efetiva depende da ingestão correta e atualizada do Knowledge Service. O Concilium já bloqueia resultados incompatíveis no contrato, mas o acervo ainda precisa de pipeline editorial, fontes confiáveis e revisão periódica.
