# Concilium — checkpoint da fase 70

## Catalogação documental por ensemble

A rota `catalogDocument` passou a executar os papéis especializados em paralelo.

### Funcionamento

- utiliza o modelo selecionado pelo titular para cada papel;
- cada papel recebe a mesma extração autorizada, com instrução independente;
- sugestões são preservadas em `catalogNotes`;
- falhas parciais ficam registradas;
- classificação unânime continua exigindo revisão humana;
- divergência força sugestão conservadora em Quarentena;
- sensibilidade máxima entre as sugestões é preservada quando houver divergência;
- documento permanece em `needs_owner_review`.

### Garantias

Nenhuma análise move, arquiva, exclui, confirma autenticidade ou transforma conteúdo em prova. A resposta mantém o formato anterior de `suggestion`, acrescentando o histórico interno do ensemble nas notas protegidas.

## Estado

A rota real de catalogação está conectada ao ensemble. A validação executável ainda depende de modelos e ambiente disponíveis.
