# Concilium — checkpoint da fase 21

## Fluxo bidirecional registrado
A arquitetura agora trata o histórico recebido como material de formulação e refinamento, não como decisão final. Estratégias antigas e propostas aparentemente consolidadas podem retornar ao Bibliotecário para nova validação e depois seguir para a Arena.

## Caminhos aceitos

```text
Estratégia → Bibliotecário → Arena → decisão humana
Bibliotecário → Estratégia → Arena → decisão humana
Histórico → Cenário → Estratégia/Bibliotecário → Arena
Arena → Bibliotecário, Compêndio, Estratégia ou Arquivo
```

## Regras

- nenhuma resposta de IA ou cláusula antiga é fundamento vigente sem fonte atual verificável;
- nenhuma proposta importada do histórico é tratada como homologada;
- versões inicial, intermediária e refinada devem permanecer preservadas;
- o titular decide qual formulação utilizar depois do refinamento;
- fontes obsoletas, contraditórias ou de jurisdição inadequada geram pendência, não aprovação;
- a Arena confronta e sintetiza, mas não escolhe automaticamente a alternativa vencedora.

## Artefato relacionado
`REFINEMENT_FLOW.md` descreve o fluxo e os estados recomendados para a próxima implementação de rastreabilidade entre cenários, estratégias, referências, rodadas e versões.

## Ajuste de arquitetura
O Estrategista terá triagem de evidências incorporada desde a origem. Não será necessário encaminhar toda estratégia ao Bibliotecário antes de continuar. A estratégia poderá consultar o contrato de conhecimento e apresentar, por linha, o grau de suporte, a jurisdição, a vigência, a citação, os riscos e as lacunas.

O Bibliotecário continuará disponível como serviço especializado de pesquisa profunda, atualização editorial, validação de fontes difíceis e revisão de resultados controversos. Portanto, o fluxo passa a ser bidirecional e opcional, não uma fila obrigatória.

A barreira será graduada: fundamento atual confirmado; possível/controvertido; não verificado; fora de jurisdição; incompatível com fonte atual; obsoleto ou rejeitado. Itens bloqueados não entram como fundamento ativo, mas podem ser enviados explicitamente à Arena como hipótese de crítica ou pesquisa, sempre com alerta.

## Próxima implementação
Criar o vínculo persistente entre uma estratégia/cenário e seu pacote de evidências, permitindo que o Estrategista consulte fontes e registre cada classificação na própria linha. O Bibliotecário poderá receber uma solicitação opcional a partir dessa linha, e os resultados retornarão ao mesmo contexto antes de enviá-lo à Arena.
