# Concilium — especificação do Checklist Dinâmico administrado pelo Estrategista

## Objetivo

Antes da publicação, incorporar ao Concilium uma Mesa de Negociação dinâmica. Ela transforma cenários e estratégias aprovados pelo titular em checklists operacionais para uso durante uma audiência ou negociação ao vivo.

A função não substitui a Arena, o Laboratório de Alternativas, o Bibliotecário ou a área de estratégias. Ela é uma camada de execução e acompanhamento.

## Regra de preservação

- Não reescrever a arquitetura existente.
- Não substituir a autenticação própria do Concilium.
- Não introduzir OAuth ou login da plataforma.
- Não remover Arena, Laboratório, Bibliotecário, documentos, cofre, quarentena, auditoria ou linhagem.
- O Estrategista pode sugerir, ordenar, calcular e alertar; somente o titular pode aprovar, apresentar, aceitar, recusar ou mudar de cenário.
- Nenhuma proposta deve ser enviada automaticamente a terceiros.

## Fluxo principal

```text
Estratégia interna aprovada pelo titular
→ Estrategista cria ou atualiza cenário
→ cenário gera checklist
→ titular revisa e autoriza apresentação
→ proposta é registrada como apresentada
→ resposta/contraproposta é registrada
→ Estrategista compara com os parâmetros
→ sugere manter, ajustar ou migrar de cenário
→ titular confirma a próxima ação
```

## Cenários progressivos

Permitir cenários ordenados e liberados pelo titular, por exemplo:

1. Cooperativo — transição com menor impacto para ambos.
2. Cooperativo protegido — acrescenta garantias e condições.
3. Equilibrado — distribui responsabilidades com menos concessões.
4. Defensivo — prioriza a proteção individual e os direitos patrimoniais.
5. Impasse — registra a posição final e alternativas formais.

Os nomes devem permanecer neutros. A mudança de cenário exige autorização explícita do titular e registra motivo, data e versão anterior.

## Checklist de cada cenário

Cada item deve conter:

- descrição;
- grupo: interesse do titular, pedido da outra parte, pergunta ou condição;
- tipo: negociável, inegociável/exige pausa ou pendente de prova;
- prioridade;
- situação: pendente, aceito, recusado, parcialmente aceito ou substituído;
- justificativa;
- documento ou fonte relacionada;
- risco jurídico e financeiro;
- condição para aceitação;
- resposta ou argumento de persuasão;
- observações feitas durante a audiência.

Permitir adicionar, editar, reordenar e excluir itens sem alterar versões já apresentadas.

## Parâmetros dinâmicos

O titular deve poder informar parâmetros do cenário, como:

- valor estimado da quota;
- entrada possível;
- capacidade mensal atual;
- capacidade mensal em cenário de novo emprego;
- renda durante seguro-desemprego;
- reserva mínima intocável;
- prazo mínimo;
- prazo preferencial;
- prazo máximo;
- correção monetária escolhida;
- custos do imóvel;
- compensação por uso exclusivo;
- condições de moradia;
- condições dependentes de emprego, financiamento ou venda.

O Estrategista deve comparar cada proposta com esses parâmetros.

## Alertas

### Verde — compatível

A proposta respeita os limites definidos e permanece executável no cenário conservador.

### Amarelo — condicional

A proposta só funciona se ocorrer evento ainda não confirmado, como contratação, financiamento, venda ou aumento de renda.

### Vermelho — incompatível

A proposta viola um ponto inegociável, exige prazo inferior ao mínimo, compromete a reserva ou cria risco elevado de inadimplemento.

O alerta é informativo. Nunca aceita ou recusa automaticamente.

## Exemplo de compra de quota

```text
Valor da quota: R$ X
Prazo mínimo: 4 anos
Prazo realista: 5 anos
Prazo máximo: 8 anos
Proposta recebida: 24 meses

Alerta: vermelho
Motivos:
- prazo inferior ao mínimo;
- capacidade de formação de recursos insuficiente;
- risco de venda ou financiamento forçado;
- necessidade de confirmar renda e liquidez.

Alternativas sugeridas:
- prazo de 4 a 8 anos;
- pagamento único ao final;
- compensação de uso registrada;
- correção monetária acordada;
- garantia e revisão formal.
```

## Argumentos de persuasão

Para cada alerta ou contraproposta, o Estrategista pode preparar argumentos baseados nos dados cadastrados, sempre separando fato, hipótese e fonte.

Exemplo:

> Um imóvel desse valor pode ter liquidez limitada. Anúncios comparáveis permanecem ativos por períodos longos, o que recomenda evitar venda urgente com desconto. Um prazo maior, com correção e garantia, pode preservar melhor o valor para os dois lados.

O sistema deve mostrar:

- argumento;
- evidência;
- fonte e data;
- força da evidência;
- possível objeção;
- resposta preparada;
- concessão possível;
- limite inegociável.

Não afirmar que uma venda forçada ocorrerá. Usar “risco de desconto por urgência” quando isso for a conclusão sustentada pelos dados.

## Mesa formal de negociação

Separar a análise interna do histórico efetivamente apresentado.

Registrar somente fatos da mesa:

- proposta apresentada;
- contraproposta recebida;
- autor;
- data e hora;
- termos objetivos;
- pontos aceitos;
- pontos recusados;
- pontos pendentes;
- versão anterior;
- próxima versão;
- status.

Uma proposta apresentada não pode ser alterada silenciosamente. Qualquer alteração cria nova versão.

Status possíveis:

```text
Rascunho interno
Apresentada
Recebida
Aceita
Recusada
Aceita parcialmente
Contraproposta recebida
Substituída
Encerrada
```

A interface deve mostrar a progressão:

```text
Proposta A → contraproposta A.1 → proposta B → contraproposta B.1
```

Não escrever que qualquer parte agiu de má-fé. Exibir somente os fatos, termos e consequências objetivas. A análise moral ou jurídica cabe ao usuário e às autoridades competentes.

## Índice comparativo

Mostrar, se houver dados suficientes:

- atendimento estimado dos interesses do titular;
- atendimento estimado dos interesses da outra parte;
- impacto patrimonial;
- segurança habitacional;
- risco financeiro;
- risco de execução;
- itens inegociáveis violados.

Nomear como “índice comparativo de atendimento dos interesses”, nunca como probabilidade de vitória ou resultado jurídico.

Mostrar os pesos utilizados e permitir revisão pelo titular. Se faltarem dados, mostrar “não calculado” em vez de inventar percentual.

## Auditoria e segurança

- Toda mudança de cenário deve registrar autor, horário e motivo.
- A apresentação de uma proposta exige confirmação do titular.
- Nenhum texto deve ser enviado automaticamente.
- Estratégias internas não devem aparecer no histórico compartilhável.
- O histórico formal deve ser exportável separadamente da análise interna.
- Documentos sensíveis continuam sujeitos a quarentena, revisão humana e controle do cofre.
- A aplicação deve funcionar mesmo sem Resend; e-mail e TOTP continuam recursos opcionais.

## Exportação e contingência

Permitir:

- impressão do cenário atual;
- exportação em PDF;
- exportação do histórico formal;
- exportação do checklist em JSON;
- cópia local para uso durante videoconferência.

A mesa deve continuar legível em notebook e não depender da navegação por múltiplas telas durante a audiência.

## Validação antes da publicação

Testar:

- criação e troca de cenários;
- autorização de mudança de cenário;
- inclusão e alteração de itens;
- alertas de prazo incompatível;
- separação titular/outra parte;
- versionamento de propostas;
- registro de contraproposta;
- índice comparativo com pesos explícitos;
- exportação PDF/JSON;
- ausência de envio automático;
- preservação da autenticação própria e das demais funções do Concilium.
