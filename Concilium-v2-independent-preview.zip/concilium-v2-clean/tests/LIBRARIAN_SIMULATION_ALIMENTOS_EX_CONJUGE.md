# Simulação integrada — Bibliotecário → Estrategista → Laboratório

> **Natureza:** simulação de fluxo. Os resultados abaixo não são uma pesquisa jurídica real, não constituem fonte, parecer ou conclusão sobre o caso. Itens sem fonte real aparecem como `SIMULADO / NÃO VERIFICADO`.

## 1. Pergunta original do titular

> Estou morando na mesma casa que minha ex-cônjuge e pagando as compras de supermercado do mês. Posso utilizar uma cláusula compensatória para substituir ou evitar o envio de dinheiro diretamente a ela?

## 2. Entrada do Bibliotecário

### Classificação

- modo: `strategy_handoff`;
- encaminhamento: Estrategista;
- curadoria de cláusulas: ativada;
- contexto integral do caso: não enviado;
- pergunta original: preservada para o encaminhamento;
- conclusão automática: proibida.

### Ampliação contextual da pesquisa

O Bibliotecário não pesquisa apenas “cláusula compensatória”. Ele abre os seguintes eixos:

1. alimentos entre ex-cônjuges e pressupostos de existência, necessidade e possibilidade;
2. formas de cumprimento: pagamento direto, prestação in natura, pagamento de despesas e fornecimento de bens;
3. diferença entre despesa doméstica, contribuição voluntária, liberalidade, adiantamento e cumprimento de obrigação;
4. compensação, abatimento, imputação ou substituição de prestações alimentares;
5. efeitos jurídicos da permanência dos ex-cônjuges na mesma residência;
6. despesas de supermercado, moradia, consumo e manutenção da casa;
7. necessidade de acordo escrito, reconhecimento, homologação ou decisão judicial;
8. prova de pagamentos, notas, transferências, finalidade e aceitação;
9. risco de inadimplemento, cobrança retroativa ou interpretação de que as compras não tinham finalidade alimentar;
10. cláusulas e minutas não normativas para documentar despesas e obrigações;
11. fontes contrárias, limites, entendimentos divergentes e alterações de vigência;
12. jurisdição, país, autoridade, versão, data de verificação e localizadores.

### Lista de consultas derivadas

```text
Q01: alimentos entre ex-cônjuges e formas juridicamente reconhecidas de cumprimento
Q02: prestação in natura e pagamento de despesas em obrigações alimentares
Q03: compensação ou abatimento de alimentos com despesas domésticas
Q04: coabitação de ex-cônjuges após separação e efeitos sobre alimentos
Q05: prova de compras e despesas como cumprimento de obrigação alimentar
Q06: acordo, homologação e cláusula de documentação de despesas
Q07: modelos não normativos de cláusulas sobre despesas, créditos e prestação in natura
Q08: fontes contrárias e limites para substituição de pagamento em dinheiro
```

## 3. Resposta simulada do Bibliotecário

### Pacote neutro

```json
{
  "status": "SIMULADO / NÃO VERIFICADO",
  "mode": "strategy_handoff",
  "notice": "A pesquisa não permite concluir que compras de supermercado substituem alimentos.",
  "foundations": [
    "normas e fontes oficiais sobre alimentos",
    "jurisprudência sobre formas de cumprimento",
    "fontes sobre prova e formalização",
    "modelos não normativos de cláusula"
  ],
  "contrary_points": [
    "despesa doméstica pode ser interpretada como contribuição voluntária",
    "pagamento sem finalidade documentada pode não ser imputado à obrigação",
    "acordo verbal pode ser insuficiente para afastar cobrança",
    "a existência de obrigação formal pode exigir alteração ou homologação"
  ],
  "not_concluded": [
    "não foi decidido se existe obrigação alimentar atual",
    "não foi decidido se compras podem ser abatidas ou compensadas",
    "não foi redigida cláusula personalizada",
    "não foi afirmado que o titular está dispensado de transferir dinheiro"
  ]
}
```

### Cartões de material simulados

| Item | Tipo | Tratamento | Limite |
|---|---|---|---|
| M01 | Fonte primária sobre alimentos | possível fundamento | exige leitura da fonte, vigência e adequação à situação |
| M02 | Jurisprudência sobre prestação in natura | exige verificação | decisão de outro caso não prova aplicação automática |
| M03 | Fonte sobre prova de despesas | possível fundamento | deve confirmar finalidade, período, valor e aceitação |
| M04 | Modelo de cláusula de despesas | modelo não normativo | não é norma nem texto pronto para assinatura |
| M05 | Entendimento contrário sobre compensação | fonte de limite | pode restringir abatimento ou substituição |

## 4. Encaminhamento ao Estrategista

### Pacote entregue

O Estrategista recebe:

- a pergunta original completa;
- o mapa de pesquisa;
- as oito consultas derivadas;
- o pacote neutro;
- os limites e pontos contrários;
- as perguntas que ainda precisam ser esclarecidas.

Ele não recebe uma resposta conclusiva do Bibliotecário. Recebe material suficiente para entender o âmago do pedido e coordenar a próxima exploração.

### Pauta simulada do Estrategista

```text
ÂMAGO:
O titular deseja saber se despesas de supermercado pagas durante a coabitação
podem documentar, substituir, abater ou compensar eventual prestação alimentar
em dinheiro devida à ex-cônjuge.

NÃO PERDER:
- coabitação atual;
- natureza e finalidade das compras;
- eventual obrigação formal;
- concordância da ex-cônjuge;
- prova dos pagamentos;
- necessidade de segurança contra cobrança posterior;
- diferença entre proposta de acordo e efeito jurídico automático.

DISTRIBUIÇÃO:
- linha patrimonial: quantificação, créditos e despesas;
- linha familiar: alimentos, necessidade, possibilidade e forma de cumprimento;
- linha probatória: notas, recibos, finalidade, aceitação e rastreabilidade;
- linha negocial: acordo, cláusula, transparência e homologação;
- linha processual: risco de cobrança, inadimplemento e reconhecimento judicial.

CRITÉRIO DE ENCERRAMENTO:
Uma linha só encerra quando separar o que é fonte, hipótese, risco e pergunta
pendente. Nenhuma linha pode afirmar dispensa automática sem base válida.
```

## 5. Laboratório de Alternativas

### Projeção enviada às IAs

```text
CONTEXTO PROTEGIDO:
Ex-cônjuges permanecem na mesma residência durante período de reorganização.
Uma das partes assume compras mensais de supermercado. Investigar se despesas
podem ser documentadas ou consideradas em eventual composição alimentar.
Identificadores, endereços, valores exatos e documentos pessoais: protegidos.

PAUTA DO ESTRATEGISTA:
[projeção da pauta acima, sem dados identificadores]
```

Nenhuma linha recebe as respostas das demais.

### Linhas simuladas

#### Linha familiar

Investiga a diferença entre obrigação alimentar, prestação in natura, pagamento de despesas e mera contribuição doméstica.

Pergunta bloqueante possível:

> Existe decisão judicial, acordo homologado ou outro instrumento vigente que já fixe alimentos ou a forma de pagamento?

#### Linha probatória

Investiga como demonstrar compras, notas, períodos, finalidade, aceitação e vínculo com a obrigação discutida.

Pergunta bloqueante possível:

> As compras são identificáveis por notas, pagamentos rastreáveis e registro de que foram feitas em benefício da ex-cônjuge?

#### Linha negocial

Explora formatos de acordo, declaração periódica de despesas, limite de valor, prestação de contas, prazo e necessidade de formalização.

Pergunta bloqueante possível:

> Há disposição de ambas as partes para reconhecer expressamente a finalidade das despesas e a forma de imputação?

#### Linha patrimonial

Compara o custo mensal das compras com outras despesas de residência e com eventual valor monetário, sem presumir equivalência.

Pergunta bloqueante possível:

> Quais despesas são exclusivamente da ex-cônjuge, quais são comuns e quais beneficiam também outras pessoas da residência?

#### Linha processual

Estressa riscos de cobrança futura, interpretação de liberalidade, insuficiência de acordo verbal e necessidade de revisão profissional.

Pergunta bloqueante possível:

> Existe algum risco de a obrigação ser cobrada por período anterior ou de a parte negar que as compras tinham finalidade alimentar?

## 6. Tentativa de estresse pelo titular

Nesta simulação, o titular poderia responder às linhas com perguntas como:

```text
- E se ela concordar verbalmente que as compras substituem o pagamento?
- E se eu guardar todas as notas e comprovantes?
- E se eu pagar também condomínio, energia ou internet?
- E se o valor das compras for maior que o valor que eu enviaria?
- E se houver filhos ou outras pessoas usando a mesma casa?
- E se fizermos um acordo particular por escrito?
- E se ela mudar de ideia depois?
- E se já existir uma decisão ou acordo anterior?
```

O Estrategista deve receber essas respostas integralmente, atualizar a pauta e decidir quais linhas continuam. As IAs do Laboratório recebem apenas a parte projetada e pertinente a cada linha.

## 7. Resultado esperado da simulação

A síntese final não deve responder simplesmente “sim” ou “não”. Ela deve entregar:

- quais hipóteses dependem de obrigação existente;
- quais fatos precisam ser confirmados;
- quais fontes foram realmente verificadas;
- quais modelos de cláusula podem documentar o arranjo;
- quais riscos permanecem;
- quais alternativas são lícitas e operacionalmente executáveis;
- o que precisa ser levado à Arena;
- o que exige revisão profissional antes de qualquer assinatura ou mudança de pagamento.

## Estado

Simulação estruturada para teste do fluxo. Nenhuma fonte real foi consultada e nenhum efeito jurídico foi atribuído aos exemplos.
