# Teste do Bibliotecário — despesas da casa e alimentos ao ex-cônjuge

## Pergunta de teste recebida

> Estou morando na mesma casa que minha ex-cônjuge e pagando as compras de supermercado do mês. Posso utilizar uma cláusula compensatória para substituir ou evitar o envio de dinheiro diretamente a ela?

## Classificação esperada

- modo: `strategy_handoff`;
- pesquisa bibliotecária: permitida, em contexto minimizado;
- encaminhamento ao Estrategista: recomendado;
- resposta automática de validade para o caso: proibida.

## Como o Bibliotecário deve pesquisar

A pesquisa deve ser neutra e não deve afirmar que a despesa de supermercado substitui alimentos. Deve procurar, separadamente:

1. natureza jurídica de alimentos entre ex-cônjuges;
2. modalidades de cumprimento, pagamento direto, prestação in natura e despesas assumidas;
3. requisitos para reconhecimento ou compensação de despesas;
4. necessidade de acordo expresso, homologação ou decisão judicial;
5. tratamento de despesas de moradia, alimentação, consumo e manutenção da residência;
6. efeitos de coabitação após separação;
7. riscos de inadimplemento, alegação de liberalidade e falta de prova;
8. cláusulas e modelos não normativos que documentem despesas ou prestação in natura;
9. fontes contrárias, limites e entendimentos divergentes;
10. país, jurisdição, autoridade, vigência, versão, data de verificação e localizadores.

## Limite do teste

O Bibliotecário deve entregar fontes, padrões de cláusula e perguntas para validação. Não deve concluir se Augusto está dispensado de pagar, não deve redigir uma cláusula final personalizada e não deve recomendar ocultar ou substituir obrigação sem confirmação profissional e documental.

## Próxima etapa esperada

Os resultados neutros podem acompanhar uma exploração do Estrategista, que deverá separar:

- despesas efetivamente pagas;
- eventual obrigação formal existente;
- acordo ou decisão vigente;
- prova dos pagamentos e da finalidade;
- risco de a despesa ser considerada mera contribuição voluntária;
- alternativas de formalização e seus riscos.

## Estado

Fixture e classificação implementados. A busca real não foi executada porque o Knowledge Service ainda não está conectado.
