# Concilium — checkpoint da fase 25

## Estratégia triada → Laboratório
Uma avaliação de argumento pode agora iniciar uma nova exploração divergente sem perder o contexto de origem.

- Estratégia manual pode ser triada automaticamente;
- avaliação triada pode ser carregada no Laboratório;
- o Laboratório recebe o `sourceAssessmentId`;
- o pacote de evidências da avaliação é salvo junto da exploração;
- todas as IAs recebem o mesmo pacote comum de evidências;
- nenhuma IA recebe a resposta ou o raciocínio de outra;
- a exploração pode seguir para a Arena;
- versões e origem permanecem preservadas.

## Alternativa do Laboratório → Arena
Ao selecionar uma alternativa para a Arena, o sistema mantém a ligação com exploração, ideia e thread e registra uma avaliação inicial como `nao_verificado`, pronta para confronto, não como fundamento jurídico aprovado.

## Interface
- botão `Usar no Laboratório` na lista de avaliações do Estrategista;
- aviso de que o pacote de evidências será compartilhado como referência comum, sem misturar raciocínios;
- botão `Levar à Arena` para abrir o argumento triado;
- carregamento do argumento na nova rodada da Arena.

## Persistência
- `sourceAssessmentId` e `evidenceSnapshotJson` em explorações;
- `explorationRunId`, `explorationIdeaId` e `explorationThreadId` em avaliações;
- migração `0020_strategy_evidence_bridge.sql`.

## Estado de validação
Código e migrações foram preparados. Ainda não houve build, teste, migração ou execução contra banco, Knowledge Service ou provedor de IA reais.
