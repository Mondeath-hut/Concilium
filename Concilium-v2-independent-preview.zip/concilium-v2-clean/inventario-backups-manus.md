# Inventário seguro dos backups Manus recebidos

## Escopo da inspeção

Os arquivos recebidos foram inspecionados somente quanto ao formato, à estrutura de arquivos e aos manifestos legíveis. Nenhum conteúdo criptografado foi desbloqueado, executado, extraído ou importado para o Concilium.

| Pacote | Estrutura observada | Conclusão segura |
|---|---|---|
| Backup de conta (`.manusaccount`) | Pacote ZIP UXP/4 com conteúdo crítico cifrado, redundância de integridade e manifesto assinado. | Contém informações de conta cifradas. Não é uma exportação diretamente importável para o banco do Concilium. |
| Backup de tarefas (`.manustask`) | Pacote ZIP UXP/4 com conteúdo principal cifrado, segmentos de recuperação e manifesto assinado. | Pode preservar artefatos da tarefa exportada, mas o conteúdo não é legível nem migrável diretamente sem o processo oficial de restauração. |

## Limites de recuperação

Os dois pacotes são exportações pontuais e criptografadas da plataforma. O conteúdo real — incluindo arquivos, dados de tarefas e eventuais artefatos — deve ser restaurado pelo fluxo oficial da conta antes de qualquer seleção ou migração para esta aplicação. Essa restauração é única; portanto, os pacotes não serão modificados, renomeados, combinados nem submetidos a tentativas de extração local.

Após a restauração oficial, qualquer conteúdo destinado ao Concilium deverá ser revisado separadamente, com confirmação expressa do titular, estrutura de importação compatível e preservação dos controles de autorização e auditoria.
