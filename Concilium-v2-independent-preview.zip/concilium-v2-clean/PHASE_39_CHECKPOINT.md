# Concilium — checkpoint da fase 39

## Estrategista central e redistribuição contínua
O Laboratório passou a ter uma etapa explícita de coordenação pelo Estrategista central.

### Abertura da exploração

- o Estrategista recebe a solicitação integral autorizada;
- consulta o pacote de evidências já triado;
- gera uma pauta com o âmago do pedido, fatos que não podem ser perdidos, eixos, perguntas e critérios de encerramento;
- persiste essa pauta e o modelo coordenador;
- envia às linhas somente a projeção protegida da pauta e do contexto.

### Continuação do diálogo

Quando o titular responde a uma pergunta:

- a resposta integral retorna primeiro ao Estrategista;
- o Estrategista recebe o estado das linhas e a pauta anterior;
- gera uma pauta atualizada, podendo indicar continuidade, encerramento, lacuna ou redistribuição;
- a pauta é persistida;
- somente a projeção pertinente é repassada à linha correspondente;
- históricos de linhas continuam isolados.

## Permissões

- Estrategista: `integral_autorizado`;
- supervisor da Arena: `integral_autorizado`;
- IAs derivadas do Laboratório: `contexto_protegido`;
- Bibliotecário/Knowledge Service: pergunta e perímetro minimizados.

## Implementação

- `strategistBrief` e `strategistModelId` na exploração;
- migração `0025_strategist_coordination.sql`;
- `buildStrategistCoordinatorPrompt`;
- `buildStrategistContinuationPrompt`;
- coordenação inicial e de continuação no router;
- pauta protegida repassada às linhas;
- auditoria de níveis de transmissão;
- interface exibindo a pauta do Estrategista central.

## Limite atual
A redistribuição está modelada e a pauta é atualizada. A criação automática de uma nova linha independente a partir de uma redistribuição ainda deve ser implementada em uma fase posterior, após validar o ciclo básico com banco e modelos reais.
