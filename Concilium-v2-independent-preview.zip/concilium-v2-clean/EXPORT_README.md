# Exportação portátil do Concilium

## O que este pacote transporta

Este ZIP contém a árvore de código, documentação, testes, migrações, contratos de integração e checkpoints do Concilium.

O ZIP é a forma canônica de transporte porque preserva a estrutura de pastas. Um HTML único pode servir como índice ou visualizador, mas não substitui a árvore do projeto e não deve ser usado como compilador/descompilador improvisado.

## O que não é incluído

- senhas;
- API keys, tokens ou códigos MFA;
- arquivos `.env`;
- banco de dados;
- `node_modules`;
- `dist` ou artefatos de build;
- pacotes de documentos reais;
- arquivos de cofre de chaves.

## Retomada no Manus

1. Descompactar preservando a árvore.
2. Ler `MANUS_INTEGRATION_HANDOFF.md`.
3. Ler `APPLICATION_OPERATING_GUIDE.md`, `MANUS_DATABASE_SYNC.md` e `SENSITIVE_DOCUMENT_MIGRATION.md`.
4. Instalar dependências.
5. Executar `pnpm check`, `pnpm test` e `pnpm build`.
6. Aplicar migrações em banco de teste.
7. Adaptar somente os pontos de infraestrutura documentados.
8. Produzir relatório de arquivos alterados, testes, migrações e rollback.

## Regra de integridade

O integrador não deve compactar novamente removendo arquivos, transformar o projeto em HTML único nem reescrever o núcleo para contornar limitações. Se o ambiente exigir uma adaptação, preservar a cópia original e registrar a alteração.
