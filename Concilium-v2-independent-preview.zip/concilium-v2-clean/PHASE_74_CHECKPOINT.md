# Concilium — checkpoint da fase 74

## Histórico de versões documentais

Foi criada estrutura para registrar versões e duplicidades sem substituir um documento anterior.

### Cada versão preserva

- documento de origem;
- rótulo da versão;
- hash de conteúdo;
- referência de origem;
- arquivo privado, quando houver;
- nota de alteração;
- data de recebimento.

### Rotas

- `listDocumentVersions`;
- `createDocumentVersion`.

### Regras

- versão nova não apaga a anterior;
- a origem permanece rastreável;
- hash é metadado técnico, não prova de autenticidade;
- a IA pode sugerir relação/duplicidade, mas não decide equivalência;
- acesso exige titular e caso autorizados;
- auditoria registra somente metadados.

## Migração

```text
drizzle/0031_document_versions.sql
```

## Estado

Histórico e rotas de versões preparados. A interface de comparação de versões e a integração automática com upload/OCR ficam para a próxima etapa.
