# Concilium — checkpoint da fase 8

## Correção de fidelidade contextual da Arena
Foi identificado e corrigido um risco importante: o supervisor podia transformar um cenário concreto em um rótulo jurídico genérico, como “cláusula de boa convivência”, e com isso apagar o motivo real da pergunta.

A política agora exige que o supervisor preserve, quando presentes no material:

- a situação concreta de coabitação após a separação;
- a falta de condições materiais ou a decisão de não envolver familiares;
- áreas comuns, despesas, rotinas e responsabilidades;
- visitas e entrada de novos companheiros;
- privacidade e constrangimentos;
- filhos e imagem familiar/social;
- limites de duração, alcance e execução da cláusula;
- a diferença entre fato narrado, pedido real, hipótese e questão jurídica.

## Nova regra de minimização
A proteção de conteúdo foi refinada:

- identificadores, contatos, endereços e valores podem ser removidos;
- contexto relacional, doméstico e patrimonial necessário ao raciocínio é preservado;
- termos como coabitação, filhos, áreas comuns, convivência e regime patrimonial não são tratados como identificadores;
- o supervisor recebe o material integral;
- as demais IAs recebem a versão contextualizada compatível com a autorização.

## Resultado esperado
Uma pergunta sobre convivência pós-separação não deve mais chegar à Arena apenas como “boa convivência”. Ela deve ser debatida com o contexto que dá sentido à pergunta, permitindo examinar critérios, limites, consequências práticas e alternativas.

## Validação adicionada
Foram incluídos testes de política para garantir que:

- o supervisor permaneça em nível integral autorizado;
- o contexto de convivência seja preservado sem identificadores;
- a síntese da rodada anterior continue sendo ponto de partida separado.
