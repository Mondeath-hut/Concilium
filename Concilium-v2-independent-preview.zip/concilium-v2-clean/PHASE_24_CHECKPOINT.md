# Concilium — checkpoint da fase 24

## Triagem automática ligada ao Estrategista
O Estrategista agora possui um caminho preparado para enviar uma formulação autorizada a uma triagem automática:

1. minimiza identificadores da formulação;
2. consulta o Knowledge Service com `requireCurrent: true`, quando configurado;
3. monta um pacote de evidências com fonte, versão, jurisdição, validade e citação;
4. solicita ao modelo uma classificação estruturada;
5. valida a resposta contra o contrato de triagem;
6. grava a avaliação vinculada à estratégia ou à linha do Laboratório;
7. preserva fontes, contrapontos, dependências e limitações;
8. deixa a decisão final para o titular.

## Ausência de serviço
Se o Knowledge Service não estiver conectado, a triagem não inventa fontes. O resultado deve permanecer não verificado ou exigir revisão, com aviso de que a classificação é preliminar.

## Arena
As avaliações persistem com vínculo opcional a rodada e execução da Arena. A Arena poderá receber a linha já triada, sem perder a origem no Estrategista.

## Interface
O botão `Pesquisar e triar` foi adicionado às estratégias do caso. A área de Estratégias mostra as avaliações registradas; a área do Comitê mostra as avaliações ligadas ao caso, com origem e estado.

## Estado de validação
O caminho foi implementado no código, mas não foi executado com dependências, banco, provedor de modelo ou Knowledge Service reais. Build, testes e migrações continuam pendentes.
