# Concilium — checkpoint da fase 72

## Revisão visual de catalogação documental

Foi criada a interface para revisar sugestões do ensemble antes de confirmar o cofre.

### A interface mostra

- documento pendente;
- cofre sugerido;
- sensibilidade sugerida;
- nível de confiança;
- seletor de cofre final.

### Regras

- aparece somente para `needs_owner_review`;
- a decisão fica com o titular;
- o cofre sugerido pode ser alterado;
- a confirmação usa rota protegida;
- a confirmação não atesta autenticidade, relevância ou valor probatório;
- documentos divergentes permanecem revisáveis.

## Arquivos

- `client/src/components/DocumentCatalogReview.tsx`;
- integração em `client/src/pages/OwnerWorkspace.tsx`;
- `PHASE_72_CHECKPOINT.md`.
