# Concilium — checkpoint da fase 60

## Exploração derivada com linhagem preservada

Foi preparada a criação de uma nova exploração a partir de um pacote de ramificações submetido.

### Garantias

- o pacote precisa estar em `submitted`;
- a nova exploração recebe novo identificador;
- `parentRunId` aponta para a exploração original;
- `sourceBranchBundleId` aponta para o pacote composto;
- `derivationType` fica como `branch`;
- o contexto cifrado e o pacote de evidências são herdados de forma controlada;
- a exploração original não é alterada;
- a nova pulverização não ocorre silenciosamente no mesmo run.

### Nova rota

```text
startDerivedStrategyExploration
```

Ela cria a unidade derivada e deixa a geração das linhas para a etapa seguinte, após revisão do título e objetivo.

### Migração

```text
drizzle/0030_derived_exploration_lineage.sql
```

## Estado
Linhagem e criação da nova unidade preparadas no backend. A interface ainda precisa oferecer o formulário de título/objetivo e o comando para iniciar a pulverização da exploração derivada.
