# Concilium — Manual funcional e visão do produto

## 1. O que é o Concilium

O Concilium é uma sala operacional privada para organizar fatos, documentos, cenários, propostas e decisões em situações complexas, especialmente negociações familiares, patrimoniais e financeiras.

Ele não substitui advogado, defensor público, mediador, juiz ou a decisão do titular. Seu papel é transformar informações dispersas em uma estrutura verificável para análise, negociação, preparação de audiência e acompanhamento de consequências.

O sistema deve distinguir claramente:

- fato comprovado;
- relato do usuário;
- hipótese;
- premissa dependente de prova;
- proposta;
- contraproposta;
- alerta;
- decisão autorizada;
- análise interna da IA.

## 2. Princípios do produto

- Privacidade por padrão.
- O titular mantém controle sobre decisões e comunicações.
- Nenhuma IA aceita, rejeita ou envia acordo autonomamente.
- Estratégias internas não se confundem com histórico formal da negociação.
- Fontes devem ser verificadas quanto a jurisdição, vigência, autoridade, data e escopo.
- Incertezas devem aparecer, nunca ser preenchidas por invenção.
- Propostas devem evoluir do cooperativo ao defensivo somente quando autorizadas.
- O sistema deve favorecer soluções sustentáveis para ambas as partes antes do impasse.
- Dados sensíveis não devem aparecer no frontend público, logs, exportações indevidas ou código.

## 3. Usuário principal e acesso

A primeira versão é uma sala privada do titular. O fluxo previsto é:

```text
bootstrap de uso único
→ identificação do titular
→ passkey/WebAuthn ou biometria do dispositivo
→ códigos de recuperação
→ espaço privado do titular
```

Não depender de login da plataforma de desenvolvimento. Resend, e-mail confirmado, TOTP e passkeys adicionais são camadas opcionais posteriores, não requisitos do primeiro acesso.

Não criar backdoor, senha universal ou código oculto.

## 4. Arquitetura conceitual

### 4.1 Espaço do titular

Área privada com:

- fatos e cronologia;
- documentos;
- cenários;
- estratégias;
- limites;
- análises da IA;
- pontos fracos;
- inegociáveis;
- preparação de propostas;
- histórico interno de decisões.

### 4.2 Mesa formal de negociação

Área que registra somente o que foi efetivamente apresentado ou recebido:

- proposta;
- contraproposta;
- resposta;
- itens aceitos;
- itens recusados;
- itens pendentes;
- versões e horários.

Uma proposta apresentada nunca deve ser alterada silenciosamente. Alterações geram nova versão.

### 4.3 Arena

Ambiente para submeter teses, propostas e interpretações a análises independentes, críticas, defesa, acusação ou advogado do diabo, coordenadas por supervisor.

A Arena trabalha por rodadas isoladas e comparáveis. Uma rodada pode continuar aberta para intervenção. Ao iniciar outra, a anterior é recolhida com síntese, definições e considerações finais.

O supervisor pode ter acesso integral autorizado. Outras IAs recebem apenas o nível de contexto permitido na rodada: protegido, redigido ou integral autorizado.

### 4.4 Laboratório de Alternativas

Ambiente divergente para gerar possibilidades sem decidir imediatamente.

Cada linha de raciocínio deve permanecer independente e interativa. Perguntas semelhantes podem ser agrupadas visualmente, mas respostas não devem contaminar linhas divergentes. Ideias selecionadas podem ir para a Arena.

### 4.5 Bibliotecário / Knowledge Service

Acervo jurídico e documental separado dos dados operacionais do caso.

O sistema recupera somente resultados necessários, com:

- fonte;
- versão;
- data de consulta;
- jurisdição;
- autoridade;
- escopo;
- limitações;
- situação de vigência;
- citações verificáveis.

Não enviar dados sensíveis do caso ao acervo por padrão.

## 5. Documentos e evidências

Permitir importar, classificar, visualizar e relacionar documentos sem confundir documento com fato provado.

Cada item pode indicar:

- origem;
- data;
- tipo;
- assunto;
- pessoas relacionadas;
- fato que pretende comprovar;
- grau de confiabilidade;
- lacunas;
- cenário relacionado;
- status de revisão.

Documentos sensíveis podem passar por quarentena antes de serem usados.

O pacote 7z protegido deve ser tratado como artefato opaco e separado. Não abrir, extrair ou importar automaticamente. A senha nunca deve aparecer no chat, código, README, log ou manifesto.

## 6. Fatos e cronologia

A cronologia deve separar:

- data conhecida;
- data aproximada;
- evento;
- fonte;
- participantes;
- consequência;
- grau de certeza;
- contradições.

O sistema deve permitir identificar quando uma informação é apenas hipótese ou depende de confirmação futura.

## 7. Cenários

Um cenário é uma configuração completa de fatos, premissas, objetivos, parâmetros, restrições, propostas e riscos.

Cada cenário contém:

- nome;
- finalidade;
- parâmetros;
- fatos utilizados;
- premissas;
- restrições;
- interesses de cada parte;
- checklist;
- alertas;
- argumentos;
- evidências;
- contestações prováveis;
- concessões possíveis;
- pontos inegociáveis;
- contrapropostas;
- plano de migração para outro cenário.

### Progressão padrão

1. Cooperativo — menor impacto conjunto.
2. Cooperativo protegido — mais garantias.
3. Equilibrado — menos concessões recíprocas.
4. Defensivo — proteção individual maior.
5. Impasse — posição final e alternativas formais.

A passagem entre cenários exige autorização do titular, com registro de motivo, data, versão anterior e nova versão.

## 8. Estratégias e Estrategista

O Estrategista pode:

- comparar cenários;
- calcular impactos conforme parâmetros;
- identificar conflitos;
- apontar riscos;
- criar checklists;
- preparar argumentos;
- sugerir concessões;
- formular contrapropostas;
- sugerir migração de cenário;
- detectar dependência de fato não confirmado.

O Estrategista não pode:

- decidir pelo titular;
- aceitar ou rejeitar acordo;
- afirmar que alguém agiu de má-fé;
- transformar hipótese em fato;
- enviar mensagem automaticamente;
- apresentar uma proposta sem autorização.

## 9. Checklist dinâmico

O checklist é administrado pelo Estrategista conforme parâmetros aprovados pelo titular.

Cada item deve conter:

- descrição;
- categoria;
- prioridade;
- status;
- condição de aceitação;
- evidência;
- risco;
- resposta preparada;
- observação da audiência.

Categorias:

- interesse do titular;
- interesse da outra parte;
- negociável;
- inegociável / exige pausa;
- pergunta;
- condição;
- pendente de prova.

Status:

- pendente;
- aceito;
- recusado;
- parcialmente aceito;
- substituído;
- dependente de confirmação.

## 10. Parâmetros financeiros e patrimoniais

Permitir configurar:

- valor estimado do imóvel;
- valor estimado da quota;
- prazo mínimo, ideal e máximo;
- pagamento único ou parcelas;
- índice de correção;
- capacidade atual;
- renda em cenários profissionais diferentes;
- reserva mínima protegida;
- despesas comuns;
- despesas exclusivas;
- compensação por uso exclusivo;
- custos de moradia externa;
- garantias;
- eventos condicionais.

Não presumir que uma despesa pode ser abatida do preço da quota. Isso deve estar previsto formalmente ou ser juridicamente reconhecido.

Separar contabilmente:

- despesas do imóvel;
- compensação pelo uso exclusivo;
- moradia externa do titular;
- despesas de consumo pessoal;
- despesas comuns de conservação.

## 11. Alertas

### Verde

Compatível com parâmetros e executável no cenário informado.

### Amarelo

Depende de fato não confirmado, como emprego, financiamento, venda, aumento de renda ou reconhecimento de crédito.

### Vermelho

Viola inegociável, compromete reserva, exige prazo inviável, cria risco elevado ou contém renúncia ampla sem proteção.

Alertas são informativos. Não produzem decisão automática.

## 12. Índice comparativo

O sistema pode mostrar um índice de atendimento dos interesses de cada parte, desde que os critérios sejam explícitos.

Exemplos de dimensões:

- segurança habitacional;
- preservação patrimonial;
- liquidez;
- previsibilidade;
- prazo;
- risco de inadimplemento;
- impacto financeiro;
- preservação dos interesses dos filhos.

O resultado deve ser chamado de:

```text
índice comparativo de atendimento dos interesses
```

Nunca apresentar como probabilidade de vitória, previsão judicial ou garantia de aceitação.

Mostrar os pesos e as premissas. Se faltarem dados, mostrar “não calculado”.

## 13. Mesa de negociação e histórico

A mesa formal deve registrar a progressão real:

```text
Proposta A
→ contraproposta A.1
→ Proposta B
→ contraproposta B.1
→ Proposta C
```

Cada registro:

- ID;
- autor;
- data e hora;
- texto ou termos objetivos;
- versão anterior;
- itens aceitos;
- itens recusados;
- itens pendentes;
- resposta;
- status;
- próxima ação autorizada.

Status:

```text
Rascunho interno
Apresentada
Recebida
Aceita
Recusada
Aceita parcialmente
Contraproposta recebida
Substituída
Encerrada
```

A interface deve ser neutra. Não dizer que uma parte agiu de má-fé. Mostrar fatos, termos, concessões, recusas e efeitos comparativos.

## 14. Negociação inicial pretendida

A primeira abordagem busca uma transição cooperativa:

- moradia provisória;
- tempo para reinserção profissional;
- eventual pensão provisória analisada separadamente;
- preservação do patrimônio;
- compra futura da quota;
- prazo compatível com liquidez real;
- despesas claramente separadas;
- proteção dos filhos;
- revisão e garantias.

Hipóteses de contratação pela Vale, dispensa e seguro-desemprego devem permanecer separadas e nunca ser tratadas como fatos confirmados antes da prova.

## 15. Casos patrimoniais prioritários

O sistema deve permitir comparar:

1. contratação pela Vale;
2. dispensa e seguro-desemprego;
3. compra futura da quota em quatro a oito anos, preferencialmente cerca de cinco;
4. uso exclusivo provisório com compensação acumulada;
5. proteção patrimonial dos filhos;
6. impasse com saída do titular e compensação por uso exclusivo;
7. venda ou dissolução como alternativa de comparação.

A transferência a filhos adultos deve ser tratada apenas como hipótese de alto risco, dependente de análise sobre fraude, credores, regime de bens, tributos, registro, usufruto e validade jurídica.

## 16. Segurança e auditoria

- Registrar alterações e autorizações.
- Não permitir senha universal ou backdoor.
- Usar variáveis de ambiente para segredos.
- Não expor chaves em frontend, logs, exportações ou mensagens.
- Minimizar registros biométricos: guardar credencial, evento e horário, não fotografia biométrica.
- Manter cofre, quarentena e permissões.
- Separar dados do caso da biblioteca jurídica.
- Permitir auditoria de acesso e de mudança.

## 17. Exportações e uso offline

Permitir exportar separadamente:

- síntese de uma página;
- checklist atual;
- histórico formal da negociação;
- tabela de propostas;
- perguntas da audiência;
- pontos inegociáveis;
- PDF;
- JSON estruturado.

A versão offline não deve enviar dados ao servidor e deve continuar utilizável durante videoconferência.

## 18. Regras de apresentação durante audiência

O usuário deve poder:

- pausar antes de concordar;
- consultar os efeitos patrimoniais;
- comparar cenários;
- registrar a proposta sem aceitá-la;
- pedir esclarecimento;
- gerar uma contraproposta;
- marcar condição como pendente;
- retornar ao titular antes de qualquer decisão irreversível.

Frase operacional sugerida:

> A proposta parece relevante, mas preciso conferir os efeitos patrimoniais, os prazos e as condições antes de manifestar concordância definitiva.

## 19. Critérios de publicação

Antes de publicar, verificar:

- instalação limpa;
- checagem de tipos;
- testes;
- build;
- saúde da infraestrutura;
- autenticação própria;
- passkey;
- recuperação;
- banco e migrações;
- armazenamento privado;
- auditoria;
- exportação;
- ausência de OAuth da plataforma;
- ausência de dependência de login do provedor;
- nenhuma abertura automática do 7z;
- nenhum envio automático de proposta;
- preservação das funções existentes.

A plataforma de publicação deve primeiro analisar compatibilidade. Não deve reescrever, simplificar ou migrar a aplicação sem aprovação expressa do titular.

## 20. Evolução futura — Sala de audiência por videoconferência

Em uma versão futura, o Concilium poderá incorporar uma sala de videoconferência integrada ou conectada a uma videoconferência externa. O módulo deve exigir consentimento dos participantes e obedecer às regras aplicáveis de privacidade, gravação, transcrição e sigilo profissional.

### Função do Estrategista em tempo real

Com autorização, o Estrategista poderá acompanhar a transcrição ou os eventos da audiência e relacionar as falas a:

- itens do checklist;
- propostas e contrapropostas;
- condições já atendidas;
- pontos pendentes;
- limites inegociáveis;
- riscos financeiros ou jurídicos previamente cadastrados;
- divergências entre o que foi dito e o que foi formalmente registrado.

Ele poderá mostrar ao usuário autorizado, em painel privado:

- percentual ou índice de itens atendidos;
- concessões realizadas por cada lado;
- condições ainda não respondidas;
- alerta de possível violação de parâmetro;
- perguntas de esclarecimento;
- necessidade de pausar antes de concordar;
- resumo da proposta em discussão.

### Separação de visões

A audiência deve possuir visões independentes:

- visão neutra do mediador ou defensor responsável;
- visão privada do advogado de uma parte;
- visão privada da outra parte e de seu advogado;
- visão administrativa e auditável do sistema.

Nenhuma estratégia privada, limite, observação ou análise de uma parte pode aparecer para outra parte sem autorização explícita.

### Limites de autonomia

O Estrategista não deve:

- falar automaticamente na audiência;
- interromper participantes;
- aceitar ou rejeitar acordo;
- sugerir ao mediador que uma parte agiu de má-fé;
- revelar estratégia privada;
- gravar ou transcrever sem consentimento;
- transformar uma fala ambígua em aceitação definitiva.

Qualquer intervenção deve ser uma sugestão privada para a pessoa autorizada, com confirmação humana antes de ser apresentada.

### Registro formal

Quando uma proposta for verbalizada, o sistema poderá gerar um resumo para confirmação:

> “Foi compreendido que a proposta prevê A, B e C. Deseja registrar esses termos como proposta apresentada?”

Somente após confirmação humana o item entra no histórico formal. Correções geram nova versão, preservando o registro anterior.

### Requisitos de segurança

- consentimento explícito para áudio, vídeo e transcrição;
- indicação visível de quando a transcrição estiver ativa;
- processamento local ou ambiente protegido sempre que possível;
- criptografia em trânsito e em repouso;
- retenção configurável;
- eliminação segura;
- auditoria de acesso;
- exportação separada por perfil;
- bloqueio de compartilhamento entre partes;
- revisão humana de qualquer resumo antes de uso formal.

O módulo deve ser tratado como evolução futura e não é requisito para a primeira publicação operacional do Concilium.

### Integração com videoconferência externa

O Concilium não deve possuir uma camada própria de videoconferência. Microsoft Teams, Google Meet, Zoom, Webex ou outra ferramenta institucional ficam responsáveis por áudio, vídeo, participantes, chat e gravação conforme a política da instituição.

O Concilium funciona como uma camada secundária de análise e suporte:

```text
Teams / Meet / Zoom / Webex = áudio, vídeo, participantes e gravação
Concilium = cenários, painéis, estratégias, checklist, registro e alertas
```

A compatibilidade deve ser progressiva, sem acoplar o núcleo do Concilium a um único fornecedor. A primeira forma de uso pode ser lado a lado, com o Concilium em outra janela. Depois podem ser acrescentadas importação autorizada de transcrição, integração por API, webhooks ou extensão, conforme a ferramenta e as permissões institucionais.

### Áudio, vídeo e transcrição

Se Teams, Meet ou outra ferramenta já estiver responsável pela videoconferência, o Concilium não precisa acessar diretamente câmera ou microfone. Ele pode receber uma transcrição autorizada ou notas selecionadas.

Se houver integração direta, cada permissão deve ser separada:

- microfone: somente para captura autorizada de áudio;
- câmera: normalmente desnecessária para a função estratégica;
- transcrição: somente com consentimento e indicação visível;
- gravação: preferencialmente mantida na ferramenta oficial da audiência;
- acesso ao áudio bruto: excepcional, justificado e com retenção limitada.

A transcrição deve priorizar português brasileiro, identificação de quem fala, marcação de tempo, vocabulário jurídico e nomes próprios. Deve lidar com repetições, hesitações, gagueira e vícios de linguagem sem alterar o sentido.

Manter duas camadas quando possível:

1. transcrição original, preservada para conferência;
2. versão normalizada, com repetições e preenchimentos reduzidos para análise.

A versão normalizada nunca substitui a original. O Estrategista deve tratar qualquer trecho como hipótese até confirmação humana, especialmente quando houver negação, valor, prazo, nome próprio ou aceitação de proposta.

A interface deve permitir corrigir um trecho, identificar o orador, marcar baixa confiança e confirmar se uma fala realmente representa proposta, aceite, recusa ou pergunta.

A integração pode começar de forma simples, com o Concilium aberto em uma segunda janela e o Teams na janela da audiência. Em fase posterior, poderá usar transcrição ou APIs autorizadas da ferramenta de videoconferência, sempre respeitando consentimento, políticas institucionais e permissões.

O Concilium não deve duplicar ou iniciar uma gravação independente sem autorização expressa. A gravação oficial pode permanecer no Teams ou no sistema institucional, enquanto o Concilium registra apenas os termos, eventos e decisões que forem confirmados para o histórico.

### Estrutura multinível de organizações e papéis

A aplicação deve suportar, progressivamente:

- organização da Defensoria ou instituição mediadora;
- defensor ou mediador responsável;
- organização e advogado da parte A;
- espaço privado da parte A;
- organização e advogado da parte B;
- espaço privado da parte B;
- administrador técnico sem acesso automático ao conteúdo jurídico;
- auditor com acesso limitado e justificado.

Cada organização pode possuir configurações, modelos, políticas de retenção e permissões próprias. Um caso reúne os participantes autorizados, mas não mistura seus espaços privados.

### Estratégistas por perspectiva

Pode haver pelo menos três contextos estratégicos independentes:

1. Estrategista da parte A — atende somente a parte A e seu advogado.
2. Estrategista da parte B — atende somente a parte B e seu advogado.
3. Estrategista neutro do defensor/mediador — trabalha com os elementos autorizados para facilitar a compreensão e a composição, sem defender uma parte.

Os três podem analisar os mesmos termos públicos da mesa, mas recebem contextos privados diferentes. Uma proposta apresentada passa à camada formal comum somente quando efetivamente comunicada e registrada. A análise interna que levou à proposta continua privada.

O defensor ou mediador não deve ser tratado como alguém que “defende” os dois lados. Seu ambiente deve apoiar neutralidade, equilíbrio procedimental, esclarecimento e verificação de viabilidade, conforme as regras da instituição.

### Visualização durante a audiência

O usuário pode manter:

- Teams em uma janela ou dispositivo;
- painel privado do Concilium em outra janela;
- painel da mesa formal para registrar propostas confirmadas;
- alertas discretos do Estrategista sem interrupção do áudio ou do chat da audiência.

Os alertas devem ser privados, identificados por origem e acompanhados da base utilizada. Nenhum alerta privado deve aparecer na tela compartilhada da audiência.
