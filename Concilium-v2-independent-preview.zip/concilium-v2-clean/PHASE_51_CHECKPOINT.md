# Concilium — checkpoint da fase 51

## Cofre cifrado por entrada
Foi preparado o adaptador criptográfico para o armazenamento de segredos já aprovados.

### Características

- AES-256-GCM;
- IV aleatório por registro;
- tag de autenticação por registro;
- formato versionado `sv1`;
- derivação da chave por SHA-256;
- rejeição de chaves menores que 32 caracteres;
- rejeição de segredo vazio;
- registro sem valor em claro;
- descriptografia interna somente com a chave correta.

### Registro persistível

O registro contém apenas:

- nome;
- consumidor;
- valor cifrado;
- algoritmo;
- versão;
- data de criação.

### Limite
Este adaptador ainda não está conectado a uma tabela de produção nem ao descriptografador 7z. Os testes usam somente valores fictícios e não validam o ambiente real, o banco ou as chaves do projeto.

## Arquivos

- `server/secretVault.ts`;
- `server/secretVault.test.ts`;
- `SECURE_SECRET_INTAKE.md`.
