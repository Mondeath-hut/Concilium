# Concilium — checkpoint da fase 43

## Pacote Estrategista → Arena
O encaminhamento da síntese final agora pode abrir um pacote composto por:

- contexto original integral, cifrado em repouso;
- contexto estratégico amplo;
- pauta do Estrategista;
- síntese final;
- vínculo com exploração e caso.

### Acesso

O supervisor da Arena recebe o pacote integral depois da autorização da rodada. Defesa, acusação/advogado do diabo e mediador continuam recebendo projeções conforme o nível de visibilidade escolhido.

### Segurança

- o contexto original não fica em claro no banco;
- a chave usa `CONCILIUM_AI_CONTEXT_ENCRYPTION_KEY`, com fallback controlado para a chave do cofre de IA existente;
- sem chave válida, a exploração pode continuar, mas o handoff seguro para a Arena é recusado;
- o pacote não é colocado em URL;
- a abertura é auditada.

## Interface
O botão de encaminhar a síntese final à Arena agora leva também o identificador da síntese. A página da Arena recupera o pacote protegido e preenche:

- conteúdo original para o supervisor;
- contexto estratégico separado;
- objetivo de estresse adversarial;
- visibilidade padrão protegida para as IAs derivadas.

## Implementação

- `originalContextEncrypted` na exploração;
- migração `0026_strategy_arena_context_handoff.sql`;
- `encryptAiContext`/`decryptAiContext`;
- rota `getStrategyArenaHandoff`;
- campo `strategistContext` na abertura da Arena;
- supervisor recebe contexto estratégico no prompt;
- auditoria do handoff.

## Estado
Fluxo implementado no código. A execução real depende da chave configurada, banco, build e provedores. Explorações antigas sem contexto cifrado exigirão nova exploração para usar este handoff seguro.
