# Concilium — checkpoint da fase 33

## Teste do Bibliotecário: alimentos e despesas da residência
Foi criado um caso de teste com a pergunta:

> Estou morando na mesma casa que minha ex-cônjuge e pagando as compras de supermercado do mês. Posso utilizar uma cláusula compensatória para substituir ou evitar o envio de dinheiro diretamente a ela?

## Comportamento esperado

A pergunta é classificada como `strategy_handoff`, porque pede aplicação ao caso e possível substituição de uma obrigação. Mesmo assim, o Bibliotecário deve pesquisar fontes neutras e padrões de cláusulas, ativando também o curador de cláusulas.

A resposta deve separar:

- alimentos entre ex-cônjuges;
- pagamento direto e prestação in natura;
- despesas de moradia e alimentação;
- necessidade de acordo, homologação ou decisão;
- prova e finalidade dos pagamentos;
- risco de liberalidade ou inadimplemento;
- modelos de cláusula não normativos;
- fontes contrárias, vigência e limites.

O teste proíbe uma conclusão automática de que compras de supermercado substituem alimentos ou eximem qualquer obrigação.

## Arquivos

- `shared/librarianWorkflow.ts`;
- `shared/librarianWorkflow.test.ts`;
- `tests/LIBRARIAN_TEST_ALIMENTOS_EX_CONJUGE.md`.

## Estado
Teste e roteamento preparados. A busca real depende da conexão do Knowledge Service e não foi executada.
