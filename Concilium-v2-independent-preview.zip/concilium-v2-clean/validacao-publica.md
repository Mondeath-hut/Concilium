# Verificação pública da versão publicada

## 21 de agosto de 2026

A página pública publicada em `https://concilium-byrsnrmc.manus.space/` carregou com os pontos de entrada **Acessar** e **Área reservada** visíveis, sem iniciar autenticação automaticamente.

Foi feita uma navegação direta, em sessão sem autenticação, para `https://concilium-byrsnrmc.manus.space/espaco`. A tela apresentou inicialmente o estado transitório **“Abrindo espaço de trabalho…”** e, após a consulta de sessão, encaminhou para `/ativacao`. A página resultante informou que a conta titular já está configurada e exibiu apenas o fluxo **“Confirmar com passkey”**, com TOTP e códigos de recuperação descritos como contingência. Não foi executada autenticação, cerimônia de passkey ou acesso a dados protegidos nesta validação.

Esta evidência não substitui a validação do titular em um dispositivo com passkey cadastrada, necessária para confirmar a cerimônia biométrica e o acesso ao espaço interno autenticado.
