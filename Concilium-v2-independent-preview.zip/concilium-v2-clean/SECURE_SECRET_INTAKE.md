# Ingestão segura do cofre de credenciais

## Princípio
O arquivo criptografado é um transporte, não o cofre definitivo. Os segredos não devem passar pelo chat, não devem ser exibidos após a configuração e não devem ser copiados indiscriminadamente para módulos.

## Fluxo recomendado

```text
Arquivo 7z criptografado
        ↓
Ambiente de implantação / wizard seguro
        ↓
Senha digitada em campo protegido
        ↓
Descriptografia em memória
        ↓
Validação de manifesto e nomes
        ↓
Confirmação do titular
        ↓
Cofre de segredos cifrado
        ↓
Referências por módulo, com privilégio mínimo
```

## Manifesto público

O wizard deve carregar um manifesto contendo somente nomes, finalidade, consumidor, sensibilidade e método de configuração. O manifesto não contém valores secretos. A primeira versão está em `shared/secretManifest.ts` e é exposta pela consulta protegida `getSecretIntakeManifest`.

## Mapeamento conhecido

| Segredo | Módulo consumidor | Regra |
|---|---|---|
| `CONCILIUM_BOOTSTRAP_CODE` | ativação inicial | uso controlado, auditado e desativado/rotacionado após bootstrap |
| `CONCILIUM_MFA_ENCRYPTION_KEY` | autenticação e TOTP | nunca expor; não confundir com o segredo 2FA |
| `CONCILIUM_AI_CREDENTIAL_ENCRYPTION_KEY` | cofre de credenciais de provedores | cifra API keys; somente módulo de credenciais/despacho pode acessar |
| segredo do autenticador 2FA | conta/autenticador | material altamente sensível; não é chave de cifragem |
| códigos de recuperação | recuperação da conta | uso único; guardar como hashes quando possível; não enviar a modelos |
| chave mestre | depende do contrato definido | não mapear automaticamente sem confirmar a finalidade |
| chave de cifragem | depende do contrato definido | não mapear por semelhança de nome; identificar escopo e rotação |

## Manifesto interno

O pacote deverá conter, quando possível, um arquivo `concilium-secrets.manifest.json`. Ele deve declarar somente os nomes das entradas e metadados não secretos. A validação extrai nomes, compara com o catálogo esperado e retorna apenas ausências, desconhecidos e duplicidades. Valores presentes no manifesto nunca entram no relatório.

O manifesto não substitui a validação do valor. Ele apenas impede que uma entrada seja encaminhada ao módulo errado por engano.

## Plano de roteamento

Depois da validação dos nomes, o sistema cria um plano com estado `proposed`. Nenhuma entrada é armazenada automaticamente. A aprovação humana transforma somente os nomes confirmados em `approved`; entradas não confirmadas e nomes desconhecidos ficam bloqueados. `CHAVE_MESTRE` e `CHAVE_DE_CIFRAGEM` permanecem bloqueadas até que sua finalidade, escopo, algoritmo e rotação sejam definidos.

## Cofre cifrado

Foi preparado um formato versionado de registro para armazenamento: AES-256-GCM, com IV e tag de autenticação independentes por entrada. O registro contém nome, consumidor, versão, algoritmo e valor cifrado; nunca contém o valor em claro. A chave do cofre precisa ter pelo menos 32 caracteres e é derivada por SHA-256 apenas para uso criptográfico.

A função de descriptografia é interna e deve ser chamada somente por módulo autorizado, após aprovação do plano de roteamento. A limpeza de buffers mutáveis é disponibilizada como medida adicional, sem prometer apagar cópias internas do runtime.

## Orquestrador

O orquestrador agora separa o pipeline em etapas injetáveis: leitor temporário do pacote, manifesto, plano aprovado e escritor do cofre. Ele recusa planos pendentes ou bloqueados antes de abrir o pacote, exige correspondência entre manifesto e plano, rejeita entradas extras ou ausentes, grava somente registros cifrados e encerra o leitor ao final. Os valores são tratados como buffers temporários e limpos após cada entrada.

O leitor 7z foi isolado em `server/sevenZipMemoryReader.ts`, usando `7z-wasm` e o filesystem virtual do WASM. O arquivo é copiado para a memória do módulo, extrações são pontuais e os arquivos virtuais são removidos ao terminar. O leitor não cria diretório temporário e o orquestrador não recebe senha nem conhece o formato do arquivo.

O adaptador exige nomes de entrada simples, sem caminhos, e extrai somente o manifesto fixo e os nomes aprovados. A senha fica em buffer temporário; a limpeza é executada no encerramento, embora o runtime JavaScript não permita prometer apagamento de toda cópia interna.

## Regras de implementação

1. senha do 7z nunca é armazenada;
2. valores não aparecem em respostas, logs, auditoria, prompts ou mensagens de erro;
3. o arquivo pode ser descriptografado em memória ou localmente, sem persistir uma cópia aberta;
4. o sistema valida nomes, tamanho, formato e duplicidade antes de aceitar cada segredo;
5. o titular confirma o mapeamento sem visualizar novamente os valores;
6. cada módulo recebe uma referência ou variável específica, não o cofre inteiro;
7. API keys só são usadas pelo adaptador do respectivo provedor;
8. códigos de recuperação não são enviados a nenhuma IA;
9. rotação e revogação devem ser possíveis sem alterar o código;
10. qualquer falha limpa buffers temporários e mantém o arquivo original intocado.

## Chat seguro

O chat do Concilium não deve ser usado como cofre de chaves. Mesmo em uma conversa privada, não se deve digitar senha, código de bootstrap, segredo 2FA, chave de cifragem ou API key.

A alternativa futura é um wizard seguro dentro da própria aplicação, com TLS, campo de senha, processamento controlado e confirmação sem revelar os valores. Isso exige implementação e validação específicas; não deve ser improvisado por uma mensagem do chat.

## Estado

As nomenclaturas conhecidas já permitem mapear três variáveis do código. “Chave Mestre” e “Chave de Cifragem” permanecem pendentes de contrato funcional; o nome sozinho não é suficiente para decidir onde serão usadas.
