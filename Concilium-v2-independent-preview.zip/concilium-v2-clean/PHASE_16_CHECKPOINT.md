# Concilium — checkpoint da fase 16

## Síntese progressiva das linhas
O Laboratório agora trata cada encerramento como uma contribuição para uma síntese que cresce por etapas.

- quando uma linha termina, sua conclusão entra em uma síntese incremental;
- as linhas ainda ativas ou aguardando resposta não são tratadas como concluídas;
- quando a última linha termina, é gerada uma síntese final;
- a síntese final mantém convergências, divergências, premissas, riscos e pendências;
- nenhuma linha é reaberta automaticamente por causa da síntese.

## Separação preservada
A síntese pode considerar todas as linhas encerradas, mas não mistura os históricos durante a geração de cada alternativa. A linha patrimonial continua patrimonial; a linha familiar continua familiar; a linha processual continua processual.

## Fluxo completo

```text
Pergunta inicial
  → linhas independentes
  → algumas encerram
  → síntese incremental
  → outras continuam perguntando
  → novas sínteses incrementais
  → última linha encerra
  → síntese final abrangente
  → seleção para Bibliotecário/Arena
```

## Estado técnico
Foram adicionados registros de síntese incremental/final e prompt específico para consolidar somente linhas encerradas. A interface exibe as sínteses progressivas dentro da exploração.

## Próximo marco
Permitir que o titular aprove a síntese final, selecione quais conclusões irão para a Arena e mantenha as demais apenas como alternativas arquivadas.
