# Concilium — checkpoint da fase 7

## Refinamento da Arena de IAs
A arquitetura foi ajustada para separar coordenação, análise e continuidade:

- o supervisor recebe `integral_autorizado` como nível próprio e invariável;
- o supervisor recebe uma pauta integral para manter o raciocínio avançando;
- o titular pode registrar intervenção/pergunta durante uma rodada ativa;
- as demais IAs recebem projeção automática conforme papel e limite autorizado;
- auditor crítico com contexto sensível tende a receber conteúdo redigido;
- mediador e defensor recebem contexto protegido por padrão;
- conteúdo integral para as demais IAs continua exigindo autorização expressa;
- cada execução registra o nível efetivamente transmitido e os hashes correspondentes.

## Rodadas isoladas
Foram adicionados:

- número sequencial da rodada;
- vínculo opcional com a rodada anterior;
- estados `active`, `collapsed` e `closed`;
- pauta do supervisor;
- síntese da rodada;
- aprovação humana da síntese;
- mensagens de intervenção do titular e coordenação;
- ação para abrir uma rodada em página separada;
- continuidade condicionada à síntese aprovada.

A interface agora recolhe rodadas anteriores em painéis independentes, mantendo a rodada ativa aberta para acompanhamento e intervenção.

## Regra de continuidade
A nova rodada não é uma continuação textual infinita. Ela só pode usar a síntese anterior depois que o titular a revisar e aprovar. O conteúdo de origem ainda precisa ser autorizado novamente na nova rodada.

## Limitações atuais
- o supervisor ainda é executado pelo primeiro modelo selecionado como camada de coordenação; a separação futura de um provedor/modelo supervisor dedicado permanece prevista;
- síntese automática final das respostas ainda precisa ser refinada;
- build, testes e migrações continuam pendentes de execução em ambiente com dependências e banco configurados.
