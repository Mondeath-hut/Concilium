# Concilium — checkpoint da fase 58

## Persistência e revisão de ramificações

A arquitetura de ramificações dinâmicas foi conectada ao backend.

### Funcionalidades preparadas

- respostas do Laboratório podem registrar `RAMIFICACAO_PROPOSTA` e `MOTIVO_RAMIFICACAO`;
- cada proposta é vinculada à linha de origem;
- propostas podem ser listadas por exploração;
- o titular/supervisor pode selecionar propostas relacionadas;
- o servidor compõe uma pergunta preliminar para o Estrategista;
- o pacote fica reservado em `ready_for_strategist`;
- o pacote pode ser marcado como `submitted`, `resolved` ou `dismissed`;
- cada alteração é auditada;
- somente as propostas selecionadas são marcadas como agrupadas.

### Rotas protegidas

- `listStrategyBranchProposals`;
- `composeStrategyBranchBundle`;
- `updateStrategyBranchBundleState`.

### Garantia

A composição não reescreve a linha original nem envia automaticamente a nova pergunta ao Estrategista. A submissão continua sendo uma ação explícita.

## Estado

Persistência e rotas de revisão preparadas. A interface visual de caixa de ramificações e a criação de uma nova exploração a partir de um pacote submetido permanecem como próximas etapas.
