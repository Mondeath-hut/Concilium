# Concilium — checkpoint da fase 22

## Triagem da Arena revisada
A Arena não deve funcionar como filtro moral. Uma tese, conduta ou resultado moralmente repulsivo pode continuar sendo juridicamente arguível e relevante para a defesa, desde que a análise e a execução permaneçam dentro dos meios lícitos.

A triagem passou a separar:

1. possibilidade jurídica;
2. força da fonte, prova e grau de incerteza;
3. moral, ética, risco profissional e impacto social;
4. risco operacional de uma instrução ilícita.

## Barreiras

- tese controversa ou improvável: permanece visível, com fontes contrárias, dependências e alerta;
- tese sem fonte localizada: marcada como não verificada, sem ser chamada automaticamente de ilegal;
- tese contradita por fonte vigente: não entra como fundamento confirmado;
- fonte estrangeira ou fora da competência: não sustenta o caso solicitado;
- fraude, ameaça, violência, obstrução, fabricação/destruição de prova e condutas ilícitas: bloqueadas como instruções operacionais;
- defesa jurídica lícita de pessoa acusada de ato grave: não é bloqueada por reprovação moral.

## Código atualizado
`shared/aiForumPolicy.ts` agora contém estados de triagem e instruções explícitas para supervisor e IAs, exigindo separação entre legalidade, incerteza e avaliação moral/ética.

## Implementação ainda pendente
Os estados foram incorporados ao contrato de orientação e aos prompts. O registro persistente da classificação por argumento, o validador independente de fontes e os testes automatizados da Arena ainda precisam ser implementados e validados em ambiente executável.
