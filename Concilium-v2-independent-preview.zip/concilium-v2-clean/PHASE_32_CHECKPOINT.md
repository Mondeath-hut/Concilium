# Concilium — checkpoint da fase 32

## Bibliotecário em ensemble e roteamento
O Bibliotecário deixou de ser modelado como uma única voz. A camada de contrato agora permite distribuir consultas por funções independentes:

- fonte primária;
- jurisprudência;
- vigência e jurisdição;
- curadoria de cláusulas e modelos;
- fontes contrárias e limites.

A consolidação deve trabalhar com resultados, metadados, fontes e divergências verificáveis, sem receber o caso protegido por padrão.

## Modos de consulta

- `sources`: fontes e precedentes;
- `clause_models`: cláusulas e modelos de minuta não normativos;
- `strategy_handoff`: pergunta que deve acompanhar uma exploração do Estrategista.

A interface passou a permitir escolher o modo. O sistema também classifica automaticamente a pergunta e mostra o roteamento recomendado.

## Fronteira entre módulos

- o Bibliotecário recupera e qualifica;
- o Estrategista formula alternativas para o contexto autorizado;
- a Arena estressa e compara;
- o titular decide.

## Implementação

- `shared/librarianWorkflow.ts`;
- `shared/librarianWorkflow.test.ts`;
- contrato atualizado em `shared/knowledgeService.ts`;
- roteamento em `server/routers/knowledge.ts`;
- seletor e encaminhamento na Biblioteca;
- `LIBRARIAN_ENSEMBLE_AND_ROUTING.md`.

## Estado de validação
Contrato, classificação, interface e teste unitário preparados. O Knowledge Service externo e o ensemble real ainda não estão conectados nem validados.
