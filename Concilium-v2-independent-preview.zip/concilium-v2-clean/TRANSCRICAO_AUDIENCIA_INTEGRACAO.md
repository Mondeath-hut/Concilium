# Integração segura de transcrição para audiências

## Escopo da primeira publicação

A aplicação não substitui Teams, Google Meet, Zoom ou Webex e não cria videoconferência própria.

A primeira versão oferece:

1. importação autorizada de transcrição;
2. upload controlado de áudio para transcrição, quando habilitado pelo titular;
3. processamento preferencial em `pt-BR`;
4. apresentação da transcrição original e de uma versão normalizada;
5. revisão e confirmação humana antes de criar proposta, aceite, recusa ou alteração de cenário;
6. associação manual de trechos a itens do checklist;
7. marcação de baixa confiança, orador e horário;
8. nenhuma gravação automática ou envio de conteúdo a terceiros.

## Permissões

- microfone: solicitar somente quando o usuário iniciar captura de áudio;
- câmera: não solicitar para o módulo de transcrição;
- transcrição: exigir consentimento e mostrar estado ativo;
- gravação: ficar preferencialmente na plataforma oficial da audiência;
- áudio bruto: retenção mínima, acesso restrito e exclusão configurável.

## Qualidade em português brasileiro

Usar como configuração padrão:

```text
language: pt
locale/context: pt-BR
```

O contexto de transcrição deve incluir, quando autorizado pelo usuário, nomes próprios, termos jurídicos, nomes de documentos e vocabulário do caso. Isso não autoriza transformar hipótese em fato.

O sistema deve tolerar:

- repetições;
- “é”, “né” e outros preenchimentos;
- gagueira;
- pausas;
- frases incompletas;
- sobreposição de falas;
- ruído e baixa confiança.

## Duas representações

### Original

Preservar o texto retornado pelo serviço, segmentos, horários, orador quando disponível, confiança e eventuais erros.

### Normalizada

Gerar somente para leitura e análise, reduzindo preenchimentos e repetições sem alterar negações, valores, prazos, nomes ou condições. A versão normalizada nunca substitui a original.

## Confirmação obrigatória

Quando o Estrategista detectar possível proposta, aceite, recusa ou condição, mostrar:

```text
Possível termo identificado
Trecho original
Versão normalizada
Horário
Orador
Confiança
[Confirmar] [Corrigir] [Manter pendente]
```

Somente “Confirmar” pode gerar registro formal.

## Alertas de baixa confiança

Marcar para revisão humana qualquer trecho que contenha:

- valores;
- datas;
- prazos;
- percentuais;
- nomes próprios;
- negação;
- renúncia;
- aceite ou recusa;
- alteração de cenário.

## Arquitetura de provedores

A integração deve ser baseada em uma interface de provedor, sem acoplar o Concilium a uma plataforma específica. A chave deve ficar exclusivamente em Secrets. O sistema deve permitir trocar o provedor sem alterar o histórico ou a camada de análise.

A primeira publicação pode usar a transcrição oficial do Teams/Meet importada manualmente. Integrações por API, webhooks ou processamento ao vivo ficam para etapa posterior e exigem consentimento e permissões institucionais.

## Proibições

- não iniciar gravação sem confirmação;
- não solicitar câmera sem necessidade;
- não enviar a transcrição para outro participante;
- não aceitar acordo automaticamente;
- não alterar o histórico formal sem confirmação;
- não apagar a transcrição original ao normalizar;
- não tratar transcrição como prova definitiva sem revisão;
- não mostrar painel privado na tela compartilhada.
