# Validação visual de temas

## 20 de agosto de 2026

- A interface pública foi verificada em desktop com o tema **Azul-noturno**: hero, cartões, fluxo de segurança, seção móvel, privacidade e rodapé usam superfícies coerentes.
- O painel de configurações foi aberto e confirmou a presença dos cinco temas: Azul-noturno, Claro editorial, Verde-pinho, Grafite e Âmbar original.
- O tema **Âmbar original** foi selecionado pela interface. A janela de configurações permaneceu aberta e acompanhou os tokens claros de marfim/âmbar, enquanto a página manteve a hierarquia de superfícies profundas apenas onde o componente exige contraste.
- O tema **Verde-pinho** também foi selecionado pela interface. Cabeçalho, sobreposição, diálogo, cartões de perfil, opções de tema e área de proteção passaram simultaneamente para os tons verdes, sem herdar o fundo azul-noturno.
- A validação automatizada cobre a troca, persistência e estado claro/escuro de todas as cinco opções.

As cinco variantes também foram renderizadas por meio da prévia controlada `?theme=` nos formatos desktop (1280 × 720 px) e móvel (375 × 812 px). Em ambas as larguras, a hierarquia do hero, cartões, fluxo de segurança, telefone demonstrativo, blocos de privacidade e rodapé permaneceu legível e sem mistura visual entre paletas.

O painel de configurações foi revisado separadamente com `?theme=<tema>&panel=settings` para as cinco variantes nos dois tamanhos. O diálogo aplicou corretamente fundo, bordas, tipografia, cartões de perfil, estados selecionados e o controle de fechamento; em celular, a altura foi limitada ao viewport e o conteúdo permaneceu rolável. Após essa revisão, a suíte passou com **12 testes** e o build de produção foi concluído sem erro.

## Revisão de contrastes internos — 20 de agosto de 2026

Após a separação dos tokens de mockup, dispositivo e encerramento, as cinco variantes foram novamente capturadas em celular (375 × 812 px) e desktop (1280 × 720 px). A comparação confirmou que os cartões de demonstração não reutilizam mais a camada azul-profunda como cor implícita: cada um acompanha a sua variante, sem perder legibilidade ou a intenção de profundidade visual.

| Tema | Hero e segurança | Mockup do dispositivo | Encerramento e rodapé | Resultado |
|---|---|---|---|---|
| Azul-noturno | Painéis azul-profundo coerentes. | Moldura e cartão usam azul institucional. | Chamada final azul-noturno. | Aprovado. |
| Claro editorial | Fundos claros e painel demonstrativo grafite neutro. | Moldura e conteúdo claros, sem azul residual. | Chamada final grafite. | Aprovado. |
| Verde-pinho | Superfícies verdes em continuidade. | Moldura, cartão e detalhes em verde-pinho. | Chamada final verde profundo. | Aprovado. |
| Grafite | Tons neutros de grafite em todos os painéis. | Moldura e cartão cinza-grafite. | Chamada final grafite profundo. | Aprovado. |
| Âmbar original | Marfim e ouro com painéis escuros oliva/carvão. | Moldura preta e cartão escuro da paleta original. | Chamada final carvão/oliva, sem azul-noturno. | Aprovado. |

### Componentes e tokens revisados

| Componente corrigido | Classes finais | Tokens temáticos consumidos | Proteção contra regressão |
|---|---|---|---|
| Demonstração do hero | `.concilium-showcase-card`, `.concilium-showcase-inner` | `--concilium-showcase-card`, `--concilium-showcase`, `--concilium-showcase-border` | O cartão deixou de usar `.concilium-deep-card`, que concentrava a profundidade institucional genérica. |
| Painel de segurança | `.concilium-showcase`, `.concilium-showcase-soft-card` | `--concilium-showcase`, `--concilium-showcase-ink`, `--concilium-showcase-copy`, `--concilium-showcase-soft` | Título, descrição e cartões de apoio respondem ao tema do painel, não ao hero. |
| Mockup do dispositivo | `.concilium-device-shell`, `.concilium-device-notch` | `--concilium-device-shell` | A moldura e o entalhe assumem explicitamente a cor definida em cada uma das cinco variantes. |
| Encerramento institucional | `.concilium-callout` | `--concilium-callout`, `--concilium-callout-soft`, `--concilium-callout-border` | A chamada final não reutiliza mais a camada azul-profunda de navegação. |

Além da inspeção visual, `Home.tsx` foi revisado para confirmar o uso dessas classes nos quatro componentes. O arquivo não contém cores hexadecimais em superfícies de interface; as únicas cores diretas da página são as miniaturas de prévia do seletor de temas, cuja finalidade é justamente representar cada paleta.

## Ativação titular e área interna — 20 de agosto de 2026

As rotas `/ativacao` e `/app` foram capturadas na prévia desktop após o ajuste de nomenclatura da rota. A ativação deixou de retornar 404 e apresenta corretamente nome, e-mail institucional e código único em um assistente de quatro etapas. Sem o cookie de sessão própria do titular, `/app` não exibe dados internos e oferece somente o retorno para o assistente de passkey.

| Tema | Rota `/ativacao` | Legibilidade e contraste | Resultado |
|---|---|---|---|
| Azul-noturno | Painéis azul-profundo e destaque dourado. | Formulários e texto claros. | Aprovado. |
| Claro editorial | Superfície editorial clara e painel lateral grafite. | Campos, bordas e textos distinguíveis. | Aprovado. |
| Verde-pinho | Painéis verdes coerentes com a paleta. | Destaques e textos preservam a leitura. | Aprovado. |
| Grafite | Hierarquia neutra em grafite. | Controle principal e campos mantêm contraste. | Aprovado. |
| Âmbar original | Marfim, ouro e painel oliva/carvão. | Campo e botão distinguíveis sem azul residual. | Aprovado. |

Em tela móvel (375 × 812 px), as mesmas cinco variantes mantiveram o painel lateral e o formulário empilhados em sequência, sem sobreposição dos campos ou perda de acesso ao botão de criação da passkey. A leitura dos textos de segurança, da progressão de etapas e dos controles permaneceu preservada em azul-noturno, claro editorial, verde-pinho, grafite e âmbar original.

Na rota `/confirmar-email`, foi validada a superfície de resultado para link ausente ou incompleto: ela comunica o problema sem revelar detalhes do token e oferece retorno claro ao assistente. A rota `/ativacao` passou a apresentar cinco etapas, incluindo a confirmação institucional entre passkey e configuração TOTP, preservando o padrão visual azul-noturno.

Na prévia móvel da rota `/espaco` sem cookie de sessão, observou-se apenas o estado transitório “Abrindo espaço de trabalho…”, pois cada captura inicia uma nova consulta de autenticação. A resposta de rede concluiu sem erro e a cobertura automatizada confirma o redirecionamento para `/ativacao` quando não existe sessão titular. A abertura efetiva do novo espaço interno será confirmada pelo titular no dispositivo com a passkey já cadastrada.
