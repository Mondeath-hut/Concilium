# Concilium — checkpoint da fase 46

## Manifesto e wizard seguro de credenciais
Foi implementada a base pública do futuro wizard de ingestão de segredos, sem receber ou expor qualquer valor secreto.

### Manifesto
O sistema conhece nomes, finalidade, consumidor, sensibilidade e método de configuração para:

- bootstrap;
- MFA;
- cofre de credenciais de IA;
- cifra de contexto de IA;
- autenticador 2FA;
- recuperação;
- chaves mestre e de cifragem ainda pendentes de contrato.

### Validação
A validação trabalha somente com nomes de entradas, detectando:

- ausências;
- nomes desconhecidos;
- duplicidades;
- entradas aceitas.

Valores, senhas e tokens não entram nessa API.

## Implementação

- `shared/secretManifest.ts`;
- `shared/secretManifest.test.ts`;
- consulta protegida `getSecretIntakeManifest`;
- documentação atualizada em `SECURE_SECRET_INTAKE.md`.

## Limite
O wizard que recebe o arquivo `.7z`, solicita a senha em campo protegido e descriptografa em memória ainda depende de uma etapa própria de armazenamento seguro e suporte controlado ao formato 7z. O manifesto não abre o arquivo e não acessa os segredos.
