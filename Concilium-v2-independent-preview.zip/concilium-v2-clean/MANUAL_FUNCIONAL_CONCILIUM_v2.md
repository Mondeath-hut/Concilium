# Concilium — Manual funcional e visão do produto (v2)

> Atualiza o `MANUAL_FUNCIONAL_CONCILIUM_v1.md`. Tudo da v1 permanece válido; o que muda ou se soma está marcado como **[NOVO v2]**. Ver também `CONCILIUM_linha_do_tempo_e_decisoes.md` para o histórico de como se chegou a cada decisão.

## 1. O que é o Concilium

O Concilium é uma sala operacional privada para organizar fatos, documentos, cenários, propostas e decisões em situações complexas, especialmente negociações familiares, patrimoniais e financeiras.

Ele não substitui advogado, defensor público, mediador, juiz ou a decisão do titular. Seu papel é transformar informações dispersas em uma estrutura verificável para análise, negociação, preparação de audiência e acompanhamento de consequências.

O sistema deve distinguir claramente:

- fato comprovado;
- relato do usuário;
- hipótese;
- premissa dependente de prova;
- proposta;
- contraproposta;
- alerta;
- decisão autorizada;
- análise interna da IA.

**[NOVO v2] Base técnica escolhida**: entre as duas linhas de desenvolvimento existentes, a base do produto é a linhagem **Manus/Fullstack (v1 → v3 corrigida)** — é a única com autenticação própria madura (JWT + passkey + TOTP), cofre de segredos, e o motor de regras de negócio (Estrategista, Arena, Laboratório, Checklist) já escrito. A linhagem construída na plataforma Grok não entra como código; duas ideias pontuais dela são aproveitadas (ver seção 8-A e seção 16).

**[NOVO v2] Relação com a ACA**: o Concilium **não depende** da plataforma arquitetural ACA (Adaptive Composition Architecture — Kernel/Registry/Composition Engine/Event Bus) para funcionar. Essa decisão foi tomada explicitamente para permitir entregar o Concilium como aplicação standalone primeiro; a ACA continua como visão de plataforma para o futuro, onde o Concilium poderia um dia ser "replugado" como um módulo entre outros (inventário, holding familiar, etc.).

## 2. Princípios do produto

- Privacidade por padrão.
- O titular mantém controle sobre decisões e comunicações.
- Nenhuma IA aceita, rejeita ou envia acordo autonomamente.
- Estratégias internas não se confundem com histórico formal da negociação.
- Fontes devem ser verificadas quanto a jurisdição, vigência, autoridade, data e escopo.
- Incertezas devem aparecer, nunca ser preenchidas por invenção.
- Propostas devem evoluir do cooperativo ao defensivo somente quando autorizadas.
- O sistema deve favorecer soluções sustentáveis para ambas as partes antes do impasse.
- Dados sensíveis não devem aparecer no frontend público, logs, exportações indevidas ou código.

## 3. Usuário principal e acesso

A primeira versão é uma sala privada do titular. O fluxo previsto é:

```text
bootstrap de uso único
→ identificação do titular
→ passkey/WebAuthn ou biometria do dispositivo
→ códigos de recuperação
→ espaço privado do titular
```

Não depender de login da plataforma de desenvolvimento. Resend, e-mail confirmado, TOTP e passkeys adicionais são camadas opcionais posteriores, não requisitos do primeiro acesso.

Não criar backdoor, senha universal ou código oculto.

## 4. Arquitetura conceitual

### 4.1 Espaço do titular

Área privada com:

- fatos e cronologia;
- documentos;
- cenários;
- estratégias;
- limites;
- análises da IA;
- pontos fracos;
- inegociáveis;
- preparação de propostas;
- histórico interno de decisões.

### 4.2 Mesa formal de negociação

Área que registra somente o que foi efetivamente apresentado ou recebido:

- proposta;
- contraproposta;
- resposta;
- itens aceitos;
- itens recusados;
- itens pendentes;
- versões e horários.

Uma proposta apresentada nunca deve ser alterada silenciosamente. Alterações geram nova versão.

### 4.3 Arena

Ambiente para submeter teses, propostas e interpretações a análises independentes, críticas, defesa, acusação ou advogado do diabo, coordenadas por supervisor.

A Arena trabalha por rodadas isoladas e comparáveis. Uma rodada pode continuar aberta para intervenção. Ao iniciar outra, a anterior é recolhida com síntese, definições e considerações finais.

O supervisor pode ter acesso integral autorizado. Outras IAs recebem apenas o nível de contexto permitido na rodada: protegido, redigido ou integral autorizado.

### 4.4 Laboratório de Alternativas

Ambiente divergente para gerar possibilidades sem decidir imediatamente.

Cada linha de raciocínio deve permanecer independente e interativa. Perguntas semelhantes podem ser agrupadas visualmente, mas respostas não devem contaminar linhas divergentes. Ideias selecionadas podem ir para a Arena.

### 4.5 Bibliotecário / Knowledge Service

Acervo jurídico e documental separado dos dados operacionais do caso.

O sistema recupera somente resultados necessários, com:

- fonte;
- versão;
- data de consulta;
- jurisdição;
- autoridade;
- escopo;
- limitações;
- situação de vigência;
- citações verificáveis.

Não enviar dados sensíveis do caso ao acervo por padrão.

## 5. Documentos e evidências

Permitir importar, classificar, visualizar e relacionar documentos sem confundir documento com fato provado.

Cada item pode indicar:

- origem;
- data;
- tipo;
- assunto;
- pessoas relacionadas;
- fato que pretende comprovar;
- grau de confiabilidade;
- lacunas;
- cenário relacionado;
- status de revisão.

Documentos sensíveis podem passar por quarentena antes de serem usados.

O pacote 7z protegido deve ser tratado como artefato opaco e separado. Não abrir, extrair ou importar automaticamente. A senha nunca deve aparecer no chat, código, README, log ou manifesto.

## 6. Fatos e cronologia

A cronologia deve separar:

- data conhecida;
- data aproximada;
- evento;
- fonte;
- participantes;
- consequência;
- grau de certeza;
- contradições.

O sistema deve permitir identificar quando uma informação é apenas hipótese ou depende de confirmação futura.

## 7. Cenários

Um cenário é uma configuração completa de fatos, premissas, objetivos, parâmetros, restrições, propostas e riscos.

Cada cenário contém:

- nome;
- finalidade;
- parâmetros;
- fatos utilizados;
- premissas;
- restrições;
- interesses de cada parte;
- checklist;
- alertas;
- argumentos;
- evidências;
- contestações prováveis;
- concessões possíveis;
- pontos inegociáveis;
- contrapropostas;
- plano de migração para outro cenário.

### Progressão padrão

1. Cooperativo — menor impacto conjunto.
2. Cooperativo protegido — mais garantias.
3. Equilibrado — menos concessões recíprocas.
4. Defensivo — proteção individual maior.
5. Impasse — posição final e alternativas formais.

A passagem entre cenários exige autorização do titular, com registro de motivo, data, versão anterior e nova versão.

**[NOVO v2 — implementado]**: os 5 estágios já existem como campo estruturado (`stage` em `ownerCaseNegotiationScenarios`), com `previousScenarioVersionId`/`migrationReason`/`migratedBy`/`migratedAt` — a migração sem motivo é rejeitada em código (`shared/scenarioParameters.ts`, `assertValidScenarioMigration`), com testes cobrindo avanço, retrocesso e motivo obrigatório.

## 8. Estratégias e Estrategista

O Estrategista pode:

- comparar cenários;
- calcular impactos conforme parâmetros;
- identificar conflitos;
- apontar riscos;
- criar checklists;
- preparar argumentos;
- sugerir concessões;
- formular contrapropostas;
- sugerir migração de cenário;
- detectar dependência de fato não confirmado.

O Estrategista não pode:

- decidir pelo titular;
- aceitar ou rejeitar acordo;
- afirmar que alguém agiu de má-fé;
- transformar hipótese em fato;
- enviar mensagem automaticamente;
- apresentar uma proposta sem autorização.

## 8-A. Atores interativos [NOVO v2]

Cada papel (Estrategista, Supervisor, Bibliotecário, Defesa, Advogado do Diabo, Mediador) ganha um retrato clicável na interface — **sem nome próprio**, só o papel. Ao clicar, abre um chat dedicado àquele papel, usando os mesmos prompts e as mesmas regras de acesso por nível de contexto que já existem (seção 4.3).

Cada ator continua limitado ao que sua função permite ver — o Bibliotecário, por exemplo, nunca recebe o dossiê completo do caso, só o necessário para a busca jurídica, mesmo na interface de chat.

**Entrada e saída por voz**: você pode falar com qualquer ator em vez de digitar. Texto→fala (a resposta do ator sendo lida em voz alta) é a única peça nova a construir; fala→texto reaproveita a transcrição que o sistema já usa em outros pontos.

## 9. Checklist dinâmico

O checklist é administrado pelo Estrategista conforme parâmetros aprovados pelo titular.

Cada item deve conter:

- descrição;
- categoria;
- prioridade;
- status;
- condição de aceitação;
- evidência;
- risco;
- resposta preparada;
- observação da audiência.

Categorias:

- interesse do titular;
- interesse da outra parte;
- negociável;
- inegociável / exige pausa;
- pergunta;
- condição;
- pendente de prova.

Status:

- pendente;
- aceito;
- recusado;
- parcialmente aceito;
- substituído;
- dependente de confirmação.

**[NOVO v2 — implementado]**: além das regras e alertas, agora existe a tabela (`concilium_checklist_items`) e a rota tRPC (`checklist.*` em `server/checklist.ts`) que transformam a regra em funcionalidade de verdade — criar, listar e mudar o estado de um item já funciona ponta a ponta.

## 9-A. Alimentando o checklist durante a negociação ao vivo [NOVO v2]

O checklist pode ser alimentado de duas formas, com o mesmo motor por trás:

**Modo ao vivo** — o Concilium capta o áudio da reunião (Teams, Zoom ou Meet, rodando no navegador) enquanto você participa. O áudio é transcrito em pedaços curtos (~20–30s) e cada trecho passa pelo mesmo analisador de fala que já existe no sistema, que sinaliza: possível aceite, possível recusa, possível proposta, ou menção a valor/prazo — **sempre pedindo sua confirmação, nunca decidindo sozinho**.

**Modo manual (ditado)** — se não for possível conectar a reunião ao vivo, você mesmo fala ou digita a informação direto na sala (ex.: *"minha ex-esposa está pedindo pensão de dois mil reais"*). O mesmo motor analisa a frase; muda só a origem do dado, não o comportamento.

Em ambos os modos, o motor de comparação com o cenário ativo funciona em 3 camadas, cada uma um substituto da anterior quando ela não está disponível:

1. **Online** — usa a IA já conectada ao sistema para comparar sua fala com os itens do checklist e os parâmetros do cenário. Melhor qualidade.
2. **Local (offline)** — um modelo pequeno de reconhecimento de significado embarcado no próprio app, funcionando sem internet, entra automaticamente se a Camada 1 estiver indisponível.
3. **Léxica (sempre disponível)** — dicionário de sinônimos que você cadastra por item ("pensão" → alimentos, mesada, valor mensal) mais extração de números por extenso ("dois mil reais" → 2000), comparado direto contra os parâmetros do cenário (mínimo/ideal/máximo/reserva mínima). Não depende de nenhuma IA.

O sistema sempre indica qual camada gerou cada alerta, para você calibrar a confiança nele.

> **Atenção**: se a reunião for uma audiência oficial de mediação (ex.: CEJUSC), verifique com seu advogado/defensor se gravar a sessão não conflita com a confidencialidade própria da mediação (Lei 13.140/2015) antes de ativar a captação ao vivo nesse contexto.

## 10. Parâmetros financeiros e patrimoniais

Permitir configurar:

- valor estimado do imóvel;
- valor estimado da quota;
- prazo mínimo, ideal e máximo;
- pagamento único ou parcelas;
- índice de correção;
- capacidade atual;
- renda em cenários profissionais diferentes;
- reserva mínima protegida;
- despesas comuns;
- despesas exclusivas;
- compensação por uso exclusivo;
- custos de moradia externa;
- garantias;
- eventos condicionais.

Não presumir que uma despesa pode ser abatida do preço da quota. Isso deve estar previsto formalmente ou ser juridicamente reconhecido.

Separar contabilmente:

- despesas do imóvel;
- compensação pelo uso exclusivo;
- moradia externa do titular;
- despesas de consumo pessoal;
- despesas comuns de conservação.

**[NOVO v2 — implementado]**: os parâmetros já existem como campos estruturados (`concilium_scenario_parameters`: mínimo, ideal, máximo, reserva mínima, unidade), com a comparação de valor observado (`shared/scenarioParameters.ts`, `evaluateParameterValue`) devolvendo verde/amarelo/vermelho, incluindo o caso de violar a reserva mínima.

## 11. Alertas

### Verde

Compatível com parâmetros e executável no cenário informado.

### Amarelo

Depende de fato não confirmado, como emprego, financiamento, venda, aumento de renda ou reconhecimento de crédito.

### Vermelho

Viola inegociável, compromete reserva, exige prazo inviável, cria risco elevado ou contém renúncia ampla sem proteção.

Alertas são informativos. Não produzem decisão automática.

## 12. Índice comparativo

O sistema pode mostrar um índice de atendimento dos interesses de cada parte, desde que os critérios sejam explícitos.

Exemplos de dimensões:

- segurança habitacional;
- preservação patrimonial;
- liquidez;
- previsibilidade;
- prazo;
- risco de inadimplemento;
- impacto financeiro;
- preservação dos interesses dos filhos.

O resultado deve ser chamado de:

```text
índice comparativo de atendimento dos interesses
```

Nunca apresentar como probabilidade de vitória, previsão judicial ou garantia de aceitação.

Mostrar os pesos e as premissas. Se faltarem dados, mostrar "não calculado".

**[NOVO v2 — resolvido]**: o campo `agreementChance` foi renomeado para `strategicPostureScore` (não é mais confundível com previsão de resultado), e o índice comparativo de verdade — multi-dimensão, com pesos visíveis e "não calculado" quando falta dado — foi implementado em `shared/interestAlignmentIndex.ts`.

## 13. Mesa de negociação e histórico

A mesa formal deve registrar a progressão real:

```text
Proposta A
→ contraproposta A.1
→ Proposta B
→ contraproposta B.1
→ Proposta C
```

Cada registro:

- ID;
- autor;
- data e hora;
- texto ou termos objetivos;
- versão anterior;
- itens aceitos;
- itens recusados;
- itens pendentes;
- resposta;
- status;
- próxima ação autorizada.

Status:

```text
Rascunho interno
Apresentada
Recebida
Aceita
Recusada
Aceita parcialmente
Contraproposta recebida
Substituída
Encerrada
```

A interface deve ser neutra. Não dizer que uma parte agiu de má-fé. Mostrar fatos, termos, concessões, recusas e efeitos comparativos.

**[NOVO v2 — resolvido]**: o banco já aceita os 9 estados (migração em `drizzle/schema.ts`), com o grafo de transição validado em código (`shared/hearingChecklist.ts`, `isValidProposalTransition`/`assertValidProposalTransition`) — os três estados que faltavam agora funcionam.

## 14. Negociação inicial pretendida

A primeira abordagem busca uma transição cooperativa:

- moradia provisória;
- tempo para reinserção profissional;
- eventual pensão provisória analisada separadamente;
- preservação do patrimônio;
- compra futura da quota;
- prazo compatível com liquidez real;
- despesas claramente separadas;
- proteção dos filhos;
- revisão e garantias.

Hipóteses de contratação pela Vale, dispensa e seguro-desemprego devem permanecer separadas e nunca ser tratadas como fatos confirmados antes da prova.

## 15. Casos patrimoniais prioritários

O sistema deve permitir comparar:

1. contratação pela Vale;
2. dispensa e seguro-desemprego;
3. compra futura da quota em quatro a oito anos, preferencialmente cerca de cinco;
4. uso exclusivo provisório com compensação acumulada;
5. proteção patrimonial dos filhos;
6. impasse com saída do titular e compensação por uso exclusivo;
7. venda ou dissolução como alternativa de comparação.

A transferência a filhos adultos deve ser tratada apenas como hipótese de alto risco, dependente de análise sobre fraude, credores, regime de bens, tributos, registro, usufruto e validade jurídica.

## 16. Segurança e auditoria

- Registrar alterações e autorizações.
- Não permitir senha universal ou backdoor.
- Usar variáveis de ambiente para segredos.
- Não expor chaves em frontend, logs, exportações ou mensagens.
- Minimizar registros biométricos: guardar credencial, evento e horário, não fotografia biométrica.
- Manter cofre, quarentena e permissões.
- Separar dados do caso da biblioteca jurídica.
- Permitir auditoria de acesso e de mudança.

**[NOVO v2 — resolvido]**: a derivação de chave do cofre agora usa PBKDF2-HMAC-SHA256 (210.000 iterações) com sal aleatório por registro (`server/secretVault.ts`), mantendo leitura compatível com registros antigos gravados antes desta mudança.

## 17. Exportações e uso offline

Permitir exportar separadamente:

- síntese de uma página;
- checklist atual;
- histórico formal da negociação;
- tabela de propostas;
- perguntas da audiência;
- pontos inegociáveis;
- PDF;
- JSON estruturado.

A versão offline não deve enviar dados ao servidor e deve continuar utilizável durante videoconferência.

**[NOVO v2 — implementado]**: as três formas de exportação já existem (`shared/caseExport.ts` monta o pacote único; `server/caseExportPdf.ts` gera o PDF de verdade com `pdf-lib` — texto selecionável, paginação automática). JSON, HTML autônomo (para impressão) e PDF descrevem sempre o mesmo conteúdo, só muda o formato. Rota: `caseExport.buildBundle`.

## 18. Regras de apresentação durante audiência

O usuário deve poder:

- pausar antes de concordar;
- consultar os efeitos patrimoniais;
- comparar cenários;
- registrar a proposta sem aceitá-la;
- pedir esclarecimento;
- gerar uma contraproposta;
- marcar condição como pendente;
- retornar ao titular antes de qualquer decisão irreversível.

Frase operacional sugerida:

> A proposta parece relevante, mas preciso conferir os efeitos patrimoniais, os prazos e as condições antes de manifestar concordância definitiva.

## 19. Critérios de publicação

Antes de publicar, verificar:

- instalação limpa;
- checagem de tipos;
- testes;
- build;
- saúde da infraestrutura;
- autenticação própria;
- passkey;
- recuperação;
- banco e migrações;
- armazenamento privado;
- auditoria;
- exportação;
- ausência de OAuth da plataforma;
- ausência de dependência de login do provedor;
- nenhuma abertura automática do 7z;
- nenhum envio automático de proposta;
- preservação das funções existentes.

A plataforma de publicação deve primeiro analisar compatibilidade. Não deve reescrever, simplificar ou migrar a aplicação sem aprovação expressa do titular.

## 20. Roteiro de implementação [NOVO v2 — concluído nesta versão]

As 5 fases do plano foram implementadas nesta entrega (detalhes técnicos completos em `CONCILIUM_linha_do_tempo_e_decisoes.md`, seções 9–10, e em `LEIA-ME_MUDANCAS_V2.md`):

1. ~~**Fase 0**~~ — enum de 9 estados da Mesa Formal, tabelas de checklist/parâmetros/transcrição, rotas reais. ✅
2. ~~**Fase 1**~~ — 5 estágios nomeados de cenário, com motivo e versão de migração. ✅
3. ~~**Fase 2**~~ — cofre com PBKDF2 e sal. ✅
4. ~~**Fase 3**~~ — atores interativos com voz. ✅
5. ~~**Fase 4**~~ — exportações completas (JSON/HTML/PDF) e índice comparativo com pesos. ✅

**Importante**: o código foi escrito e revisado com cuidado, mas eu não consegui rodar `npm install`/`npm run check`/`npm run test` neste sandbox (sem acesso à internet). **Rode os três antes de publicar** — veja `LEIA-ME_MUDANCAS_V2.md` para o que ainda ficou como próximo passo (conectar as camadas online/offline do matcher de transcrição a um provedor real, persistir o histórico do chat por ator, escrever testes de integração com banco mockado).

## 21. Anexo técnico — novas rotas desta versão [NOVO v2]

Para quem for integrar a interface a estas funcionalidades:

| Router | Uso |
|---|---|
| `checklist.list` / `checklist.create` / `checklist.updateState` | Checklist dinâmico por cenário (seção 9) |
| `checklist.setParameter` / `checklist.listParameters` | Parâmetros dinâmicos do cenário (seção 10) |
| `checklist.migrateStage` | Migração de estágio do cenário, com motivo obrigatório (seção 7) |
| `checklist.ingestTranscriptChunk` | Modo ao vivo e modo manual (ditado) — mesmo motor, muda só `source` (seção 9-A) |
| `checklist.listTranscriptReviews` / `checklist.resolveTranscriptReview` | Lista e confirma/descarta alertas gerados da transcrição |
| `actorChat.roles` / `actorChat.sendMessage` | Chat por ator anônimo, com nível de acesso já aplicado (seção 8-A) |
| `caseExport.buildBundle` | Gera síntese, checklist, histórico, e as três exportações (JSON, HTML, PDF em base64) (seção 17) |

Componente de interface pronto para os atores: `client/src/components/ActorRoster.tsx` (retratos clicáveis, sem nome próprio, com microfone e leitura em voz alta).

