# Concilium — checkpoint da fase 52

## Integração controlada do cofre com o banco
Foi criada a estrutura persistível para registros cifrados do cofre do titular.

### Tabela

`concilium_owner_secret_vault` armazena somente:

- identificador técnico;
- titular;
- nome da entrada;
- consumidor;
- valor cifrado;
- algoritmo;
- versão;
- datas;
- revogação.

O valor em claro não é armazenado.

### Operações protegidas

- listagem de metadados sem `encryptedValue`;
- gravação/rotação de registro cifrado;
- revogação por titular e nome;
- consulta protegida `listSecretVaultMetadata`.

A rotação atualiza o registro ativo do mesmo nome e reativa a entrada, sem criar duplicidade lógica.

### Migração

- `drizzle/0028_secret_vault.sql`.

## Limites

- não executada contra banco real;
- não conectada ao arquivo 7z;
- não recebe senha no chat;
- não distribui segredos para módulos;
- ainda depende de aprovação do plano e do adaptador de descriptografia em memória.
