# Convites por WhatsApp: fluxo privado e auditável

**Autor:** Manus AI  
**Data:** 20 de agosto de 2026  
**Status:** definição técnica para implementação futura no módulo de casos

## Decisão de produto

O Concilium deve permitir que a pessoa responsável configure o convite **antes** de compartilhá-lo: contexto do caso, papel de acesso e prazo de expiração. Depois disso, o botão **“Compartilhar pelo WhatsApp”** abre o WhatsApp com uma mensagem já preparada, mas deixa a escolha de um ou mais contatos inteiramente a cargo da pessoa usuária, dentro do próprio WhatsApp. Assim, o Concilium não solicita, exibe, armazena ou normaliza DDI, bandeira ou número de telefone.

O mecanismo recomendado no navegador é o link `https://wa.me/?text=<mensagem-codificada>`. A central oficial do WhatsApp informa que essa modalidade, sem número no endereço, preenche a mensagem e exibe a lista de contatos para envio. Em aplicativos móveis nativos, o equivalente adequado é a folha de compartilhamento do sistema operacional; a documentação do WhatsApp recomenda a extensão de compartilhamento como o caminho preferencial para compartilhar conteúdo de outro aplicativo em iOS. [1] [2]

> **Regra de privacidade:** a mensagem compartilhada não deve mencionar nome do caso, partes, documentos, valor, situação processual ou qualquer dado que permita inferir conteúdo jurídico. Ela contém somente uma chamada neutra e um link opaco de curta duração.

| Elemento configurado no Concilium | Finalidade | Deve aparecer no WhatsApp? |
|---|---|---|
| Papel de acesso | Define permissões após a aceitação, como parte principal, convidado, observador ou outro papel válido no caso. | Não por padrão; só se a equipe decidir que essa informação não é sensível. |
| Expiração | Limita o período para o convite ser iniciado e aceito. | Não é necessária na mensagem; é aplicada pelo servidor. |
| Caso e escopo | Vinculam o convite a um caso e a permissões mínimas. | Nunca. |
| Link opaco | Inicia a aceitação protegida sem revelar o contexto. | Sim. |

## Fluxo recomendado

O responsável seleciona o caso, o papel e a validade. O servidor cria um convite em estado `active`, associado a um identificador aleatório de alta entropia, guarda apenas o hash desse identificador e registra o evento de criação na auditoria. O cliente recebe um link curto, como `https://dominio-do-concilium/i/<segredo-opaco>`, e monta uma mensagem neutra:

> *Você recebeu um convite protegido para acessar o Concilium. Abra o link para conferir e confirmar sua participação: <link>*

Ao escolher **“Compartilhar pelo WhatsApp”**, o aplicativo abre o WhatsApp sem destinatário pré-definido. A pessoa usuária escolhe os contatos, inclusive contatos internacionais, e confirma o envio diretamente ali. O Concilium pode registrar que o compartilhamento foi **iniciado**, mas não deve afirmar que houve entrega, leitura ou aceitação: esses eventos não são observáveis por esse mecanismo.

Quando alguém abre o link, o servidor verifica expiração, revogação, uso anterior e integridade do segredo. Antes de revelar qualquer informação do caso, a pessoa precisa autenticar-se e satisfazer os controles exigidos pela arquitetura do Concilium, incluindo passkey como caminho preferencial e TOTP como alternativa. Apenas após a confirmação da identidade e das regras de elegibilidade o acesso é efetivamente concedido, e a auditoria registra a aceitação pelo identificador interno da conta, não pelo telefone.

```mermaid
sequenceDiagram
  participant R as Responsável
  participant C as Concilium
  participant W as WhatsApp
  participant P as Participante

  R->>C: Define caso, papel e validade
  C->>C: Cria convite opaco, limitado e auditável
  R->>W: Compartilha mensagem neutra com link
  R->>W: Escolhe um ou mais contatos
  W->>P: Entrega conforme ação do usuário
  P->>C: Abre o link
  C->>P: Exige autenticação e confirmação forte
  C->>C: Valida convite e política de elegibilidade
  C-->>P: Concede somente o escopo autorizado
```

## Tratamento de um ou mais contatos

Há uma limitação de segurança importante. Quando o responsável seleciona vários contatos no WhatsApp, todos recebem a **mesma** mensagem e o mesmo link. O Concilium não recebe a identidade desses contatos e, portanto, não pode emitir automaticamente um vínculo individual diferente para cada pessoa sem coletar telefone, e-mail ou outro identificador externo.

Para convites jurídicos sensíveis, um link compartilhável em massa **não deve** conceder acesso direto ao primeiro usuário que o abrir. Há duas opções de produto seguras, ordenadas por preferência.

| Cenário | Modelo recomendado | Resultado de segurança |
|---|---|---|
| Uma pessoa definida | Convite individual, aceito somente por uma conta previamente elegível ou confirmada por aprovação. | Maior precisão e trilha clara de responsabilidade. |
| Várias pessoas escolhidas no WhatsApp | Link de **solicitação de acesso**, com o mesmo papel e validade; cada destinatário se autentica e fica pendente de aprovação do responsável. | Não concede acesso só por possuir o link e não depende de telefone. |
| Vários destinatários já conhecidos no Concilium | O responsável cria convites individuais por conta e compartilha cada link no contato correspondente. | Permite escopos e revogações individuais. |

O segundo modelo é o adequado para a ideia de selecionar vários contatos no WhatsApp. Ele preserva a conveniência da seleção dentro do aplicativo, mas transforma o link em uma solicitação protegida, nunca em uma credencial de acesso. O responsável recebe no Concilium uma lista de solicitações com identidade autenticada para aprovar ou rejeitar. O prazo do convite continua a valer para a solicitação e para a eventual aprovação.

## Limites entre compartilhamento e API oficial

O compartilhamento iniciado pelo usuário não é uma integração de mensageria automatizada: o Concilium entrega conteúdo ao WhatsApp e a pessoa usuária escolhe destinatários e confirma o envio. Por isso, não há necessidade de conta empresarial, token da Meta, telefone do destinatário ou gestão de templates nesta fase.

Caso o produto futuramente passe a enviar mensagens automaticamente, o desenho muda. A Cloud API requer número comercial registrado para envio e recebimento, e mensagens enviadas fora da janela de atendimento exigem templates aprovados. Os exemplos oficiais de template também usam o campo individual `to`, com número de telefone do destinatário. [3] [4] Essa alternativa somente deve ser considerada após definir base legal, transparência, retenção, gestão de consentimento e contrato operacional compatíveis com a LGPD.

| Modalidade | Quem escolhe o contato | Dados pessoais tratados pelo Concilium | Capacidade de provar entrega | Indicação para o Concilium |
|---|---|---|---|---|
| Compartilhar no WhatsApp | Usuário, dentro do WhatsApp | Nenhum número ou DDI necessário. | Não; registra-se apenas a intenção de compartilhar. | **Primeira versão recomendada.** |
| Cloud API do WhatsApp | Sistema | Telefone internacional, consentimento e metadados de envio. | Retornos técnicos de mensageria, não aceitação jurídica. | Fase posterior, com avaliação de privacidade. |

## Controles mínimos para implementação

| Controle | Requisito técnico |
|---|---|
| Segredo do convite | Gerar token aleatório de alta entropia, armazenar somente o hash e nunca incluir identificadores do caso no URL. |
| Expiração e revogação | Verificar no servidor em toda abertura e aceitação; não depender de cronômetro do cliente. |
| Uso e autorização | Um convite individual deve ter uso único. O link de solicitação em grupo não concede acesso antes de aprovação explícita. |
| Autenticação | Exigir a política de MFA planejada antes de revelar dados ou criar vínculo de caso. |
| Auditoria | Registrar criação, compartilhamento iniciado, abertura, autenticação, solicitação, aprovação, aceite, expiração, revogação e falhas; não registrar conteúdo da mensagem nem número. |
| Limitação de abuso | Aplicar limitação de tentativas por token, conta e origem; invalidar o token após revogação ou aceite individual. |
| Segurança da página | Usar `Referrer-Policy: no-referrer`, não carregar recursos de terceiros na rota de convite e evitar título/metadados que revelem o caso. |

Esta especificação é técnica e deve ser revisada pela equipe de produto, segurança e privacidade antes de processar dados reais. Ela não constitui parecer jurídico.

## Referências

[1]: https://faq.whatsapp.com/5913398998672934 "WhatsApp Help Center — Como usar o recurso Chat Direct"
[2]: https://faq.whatsapp.com/425247423114725 "WhatsApp Help Center — Como criar link para o WhatsApp a partir de outro aplicativo"
[3]: https://developers.facebook.com/documentation/business-messaging/whatsapp/business-phone-numbers/phone-numbers "Meta for Developers — Números comerciais do WhatsApp"
[4]: https://developers.facebook.com/documentation/business-messaging/whatsapp/templates/overview "Meta for Developers — Fundamentos de templates do WhatsApp"
