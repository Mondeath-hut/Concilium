# Concilium — sincronização do banco no Manus

## Princípio

O banco do Manus deve ser tratado como infraestrutura de destino. Não copiar dados sensíveis diretamente para tabelas improvisadas e não alterar o esquema silenciosamente. A sincronização deve começar em banco de teste, com backup e plano de rollback.

## Sequência

1. Clonar o projeto e preservar o original.
2. Instalar dependências.
3. Configurar `DATABASE_URL` somente no secret manager.
4. Comparar `drizzle/schema.ts` com o banco de teste.
5. Gerar o diff de migrações.
6. Revisar especialmente `0019` a `0028`.
7. Aplicar em banco vazio ou cópia de teste.
8. Executar `pnpm check`, `pnpm test` e `pnpm build`.
9. Validar autenticação, auditoria, documentos, Estratégias, Laboratório e Arena.
10. Fazer backup e repetir em produção com janela de manutenção.

## Migrações críticas

- `0025_strategist_coordination.sql`: coordenação do Estrategista;
- `0026_strategy_arena_context_handoff.sql`: passagem segura para Arena;
- `0027_document_catalog_quarantine.sql`: catálogo e quarentena documental;
- `0028_secret_vault.sql`: metadados e registros cifrados do cofre.

## Regras de sincronização

- não executar `DROP`, truncamento ou reset contra produção;
- não importar conteúdo real antes de validar o esquema;
- preservar IDs e hashes quando a migração exigir rastreabilidade;
- validar índices, chaves únicas e tipos de data;
- registrar cada migração aplicada;
- testar rollback ou procedimento de restauração;
- não incluir `storageKey`, hashes de conteúdo ou texto documental em relatórios públicos sem necessidade.

## Critério de aceite

A sincronização só é considerada concluída quando houver relatório com: banco de destino, versão do esquema, migrações, testes, backup, rollback, divergências e aprovação humana.
