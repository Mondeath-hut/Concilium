# Proposta de estrutura para o memorial do caso

## Finalidade e controle de uso

Esta proposta organiza o material encontrado nos arquivos enviados em uma estrutura técnica revisável. Ela não importa anexos, não cria fatos no banco e não converte minutas ou sugestões de conversa em termos do acordo. Cada item só poderá ser registrado no Concilium após confirmação do titular, com a respectiva fonte e um status de revisão.

> **Nota de escopo.** O Concilium deverá registrar e organizar informações. A definição de tese, o conteúdo de minutas e a decisão de enviar, assinar ou protocolar documentos exigem a revisão de profissional jurídico habilitado.

## Camadas do memorial

| Camada | Objetivo | Fonte inicial possível | Estado proposto |
|---|---|---|---|
| Identificação do caso | Título interno, objetivo, partes com dados minimizados e status. | Confirmação do titular. | Pendente de confirmação. |
| Cronologia | Eventos, marcos e datas, sempre com referência ao documento ou conversa de origem. | Memorial de conversa e anexos. | Pendente de extração revisável. |
| Patrimônio e premissas | Itens patrimoniais, valor de referência, fonte, data e grau de confiança. | Propostas e evidências documentais. | Pendente de confirmação por item. |
| Negociação | Propostas, contrapropostas, premissas, alternativas e estado de cada ponto. | Conversas e minutas. | Pendente de confirmação; não implica aceitação. |
| Estratégia técnica | Hipóteses, objetivos de comunicação, riscos e evidências relacionadas. | Notas do titular. | Pendente de revisão e classificação. |
| Documentos e anexos | Metadados, vínculo com item do memorial e controle de acesso. | Arquivo recebido e futuras inclusões. | Não importar até seleção expressa. |
| Decisões do caso | Decisões efetivamente tomadas, justificativa, fonte e responsável. | Ações confirmadas pelo titular. | Vazio inicialmente. |

## Candidatos identificados para revisão

O memorial contém referências a uma negociação patrimonial em que o titular deseja comparar uma solução com pagamento programado e correção monetária contra uma alternativa de venda com liquidez incerta. Essas referências devem ser classificadas como **notas de estratégia de negociação**, e não como cláusulas, avaliação definitiva ou acordo aceito. O próprio material indica que parte do raciocínio seria usada na condução da negociação, sem necessariamente integrar a minuta.

O mesmo arquivo contém blocos extensos de arquitetura e de módulos genéricos da ACA/Concilium — por exemplo, contratos de módulo, biblioteca de cláusulas, motor documental e simulações. Esses blocos serão mantidos fora do memorial do caso e poderão apenas orientar a evolução técnica da plataforma. O Webbook/POCC, por sua vez, será restrito ao modelo de rastreabilidade: origem, classificação, confiança, vínculo e histórico de alteração.

## Módulos a habilitar somente após confirmação

| Módulo | Primeiro recorte seguro | Proteção indispensável |
|---|---|---|
| Visão Geral | Um caso confirmado e um resumo sem dados sensíveis desnecessários. | Sessão própria do titular e minimização de dados. |
| Memorial | Cronologia com fonte, categoria, confiança e status de revisão. | Trilhas de alteração e remoção lógica. |
| Patrimônio | Premissas e evidências de avaliação, sem tratar estimativas como fatos definitivos. | Fonte e data obrigatórias. |
| Negociação | Registro de propostas e pontos em aberto, sem envio automático. | Estado explícito e autorização por titular. |
| Estratégias | Notas privadas classificadas por hipótese, risco e evidência. | Acesso exclusivo do titular na fase atual. |
| Biblioteca | Metadados de documentos selecionados, sem upload antes da integração de armazenamento. | Armazenamento separado e autorização por caso. |

## Confirmações solicitadas antes da implementação

O titular deverá confirmar: o título interno do caso; quais fatos entram na cronologia; quais anexos devem ser armazenados; quais notas constituem estratégia; e quais valores ou condições podem constar em uma proposta. Nenhum valor, prazo, identificação de pessoa, bem, minuta ou evidência será criado automaticamente a partir do texto analisado.
