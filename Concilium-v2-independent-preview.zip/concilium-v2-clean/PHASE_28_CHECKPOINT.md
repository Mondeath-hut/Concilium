# Concilium — checkpoint da fase 28

## Síntese final do Estrategista → Arena
A síntese final agora é tratada como um artefato de transição, não como conclusão jurídica.

### Regras da síntese

- convergência entre IAs não equivale a consenso do titular;
- divergências, premissas e pontos cegos são preservados;
- teses controversas continuam visíveis com grau de incerteza;
- fontes confirmadas e fontes pendentes ficam separadas;
- riscos jurídicos, éticos e práticos não são fundidos em um único juízo;
- a síntese não escolhe automaticamente uma alternativa.

### Encaminhamento
O titular pode levar a síntese final ao Comitê de IA. O sistema cria uma avaliação de argumento vinculada a:

- síntese final;
- exploração do Laboratório;
- caso;
- origem do cenário.

A Arena recebe a síntese como conteúdo para nova rodada, mantendo a marcação de que ela ainda está `nao_verificado` e requer revisão humana.

## Persistência
- `sourceSynthesisId` em avaliações de argumentos;
- `drizzle/0023_strategy_synthesis_arena.sql`;
- função e rota `selectStrategySynthesisForArena`;
- botão `Levar síntese final à Arena` no Laboratório.

## Estado de validação
Prompts, vínculo, persistência e interface foram preparados. Ainda não houve build, migração ou execução contra banco/provedor reais.
