# Concilium — checkpoint da fase 6

## Avanço realizado
A biblioteca começou a receber o fluxo de anexos protegidos:

- listagem de anexos vinculados ao caso;
- upload controlado por sessão titular;
- limite inicial de 20 MB por arquivo;
- armazenamento por chave privada e URL assinada;
- hash SHA-256 do conteúdo;
- tamanho e tipo MIME registrados;
- abertura somente após validar titularidade e caso;
- interface para selecionar, armazenar e abrir anexo privado.

O modelo operacional também passou a registrar criação de estratégias personalizadas e propostas no mesmo núcleo de dados.

## Segurança preservada
- o arquivo não é publicado em rota estática;
- a chave de armazenamento não aparece na listagem da interface;
- o anexo fica associado ao caso e ao usuário operacional vinculado;
- a senha de um pacote `.7z` não é armazenada;
- arquivos reais ainda não foram importados.

## Observação técnica
O upload atual é a primeira camada de armazenamento protegido. O próximo refinamento será adicionar o cofre criptográfico por documento/pacote, com desbloqueio por sessão e passkey/biometria, antes da importação dos documentos sensíveis.

## Próximo marco
Implementar contraproposta com participante autorizado e integrar os documentos/anexos à mesa de negociação, mantendo a V2 como apresentação e a V1 como regra operacional.
