# Concilium — checkpoint da fase 34

## Pacote neutro de resposta do Bibliotecário
Foi criado um formato intermediário para que os resultados não retornem como uma lista sem interpretação de risco.

Cada item agora pode ser classificado como:

- `primary_source`;
- `jurisprudence`;
- `clause_model`;
- `secondary_material`.

E recebe tratamento:

- `candidate_foundation`;
- `non_normative_model`;
- `needs_verification`;
- `not_current`.

Cada item também leva:

- limitação explícita;
- pergunta para a próxima etapa;
- indicação de que a fonte ainda precisa ser lida e confrontada.

## Aplicação ao teste de alimentos
O pacote não poderá afirmar que compras de supermercado substituem alimentos. Ele poderá apenas recuperar material sobre pagamento direto, prestação in natura, despesas da residência, prova, formalização, limites e fontes contrárias.

## Interface
A Biblioteca exibe o pacote neutro em bloco separado dos resultados brutos, permitindo distinguir:

1. o que foi encontrado;
2. como deve ser tratado;
3. qual pergunta segue para o Estrategista.

## Arquivos

- `shared/librarianWorkflow.ts`;
- `shared/knowledgeService.ts`;
- `server/routers/knowledge.ts`;
- `client/src/pages/OwnerWorkspace.tsx`;
- `shared/librarianWorkflow.test.ts`.

## Estado
Formato, classificação e interface preparados. Ainda não há retorno de fonte real porque o Knowledge Service permanece desconectado.
